import { jwtDecode } from "jwt-decode";
import { useEffect, useState } from "react";

interface JWTPayload {
    id: string;
    role: string;
    authorization: Array<{ module: string; accessLevel: string[]; _id?: string }>;
    iat?: number;
    exp?: number;
}

export const useAuthorization = () => {
    const [authorizationList, setAuthorizationList] = useState<Array<{ module: string; accessLevel: string[] }>>([]);

    //Check user authorization
    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) return;

        try {
            const decoded = jwtDecode<JWTPayload>(token);

            if (decoded.authorization && decoded.authorization.length > 0) {
                const cleanAuth = decoded.authorization.map(({ module, accessLevel }) => ({
                    module,
                    accessLevel
                }));

                setAuthorizationList(cleanAuth);
            }
        } catch (error) {
            console.error('Invalid token', error);
        }
    }, [])

    const hasAccess = (module: string, accessLevel: string) => {
        return authorizationList.some(
            (auth) =>
                auth.module === module &&
                auth.accessLevel.includes(accessLevel));
    }

    return { authorizationList, hasAccess };
}