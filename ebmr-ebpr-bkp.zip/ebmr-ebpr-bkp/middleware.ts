import { NextRequest, NextResponse } from "next/server";

export function middleware(req:NextRequest){
    const token = req.cookies.get('token')?.value||null
const publicPaths = ['/', '/api/auth']

    const {pathname} = req.nextUrl

    //Public Routes
    if(publicPaths.includes(pathname)){
        return NextResponse.next()
    }

    //Private Routes
    if(!token){
        return NextResponse.redirect(new URL('/', req.url))
    }

}
export const config = {
  matcher: ["/admin/:path", "/user/:path"], // middleware active routes
};
