import connectToDatabase from "@/lib/db";
import ShiftConfig from "@/lib/models/ShiftConfig";
import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import { JWT_SECRET } from "@/lib/auth";

type AdminTokenPayload = {
  id: string;
  role: string;
  name: string;
};

type VerifyAdminResult =
  | { decoded: AdminTokenPayload; error?: never; status?: never }
  | { error: string; status: number; decoded?: never };

async function verifyAdmin(req: NextRequest): Promise<VerifyAdminResult> {
  const authHeader = req.headers.get("authorization");
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return { error: "Unauthorized", status: 401 };
  }
  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as AdminTokenPayload;
    if (decoded.role !== "admin") {
      return { error: "Forbidden", status: 403 };
    }
    return { decoded };
  } catch {
    return { error: "Invalid or expired token", status: 401 };
  }
}

// GET all shift configs
export async function GET(req: NextRequest) {
  try {
    const auth = await verifyAdmin(req);
    if ("error" in auth) {
      return NextResponse.json(
        { success: false, message: auth.error },
        { status: auth.status }
      );
    }

    await connectToDatabase();
    const configs = await ShiftConfig.find().sort({ createdAt: -1 });

    return NextResponse.json({ success: true, configs }, { status: 200 });
  } catch (error: unknown) {
    console.error("Error fetching shift configs:", error);
    return NextResponse.json(
      { success: false, message: "Internal server error" },
      { status: 500 }
    );
  }
}

// POST create new shift config
export async function POST(req: NextRequest) {
  try {
    const auth = await verifyAdmin(req);
    if ("error" in auth) {
      return NextResponse.json(
        { success: false, message: auth.error },
        { status: auth.status }
      );
    }

    await connectToDatabase();
    const data = await req.json();
    const { name, numberOfShifts, hoursPerShift, shiftNames, startTime } = data;

    if (!name || !numberOfShifts || !hoursPerShift) {
      return NextResponse.json(
        {
          success: false,
          message: "Name, number of shifts, and hours per shift are required",
        },
        { status: 400 }
      );
    }

    const totalHours = numberOfShifts * hoursPerShift;
    if (totalHours > 24) {
      return NextResponse.json(
        {
          success: false,
          message: `Total hours (${totalHours}) exceeds 24 hours. Please adjust shifts or hours.`,
        },
        { status: 400 }
      );
    }

    const config = await ShiftConfig.create({
      name,
      numberOfShifts,
      hoursPerShift,
      shiftNames: shiftNames || [
        "Morning",
        "Afternoon",
        "Evening",
        "Night",
      ],
      startTime: startTime || "06:00",
      lastModifiedBy: auth.decoded.name || "Admin",
    });

    return NextResponse.json(
      {
        success: true,
        message: "Shift configuration created successfully",
        config,
      },
      { status: 201 }
    );
  } catch (error: unknown) {
    console.error("Error creating shift config:", error);
    return NextResponse.json(
      { success: false, message: "Internal server error" },
      { status: 500 }
    );
  }
}

// PUT update existing shift config
export async function PUT(req: NextRequest) {
  try {
    const auth = await verifyAdmin(req);
    if ("error" in auth) {
      return NextResponse.json(
        { success: false, message: auth.error },
        { status: auth.status }
      );
    }

    await connectToDatabase();
    const data = await req.json();
    const { id, name, numberOfShifts, hoursPerShift, shiftNames, startTime } = data;

    if (!id) {
      return NextResponse.json(
        { success: false, message: "Shift config ID is required" },
        { status: 400 }
      );
    }

    const existing = await ShiftConfig.findById(id);
    if (!existing) {
      return NextResponse.json(
        { success: false, message: "Shift config not found" },
        { status: 404 }
      );
    }

    const finalNumberOfShifts = numberOfShifts ?? existing.numberOfShifts;
    const finalHoursPerShift = hoursPerShift ?? existing.hoursPerShift;
    const totalHours = finalNumberOfShifts * finalHoursPerShift;
    if (totalHours > 24) {
      return NextResponse.json(
        {
          success: false,
          message: `Total hours (${totalHours}) exceeds 24 hours. Please adjust shifts or hours.`,
        },
        { status: 400 }
      );
    }

    if (name !== undefined) existing.name = name;
    if (numberOfShifts !== undefined) existing.numberOfShifts = numberOfShifts;
    if (hoursPerShift !== undefined) existing.hoursPerShift = hoursPerShift;
    if (shiftNames !== undefined) existing.shiftNames = shiftNames;
    if (startTime !== undefined) existing.startTime = startTime;
    existing.lastModifiedBy = auth.decoded.name || "Admin";

    await existing.save();

    return NextResponse.json(
      {
        success: true,
        message: "Shift configuration updated successfully",
        config: existing,
      },
      { status: 200 }
    );
  } catch (error: unknown) {
    console.error("Error updating shift config:", error);
    return NextResponse.json(
      { success: false, message: "Internal server error" },
      { status: 500 }
    );
  }
}

// DELETE shift config
export async function DELETE(req: NextRequest) {
  try {
    const auth = await verifyAdmin(req);
    if ("error" in auth) {
      return NextResponse.json(
        { success: false, message: auth.error },
        { status: auth.status }
      );
    }

    await connectToDatabase();
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { success: false, message: "Shift config ID is required" },
        { status: 400 }
      );
    }

    const deleted = await ShiftConfig.findByIdAndDelete(id);
    if (!deleted) {
      return NextResponse.json(
        { success: false, message: "Shift config not found" },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { success: true, message: "Shift configuration deleted successfully" },
      { status: 200 }
    );
  } catch (error: unknown) {
    console.error("Error deleting shift config:", error);
    return NextResponse.json(
      { success: false, message: "Internal server error" },
      { status: 500 }
    );
  }
}