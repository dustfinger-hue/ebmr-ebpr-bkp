import connectToDatabase from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import { JWT_SECRET } from "@/lib/auth";
import RoleBasedSigning from "@/lib/models/RoleBasedSigning";

type AdminTokenPayload = {
  id: string;
  role: string;
  name: string;
};

type VerifyAdminResult =
  | { decoded: AdminTokenPayload; error?: never; status?: never }
  | { error: string; status: number; decoded?: never };

async function verifyAdmin(req: NextRequest): Promise<VerifyAdminResult> {
  const authHeader = req.headers.get("authorization");
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return { error: "Unauthorized", status: 401 };
  }
  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as AdminTokenPayload;
    if (decoded.role !== "admin") {
      return { error: "Forbidden", status: 403 };
    }
    return { decoded };
  } catch {
    return { error: "Invalid or expired token", status: 401 };
  }
}

export async function GET(req: NextRequest) {
  await connectToDatabase();
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json(
        { success: false, message: "Unauthorized" },
        { status: 401 },
      );
    }

    const token = authHeader.split(" ")[1];
    try {
      jwt.verify(token, JWT_SECRET);
    } catch {
      return NextResponse.json(
        { success: false, message: "Invalid token" },
        { status: 401 },
      );
    }

    const modules = await RoleBasedSigning.find({})
      .sort({ updatedAt: -1 })
      .lean();
    return NextResponse.json({ success: true, modules }, { status: 200 });
  } catch (error) {
    console.error("Error fetching role based signing modules:", error);
    return NextResponse.json(
      { success: false, message: "Failed to fetch modules" },
      { status: 500 },
    );
  }
}

export async function POST(req: NextRequest) {
  await connectToDatabase();
  try {
    const auth = await verifyAdmin(req);
    if (auth.error) {
      return NextResponse.json(
        { success: false, message: auth.error },
        { status: auth.status || 401 },
      );
    }

    const { moduleName, signRequired, status, roles } = await req.json();

    if (!moduleName?.trim()) {
      return NextResponse.json(
        { success: false, message: "Module name is required" },
        { status: 400 },
      );
    }
    if (!signRequired || signRequired < 1) {
      return NextResponse.json(
        { success: false, message: "Sign required must be at least 1" },
        { status: 400 },
      );
    }
    if (!roles || roles.length === 0) {
      return NextResponse.json(
        { success: false, message: "At least one role is required" },
        { status: 400 },
      );
    }

    // Validate role entries
    for (const role of roles) {
      if (
        !role.userRole?.trim() ||
        !role.levelOfAuthorization?.trim() ||
        !role.sequence
      ) {
        return NextResponse.json(
          {
            success: false,
            message: "Each role needs userRole, levelOfAuthorization, and sequence",
          },
          { status: 400 },
        );
      }
    }

    // Check for duplicate module
    const existing = await RoleBasedSigning.findOne({
      moduleName: { $regex: new RegExp(`^${moduleName}$`, "i") },
    }).lean();
    if (existing) {
      return NextResponse.json(
        { success: false, message: "A module with this name already exists" },
        { status: 409 },
      );
    }

    const newModule = await RoleBasedSigning.create({
      moduleName: moduleName.trim(),
      signRequired,
      status: status || "active",
      roles: roles.map((r: any) => ({
        userRole: r.userRole.trim(),
        levelOfAuthorization: r.levelOfAuthorization.trim(),
        sequence: r.sequence,
      })),
      lastModifiedBy: auth.decoded?.name || "Admin",
    });

    return NextResponse.json(
      {
        success: true,
        message: "Module added successfully",
        module: newModule,
      },
      { status: 201 },
    );
  } catch (error) {
    console.error("Error adding role based signing module:", error);
    return NextResponse.json(
      { success: false, message: "Failed to add module" },
      { status: 500 },
    );
  }
}

export async function PUT(req: NextRequest) {
  await connectToDatabase();
  try {
    const auth = await verifyAdmin(req);
    if (auth.error) {
      return NextResponse.json(
        { success: false, message: auth.error },
        { status: auth.status || 401 },
      );
    }

    const { id, moduleName, signRequired, status, roles } = await req.json();

    if (!id) {
      return NextResponse.json(
        { success: false, message: "Module ID is required" },
        { status: 400 },
      );
    }
    if (!moduleName?.trim()) {
      return NextResponse.json(
        { success: false, message: "Module name is required" },
        { status: 400 },
      );
    }
    if (!signRequired || signRequired < 1) {
      return NextResponse.json(
        { success: false, message: "Sign required must be at least 1" },
        { status: 400 },
      );
    }
    if (!roles || roles.length === 0) {
      return NextResponse.json(
        { success: false, message: "At least one role is required" },
        { status: 400 },
      );
    }

    const updated = await RoleBasedSigning.findByIdAndUpdate(
      id,
      {
        moduleName: moduleName.trim(),
        signRequired,
        status: status || "active",
        roles: roles.map((r: any) => ({
          userRole: r.userRole.trim(),
          levelOfAuthorization: r.levelOfAuthorization.trim(),
          sequence: r.sequence,
        })),
        lastModifiedBy: auth.decoded?.name || "Admin",
      },
      { new: true },
    );

    if (!updated) {
      return NextResponse.json(
        { success: false, message: "Module not found" },
        { status: 404 },
      );
    }

    return NextResponse.json(
      {
        success: true,
        message: "Module updated successfully",
        module: updated,
      },
      { status: 200 },
    );
  } catch (error) {
    console.error("Error updating role based signing module:", error);
    return NextResponse.json(
      { success: false, message: "Failed to update module" },
      { status: 500 },
    );
  }
}

export async function DELETE(req: NextRequest) {
  await connectToDatabase();
  try {
    const auth = await verifyAdmin(req);
    if (auth.error) {
      return NextResponse.json(
        { success: false, message: auth.error },
        { status: auth.status || 401 },
      );
    }

    const { id } = await req.json();

    if (!id) {
      return NextResponse.json(
        { success: false, message: "Module ID is required" },
        { status: 400 },
      );
    }

    const deleted = await RoleBasedSigning.findByIdAndDelete(id);
    if (!deleted) {
      return NextResponse.json(
        { success: false, message: "Module not found" },
        { status: 404 },
      );
    }

    return NextResponse.json(
      { success: true, message: "Module deleted successfully" },
      { status: 200 },
    );
  } catch (error) {
    console.error("Error deleting role based signing module:", error);
    return NextResponse.json(
      { success: false, message: "Failed to delete module" },
      { status: 500 },
    );
  }
}