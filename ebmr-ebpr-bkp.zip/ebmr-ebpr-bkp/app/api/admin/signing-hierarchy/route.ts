import connectToDatabase from "@/lib/db";
import SigningHierarchy from "@/lib/models/SigningHierarchy";
import AuditLog from "@/lib/models/UserAuditLog";
import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import { JWT_SECRET } from "@/lib/auth";

type AdminTokenPayload = {
    id: string;
    role: string;
    name: string;
};

type VerifyAdminResult =
    | { decoded: AdminTokenPayload; error?: never; status?: never }
    | { error: string; status: number; decoded?: never };

type IncomingAuthorizedPerson = {
    userId?: string;
    name?: string;
    designation?: string;
    department?: string;
    authorizationLevel?: string;
    authorizationSequence?: number;
};

function getIpAddress(req: NextRequest) {
    const forwarded = req.headers.get("x-forwarded-for");
    return forwarded
        ? forwarded.split(",")[0]
        : req.headers.get("x-real-ip") || "Unknown";
}

function pickFields(data: Record<string, unknown>, fields: string[]) {
    return Object.fromEntries(
        Object.entries(data).filter(([key]) => fields.includes(key))
    );
}

function toTitleCase(value: string) {
    return value
        .trim()
        .toLowerCase()
        .replace(/\b\w/g, (char) => char.toUpperCase());
}

function normalizeAuthorizedPersons(authorizedPersons: IncomingAuthorizedPerson[] = []) {
    return authorizedPersons.map((person, index) => ({
        userId: person.userId,
        name: person.name,
        designation: person.designation,
        department: person.department,
        authorizationLevel: toTitleCase(person.authorizationLevel || ""),
        authorizationSequence: person.authorizationSequence ?? (index + 1),
    }));
}

function hasInvalidAuthorizedPerson(authorizedPersons: ReturnType<typeof normalizeAuthorizedPersons>) {
    return authorizedPersons.some(
        (person) =>
            !person.userId ||
            !person.name ||
            !person.designation ||
            !person.department ||
            !person.authorizationLevel
    );
}

async function verifyAdmin(req: NextRequest): Promise<VerifyAdminResult> {
    const authHeader = req.headers.get("authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return { error: "Unauthorized", status: 401 };
    }
    const token = authHeader.split(" ")[1];
    try {
        const decoded = jwt.verify(token, JWT_SECRET) as AdminTokenPayload;
        if (decoded.role !== "admin") {
            return { error: "Forbidden", status: 403 };
        }
        return { decoded };
    } catch {
        return { error: "Invalid or expired token", status: 401 };
    }
}

export async function GET(req: NextRequest) {
    try {
        const auth = await verifyAdmin(req);
        if ("error" in auth) {
            return NextResponse.json({ success: false, message: auth.error }, { status: auth.status });
        }

        await connectToDatabase();
        const modules = await SigningHierarchy.find().sort({ createdAt: -1 });

        return NextResponse.json({ success: true, modules }, { status: 200 });
    } catch (error: unknown) {
        console.error("Error fetching signing hierarchy:", error);
        return NextResponse.json(
            { success: false, message: "Internal server error" },
            { status: 500 }
        );
    }
}

export async function POST(req: NextRequest) {
    try {
        const auth = await verifyAdmin(req);
        if ("error" in auth) {
            return NextResponse.json({ success: false, message: auth.error }, { status: auth.status });
        }

        await connectToDatabase();
        const data = await req.json();
        const { module, signRequired, authorizedPersons, status } = data;
        const normalizedAuthorizedPersons = normalizeAuthorizedPersons(authorizedPersons);

        if (!module || !signRequired) {
            return NextResponse.json(
                { success: false, message: "Module name and sign required are mandatory" },
                { status: 400 }
            );
        }

        if (normalizedAuthorizedPersons.length === 0 || hasInvalidAuthorizedPerson(normalizedAuthorizedPersons)) {
            return NextResponse.json(
                { success: false, message: "Authorized persons with authorization level are mandatory" },
                { status: 400 }
            );
        }

        const existing = await SigningHierarchy.findOne({ module });
        if (existing) {
            return NextResponse.json(
                { success: false, message: "Module with this name already exists" },
                { status: 409 }
            );
        }

        const newModule = await SigningHierarchy.create({
            module,
            signRequired,
            authorizedPersons: normalizedAuthorizedPersons,
            status: status || "active",
            lastModifiedBy: auth.decoded.name || "Admin",
        });

        await AuditLog.create({
            userId: auth.decoded.id,
            userRole: auth.decoded.role,
            moduleName: "Signing Hierarchy",
            recordId: newModule._id,
            action: "CREATE",
            oldData: null,
            newData: newModule.toObject(),
            changedFields: ["module", "signRequired", "authorizedPersons", "status", "lastModifiedBy"],
            changeReason: null,
            ipAddress: getIpAddress(req),
            userAgent: req.headers.get("user-agent") || "Unknown",
        });

        return NextResponse.json(
            { success: true, message: "Signing module created successfully", module: newModule },
            { status: 201 }
        );
    } catch (error: unknown) {
        console.error("Error creating signing module:", error);
        return NextResponse.json(
            { success: false, message: "Internal server error" },
            { status: 500 }
        );
    }
}

export async function PUT(req: NextRequest) {
    try {
        const auth = await verifyAdmin(req);
        if ("error" in auth) {
            return NextResponse.json({ success: false, message: auth.error }, { status: auth.status });
        }

        await connectToDatabase();
        const data = await req.json();
        const { id, module, signRequired, authorizedPersons, status } = data;
        const normalizedAuthorizedPersons = authorizedPersons
            ? normalizeAuthorizedPersons(authorizedPersons)
            : undefined;

        if (!id) {
            return NextResponse.json(
                { success: false, message: "Module ID is required" },
                { status: 400 }
            );
        }

        if (normalizedAuthorizedPersons && hasInvalidAuthorizedPerson(normalizedAuthorizedPersons)) {
            return NextResponse.json(
                { success: false, message: "Authorized persons with authorization level are mandatory" },
                { status: 400 }
            );
        }

        const existing = await SigningHierarchy.findById(id);
        if (!existing) {
            return NextResponse.json(
                { success: false, message: "Module not found" },
                { status: 404 }
            );
        }

        const oldModule = existing.toObject();
        const changedFields: string[] = [];
        const requestedUpdates = { module, signRequired, authorizedPersons: normalizedAuthorizedPersons, status };

        Object.entries(requestedUpdates).forEach(([key, value]) => {
            if (value !== undefined && JSON.stringify(value) !== JSON.stringify(oldModule[key])) {
                changedFields.push(key);
            }
        });

        const lastModifiedBy = auth.decoded.name || "Admin";
        if (lastModifiedBy !== oldModule.lastModifiedBy) {
            changedFields.push("lastModifiedBy");
        }

        if (module) existing.module = module;
        if (signRequired) existing.signRequired = signRequired;
        if (normalizedAuthorizedPersons) existing.authorizedPersons = normalizedAuthorizedPersons;
        if (status) existing.status = status;
        existing.lastModifiedBy = lastModifiedBy;

        await existing.save();

        if (changedFields.length > 0) {
            await AuditLog.create({
                userId: auth.decoded.id,
                userRole: auth.decoded.role,
                moduleName: "Signing Hierarchy",
                recordId: existing._id,
                action: "UPDATE",
                oldData: pickFields(oldModule, changedFields),
                newData: pickFields(existing.toObject(), changedFields),
                changedFields,
                changeReason: null,
                ipAddress: getIpAddress(req),
                userAgent: req.headers.get("user-agent") || "Unknown",
            });
        }

        return NextResponse.json(
            { success: true, message: "Module updated successfully", module: existing },
            { status: 200 }
        );
    } catch (error: unknown) {
        console.error("Error updating signing module:", error);
        return NextResponse.json(
            { success: false, message: "Internal server error" },
            { status: 500 }
        );
    }
}

export async function DELETE(req: NextRequest) {
    try {
        const auth = await verifyAdmin(req);
        if ("error" in auth) {
            return NextResponse.json({ success: false, message: auth.error }, { status: auth.status });
        }

        await connectToDatabase();
        const { searchParams } = new URL(req.url);
        const id = searchParams.get("id");

        if (!id) {
            return NextResponse.json(
                { success: false, message: "Module ID is required" },
                { status: 400 }
            );
        }

        const deleted = await SigningHierarchy.findByIdAndDelete(id);
        if (!deleted) {
            return NextResponse.json(
                { success: false, message: "Module not found" },
                { status: 404 }
            );
        }

        await AuditLog.create({
            userId: auth.decoded.id,
            userRole: auth.decoded.role,
            moduleName: "Signing Hierarchy",
            recordId: deleted._id,
            action: "DELETE",
            oldData: deleted.toObject(),
            newData: null,
            changedFields: ["module", "signRequired", "authorizedPersons", "status", "lastModifiedBy"],
            changeReason: null,
            ipAddress: getIpAddress(req),
            userAgent: req.headers.get("user-agent") || "Unknown",
        });

        return NextResponse.json(
            { success: true, message: "Module deleted successfully" },
            { status: 200 }
        );
    } catch (error: unknown) {
        console.error("Error deleting signing module:", error);
        return NextResponse.json(
            { success: false, message: "Internal server error" },
            { status: 500 }
        );
    }
}
