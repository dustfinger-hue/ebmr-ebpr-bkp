import connectToDatabase from "@/lib/db"
import User from "@/lib/models/User"
import { NextRequest, NextResponse } from "next/server"
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken';
import { JWT_SECRET } from "@/lib/auth";
import { getNextEmployeeId } from "@/lib/utils/employeeID";


export async function POST(req: NextRequest) {
    try {
        await connectToDatabase()
        const authHeader = req.headers.get('authorization')

        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            )
        }

        const token = authHeader.split(' ')[1]
        let decoded
        try {
            decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string }
        } catch (error) {
            console.error('Error decoding token:', error)
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            )
        }

        if (decoded.role !== 'admin') {
            return NextResponse.json(
                { success: false, message: 'Forbidden' },
                { status: 403 }
            )
        }
        const { fullName, email, password, role, department, designation } = await req.json()
        if (!fullName || !email || !password || !role || !department || !designation) {
            return NextResponse.json(
                { success: false, message: 'Missing required fields' },
                { status: 400 }
            )
        }

        const existingUser = await User.findOne({ email })
        if (existingUser) {
            return NextResponse.json(
                { success: false, message: 'Email already exists' },
                { status: 409 })
        }

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        const employeeId = await getNextEmployeeId()

        await User.create({
            fullName,
            email,
            password: hashedPassword,
            employeeId,
            role,
            department,
            designation,
        })
        return NextResponse.json(
            {
                success: true,
                message: 'User created successfully!'
            },
            { status: 201 }
        )

    } catch (error: any) {
        console.error('Error creating user:', error)
        return NextResponse.json(
            { success: false, message: 'Internal server error' },
            { status: 500 })
    }
}

export async function GET(req: NextRequest) {
    try {
        await connectToDatabase()
        const authHeader = req.headers.get('authorization')
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            )
        }
        const token = authHeader.split(' ')[1]
        let decoded
        try {
            decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string }
        } catch (error) {
            console.error('Error decoding token:', error)
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            )
        }
        if (decoded.role !== 'admin') {
            return NextResponse.json(
                { success: false, message: 'Forbidden' },
                { status: 403 }
            )
        }

        // Get type parameter from query string
        const url = new URL(req.url)
        const type = url.searchParams.get('type')||''
        const id = url.searchParams.get('id') || ''

        let users
        if (type === 'detailed') {
            // Return complete user data for detailed view
            users = await User.findById(id).select('-password')
        } else {
            // Return minimal data for list view (better performance)
            users = await User.find().select('fullName email role department designation status lastLogin')
        }

        return NextResponse.json(
            { success: true, message: 'Users fetched successfully', users },
            { status: 200 }
        )
    } catch (error: any) {
        console.error('Error fetching users:', error)
        return NextResponse.json(
            { success: false, message: 'Internal server error' },
            { status: 500 })
    }
}

export async function PUT(req: NextRequest) {
    try {
        await connectToDatabase()
        const authHeader = req.headers.get('authorization')

        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            )
        }

        const token = authHeader.split(' ')[1]
        let decoded
        try {
            decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string }
        } catch (error) {
            console.error('Error decoding token:', error)
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            )
        }

        if (decoded.role !== 'admin') {
            return NextResponse.json(
                { success: false, message: 'Forbidden' },
                { status: 403 }
            )
        }

        const data = await req.json()
        const { id, ...updateFields } = data

        if (!id) {
            return NextResponse.json({ success: false, message: 'User ID is required' }, { status: 400 });
        }

        const user = await User.findById(id)

        if (!user) {
            return NextResponse.json(
                { success: false, message: 'User not found' },
                { status: 404 }
            )
        }

        // Update the user with the provided data
        Object.keys(updateFields).forEach(key => {
            if (updateFields[key] !== undefined) {
                user[key] = updateFields[key]
            }
        })
        await user.save();

        return NextResponse.json(
            { success: true, message: 'User updated successfully!' },
            { status: 200 }
        )


    } catch (error: any) {
        console.error('Error updating user:', error)
        return NextResponse.json(
            { success: false, message: 'Internal server error' },
            { status: 500 })
    }
}