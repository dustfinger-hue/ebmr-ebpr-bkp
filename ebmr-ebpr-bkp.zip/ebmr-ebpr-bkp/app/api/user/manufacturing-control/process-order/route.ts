import connectToDatabase from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import jwt from 'jsonwebtoken';
import { JWT_SECRET } from "@/lib/auth";
import { generateProcessOrderCode } from "@/lib/utils/generateCode";
import ProcessOrder from "@/lib/models/ProcessOrder";
import AuditLog from "@/lib/models/UserAuditLog";
import BatchTracker from "@/lib/models/BatchTracker";

export async function POST(req: NextRequest) {
    await connectToDatabase()
    try {
        //Check Auth
        const authHeader = req.headers.get('authorization')
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            )
        }
        const token = authHeader.split(' ')[1]
        let decoded
        try {
            decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string; authorization: Array<{ module: string; accessLevel: string[] }> }
        } catch (error) {
            console.error('Error decoding token:', error)
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            )
        }

        // Check if the user has the required authorization level
        const hasAccess = decoded.authorization?.some(
            (auth) =>
                auth.module === 'Process Order' &&
                auth.accessLevel.includes("create")
        )
        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            )
        }
        const body = await req.json()

        const {
            productCode,
            productName,
            bomCode,
            bomVersion,
            batchSizeSemifinished,
            bulkSize,
            uom,
            bulkUom,
            plannedStartDate,
            plannedEndDate,
            status,
            remarks,
            manufacturingFacility,
        } = body;

        if (!productCode || !productName || !bomCode || !batchSizeSemifinished || !bulkSize || !uom || !bulkUom || !plannedStartDate || !plannedEndDate || !status) {
            return NextResponse.json(
                { success: false, message: "Missing required fields" },
                { status: 400 }
            );
        }

        // Generate Process Order Code
        const prefix = 'POM';
        const processOrderCode = await generateProcessOrderCode(prefix)

        const processOrder = await ProcessOrder.create({
            ...body,
            processOrderCode,
            createdBy: decoded.id,
        })

        // Create Batch Tracker record
        await BatchTracker.create({
            processOrderId: processOrder._id,
        })

        // 🌍 Get IP properly
        const forwarded = req.headers.get("x-forwarded-for");
        const ipAddress = forwarded
            ? forwarded.split(",")[0]
            : req.headers.get("x-real-ip") || "Unknown";

        //Create audit log
        await AuditLog.create({
            userId: decoded.id,
            userRole: decoded.role,
            moduleName: 'Process Order',
            recordId: processOrder._id,
            action: 'CREATE',
            oldData: null,
            newData: processOrder.toObject(),
            changedFields: Object.keys(body),
            changeReason: null,
            ipAddress,
            userAgent: req.headers.get('user-agent') || "Unknown",
        })

        return NextResponse.json(
            {
                success: true, message: `Process Order ${processOrder.processOrderCode} created successfully!`,
                processOrderCode: processOrder.processOrderCode
            },
            { status: 201 }
        )
    } catch (error) {
        console.error('Error creating process order:', error)
        return NextResponse.json(
            { success: false, message: 'Error creating process order' },
            { status: 500 }
        )
    }
}

export async function GET(req: NextRequest) {
    await connectToDatabase()
    try {
        //Check Auth
        const authHeader = req.headers.get('authorization')
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            )
        }
        const token = authHeader.split(' ')[1]
        let decoded
        try {
            decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string; authorization: Array<{ module: string; accessLevel: string[] }> }
        } catch (error) {
            console.error('Error decoding token:', error)
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            )
        }

        // Check if the user has the required authorization level
        const hasAccess = decoded.authorization?.some(
            (auth) =>
                auth.module === 'Process Order' &&
                auth.accessLevel.includes("read")
        )
        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            )
        }

        // Get query params
        const { searchParams } = new URL(req.url)

        const id = searchParams.get('id') || ''
        const page = parseInt(searchParams.get('page') || "1")
        const limit = parseInt(searchParams.get('limit') || '10')
        const search = searchParams.get('search') || ''
        const statusFilter = searchParams.get('status') || ''

        // If ID is provided, fetch single record
        if (id) {
            const data = await ProcessOrder.findById(id).lean()
            if (!data) {
                return NextResponse.json(
                    { success: false, message: 'Process Order not found' },
                    { status: 404 }
                )
            }
            return NextResponse.json(
                { success: true, data },
                { status: 200 }
            )
        }

        const skip = (page - 1) * limit

        //search filter
        let filter: any = {}
        if (search) {
            filter = {
                $or: [
                    { productCode: { $regex: search, $options: 'i' } },
                    { productName: { $regex: search, $options: 'i' } },
                    { processOrderCode: { $regex: search, $options: 'i' } }
                ]
            }
        }
        if (statusFilter) {
            const statuses = statusFilter.split(',').map(s => s.trim()).filter(Boolean)
            if (statuses.length === 1) {
                filter.status = statuses[0]
            } else if (statuses.length > 1) {
                filter.status = { $in: statuses }
            }
        }

        const data = await ProcessOrder.find(filter)
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit)
            .lean()

        const total = await ProcessOrder.countDocuments(filter)

        return NextResponse.json(
            {
                success: true,
                total,
                page,
                limit,
                data
            },
            { status: 200 }
        )

    } catch (error) {
        console.error('Error fetching process orders:', error)
        return NextResponse.json(
            { success: false, message: 'Error fetching process orders' },
            { status: 500 }
        )
    }
}

export async function PUT(req: NextRequest) {
    await connectToDatabase()
    try {
        //Check Auth
        const authHeader = req.headers.get('authorization')
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            )
        }
        const token = authHeader.split(' ')[1]
        let decoded
        try {
            decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string; authorization: Array<{ module: string; accessLevel: string[] }> }
        } catch (error) {
            console.error('Error decoding token:', error)
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            )
        }

        // Check if the user has the required authorization level
        const hasAccess = decoded.authorization?.some(
            (auth) =>
                auth.module === 'Process Order' &&
                auth.accessLevel.includes("update")
        )
        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            )
        }

        const { searchParams } = new URL(req.url)
        const id = searchParams.get('id') || ''

        if (!id) {
            return NextResponse.json(
                { success: false, message: "Process Order ID is required" },
                { status: 400 }
            )
        }

        const body = await req.json()

        // Get existing order
        const existingOrder = await ProcessOrder.findById(id)
        if (!existingOrder) {
            return NextResponse.json(
                { success: false, message: "Process Order not found" },
                { status: 404 }
            )
        }

        // Only allow editing Draft orders
        if (existingOrder.status !== 'Draft') {
            return NextResponse.json(
                { success: false, message: "Only Draft orders can be edited" },
                { status: 400 }
            )
        }

        const updates: any = {}
        const changedFields: any = {}

        Object.keys(body).forEach(key => {
            if (key === '_id' || key === 'processOrderCode' || key === 'createdBy') return;

            const newValue = body[key]
            const oldValue = existingOrder[key as keyof typeof existingOrder]

            if (JSON.stringify(newValue) !== JSON.stringify(oldValue)) {
                updates[key] = newValue
                changedFields[key] = {
                    old: oldValue,
                    new: newValue
                }
            }
        })

        if (Object.keys(updates).length === 0) {
            return NextResponse.json(
                { success: true, message: "No changes made" },
                { status: 200 }
            )
        }

        updates.updatedBy = decoded.id

        const updatedOrder = await ProcessOrder.findByIdAndUpdate(
            id,
            { $set: updates },
            { new: true }
        )

        // 🌍 Get IP properly
        const forwarded = req.headers.get("x-forwarded-for");
        const ipAddress = forwarded
            ? forwarded.split(",")[0]
            : req.headers.get("x-real-ip") || "Unknown";

        // Create audit log
        await AuditLog.create({
            userId: decoded.id,
            userRole: decoded.role,
            moduleName: 'Process Order',
            recordId: updatedOrder._id,
            action: 'UPDATE',
            oldData: Object.fromEntries(
                Object.entries(existingOrder.toObject()).filter(([key]) => changedFields[key])
            ),
            newData: Object.fromEntries(
                Object.entries(updatedOrder.toObject()).filter(([key]) => changedFields[key])
            ),
            changedFields: Object.keys(changedFields),
            changeReason: null,
            ipAddress,
            userAgent: req.headers.get('user-agent') || "Unknown",
        })

        return NextResponse.json(
            {
                success: true,
                message: `Process Order ${updatedOrder.processOrderCode} updated successfully!`,
            },
            { status: 200 }
        )

    } catch (error) {
        console.error('Error updating process order:', error)
        return NextResponse.json(
            { success: false, message: 'Error updating process order' },
            { status: 500 }
        )
    }
}

export async function DELETE(req: NextRequest) {
    await connectToDatabase()
    try {
        //Check Auth
        const authHeader = req.headers.get('authorization')
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            )
        }
        const token = authHeader.split(' ')[1]
        let decoded
        try {
            decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string; authorization: Array<{ module: string; accessLevel: string[] }> }
        } catch (error) {
            console.error('Error decoding token:', error)
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            )
        }

        // Check if the user has the required authorization level
        const hasAccess = decoded.authorization?.some(
            (auth) =>
                auth.module === 'Process Order' &&
                auth.accessLevel.includes("delete")
        )
        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            )
        }

        const { searchParams } = new URL(req.url)
        const id = searchParams.get('id') || ''

        if (!id) {
            return NextResponse.json(
                { success: false, message: "Process Order ID is required" },
                { status: 400 }
            )
        }

        const existingOrder = await ProcessOrder.findById(id)
        if (!existingOrder) {
            return NextResponse.json(
                { success: false, message: "Process Order not found" },
                { status: 404 }
            )
        }

        if (existingOrder.status !== 'Draft') {
            return NextResponse.json(
                { success: false, message: "Only Draft orders can be deleted" },
                { status: 400 }
            )
        }

        const deletedOrder = await ProcessOrder.findByIdAndDelete(id)

        // 🌍 Get IP properly
        const forwarded = req.headers.get("x-forwarded-for");
        const ipAddress = forwarded
            ? forwarded.split(",")[0]
            : req.headers.get("x-real-ip") || "Unknown";

        // Create audit log
        await AuditLog.create({
            userId: decoded.id,
            userRole: decoded.role,
            moduleName: 'Process Order',
            recordId: deletedOrder._id,
            action: 'DELETE',
            oldData: deletedOrder.toObject(),
            newData: null,
            changedFields: Object.keys(deletedOrder.toObject()),
            changeReason: null,
            ipAddress,
            userAgent: req.headers.get('user-agent') || "Unknown",
        })

        return NextResponse.json(
            {
                success: true,
                message: `Process Order ${deletedOrder.processOrderCode} deleted successfully!`,
            },
            { status: 200 }
        )

    } catch (error) {
        console.error('Error deleting process order:', error)
        return NextResponse.json(
            { success: false, message: 'Error deleting process order' },
            { status: 500 }
        )
    }
}
