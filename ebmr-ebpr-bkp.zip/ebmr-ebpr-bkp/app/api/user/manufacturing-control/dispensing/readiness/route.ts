import { JWT_SECRET } from "@/lib/auth";
import connectToDatabase from "@/lib/db";
import BatchManufacturingTemplate from "@/lib/models/BatchManufacturingTemplate";
import EquipmentMaster from "@/lib/models/EquipmentMaster";
import FacilityMaster from "@/lib/models/FacilityMaster";
import ManufacturingBOM from "@/lib/models/ManufacturingBOM";
import ProcessOrder from "@/lib/models/ProcessOrder";
import jwt from "jsonwebtoken";
import { NextRequest, NextResponse } from "next/server";

type CheckResult = {
    ok: boolean;
    title: string;
    message: string;
    details?: unknown;
};

type TemplateFacility = {
    facilityCode?: string;
    equipments?: Array<{ equipmentCode?: string | number }>;
};

type FacilityRecord = {
    facilityCode: string;
    areaName?: string;
    status?: string;
    qualificationRequired?: boolean;
    qualificationStatus?: string;
    equipment?: Array<string | number>;
};

type EquipmentRecord = {
    equipmentCode: string | number;
    equipmentName?: string;
    currentStatus?: string;
    qualificationRequired?: boolean;
    qualificationStatus?: string;
    calibrationRequired?: boolean;
    calibrationStatus?: string;
    nextCalibrationDate?: Date | string | null;
    maintenanceRequired?: boolean;
    nextMaintenanceDate?: Date | string | null;
};

const getFacilityCode = (value: string) => String(value || "").split(" - ")[0].trim();

const isDueDateOk = (date?: Date | string | null) => {
    if (!date) return false;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dueDate = new Date(date);
    dueDate.setHours(0, 0, 0, 0);
    return dueDate >= today;
};

const isQualified = (status?: string) => String(status || "").toLowerCase() === "qualified";

export async function GET(req: NextRequest) {
    await connectToDatabase();

    try {
        const authHeader = req.headers.get("authorization");
        if (!authHeader || !authHeader.startsWith("Bearer ")) {
            return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
        }

        const token = authHeader.split(" ")[1];
        let decoded;

        try {
            decoded = jwt.verify(token, JWT_SECRET) as {
                id: string;
                role: string;
                authorization: Array<{ module: string; accessLevel: string[] }>;
            };
        } catch (error) {
            console.error("Error decoding token:", error);
            return NextResponse.json({ success: false, message: "Invalid or expired token" }, { status: 401 });
        }

        const hasAccess = decoded.authorization?.some(
            (auth) => auth.module === "Process Order" && auth.accessLevel.includes("read")
        );

        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            );
        }

        const { searchParams } = new URL(req.url);
        const processOrderId = searchParams.get("processOrderId") || "";

        if (!processOrderId) {
            return NextResponse.json(
                { success: false, message: "Process order id is required" },
                { status: 400 }
            );
        }

        const processOrder = await ProcessOrder.findById(processOrderId).lean();
        if (!processOrder) {
            return NextResponse.json({ success: false, message: "Process order not found" }, { status: 404 });
        }

        const batchIssued: CheckResult = {
            ok: Boolean(processOrder.batchNumber),
            title: "Batch Number",
            message: processOrder.batchNumber
                ? `Batch ${processOrder.batchNumber} is issued.`
                : "Batch number is not issued yet.",
            details: {
                processOrderCode: processOrder.processOrderCode,
                batchNumber: processOrder.batchNumber,
            },
        };

        const activeTemplate = await BatchManufacturingTemplate.findOne({
            productCode: String(processOrder.productCode),
            status: "Active",
        })
            .sort({ createdAt: -1 })
            .lean();

        const template: CheckResult = {
            ok: Boolean(activeTemplate),
            title: "Manufacturing Template",
            message: activeTemplate
                ? `${activeTemplate.templateCode} v${activeTemplate.templateVersion} is active.`
                : "No active manufacturing template found for this product.",
            details: activeTemplate
                ? {
                    templateCode: activeTemplate.templateCode,
                    templateName: activeTemplate.templateName,
                    templateVersion: activeTemplate.templateVersion,
                    status: activeTemplate.status,
                }
                : null,
        };

        const templateBasicInfo = activeTemplate?.fullTemplateData?.["Basic Information"] || {};
        const templateBomCode = templateBasicInfo.manufacturingBomCode;
        const bomCode = templateBomCode || processOrder.bomCode;
        const activeBom = bomCode
            ? await ManufacturingBOM.findOne({ bomCode }).lean()
            : null;

        const bom: CheckResult = {
            ok: Boolean(activeBom && activeBom.status === "Active"),
            title: "Manufacturing BOM",
            message: activeBom
                ? activeBom.status === "Active"
                    ? `${activeBom.bomCode} v${activeBom.bomVersion} is active.`
                    : `${activeBom.bomCode} is ${activeBom.status}.`
                : "Manufacturing BOM not found.",
            details: activeBom
                ? {
                    bomCode: activeBom.bomCode,
                    bomVersion: activeBom.bomVersion,
                    status: activeBom.status,
                    materialCount: activeBom.materials?.length || 0,
                }
                : { bomCode },
        };

        const templateFacilities = (
            activeTemplate?.fullTemplateData?.["Facility Equipment"]?.facilitiesWithEquipment || []
        ) as TemplateFacility[];
        const processOrderFacilityCodes = (processOrder.manufacturingFacility || [])
            .map((facility: string) => getFacilityCode(facility))
            .filter(Boolean);
        const templateFacilityCodes = templateFacilities
            .map((facility) => facility.facilityCode)
            .filter(Boolean);
        const facilityCodes = Array.from(new Set([...processOrderFacilityCodes, ...templateFacilityCodes]));

        const facilityRecords = facilityCodes.length
            ? await FacilityMaster.find({ facilityCode: { $in: facilityCodes }, isDeleted: false }).lean() as FacilityRecord[]
            : [] as FacilityRecord[];

        const facilityItems = facilityCodes.map((facilityCode) => {
            const facility = facilityRecords.find((item) => item.facilityCode === facilityCode);
            const ok = Boolean(
                facility &&
                facility.status === "Active" &&
                (!facility.qualificationRequired || isQualified(facility.qualificationStatus))
            );

            return {
                ok,
                facilityCode,
                areaName: facility?.areaName || "Not found",
                status: facility?.status || "Missing",
                qualificationStatus: facility?.qualificationStatus || "-",
                message: !facility
                    ? "Facility not found in master data."
                    : facility.status !== "Active"
                        ? "Facility is not active."
                        : facility.qualificationRequired && !isQualified(facility.qualificationStatus)
                            ? "Facility qualification is not complete."
                            : "Facility is ready.",
            };
        });

        const facilities: CheckResult = {
            ok: facilityItems.length > 0 && facilityItems.every((item) => item.ok),
            title: "Facility",
            message: facilityItems.length
                ? facilityItems.every((item) => item.ok)
                    ? "All required facilities are active and qualified."
                    : "One or more facilities need attention."
                : "No facility is linked with this order/template.",
            details: facilityItems,
        };

        const equipmentCodesFromTemplate = templateFacilities.flatMap((facility) =>
            (facility.equipments || []).map((equipment) => equipment.equipmentCode)
        );
        const equipmentCodesFromFacilities = facilityRecords.flatMap((facility) => facility.equipment || []);
        const equipmentCodes = Array.from(
            new Set(
                [...equipmentCodesFromTemplate, ...equipmentCodesFromFacilities]
                    .map((code) => Number(code))
                    .filter((code) => !Number.isNaN(code))
            )
        );

        const equipmentRecords = equipmentCodes.length
            ? await EquipmentMaster.find({ equipmentCode: { $in: equipmentCodes }, isDeleted: false }).lean() as EquipmentRecord[]
            : [] as EquipmentRecord[];

        const equipmentItems = equipmentCodes.map((equipmentCode) => {
            const equipment = equipmentRecords.find((item) => Number(item.equipmentCode) === equipmentCode);
            const qualificationOk = !equipment?.qualificationRequired || isQualified(equipment?.qualificationStatus);
            const calibrationOk = !equipment?.calibrationRequired || isDueDateOk(equipment?.nextCalibrationDate);
            const maintenanceOk = !equipment?.maintenanceRequired || isDueDateOk(equipment?.nextMaintenanceDate);
            const ok = Boolean(equipment && equipment.currentStatus === "Active" && qualificationOk && calibrationOk && maintenanceOk);

            return {
                ok,
                equipmentCode,
                equipmentName: equipment?.equipmentName || "Not found",
                currentStatus: equipment?.currentStatus || "Missing",
                qualificationStatus: equipment?.qualificationStatus || "-",
                calibrationStatus: equipment?.calibrationStatus || "-",
                nextCalibrationDate: equipment?.nextCalibrationDate || null,
                nextMaintenanceDate: equipment?.nextMaintenanceDate || null,
                message: !equipment
                    ? "Equipment not found in master data."
                    : equipment.currentStatus !== "Active"
                        ? "Equipment is not active."
                        : !qualificationOk
                            ? "Equipment qualification is not complete."
                            : !calibrationOk
                                ? "Equipment calibration is due or missing."
                                : !maintenanceOk
                                    ? "Equipment maintenance is due or missing."
                                    : "Equipment is ready.",
            };
        });

        const equipment: CheckResult = {
            ok: equipmentItems.length > 0 && equipmentItems.every((item) => item.ok),
            title: "Equipment",
            message: equipmentItems.length
                ? equipmentItems.every((item) => item.ok)
                    ? "All required equipment is active and ready."
                    : "One or more equipment items need attention."
                : "No equipment is linked with the selected facilities/template.",
            details: equipmentItems,
        };

        const checks = { batchIssued, template, bom, facilities, equipment };
        const ready = Object.values(checks).every((check) => check.ok);

        return NextResponse.json({
            success: true,
            ready,
            processOrder,
            checks,
        });
    } catch (error) {
        console.error("Error checking dispensing readiness:", error);
        return NextResponse.json(
            { success: false, message: "Error checking dispensing readiness" },
            { status: 500 }
        );
    }
}
