import { JWT_SECRET } from "@/lib/auth";
import connectToDatabase from "@/lib/db";
import ManufacturingBOM from "@/lib/models/ManufacturingBOM";
import ProcessOrder from "@/lib/models/ProcessOrder";
import BatchManufacturingTemplate from "@/lib/models/BatchManufacturingTemplate";
import jwt from "jsonwebtoken";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
    await connectToDatabase();

    try {
        const authHeader = req.headers.get("authorization");
        if (!authHeader || !authHeader.startsWith("Bearer ")) {
            return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 });
        }

        const token = authHeader.split(" ")[1];
        let decoded;

        try {
            decoded = jwt.verify(token, JWT_SECRET) as {
                id: string;
                role: string;
                authorization: Array<{ module: string; accessLevel: string[] }>;
            };
        } catch {
            return NextResponse.json({ success: false, message: "Invalid or expired token" }, { status: 401 });
        }

        const hasAccess = decoded.authorization?.some(
            (auth) => auth.module === "Dispensing" && auth.accessLevel.includes("read")
        );

        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            );
        }

        const { searchParams } = new URL(req.url);
        const processOrderId = searchParams.get("processOrderId") || "";

        if (!processOrderId) {
            return NextResponse.json(
                { success: false, message: "Process order id is required" },
                { status: 400 }
            );
        }

        // Fetch process order
        const processOrder = await ProcessOrder.findById(processOrderId).lean();
        if (!processOrder) {
            return NextResponse.json({ success: false, message: "Process order not found" }, { status: 404 });
        }

        // Try to get BOM code from active manufacturing template first
        const activeTemplate = await BatchManufacturingTemplate.findOne({
            productCode: String(processOrder.productCode),
            status: "Active",
        })
            .sort({ createdAt: -1 })
            .lean();

        const templateBasicInfo = activeTemplate?.fullTemplateData?.["Basic Information"] || {};
        const templateBomCode = templateBasicInfo.manufacturingBomCode;
        const bomCode = templateBomCode || processOrder.bomCode;

        if (!bomCode) {
            return NextResponse.json(
                { success: false, message: "No BOM code found for this process order" },
                { status: 404 }
            );
        }

        // Fetch BOM with materials
        const bom = await ManufacturingBOM.findOne({ bomCode }).lean();
        if (!bom) {
            return NextResponse.json(
                { success: false, message: "Manufacturing BOM not found" },
                { status: 404 }
            );
        }

        const materials = (bom.materials || []).map((mat: Record<string, unknown>) => ({
            materialCode: mat.materialCode as string,
            materialName: mat.materialName as string,
            materialCategory: mat.materialCategory as string,
            totalRequiredQuantity: mat.quantity as number,
            uom: mat.uom as string,
        }));

        return NextResponse.json({
            success: true,
            processOrderId: processOrder._id,
            processOrderCode: processOrder.processOrderCode,
            productCode: processOrder.productCode,
            productName: processOrder.productName,
            batchNumber: processOrder.batchNumber || null,
            bomCode: bom.bomCode,
            bomVersion: bom.bomVersion,
            batchSizeSemifinished: bom.batchSizeSemifinished,
            uom: bom.uom,
            materials,
        });
    } catch (error) {
        console.error("Error fetching BOM materials:", error);
        return NextResponse.json(
            { success: false, message: "Error fetching BOM materials" },
            { status: 500 }
        );
    }
}