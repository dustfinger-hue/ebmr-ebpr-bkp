import { JWT_SECRET } from "@/lib/auth";
import connectToDatabase from "@/lib/db";
import BatchTracker from "@/lib/models/BatchTracker";
import MaterialAllocationRecord from "@/lib/models/MaterialAllocationRecord";
// import DispensingRecord from "@/lib/models/MaterialAllocationRecord";
import User from "@/lib/models/User";
import AuditLog from "@/lib/models/UserAuditLog";
import jwt from "jsonwebtoken";
import { NextRequest, NextResponse } from "next/server";

type LotInput = {
  lotNumber: string;
  quantity: number;
};

type MaterialInput = {
  materialCode: string;
  materialName: string;
  materialCategory: string;
  uom: string;
  totalRequiredQuantity: number;
  lots: LotInput[];
};

export async function GET(req: NextRequest) {
  await connectToDatabase();

  try {
    const authHeader = req.headers.get("authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json(
        { success: false, message: "Unauthorized" },
        { status: 401 },
      );
    }

    const token = authHeader.split(" ")[1];
    let decoded;

    try {
      decoded = jwt.verify(token, JWT_SECRET) as {
        id: string;
        role: string;
        authorization: Array<{ module: string; accessLevel: string[] }>;
      };
    } catch {
      return NextResponse.json(
        { success: false, message: "Invalid or expired token" },
        { status: 401 },
      );
    }

    const hasAccess = decoded.authorization?.some(
      (auth) =>
        auth.module === "Dispensing" &&
        (auth.accessLevel.includes("read") ||
          auth.accessLevel.includes("create")),
    );

    if (!hasAccess) {
      return NextResponse.json(
        {
          success: false,
          message: "You are not authorized to perform this action",
        },
        { status: 403 },
      );
    }

    const { searchParams } = new URL(req.url);
    const processOrderId = searchParams.get("processOrderId");

    if (!processOrderId) {
      return NextResponse.json(
        { success: false, message: "Process order id is required" },
        { status: 400 },
      );
    }

    const dispensingRecord = await MaterialAllocationRecord.findOne({
      processOrderId,
    }).lean();

    return NextResponse.json({
      success: true,
      exists: Boolean(dispensingRecord),
      data: dispensingRecord,
    });
  } catch (error) {
    console.error("Error fetching allocation data:", error);
    return NextResponse.json(
      { success: false, message: "Error fetching allocation data" },
      { status: 500 },
    );
  }
}

export async function POST(req: NextRequest) {
  await connectToDatabase();

  try {
    const authHeader = req.headers.get("authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json(
        { success: false, message: "Unauthorized" },
        { status: 401 },
      );
    }

    const token = authHeader.split(" ")[1];
    let decoded;

    try {
      decoded = jwt.verify(token, JWT_SECRET) as {
        id: string;
        role: string;
        authorization: Array<{ module: string; accessLevel: string[] }>;
      };
    } catch {
      return NextResponse.json(
        { success: false, message: "Invalid or expired token" },
        { status: 401 },
      );
    }

    const hasAccess = decoded.authorization?.some(
      (auth) =>
        auth.module === "Dispensing" && auth.accessLevel.includes("create"),
    );

    if (!hasAccess) {
      return NextResponse.json(
        {
          success: false,
          message: "You are not authorized to perform this action",
        },
        { status: 403 },
      );
    }

    const body = await req.json();
    const {
      processOrderId,
      processOrderCode,
      productName,
      batchNumber,
      materials,
    } = body as {
      processOrderId: string;
      processOrderCode: string;
      productName: string;
      batchNumber?: string | null;
      materials: MaterialInput[];
    };

    // Validation
    if (!processOrderId) {
      return NextResponse.json(
        { success: false, message: "Process order id is required" },
        { status: 400 },
      );
    }

    if (!materials || !Array.isArray(materials) || materials.length === 0) {
      return NextResponse.json(
        { success: false, message: "At least one material is required" },
        { status: 400 },
      );
    }

    const errors: string[] = [];

    for (const material of materials) {
      if (!material.materialCode) {
        errors.push("Material code is required for all materials");
        continue;
      }

      if (!material.lots || material.lots.length === 0) {
        errors.push(
          `Material ${material.materialCode}: At least one lot is required`,
        );
        continue;
      }

      let totalAllocatedQty = 0;

      for (const lot of material.lots) {
        if (!lot.lotNumber || lot.lotNumber.trim() === "") {
          errors.push(
            `Material ${material.materialCode}: Lot number cannot be empty`,
          );
        }
        if (!lot.quantity || lot.quantity <= 0) {
          errors.push(
            `Material ${material.materialCode}: Lot quantity must be greater than 0`,
          );
        }
        totalAllocatedQty += lot.quantity;
      }

      if (totalAllocatedQty !== material.totalRequiredQuantity) {
        errors.push(
          `Material ${material.materialCode}: Total allocated quantity (${totalAllocatedQty} ${material.uom}) does not match required quantity (${material.totalRequiredQuantity} ${material.uom})`,
        );
      }
    }

    if (errors.length > 0) {
      return NextResponse.json(
        { success: false, message: "Validation failed", errors },
        { status: 400 },
      );
    }

    const userId = decoded.id;

    // Fetch user details for lotAllocatedBy info
    const user = await User.findById(userId).lean();
    if (!user) {
      return NextResponse.json(
        { success: false, message: "User not found" },
        { status: 404 },
      );
    }

    const allocatedByInfo = {
      userId: user._id,
      fullName:
        user.fullName ||
        `${user.firstName || ""} ${user.lastName || ""}`.trim(),
      designation: user.designation || "",
      department: user.department || "",
      employeeId: user.employeeId || "",
    };

    // Check if dispensing record already exists for this process order
    let dispensingRecord = await MaterialAllocationRecord.findOne({
      processOrderId,
    });
    const isUpdate = Boolean(dispensingRecord);

    if (dispensingRecord) {
      // Update existing record
      dispensingRecord.materials = materials;
      dispensingRecord.status = "Allocated";
      dispensingRecord.lotAllocatedBy = allocatedByInfo;
      dispensingRecord.allocatedAt = new Date();
    } else {
      // Create new record
      dispensingRecord = new MaterialAllocationRecord({
        processOrderId,
        processOrderCode,
        productName,
        batchNumber: batchNumber || null,
        status: "Allocated",
        materials,
        lotAllocatedBy: allocatedByInfo,
        allocatedAt: new Date(),
      });
    }

    await dispensingRecord.save();

    // update batch tracker
    await BatchTracker.findOneAndUpdate(
      { processOrderId },
      {
        $push: {
          dispensingRecords: {
            MaterialAllocationRecordId: dispensingRecord._id,
          },
        },
      },
      { upsert: true, new: true },
    );

    // Create audit trail
    await AuditLog.create({
      userId: user._id,
      userRole: decoded.role,
      moduleName: "Dispensing",
      recordId: dispensingRecord._id,
      action: isUpdate ? "UPDATE" : "CREATE",
      newData: {
        processOrderId,
        processOrderCode,
        productName,
        batchNumber: batchNumber || null,
        materials: materials.map((mat) => ({
          materialCode: mat.materialCode,
          materialName: mat.materialName,
          totalRequiredQuantity: mat.totalRequiredQuantity,
          lots: mat.lots.map((lot) => ({
            lotNumber: lot.lotNumber,
            quantity: lot.quantity,
          })),
        })),
        lotAllocatedBy: allocatedByInfo,
      },
      changedFields: isUpdate
        ? ["materials", "status", "lotAllocatedBy", "allocatedAt"]
        : undefined,
      changeReason: `Lot allocation ${isUpdate ? "updated" : "created"} for process order ${processOrderCode}`,
      ipAddress:
        req.headers.get("x-forwarded-for") ||
        req.headers.get("x-real-ip") ||
        "unknown",
      userAgent: req.headers.get("user-agent") || "unknown",
    });

    return NextResponse.json({
      success: true,
      message: "Lot allocation saved successfully",
      data: dispensingRecord,
    });
  } catch (error) {
    console.error("Error saving lot allocation:", error);
    return NextResponse.json(
      { success: false, message: "Error saving lot allocation" },
      { status: 500 },
    );
  }
}
