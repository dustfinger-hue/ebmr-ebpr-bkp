import connectToDatabase from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import CleaningLog from "@/lib/models/CleaningLog";
import ActivityLog from "@/lib/models/ActivityLog";
import Signature from "@/lib/models/Signature";

// ─── GET ──────────────────────────────────────────────────────────────
export async function GET(request: NextRequest) {
  await connectToDatabase();
  try {
    const { searchParams } = new URL(request.url);
    const facilityCode = searchParams.get("facilityCode");

    const filter: Record<string, unknown> = {};
    if (facilityCode) filter.facilityCode = facilityCode;

    const logs = await CleaningLog.find(filter).sort({ createdAt: -1 }).lean();

    return NextResponse.json({ success: true, data: logs });
  } catch (error) {
    console.error("Error in cleaning-log GET:", error);
    return NextResponse.json(
      { success: false, message: "Error fetching cleaning logs" },
      { status: 500 },
    );
  }
}

// ─── POST: Create Cleaning Log Entry ─────────────────────────────────
export async function POST(request: NextRequest) {
  await connectToDatabase();
  try {
    const body = await request.json();

    const {
      date,
      productName,
      batchNo,
      cleaningType,
      cleaningMethod,
      startDateTime,
      facilityCode,
      cleaningStartedBy,
    } = body;

    // ── Validation ──
    if (!date || !cleaningType || !cleaningMethod || !startDateTime || !cleaningStartedBy) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Missing required fields: date, cleaningType, cleaningMethod, startDateTime, cleaningStartedBy",
        },
        { status: 400 },
      );
    }

    // ── Facility-wise validation: check previous entries ──
    if (facilityCode) {
      // Check 1: Last Activity Log
      const lastActivity = await ActivityLog.findOne({ facilityCode })
        .sort({ createdAt: -1 })
        .lean();

      if (lastActivity && lastActivity.status === "In-Progress") {
        return NextResponse.json(
          {
            success: false,
            message: `⚠ A production activity (${lastActivity.batchNumber}) is still In-Progress in this facility. Please complete it first.`,
          },
          { status: 400 },
        );
      }

      // Check 2: Last Cleaning Log
      const lastCleaning = await CleaningLog.findOne({ facilityCode })
        .sort({ createdAt: -1 })
        .lean();

      if (lastCleaning && lastCleaning.status === "In-Progress") {
        return NextResponse.json(
          {
            success: false,
            message: `⚠ A cleaning activity (${lastCleaning.cleaningType}) is already In-Progress in this facility. Please complete it first.`,
          },
          { status: 400 },
        );
      }
    }

    const newLog = await CleaningLog.create({
      facilityCode: facilityCode || "",
      date: new Date(date),
      productName: productName || "",
      batchNo: batchNo || "",
      cleaningType,
      cleaningMethod,
      startDateTime: new Date(startDateTime),
      status: "In-Progress",
      cleaningStartedBy: {
        name: cleaningStartedBy.name,
        designation: cleaningStartedBy.designation,
        department: cleaningStartedBy.department,
        signatureId: cleaningStartedBy.signatureId,
      },
    });

    // Update signature status
    await Signature.findByIdAndUpdate(cleaningStartedBy.signatureId, {
      status: "signed",
      expiresAt: undefined,
      associatedRecordId: newLog._id,
      associatedRecordType: "CleaningLog",
    });

    return NextResponse.json(
      { success: true, message: "Cleaning log entry created", data: newLog },
      { status: 201 },
    );
  } catch (error) {
    console.error("Error in cleaning-log POST:", error);
    return NextResponse.json(
      { success: false, message: "Error creating cleaning log entry" },
      { status: 500 },
    );
  }
}

// ─── PATCH: Update signature fields (checkedBy / verifiedBy) ─────────
export async function PATCH(request: NextRequest) {
  await connectToDatabase();
  try {
    const body = await request.json();

    const { id, type, signatureData } = body;

    if (!id || !type || !signatureData) {
      return NextResponse.json(
        { success: false, message: "Missing required fields: id, type, signatureData" },
        { status: 400 },
      );
    }

    if (type !== "checkedBy" && type !== "verifiedBy") {
      return NextResponse.json(
        { success: false, message: "Invalid type. Must be 'checkedBy' or 'verifiedBy'" },
        { status: 400 },
      );
    }

    const updateData: Record<string, unknown> = {
      [type]: {
        name: signatureData.name,
        designation: signatureData.designation,
        department: signatureData.department,
        signatureId: signatureData.signatureId,
      },
    };

    const updatedLog = await CleaningLog.findByIdAndUpdate(
      id,
      { $set: updateData },
      { new: true, runValidators: true }
    );

    if (!updatedLog) {
      return NextResponse.json(
        { success: false, message: "Cleaning log entry not found" },
        { status: 404 },
      );
    }

    if (signatureData.signatureId) {
      await Signature.findByIdAndUpdate(signatureData.signatureId, {
        status: "signed",
        expiresAt: undefined,
        associatedRecordId: updatedLog._id,
        associatedRecordType: "CleaningLog",
      });
    }

    return NextResponse.json({
      success: true,
      message: `Cleaning log ${type} updated successfully`,
      data: updatedLog,
    });
  } catch (error) {
    console.error("Error in cleaning-log PATCH:", error);
    return NextResponse.json(
      { success: false, message: "Error updating signature field" },
      { status: 500 },
    );
  }
}

// ─── PUT: Update Cleaning Log Entry (endDateTime, cleaningStoppedBy) ──
export async function PUT(request: NextRequest) {
  await connectToDatabase();
  try {
    const body = await request.json();

    const { id, endDateTime, cleaningStoppedBy } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, message: "Missing required field: id" },
        { status: 400 },
      );
    }

    const updateData: Record<string, unknown> = {};

    if (endDateTime) {
      updateData.endDateTime = new Date(endDateTime);
      updateData.status = "Completed";
    }

    if (cleaningStoppedBy) {
      updateData.cleaningStoppedBy = {
        name: cleaningStoppedBy.name,
        designation: cleaningStoppedBy.designation,
        department: cleaningStoppedBy.department,
        signatureId: cleaningStoppedBy.signatureId,
      };
    }

    const updatedLog = await CleaningLog.findByIdAndUpdate(
      id,
      { $set: updateData },
      { new: true, runValidators: true }
    );

    if (!updatedLog) {
      return NextResponse.json(
        { success: false, message: "Cleaning log entry not found" },
        { status: 404 },
      );
    }

    if (cleaningStoppedBy?.signatureId) {
      await Signature.findByIdAndUpdate(cleaningStoppedBy.signatureId, {
        status: "signed",
        expiresAt: undefined,
        associatedRecordId: updatedLog._id,
        associatedRecordType: "CleaningLog",
      });
    }

    return NextResponse.json({
      success: true,
      message: "Cleaning log entry updated successfully",
      data: updatedLog,
    });
  } catch (error) {
    console.error("Error in cleaning-log PUT:", error);
    return NextResponse.json(
      { success: false, message: "Error updating cleaning log entry" },
      { status: 500 },
    );
  }
}