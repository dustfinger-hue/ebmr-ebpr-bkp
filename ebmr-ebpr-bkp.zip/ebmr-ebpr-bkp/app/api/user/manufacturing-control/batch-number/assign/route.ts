import connectToDatabase from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import { JWT_SECRET } from "@/lib/auth";
import { generateBatchNumber } from "@/lib/utils/generateCode";
import ProcessOrder from "@/lib/models/ProcessOrder";
import ProductMaster from "@/lib/models/ProductMaster";
import AuditLog from "@/lib/models/UserAuditLog";
import BatchTracker from "@/lib/models/BatchTracker";
import IssuedBatchNumber from "@/lib/models/IssuedBatchNumber";

export async function PATCH(req: NextRequest) {
  await connectToDatabase();
  try {
    //Check Auth
    const authHeader = req.headers.get("authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json(
        { success: false, message: "Unauthorized" },
        { status: 401 },
      );
    }
    const token = authHeader.split(" ")[1];
    let decoded;
    try {
      decoded = jwt.verify(token, JWT_SECRET) as {
        id: string;
        role: string;
        authorization: Array<{ module: string; accessLevel: string[] }>;
      };
    } catch (error) {
      console.error("Error decoding token:", error);
      return NextResponse.json(
        { success: false, message: "Invalid or expired token" },
        { status: 401 },
      );
    }

    // Check if the user has the required authorization level
    const hasAccess = decoded.authorization?.some(
      (auth) =>
        auth.module === "Batch Number Issuance" &&
        auth.accessLevel.includes("create"),
    );
    if (!hasAccess) {
      return NextResponse.json(
        {
          success: false,
          message: "You are not authorized to perform this action",
        },
        { status: 403 },
      );
    }

    const body = await req.json();
    const { orderId } = body;

    if (!orderId) {
      return NextResponse.json(
        { success: false, message: "Order ID is required" },
        { status: 400 },
      );
    }

    // Find the process order
    const order = await ProcessOrder.findById(orderId);
    if (!order) {
      return NextResponse.json(
        { success: false, message: "Process Order not found" },
        { status: 404 },
      );
    }

    // Only allow assigning batch to "Planned" orders
    if (order.status !== "Planned") {
      return NextResponse.json(
        {
          success: false,
          message: "Only Planned orders can be assigned a batch number",
        },
        { status: 400 },
      );
    }

    // Check if already has a batch number
    if (order.batchNumber) {
      return NextResponse.json(
        {
          success: false,
          message: `Batch number ${order.batchNumber} already assigned to this order`,
        },
        { status: 400 },
      );
    }

    // Find product to get shortName
    const product = await ProductMaster.findOne({
      productCode: order.productCode,
    }).lean();
    if (!product) {
      return NextResponse.json(
        { success: false, message: "Product not found for this order" },
        { status: 404 },
      );
    }

    // Generate batch number using product shortName
    const shortName = product.shortName;
    const batchNumber = await generateBatchNumber(shortName);

    // Update the order
    order.batchNumber = batchNumber;
    order.status = "In-Progress";
    order.updatedBy = decoded.id;
    await order.save();

    // Update batch tracker
    await BatchTracker.findOneAndUpdate(
      { processOrderId: order._id },
      { batchNumber },
      { upsert: true, new: true },
    );

    // Update issued batch numbers collection
    await IssuedBatchNumber.create({
      batchNumber,
      productName: product.productName,
      status: "Batch Under Processing",
    });

    // 🌍 Get IP properly
    const forwarded = req.headers.get("x-forwarded-for");
    const ipAddress = forwarded
      ? forwarded.split(",")[0]
      : req.headers.get("x-real-ip") || "Unknown";

    // Create audit log
    await AuditLog.create({
      userId: decoded.id,
      userRole: decoded.role,
      moduleName: "Batch Number Issuance",
      recordId: order._id,
      action: "UPDATE",
      oldData: { batchNumber: null, status: "Planned" },
      newData: { batchNumber, status: "In-Progress" },
      changedFields: ["batchNumber", "status"],
      changeReason: `Batch number ${batchNumber} assigned`,
      ipAddress,
      userAgent: req.headers.get("user-agent") || "Unknown",
    });

    return NextResponse.json(
      {
        success: true,
        message: `Batch number ${batchNumber} assigned successfully! Order status changed to In-Progress`,
        batchNumber,
      },
      { status: 200 },
    );
  } catch (error) {
    console.error("Error assigning batch number:", error);
    return NextResponse.json(
      { success: false, message: "Error assigning batch number" },
      { status: 500 },
    );
  }
}
