import connectToDatabase from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import EnvironmentalLog from "@/lib/models/EnvironmentalLog";
import Signature from "@/lib/models/Signature";

// ─── GET ──────────────────────────────────────────────────────────────
export async function GET(request: NextRequest) {
  await connectToDatabase();
  try {
    const { searchParams } = new URL(request.url);
    const facilityCode = searchParams.get("facilityCode");

    const filter: Record<string, unknown> = {};
    if (facilityCode) filter.facilityCode = facilityCode;

    const logs = await EnvironmentalLog.find(filter).sort({ createdAt: -1 }).lean();

    return NextResponse.json({ success: true, data: logs });
  } catch (error) {
    console.error("Error in environmental-log GET:", error);
    return NextResponse.json(
      { success: false, message: "Error fetching environmental logs" },
      { status: 500 },
    );
  }
}

// ─── POST: Create Environmental Log Entry ─────────────────────────────
export async function POST(request: NextRequest) {
  await connectToDatabase();
  try {
    const body = await request.json();

    const {
      dateTime,
      differentialPressure,
      temperature,
      humidity,
      particulates,
      luxLevel,
      status,
      facilityCode,
      monitoredBy,
      rangeReference,
    } = body;

    // ── Validation ──
    if (!dateTime || !monitoredBy) {
      return NextResponse.json(
        {
          success: false,
          message: "Missing required fields: dateTime, monitoredBy",
        },
        { status: 400 },
      );
    }

    const newLog = await EnvironmentalLog.create({
      facilityCode: facilityCode || "",
      dateTime: new Date(dateTime),
      differentialPressure: differentialPressure != null ? Number(differentialPressure) : undefined,
      temperature: temperature != null ? Number(temperature) : undefined,
      humidity: humidity != null ? Number(humidity) : undefined,
      particulates: particulates != null ? Number(particulates) : undefined,
      luxLevel: luxLevel != null ? Number(luxLevel) : undefined,
      status: status || "Within Limit",
      monitoredBy: {
        name: monitoredBy.name,
        designation: monitoredBy.designation,
        department: monitoredBy.department,
        signatureId: monitoredBy.signatureId,
      },
      rangeReference,
    });

    // Update signature status
    await Signature.findByIdAndUpdate(monitoredBy.signatureId, {
      status: "signed",
      expiresAt: undefined,
      associatedRecordId: newLog._id,
      associatedRecordType: "EnvironmentalLog",
    });

    return NextResponse.json(
      { success: true, message: "Environmental log entry created", data: newLog },
      { status: 201 },
    );
  } catch (error) {
    console.error("Error in environmental-log POST:", error);
    return NextResponse.json(
      { success: false, message: "Error creating environmental log entry" },
      { status: 500 },
    );
  }
}

// ─── PATCH: Update signature fields (checkedBy / verifiedBy) ─────────
export async function PATCH(request: NextRequest) {
  await connectToDatabase();
  try {
    const body = await request.json();

    const { id, type, signatureData } = body;

    if (!id || !type || !signatureData) {
      return NextResponse.json(
        { success: false, message: "Missing required fields: id, type, signatureData" },
        { status: 400 },
      );
    }

    if (type !== "checkedBy" && type !== "verifiedBy") {
      return NextResponse.json(
        { success: false, message: "Invalid type. Must be 'checkedBy' or 'verifiedBy'" },
        { status: 400 },
      );
    }

    const updateData: Record<string, unknown> = {
      [type]: {
        name: signatureData.name,
        designation: signatureData.designation,
        department: signatureData.department,
        signatureId: signatureData.signatureId,
      },
    };

    const updatedLog = await EnvironmentalLog.findByIdAndUpdate(
      id,
      { $set: updateData },
      { new: true, runValidators: true }
    );

    if (!updatedLog) {
      return NextResponse.json(
        { success: false, message: "Environmental log entry not found" },
        { status: 404 },
      );
    }

    if (signatureData.signatureId) {
      await Signature.findByIdAndUpdate(signatureData.signatureId, {
        status: "signed",
        expiresAt: undefined,
        associatedRecordId: updatedLog._id,
        associatedRecordType: "EnvironmentalLog",
      });
    }

    return NextResponse.json({
      success: true,
      message: `Environmental log ${type} updated successfully`,
      data: updatedLog,
    });
  } catch (error) {
    console.error("Error in environmental-log PATCH:", error);
    return NextResponse.json(
      { success: false, message: "Error updating signature field" },
      { status: 500 },
    );
  }
}
