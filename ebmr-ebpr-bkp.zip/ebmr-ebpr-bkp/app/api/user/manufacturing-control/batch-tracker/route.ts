import connectToDatabase from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import { JWT_SECRET } from "@/lib/auth";
import BatchTracker from "@/lib/models/BatchTracker";

export async function GET(Request: NextRequest) {
  await connectToDatabase();
  try {
    const authHeader = Request.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return new Response(
        JSON.stringify({ success: false, message: "Unauthorized" }),
        { status: 401 },
      );
    }

    const token = authHeader.split(" ")[1];
    let decoded;
    try {
      decoded = jwt.verify(token, JWT_SECRET) as {
        id: string;
        role: string;
        authorization: Array<{ module: string; accessLevel: string[] }>;
      };
    } catch (error) {
      console.error("Error decoding token:", error);
      return NextResponse.json(
        { success: false, message: "Invalid or expired token" },
        { status: 401 },
      );
    }
    const hasAccess = decoded.authorization?.some(
      (auth) =>
        auth.module === "Dispensing" && auth.accessLevel.includes("read"),
    );

    if (!hasAccess) {
      return NextResponse.json(
        {
          success: false,
          message: "You are not authorized to perform this action",
        },
        { status: 403 },
      );
    }

    const { searchParams } = new URL(Request.url);
    const processOrderId = searchParams.get("processOrderId");
    if (!processOrderId) {
      return NextResponse.json(
        { success: false, message: "Process Order ID is required" },
        { status: 400 },
      );
    }

    // Fetch batch tracking information based on processOrderId
    const batchTrackingInfo = await BatchTracker.findOne({
      processOrderId:processOrderId,
    });
    if (!batchTrackingInfo) {
      return NextResponse.json(
        { success: false, message: "Batch tracking information not found" },
        { status: 404 },
      );
    }

    return NextResponse.json({ success: true, data: batchTrackingInfo });
  } catch (error) {
    console.error("Error fetching batch tracking information:", error);
    return NextResponse.json(
      { success: false, message: "Internal Server Error" },
      { status: 500 },
    );
  }
}
