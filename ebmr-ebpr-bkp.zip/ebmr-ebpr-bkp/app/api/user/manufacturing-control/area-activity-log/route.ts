import connectToDatabase from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import IssuedBatchNumber from "@/lib/models/IssuedBatchNumber";
import ActivityLog from "@/lib/models/ActivityLog";
import Signature from "@/lib/models/Signature";
import mongoose from "mongoose";
import AuditLog from "@/lib/models/UserAuditLog";
import CleaningLog from "@/lib/models/CleaningLog";

// ─── GET ──────────────────────────────────────────────────────────────
export async function GET(request: NextRequest) {
  await connectToDatabase();
  try {
    const { searchParams } = new URL(request.url);
    const batchNumber = searchParams.get("batchNumber");
    const search = searchParams.get("search");
    const facilityCode = searchParams.get("facilityCode");
    const type = searchParams.get("type"); // "activity" | "cleaning" | "environmental"

    // ── Batch search for autocomplete ──
    if (search && search.length >= 2) {
      const regex = new RegExp(
        search.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
        "i",
      );
      const matches = await IssuedBatchNumber.find({
        batchNumber: { $regex: regex },
        status: "Batch Under Processing",
      })
        .select("batchNumber productName")
        .sort({ batchNumber: 1 })
        .limit(20)
        .lean();

      return NextResponse.json({ success: true, data: matches });
    }

    // ── Exact batch check ──
    if (batchNumber) {
      const batch = await IssuedBatchNumber.findOne({
        batchNumber,
        status: "Batch Under Processing",
      })
        .select("batchNumber productName")
        .lean();

      return NextResponse.json({
        success: true,
        exists: !!batch,
        data: batch || null,
      });
    }

    // ── Fetch Activity Logs ──
    const filter: Record<string, unknown> = {};
    if (facilityCode) filter.facilityCode = facilityCode;

    const logs = await ActivityLog.find(filter).sort({ createdAt: -1 }).lean();

    return NextResponse.json({ success: true, data: logs });
  } catch (error) {
    console.error("Error in area-activity-log GET:", error);
    return NextResponse.json(
      { success: false, message: "Error fetching data" },
      { status: 500 },
    );
  }
}

// ─── POST: Create Activity Log Entry ──────────────────────────────────
export async function POST(request: NextRequest) {
  await connectToDatabase();
  try {
    const body = await request.json();

    console.log("Received POST body:", body);

    const {
      date,
      productName,
      batchNumber,
      startDateTime,
      endDateTime,
      status,
      engagedForActivity,
      remarks,
      facilityCode,
      activityStartedBy,
    } = body;

    // ── Validation ──
    if (
      !date ||
      !productName ||
      !batchNumber ||
      !startDateTime ||
      !activityStartedBy
    ) {
      return NextResponse.json(
        {
          success: false,
          message:
            "Missing required fields: date, productName, batchNumber, startDateTime, activityStartedBy",
        },
        { status: 400 },
      );
    }

    // ── Facility-wise validation: check previous activity status ──
    if (facilityCode) {
      const lastActivity = await ActivityLog.findOne({ facilityCode })
        .sort({ createdAt: -1 })
        .lean();

      if (lastActivity) {
        // 1st check, If last activity is still In-Progress → block
        if (lastActivity.status === "In-Progress") {
          return NextResponse.json(
            {
              success: false,
              message: `⚠ The previous activity for this facility (${facilityCode}) is still **In-Progress** (Batch: ${lastActivity.batchNumber}). Please complete or stop it before creating a new entry.`,
            },
            { status: 400 },
          );
        }

        // 2nd check, If last activity is Completed but missing Checked/Verified signatures → block
        if (
          lastActivity.status === "Completed" &&
          (!lastActivity.checkedBy?.signatureId ||
            !lastActivity.verifiedBy?.signatureId)
        ) {
          return NextResponse.json(
            {
              success: false,
              message: `⚠ The previous activity for this facility (${facilityCode}) requires **Checked By** and **Verified By** signatures before creating a new entry.`,
            },
            { status: 400 },
          );
        }

        // 3rd check, if last activity is completed but area is not cleaned (however if the product is same, then allow to create upto 5 entries without cleaning, after that require cleaning) → block
        // get the last 5 activities for the facility
        const lastFiveEntries = await ActivityLog.find({
          facilityCode,
        })
          .sort({ createdAt: -1 })
          .limit(5)
          .select("productName status");

        // Check if all last 5 entreis have the same product
        const allSameProduct = lastFiveEntries.every(
          (entry) => entry.productName === productName,
        );

        if (allSameProduct && lastFiveEntries.length === 5) {
          return NextResponse.json(
            {
              success: false,
              message: `⚠ Last 5 consecutive entries are all "${productName}". Maximum limit reached. Please perform cleaning before adding more.`,
            },
            { status: 400 },
          );
        }

        // If last activity's product is different from current product, then check if the area has been cleaned (i.e. there should be an entry with status "Cleaning" after the last "Completed" entry with different product) → block if not cleaned
        if (lastActivity.productName !== productName) {
          const lastCleaningEntry = await CleaningLog.findOne({
            facilityCode,
            status: "Completed",
          })
            .sort({ createdAt: -1 })
            .lean();

          if (
            !lastCleaningEntry ||
            lastCleaningEntry.createdAt < lastActivity.createdAt
          ) {
            return NextResponse.json(
              {
                success: false,
                message: `⚠ The area for facility (${facilityCode}) has not been cleaned after the last activity. Please complete the cleaning process before creating a new entry.`,
              },
              { status: 400 },
            );
          }
        }
      }
    }

    const newLog = await ActivityLog.create({
      facilityCode: facilityCode || "",
      date: new Date(date),
      productName,
      batchNumber,
      startDateTime: new Date(startDateTime),
      endDateTime: endDateTime ? new Date(endDateTime) : undefined,
      status: status || "In-Progress",
      engagedForActivity: engagedForActivity || "",
      remarks: remarks || "",
      activityStartedBy: {
        name: activityStartedBy.name,
        designation: activityStartedBy.designation,
        department: activityStartedBy.department,
        signatureId: activityStartedBy.signatureId,
      },
    });

    // update signature status to signed, TTl Field (expiresAt) to undefined, associatedRecordId and associatedRecordType to new log's id and "ActivityLog" respectively
    await Signature.findByIdAndUpdate(activityStartedBy.signatureId, {
      status: "signed",
      expiresAt: undefined,
      associatedRecordId: newLog._id,
      associatedRecordType: "ActivityLog",
    });

    // Get IP address properly    const ip =
    const forwarded = request.headers.get("x-forwarded-for");
    const ipAddress = forwarded
      ? forwarded.split(",")[0]
      : request.headers.get("x-real-ip") || "Unknown";

    // Create audit log
    await AuditLog.create({
      userId: new mongoose.Types.ObjectId(activityStartedBy.userId),
      userRole: activityStartedBy.designation,
      moduleName: "Manufacturing Control - Area Activity Log",
      recordId: newLog._id,
      action: "CREATE",
      oldData: null,
      newData: newLog.toObject(),
      changeField: "New Activity Log Entry",
      changeReason: "Created new activity log entry",
      ipAddress,
      userAgent: request.headers.get("user-agent") || "Unknown",
    });

    return NextResponse.json(
      { success: true, message: "Activity log entry created", data: newLog },
      { status: 201 },
    );
  } catch (error) {
    console.error("Error in area-activity-log POST:", error);
    return NextResponse.json(
      { success: false, message: "Error creating activity log entry" },
      { status: 500 },
    );
  }
}

// ─── PATCH: Update signature fields (checkedBy / verifiedBy) ─────────
export async function PATCH(request: NextRequest) {
  await connectToDatabase();
  try {
    const body = await request.json();

    const { id, type, signatureData } = body;

    if (!id || !type || !signatureData) {
      return NextResponse.json(
        {
          success: false,
          message: "Missing required fields: id, type, signatureData",
        },
        { status: 400 },
      );
    }

    if (type !== "checkedBy" && type !== "verifiedBy") {
      return NextResponse.json(
        {
          success: false,
          message: "Invalid type. Must be 'checkedBy' or 'verifiedBy'",
        },
        { status: 400 },
      );
    }

    // ── Build update object ──
    const updateData: Record<string, unknown> = {
      [type]: {
        name: signatureData.name,
        designation: signatureData.designation,
        department: signatureData.department,
        signatureId: signatureData.signatureId,
      },
    };

    const updatedLog = await ActivityLog.findByIdAndUpdate(
      id,
      { $set: updateData },
      { new: true, runValidators: true },
    );

    if (!updatedLog) {
      return NextResponse.json(
        { success: false, message: "Activity log entry not found" },
        { status: 404 },
      );
    }

    // ── Update signature status ──
    if (signatureData.signatureId) {
      await Signature.findByIdAndUpdate(signatureData.signatureId, {
        status: "signed",
        expiresAt: undefined,
        associatedRecordId: updatedLog._id,
        associatedRecordType: "ActivityLog",
      });
    }

    return NextResponse.json({
      success: true,
      message: `Activity log ${type} updated successfully`,
      data: updatedLog,
    });
  } catch (error) {
    console.error("Error in area-activity-log PATCH:", error);
    return NextResponse.json(
      { success: false, message: "Error updating signature field" },
      { status: 500 },
    );
  }
}

// ─── PUT: Update Activity Log Entry (endDateTime, remarks, activityStoppedBy) ──
export async function PUT(request: NextRequest) {
  await connectToDatabase();
  try {
    const body = await request.json();

    const { id, endDateTime, remarks, activityStoppedBy } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, message: "Missing required field: id" },
        { status: 400 },
      );
    }

    // ── Build update object ──
    const updateData: Record<string, unknown> = {};

    if (endDateTime) {
      updateData.endDateTime = new Date(endDateTime);
      updateData.status = "Completed";
    }

    if (remarks !== undefined) {
      updateData.remarks = remarks;
    }

    if (activityStoppedBy) {
      updateData.activityStoppedBy = {
        name: activityStoppedBy.name,
        designation: activityStoppedBy.designation,
        department: activityStoppedBy.department,
        signatureId: activityStoppedBy.signatureId,
      };
    }

    const updatedLog = await ActivityLog.findByIdAndUpdate(
      id,
      { $set: updateData },
      { new: true, runValidators: true },
    );

    if (!updatedLog) {
      return NextResponse.json(
        { success: false, message: "Activity log entry not found" },
        { status: 404 },
      );
    }

    // ── Update signature status if activityStoppedBy provided ──
    if (activityStoppedBy?.signatureId) {
      await Signature.findByIdAndUpdate(activityStoppedBy.signatureId, {
        status: "signed",
        expiresAt: undefined,
        associatedRecordId: updatedLog._id,
        associatedRecordType: "ActivityLog",
      });
    }

    return NextResponse.json({
      success: true,
      message: "Activity log entry updated successfully",
      data: updatedLog,
    });
  } catch (error) {
    console.error("Error in area-activity-log PUT:", error);
    return NextResponse.json(
      { success: false, message: "Error updating activity log entry" },
      { status: 500 },
    );
  }
}
