import connectToDatabase from "@/lib/db";
import SigningHierarchy from "@/lib/models/SigningHierarchy";
import BatchManufacturingTemplate from "@/lib/models/BatchManufacturingTemplate";
import { NextRequest, NextResponse } from "next/server";

// Dynamic model mapping for document-specific signing workflow
const SIGNING_MODEL_MAP: Record<string, { model: any; lookupField: string }> = {
    'BatchManufacturingTemplate': { model: BatchManufacturingTemplate, lookupField: 'templateCode' },
};

export async function GET(req: NextRequest) {
    await connectToDatabase();
    try {
        const { searchParams } = new URL(req.url);
        const module = searchParams.get("module");
        const documentId = searchParams.get("documentId");
        const schemaTitle = searchParams.get("schemaTitle");

        // Search for the signing hierarchy based on the module
        const signingHierarchy = await SigningHierarchy.findOne({
            module: { $regex: new RegExp(`^${module}$`, "i") },
            status: "active"
        }).lean();

        if (!signingHierarchy) {
            return NextResponse.json({ success: false, message: "No active signing hierarchy found for this module." }, { status: 404 });
        }

        let signedByUserIds: string[] = [];
        let currentSequence = 0;

        // Check document if documentId and schemaTitle are provided
        if (documentId && schemaTitle && documentId !== '-') {
            const documentConfig = SIGNING_MODEL_MAP[schemaTitle];
            if (documentConfig) {
                const document = await documentConfig.model.findOne({ [documentConfig.lookupField]: documentId }).lean();
                if (document) {
                    // Handle Reverted/Draft documents — restart workflow
                    if (document.status === 'Reverted' || document.status === 'Draft') {
                        // Only count approved signatures, not reverted/rejected ones
                        const approvedSignatures = (document.signatures || [])
                            .filter((s: any) => s.status === 'approved' || s.status === 'signed');
                        currentSequence = approvedSignatures.length;
                        signedByUserIds = approvedSignatures.map((s: any) => s.signatoryInfo.id);
                    } else {
                        // Normal flow — check completed signatures
                        currentSequence = document.signingWorkflow?.completedSignatures || 0;

                        // Collect IDs of users who have already signed
                        signedByUserIds = (document.signatures || [])
                            .filter((s: any) => s.status === 'approved' || s.status === 'signed')
                            .map((s: any) => s.signatoryInfo.id);
                    }
                }
                // Agar document nahi mila = fresh document, first signature pending
            }
        }

        // Sort authorized persons by authorizationSequence
        const sortedPersons = [...signingHierarchy.authorizedPersons].sort(
            (a: any, b: any) => (a.authorizationSequence || 0) - (b.authorizationSequence || 0)
        );

        return NextResponse.json({
            success: true,
            message: 'Signing hierarchy found.',
            data: {
                module: signingHierarchy.module,
                signRequired: signingHierarchy.signRequired,
                authorizedPersons: sortedPersons.map((person: any) => ({
                    userId: person.userId,
                    name: person.name,
                    designation: person.designation,
                    department: person.department,
                    authorizationLevel: person.authorizationLevel,
                    authorizationSequence: person.authorizationSequence,
                })),
                signedByUserIds,
                currentSequence,
            },
        }, { status: 200 });
    } catch (error) {
        console.error("Error verifying signing permissions:", error);
        return NextResponse.json({ success: false, message: 'Error finding signing hierarchy' }, { status: 500 });
    }
}