import connectToDatabase from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import { JWT_SECRET } from "@/lib/auth";
import SigningHierarchy from "@/lib/models/SigningHierarchy";
import User from "@/lib/models/User";
import bcrypt from "bcrypt";
import Signature from "@/lib/models/Signature";
import crypto from "crypto";
import BatchManufacturingTemplate from "@/lib/models/BatchManufacturingTemplate";

// Dynamic model mapping for document-specific signing workflow
const SIGNING_MODEL_MAP: Record<string, { model: any; lookupField: string }> = {
  BatchManufacturingTemplate: {
    model: BatchManufacturingTemplate,
    lookupField: "templateCode",
  },
};

export async function POST(req: NextRequest) {
  await connectToDatabase();
  try {
    // Check Auth
    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json(
        { success: false, message: "Unauthorized" },
        { status: 401 },
      );
    }

    const token = authHeader.split(" ")[1];
    let decoded;
    let loginUserInfo;

    try {
      decoded = jwt.verify(token, JWT_SECRET) as {
        id: string;
        role: string;
      };
      loginUserInfo = await User.findById(decoded.id).lean();
      if (!loginUserInfo) {
        return NextResponse.json(
          { success: false, message: "User not found" },
          { status: 404 },
        );
      }
    } catch (err) {
      return NextResponse.json(
        { success: false, message: "Invalid token" },
        { status: 401 },
      );
    }

    const {
      selectedPerson,
      employeeId,
      password,
      remarks,
      module,
      documentId,
      schemaTitle,
      signAction,
    } = await req.json();

    // Verify signing permissions based on the module and user id
    const signingHierarchy = await SigningHierarchy.findOne({
      module: { $regex: new RegExp(`^${module}$`, "i") },
      status: "active",
    }).lean();
    if (!signingHierarchy) {
      return NextResponse.json(
        {
          success: false,
          message: "No active signing hierarchy found for this module.",
        },
        { status: 404 },
      );
    }

    const userPermission = signingHierarchy.authorizedPersons.find(
      (person: any) => {
        if (!person.userId) {
          console.warn(
            `Authorized person entry with id ${person._id} is missing userId field in signing hierarchy ${signingHierarchy._id}. Skipping this entry for permission check.`,
          );
          return false;
        }
        return person.userId.toString() === selectedPerson.toString();
      },
    );

    if (!userPermission) {
      return NextResponse.json(
        {
          success: false,
          message: "You do not have permission to sign this document.",
        },
        { status: 403 },
      );
    }

    // Verify Signer's credentials (employeeId and password)
    const signerInfo = await User.findById(selectedPerson).lean();
    if (!signerInfo) {
      return NextResponse.json(
        { success: false, message: "Signer not found." },
        { status: 401 },
      );
    }
    const isCredentialValid =
      signerInfo.employeeId === employeeId || signerInfo.email === employeeId;
    if (!isCredentialValid) {
      return NextResponse.json(
        { success: false, message: "Invalid employee ID or password." },
        { status: 401 },
      );
    }
    const isPasswordValid = await bcrypt.compare(password, signerInfo.password);
    if (!isPasswordValid) {
      return NextResponse.json(
        { success: false, message: "Invalid employee ID or password." },
        { status: 401 },
      );
    }

    // Get the sequence of signing user for this module
    const signingSequence = userPermission.authorizationSequence;

    // ── DOCUMENT VALIDATION (if documentId and schemaTitle provided) ──
    if (documentId && schemaTitle && documentId !== "-") {
      const documentConfig = SIGNING_MODEL_MAP[schemaTitle];
      if (!documentConfig) {
        return NextResponse.json(
          {
            success: false,
            message: `No signing workflow model found for: ${schemaTitle}`,
          },
          { status: 400 },
        );
      }

      const document = await documentConfig.model
        .findOne({ [documentConfig.lookupField]: documentId })
        .lean();

      // 1. Check if document exists
      if (!document) {
        return NextResponse.json(
          {
            success: false,
            message: "Document not found",
          },
          { status: 404 },
        );
      }

      // 2. Check if document has signingWorkflow configured
      if (!document.signingWorkflow) {
        return NextResponse.json(
          {
            success: false,
            message:
              "This document does not have a signing workflow configured",
          },
          { status: 400 },
        );
      }

      // 3. Check if user has already signed this document
      const alreadySigned = (document.signatures || []).some(
        (s: any) =>
          s.signatoryInfo.id === selectedPerson && s.status === "signed",
      );
      if (alreadySigned) {
        return NextResponse.json(
          {
            success: false,
            message: "You have already signed this document",
          },
          { status: 403 },
        );
      }

      // 4. Validate signing sequence
      const currentSequence = document.signingWorkflow.completedSignatures || 0;
      if (currentSequence + 1 !== signingSequence) {
        return NextResponse.json(
          {
            success: false,
            message: `This document is currently at signing stage ${currentSequence}. You are authorized to sign at stage ${signingSequence}. Please wait for the previous signatories to complete their signatures.`,
          },
          { status: 403 },
        );
      }
    } else {
      // If documentId or schemaTitle is not provided, signing is allowed only for person with authorization sequence value is equal to 1 in signing heirarchy of that module.
      if (signingSequence !== 1) {
        return NextResponse.json(
          {
            success: false,
            message:
              "You are not authorized to sign at this stage. Only users with signing sequence 1 can initiate the signing process.",
          },
          { status: 403 },
        );
      }
    }

    // Get IP and User Agent
    const forwarded = req.headers.get("x-forwarded-for");
    const ipAddress = forwarded
      ? forwarded.split(",")[0]
      : req.headers.get("x-real-ip") || "Unknown";
    const userAgent = req.headers.get("user-agent") || "Unknown";

    // Generate hash for the Signature
    const SECRET_KEY =
      process.env.SIGNATURE_KEY ||
      "SDAKJHFKJSDBERH3448RUEJWFNSDJKDBVJKHSFG287598RUKAJJDHB";

    function generateSecureHash(data: any) {
      const payload = JSON.stringify({
        module: data.module,
        selectedPerson: data.selectedPerson,
        employeeId: data.employeeId,
        timestamp: Date.now(),
        nonce: crypto.randomBytes(16).toString("hex"),
      });
      return crypto
        .createHmac("sha256", SECRET_KEY)
        .update(payload)
        .digest("hex");
    }
    const signatureHash = generateSecureHash({
      module,
      selectedPerson,
      employeeId,
    });

    // Create signature record
    const newSignatre = await Signature.create({
      module,
      signatoryId: selectedPerson,
      signatoryName: signerInfo.fullName,
      signatoryDesignation: signerInfo.designation,
      signatoryDepartment: signerInfo.department,
      signatoryAuthorizationLevel: userPermission.authorizationLevel,
      signatorySequence: signingSequence,
      remarks,
      signatureHash: signatureHash,
      signAction: signAction || "approved",
      loggedInUserId: decoded.id,
      loggedInUserName: loginUserInfo.fullName,
      loggedInUserDepartment: loginUserInfo.department,
      loggedInUserDesignation: loginUserInfo.designation,
      ipAddress,
      userAgent,
    });

    return NextResponse.json(
      {
        success: true,
        message:
          "Signature pending confirmation. Please confirm within 5 minutes.",
        data: {
          signatureId: newSignatre._id,
          module: newSignatre.module,
          status: newSignatre.status,
          expiresAt: newSignatre.expiresAt,
          signatureHash: newSignatre.signatureHash,
          signingSequence: signingSequence,
          signAction: signAction || "approved",
        },
      },
      { status: 200 },
    );
  } catch (error) {
    console.error("Error during signing process:", error);
    return NextResponse.json(
      { success: false, message: "Error during signing process" },
      { status: 500 },
    );
  }
}