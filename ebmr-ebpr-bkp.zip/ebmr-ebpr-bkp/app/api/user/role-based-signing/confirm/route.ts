import connectToDatabase from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import { JWT_SECRET } from "@/lib/auth";
import Signature from "@/lib/models/Signature";

export async function POST(req: NextRequest) {
  await connectToDatabase();
  try {
    // Check Auth
    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json(
        { success: false, message: "Unauthorized" },
        { status: 401 },
      );
    }

    const token = authHeader.split(" ")[1];
    try {
      jwt.verify(token, JWT_SECRET);
    } catch {
      return NextResponse.json(
        { success: false, message: "Invalid token" },
        { status: 401 },
      );
    }

    const { signatureId, signatureHash } = await req.json();

    if (!signatureId || !signatureHash) {
      return NextResponse.json(
        { success: false, message: "Signature ID and hash are required" },
        { status: 400 },
      );
    }

    // Find the pending signature
    const signature = await Signature.findById(signatureId);
    if (!signature) {
      return NextResponse.json(
        { success: false, message: "Signature not found" },
        { status: 404 },
      );
    }

    // Verify hash matches
    if (signature.signatureHash !== signatureHash) {
      return NextResponse.json(
        { success: false, message: "Invalid signature verification" },
        { status: 403 },
      );
    }

    // Check if already expired
    if (signature.expiresAt && new Date() > new Date(signature.expiresAt)) {
      return NextResponse.json(
        { success: false, message: "Signature has expired. Please sign again." },
        { status: 410 },
      );
    }

    // Mark as completed: remove TTL by setting expiresAt to null, update status
    signature.expiresAt = undefined;
    signature.status = "signed";
    await signature.save();

    return NextResponse.json(
      {
        success: true,
        message: "Signature confirmed successfully",
        data: {
          signatureId: signature._id,
          module: signature.module,
          status: signature.status,
        },
      },
      { status: 200 },
    );
  } catch (error) {
    console.error("Error confirming signature:", error);
    return NextResponse.json(
      { success: false, message: "Error confirming signature" },
      { status: 500 },
    );
  }
}