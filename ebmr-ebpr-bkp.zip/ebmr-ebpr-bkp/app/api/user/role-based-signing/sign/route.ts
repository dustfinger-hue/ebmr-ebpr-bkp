import connectToDatabase from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import { JWT_SECRET } from "@/lib/auth";
import User from "@/lib/models/User";
import RoleBasedSigning from "@/lib/models/RoleBasedSigning";
import Signature from "@/lib/models/Signature";
import bcrypt from "bcrypt";
import crypto from "crypto";

export async function POST(req: NextRequest) {
  await connectToDatabase();
  try {
    // Check Auth
    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json(
        { success: false, message: "Unauthorized" },
        { status: 401 },
      );
    }

    const token = authHeader.split(" ")[1];
    let decoded;
    let loginUserInfo;

    try {
      decoded = jwt.verify(token, JWT_SECRET) as {
        id: string;
        role: string;
      };
      loginUserInfo = await User.findById(decoded.id).lean();
      if (!loginUserInfo) {
        return NextResponse.json(
          { success: false, message: "User not found" },
          { status: 404 },
        );
      }
    } catch {
      return NextResponse.json(
        { success: false, message: "Invalid token" },
        { status: 401 },
      );
    }

    const {
      module: moduleName,
      sequence,
      employeeId,
      password,
    } = await req.json();

    // Validate required fields
    if (!moduleName?.trim()) {
      return NextResponse.json(
        { success: false, message: "Module name is required" },
        { status: 400 },
      );
    }
    if (!sequence || sequence < 1) {
      return NextResponse.json(
        { success: false, message: "Valid sequence is required" },
        { status: 400 },
      );
    }
    if (!employeeId?.trim()) {
      return NextResponse.json(
        { success: false, message: "Employee ID is required" },
        { status: 400 },
      );
    }
    if (!password?.trim()) {
      return NextResponse.json(
        { success: false, message: "Password is required" },
        { status: 400 },
      );
    }

    // 1. Verify user credentials (employeeId/email + password)
    const user = await User.findOne({
      $or: [{ employeeId: employeeId.trim() }, { email: employeeId.trim() }],
    }).lean();

    if (!user) {
      return NextResponse.json(
        { success: false, message: "Invalid employee ID or password" },
        { status: 401 },
      );
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return NextResponse.json(
        { success: false, message: "Invalid employee ID or password" },
        { status: 401 },
      );
    }

    // 2. Verify module + levelOfAuthorization + sequence from RoleBasedSigning
    const roleBasedModule = await RoleBasedSigning.findOne({
      moduleName: { $regex: new RegExp(`^${moduleName}$`, "i") },
      status: "active",
    }).lean();

    if (!roleBasedModule) {
      return NextResponse.json(
        { success: false, message: "No active signing module found" },
        { status: 404 },
      );
    }

    const matchingRole = roleBasedModule.roles.find(
      (r: any) =>
        r.sequence === sequence &&
        r.userRole.trim().toLowerCase() === user.role.trim().toLowerCase(),
    );

    if (!matchingRole) {
      return NextResponse.json(
        {
          success: false,
          message: "You do not have authorization to sign at this level",
        },
        { status: 403 },
      );
    }

    // Use the admin-configured levelOfAuthorization from DB
    const dbLevelOfAuthorization = matchingRole.levelOfAuthorization;

    // Verify signing user has access to create document
    // Auth check
    const hasCreateAccess = user.authorization?.some(
      (auth: any) =>
        auth.module.trim().toLowerCase() === "log book entry" &&
        auth.accessLevel.some(
          (level: string) => level.trim().toLowerCase() === "create",
        ),
    );

    if (!hasCreateAccess) {
      return NextResponse.json(
        {
          success: false,
          message:
            "You do not have authorization to create documents for this module",
        },
        { status: 403 },
      );
    }

    // Get IP and User Agent
    const forwarded = req.headers.get("x-forwarded-for");
    const ipAddress = forwarded
      ? forwarded.split(",")[0]
      : req.headers.get("x-real-ip") || "Unknown";
    const userAgent = req.headers.get("user-agent") || "Unknown";

    // Generate hash
    const SECRET_KEY =
      process.env.SIGNATURE_KEY ||
      "SDAKJHFKJSDBERH3448RUEJWFNSDJKDBVJKHSFG287598RUKAJJDHB";

    const signatureHash = crypto
      .createHmac("sha256", SECRET_KEY)
      .update(
        JSON.stringify({
          module: moduleName,
          userId: user._id,
          employeeId: employeeId.trim(),
          levelOfAuthorization: dbLevelOfAuthorization,
          sequence,
          timestamp: Date.now(),
          nonce: crypto.randomBytes(16).toString("hex"),
        }),
      )
      .digest("hex");

    // Create signature record with 5-min TTL
    const newSignature = await Signature.create({
      module: moduleName,
      signatoryId: user._id.toString(),
      signatoryName: user.fullName,
      signatoryDesignation: user.designation,
      signatoryDepartment: user.department,
      signatoryAuthorizationLevel: dbLevelOfAuthorization,
      signatorySequence: sequence,
      remarks: "auto remarks", // You can modify this as needed
      signatureHash,
      signAction: "approved",
      loggedInUserId: decoded.id,
      loggedInUserName: loginUserInfo.fullName,
      loggedInUserDepartment: loginUserInfo.department,
      loggedInUserDesignation: loginUserInfo.designation,
      ipAddress,
      userAgent,
    });

    return NextResponse.json(
      {
        success: true,
        message:
          "Signature pending confirmation. Please confirm within 5 minutes.",
        data: {
          signatureId: newSignature._id,
          name: newSignature.signatoryName,
          designation: newSignature.signatoryDesignation,
          department: newSignature.signatoryDepartment,
          userId: user._id,
          module: newSignature.module,
          status: newSignature.status,
          expiresAt: newSignature.expiresAt,
          signatureHash: newSignature.signatureHash,
          signingSequence: sequence,
          levelOfAuthorization: dbLevelOfAuthorization,
        },
      },
      { status: 200 },
    );
  } catch (error) {
    console.error("Error during role-based signing:", error);
    return NextResponse.json(
      { success: false, message: "Error during signing process" },
      { status: 500 },
    );
  }
}
