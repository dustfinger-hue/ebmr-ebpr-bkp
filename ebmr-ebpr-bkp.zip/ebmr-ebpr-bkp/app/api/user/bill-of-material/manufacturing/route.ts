import connectToDatabase from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import jwt from 'jsonwebtoken';
import { JWT_SECRET } from "@/lib/auth";
import { generateManufacturingBomCode } from "@/lib/utils/generateCode";
import ManufacturingBOM from "@/lib/models/ManufacturingBOM";
import AuditLog from "@/lib/models/UserAuditLog";

export async function POST(req: NextRequest) {
    await connectToDatabase()
    try {
        //Check Auth
        const authHeader = req.headers.get('authorization')
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            )
        }
        const token = authHeader.split(' ')[1]
        let decoded
        try {
            decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string; authorization: Array<{ module: string; accessLevel: string[] }> }
        } catch (error) {
            console.error('Error decoding token:', error)
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            )
        }

        // Check if the user has the required authorization level
        const hasAccess = decoded.authorization?.some(
            (auth) =>
                auth.module === 'Manufacturing BOM' &&
                auth.accessLevel.includes("create")
        )
        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            )
        }
        const body = await req.json()

        const {
            productCode,
            productName,
            bomVersion,
            batchSizeSemifinished,
            uom,
            bulkSize,
            bulkUom,
            effectiveDate,
            status,
            materials,
        } = body;
        if (!productCode || !productName || !bomVersion || !batchSizeSemifinished || !uom || !bulkSize || !bulkUom || !effectiveDate || !status || !materials || !Array.isArray(materials) || materials.length === 0) {
            return NextResponse.json(
                { success: false, message: "Missing required fields" },
                { status: 400 }
            );
        }

        // Generate BOM Code
        const prefix = 'MBOM';
        const bomCode = await generateManufacturingBomCode(prefix)

        const bom = await ManufacturingBOM.create({
            ...body,
            bomCode,
            createdBy: decoded.id,
        })

        // 🌍 Get IP properly
        const forwarded = req.headers.get("x-forwarded-for");
        const ipAddress = forwarded
            ? forwarded.split(",")[0]
            : req.headers.get("x-real-ip") || "Unknown";

        //Create audit log
        await AuditLog.create({
            userId: decoded.id,
            userRole: decoded.role,
            moduleName: 'Manufacturing BOM',
            recordId: bom._id,
            action: 'CREATE',
            oldData: null,
            newData: bom.toObject(),
            changedFields: Object.keys(body),
            changeReason: null,
            ipAddress,
            userAgent: req.headers.get('user-agent') || "Unknown",
        })

        return NextResponse.json(
            {
                success: true, message: `Manufacturing BOM ${bom.bomCode} created successfully!`,
                bomCode: bom.bomCode
            },
            { status: 201 }
        )
    } catch (error) {
        console.error('Error creating manufacturing BOM:', error)
        return NextResponse.json(
            { success: false, message: 'Error creating manufacturing BOM' },
            { status: 500 }
        )
    }
}
export async function GET(req: NextRequest) {
    await connectToDatabase()
    try {
        //Check Auth
        const authHeader = req.headers.get('authorization')
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            )
        }
        const token = authHeader.split(' ')[1]
        let decoded
        try {
            decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string; authorization: Array<{ module: string; accessLevel: string[] }> }
        } catch (error) {
            console.error('Error decoding token:', error)
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            )
        }

        // Check if the user has the required authorization level
        const hasAccess = decoded.authorization?.some(
            (auth) =>
                auth.module === 'Manufacturing BOM' &&
                auth.accessLevel.includes("read")
        )
        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            )
        }

        // Get query params
        const { searchParams } = new URL(req.url)

        const page = parseInt(searchParams.get('page') || "1")
        const limit = parseInt(searchParams.get('limit') || '10')
        const search = searchParams.get('search') || ''
        const bomId = searchParams.get('bomId') || ''
        const productCode = searchParams.get('productCode') || ''
        const bomCode = searchParams.get('bomCode') || ''
        const fetchAll = searchParams.get('fetchAll') || ''

        const skip = (page - 1) * limit

        //search filter
        let filter: any = {}
        if (search) {
            filter = {
                $or: [
                    { productCode: { $regex: search, $options: 'i' } },
                    { productName: { $regex: search, $options: 'i' } },
                    { bomCode: { $regex: search, $options: 'i' } }
                ]
            }
        }

        // fetch data - if fetchAll is true, return all BOMs without grouping
        if (fetchAll === 'true') {
            const data = await ManufacturingBOM.find(filter)
                .sort({ createdAt: -1 })
                .limit(limit)
                .lean()
            const total = await ManufacturingBOM.countDocuments(filter)
            return NextResponse.json(
                {
                    success: true,
                    total,
                    data
                },
                { status: 200 }
            )
        } else if (!bomId && !productCode && !bomCode) {
            const data = await ManufacturingBOM.aggregate([
                { $match: filter },
                {
                    $group: {
                        _id: "$productCode",
                        productName: { $first: "$productName" },
                        totalBoms: { $sum: 1 }
                    }
                },
                {
                    $project: {
                        _id: 0,
                        productCode: "$_id",
                        productName: "$productName",
                        totalBoms: 1
                    }
                },
                { $sort: { totalBoms: -1 } },
                { $limit: limit },
                { $skip: skip }
            ])
            const total = await ManufacturingBOM.countDocuments(filter)
            return NextResponse.json(
                {
                    success: true,
                    total,
                    data
                },
                { status: 200 }
            )
        } else if (productCode) {
            const data = await ManufacturingBOM.find({ productCode })
                .lean()
            return NextResponse.json(
                {
                    success: true,
                    data
                },
                { status: 200 }
            )
        } else if (bomCode) {
            const data = await ManufacturingBOM.find({ bomCode })
                .lean()
            return NextResponse.json(
                {
                    success: true,
                    data
                },
                { status: 200 }
            )
        } else {
            const data = await ManufacturingBOM.findById(bomId)
                .lean()
            return NextResponse.json(
                {
                    success: true,
                    data
                },
                { status: 200 }
            )
        }

    } catch (error) {
        console.error('Error fetching manufacturing BOM:', error)
        return NextResponse.json(
            { success: false, message: 'Error fetching manufacturing BOM' },
            { status: 500 }
        )
    }
}

// export async function PUT(req: NextRequest) {
//     await connectToDatabase()
//     try {
//         //Check Auth
//         const authHeader = req.headers.get('authorization')
//         if (!authHeader || !authHeader.startsWith('Bearer ')) {
//             return NextResponse.json(
//                 { success: false, message: 'Unauthorized' },
//                 { status: 401 }
//             )
//         }
//         const token = authHeader.split(' ')[1]
//         let decoded
//         try {
//             decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string; authorization: Array<{ module: string; accessLevel: string[] }> }
//         } catch (error) {
//             console.error('Error decoding token:', error)
//             return NextResponse.json(
//                 { success: false, message: 'Invalid or expired token' },
//                 { status: 401 }
//             )
//         }

//         // Check if the user has the required authorization level
//         const hasAccess = decoded.authorization?.some(
//             (auth) =>
//                 auth.module === 'Manufacturing BOM' &&
//                 auth.accessLevel.includes("update")
//         )
//         if (!hasAccess) {
//             return NextResponse.json(
//                 { success: false, message: "You are not authorized to perform this action" },
//                 { status: 403 }
//             )
//         }

//         const searchParams = new URL(req.url).searchParams
//         const id = searchParams.get('bomId') || ''
//         const body = await req.json()

//         if (!id) {
//             return NextResponse.json(
//                 { success: false, message: "BOM ID is required" },
//                 { status: 400 }
//             )
//         }

//         // Get existing BOM details
//         const bom = await ManufacturingBOM.findById(id)
//         if (!bom) {
//             return NextResponse.json(
//                 { success: false, message: "BOM not found" },
//                 { status: 404 }
//             )
//         }

//         // Update BOM
//         const updates: any = {}
//         const changedFields: any = {}

//         // Compare existing BOM details with updated BOM details
//         Object.keys(body).forEach(key => {
//             const newValue = body[key]
//             const oldValue = bom[key]
//             if (JSON.stringify(newValue) !== JSON.stringify(oldValue)) {
//                 updates[key] = newValue
//                 changedFields[key] = {
//                     old: oldValue,
//                     new: newValue
//                 }
//             }
//         })

//         // If no changes, return success
//         if (Object.keys(updates).length === 0) {
//             return NextResponse.json(
//                 { success: true, message: "No changes made" },
//                 { status: 200 }
//             )
//         }

//         // Update with reason
//         const updateData: any = { ...updates }
//         if (body.updateReason) {
//             updateData.updateReason = body.updateReason
//         }
//         updateData.updatedBy = decoded.id

//         // If BOM is being activated, deactivate other BOMs of the same product
//         if (body.status === 'Active') {
//             const validTill = new Date(body.validTill);
//             const today = new Date();

//             //remove time part
//             today.setHours(0, 0, 0, 0);

//             const maxDate = new Date()
//             maxDate.setFullYear(maxDate.getFullYear() + 5);

//             if (validTill < today) {
//                 return NextResponse.json(
//                     { success: false, message: "Valid Till date cannot be in the past" },
//                     { status: 400 }
//                 )
//             }

//             if (validTill > maxDate) {
//                 return NextResponse.json(
//                     { success: false, message: "Valid Till date cannot be more than 5 years in the future" },
//                     { status: 400 }
//                 )
//             }
//             const activeBoms = await ManufacturingBOM.find({
//                 productCode: bom.productCode,
//                 status: 'Active',
//                 _id: { $ne: id }
//             })
//             if (activeBoms.length > 0) {
//                 await ManufacturingBOM.updateMany({
//                     productCode: bom.productCode,
//                     status: 'Active',
//                     _id: { $ne: id }
//                 }, {
//                     $set: {
//                         status: 'Inactive',
//                         validTill: new Date(),
//                         updatedBy: decoded.id,
//                         updateReason: 'BOM is being activated, deactivating other active BOMs for the same product'
//                     }
//                 })
//                 //Add audit log for deactivating other active BOMs
//                 // 🌍 Get IP properly
//                 const forwarded = req.headers.get("x-forwarded-for");
//                 const ipAddress = forwarded
//                     ? forwarded.split(",")[0]
//                     : req.headers.get("x-real-ip") || "Unknown";


//                 for (const bom of activeBoms) {
//                     await AuditLog.create({
//                         userId: decoded.id,
//                         userRole: decoded.role,
//                         moduleName: 'Manufacturing BOM',
//                         recordId: bom._id,
//                         action: 'UPDATE',
//                         oldData: { status: bom.status, validTill: bom.validTill },
//                         newData: { status: "Inactive", validTill: new Date() },
//                         changedFields: Object.keys(body),
//                         changeReason: 'BOM is being activated, deactivating other active BOMs for the same product',
//                         ipAddress,
//                         userAgent: req.headers.get('user-agent') || "Unknown",
//                     })
//                 }
//             }

//         }

//         const updatedBom = await ManufacturingBOM.findByIdAndUpdate(
//             id,
//             { $set: updateData },
//             { new: true }
//         )

//         // 🌍 Get IP properly
//         const forwarded = req.headers.get("x-forwarded-for");
//         const ipAddress = forwarded
//             ? forwarded.split(",")[0]
//             : req.headers.get("x-real-ip") || "Unknown";

//         //Create audit log
//         await AuditLog.create({
//             userId: decoded.id,
//             userRole: decoded.role,
//             moduleName: 'Manufacturing BOM',
//             recordId: bom._id,
//             action: 'UPDATE',
//             oldData: Object.fromEntries(
//                 Object.entries(bom.toObject()).filter(([key]) => key !== 'materials')
//             ),
//             newData: Object.fromEntries(
//                 Object.entries(body).filter(([key]) => key !== 'materials')
//             ),
//             changedFields: Object.keys(body),
//             changeReason: null,
//             ipAddress,
//             userAgent: req.headers.get('user-agent') || "Unknown",
//         })

//         return NextResponse.json(
//             {
//                 success: true, message: `Manufacturing BOM ${bom.bomCode} updated successfully!`,
//                 bomCode: bom.bomCode,
//                 updatedBom
//             },
//             { status: 200 }
//         )

//     } catch (error) {
//         console.error('Error updating manufacturing BOM:', error)
//         return NextResponse.json(
//             { success: false, message: 'Error updating manufacturing BOM' },
//             { status: 500 }
//         )
//     }
// }
export async function PUT(req: NextRequest) {
    await connectToDatabase()

    try {

        // ---------------- AUTH CHECK ----------------
        const authHeader = req.headers.get('authorization')

        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            )
        }

        const token = authHeader.split(' ')[1]

        let decoded

        try {
            decoded = jwt.verify(token, JWT_SECRET) as {
                id: string
                role: string
                authorization: Array<{ module: string; accessLevel: string[] }>
            }
        } catch (error) {
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            )
        }

        const hasAccess = decoded.authorization?.some(
            (auth) =>
                auth.module === 'Manufacturing BOM' &&
                auth.accessLevel.includes("update")
        )

        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            )
        }

        // ---------------- PARAMS ----------------

        const searchParams = new URL(req.url).searchParams
        const id = searchParams.get('bomId') || ''

        if (!id) {
            return NextResponse.json(
                { success: false, message: "BOM ID is required" },
                { status: 400 }
            )
        }

        const body = await req.json()

        // ---------------- EXISTING BOM ----------------

        const bom = await ManufacturingBOM.findById(id)

        if (!bom) {
            return NextResponse.json(
                { success: false, message: "BOM not found" },
                { status: 404 }
            )
        }

        // ---------------- CHANGE DETECTION ----------------

        const updates: any = {}
        const changedFields: any = {}

        Object.keys(body).forEach((key) => {

            const newValue = body[key]
            const oldValue = bom[key]

            if (JSON.stringify(newValue) !== JSON.stringify(oldValue)) {
                updates[key] = newValue

                changedFields[key] = {
                    old: oldValue,
                    new: newValue
                }
            }

        })

        if (Object.keys(updates).length === 0) {
            return NextResponse.json(
                { success: true, message: "No changes made" },
                { status: 200 }
            )
        }

        const updateData: any = { ...updates }

        updateData.updatedBy = decoded.id

        if (body.updateReason) {
            updateData.updateReason = body.updateReason
        }

        // ---------------- IP ADDRESS ----------------

        const forwarded = req.headers.get("x-forwarded-for")

        const ipAddress = forwarded
            ? forwarded.split(",")[0]
            : req.headers.get("x-real-ip") || "Unknown"

        const userAgent = req.headers.get('user-agent') || "Unknown"

        // ---------------- ACTIVE BOM LOGIC ----------------

        if (body.status === "Active") {

            const validTill = new Date(body.validTill)

            const today = new Date()
            today.setHours(0, 0, 0, 0)

            const maxDate = new Date()
            maxDate.setFullYear(maxDate.getFullYear() + 5)

            if (validTill <= today) {
                return NextResponse.json(
                    { success: false, message: "Valid Till must be a future date" },
                    { status: 400 }
                )
            }

            if (validTill > maxDate) {
                return NextResponse.json(
                    { success: false, message: "Valid Till cannot exceed 5 years" },
                    { status: 400 }
                )
            }

            // Find currently active BOMs
            const activeBoms = await ManufacturingBOM.find({
                productCode: bom.productCode,
                status: "Active",
                _id: { $ne: id }
            })

            if (activeBoms.length > 0) {

                const now = new Date()

                await ManufacturingBOM.updateMany(
                    {
                        productCode: bom.productCode,
                        status: "Active",
                        _id: { $ne: id }
                    },
                    {
                        $set: {
                            status: "Inactive",
                            validTill: now,
                            updatedBy: decoded.id,
                            updateReason: "Automatically deactivated due to new BOM activation"
                        }
                    }
                )

                // Audit logs for old BOMs
                const auditLogs = activeBoms.map((oldBom) => ({
                    userId: decoded.id,
                    userRole: decoded.role,
                    moduleName: "Manufacturing BOM",
                    recordId: oldBom._id,
                    action: "UPDATE",
                    oldData: {
                        status: oldBom.status,
                        validTill: oldBom.validTill
                    },
                    newData: {
                        status: "Inactive",
                        validTill: now
                    },
                    changedFields: ["status", "validTill"],
                    changeReason: "Automatically deactivated due to new BOM activation",
                    ipAddress,
                    userAgent
                }))

                await AuditLog.insertMany(auditLogs)
            }
        }

        // ---------------- UPDATE CURRENT BOM ----------------

        const updatedBom = await ManufacturingBOM.findByIdAndUpdate(
            id,
            { $set: updateData },
            { new: true }
        )

        // ---------------- AUDIT LOG ----------------

        await AuditLog.create({
            userId: decoded.id,
            userRole: decoded.role,
            moduleName: "Manufacturing BOM",
            recordId: bom._id,
            action: "UPDATE",
            oldData: Object.fromEntries(
                Object.entries(bom.toObject()).filter(([key]) => key !== "materials")
            ),
            newData: Object.fromEntries(
                Object.entries(body).filter(([key]) => key !== "materials")
            ),
            changedFields: Object.keys(updates),
            changeReason: body.updateReason || null,
            ipAddress,
            userAgent
        })

        return NextResponse.json(
            {
                success: true,
                message: `Manufacturing BOM ${bom.bomCode} updated successfully!`,
                bomCode: bom.bomCode,
                updatedBom
            },
            { status: 200 }
        )

    } catch (error) {

        console.error("Error updating manufacturing BOM:", error)

        return NextResponse.json(
            { success: false, message: "Error updating manufacturing BOM" },
            { status: 500 }
        )

    }
}