import connectToDatabase from "@/lib/db";
import ShiftConfig from "@/lib/models/ShiftConfig";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  await connectToDatabase();
  try {
    const config = await ShiftConfig.find({ name: "Production Shift" })
      .sort({ createdAt: -1 })
      .limit(1);

    if (!config) {
      return NextResponse.json(
        { success: false, message: "No shift configuration found" },
        { status: 404 },
      );
    }

    return NextResponse.json(
      {
        success: true,
        message: "Shift configuration fetched successfully",
        config: config[0],
      },
      { status: 200 },
    );
  } catch (error) {
    console.error("Error fetching shift info:", error);
    return NextResponse.json(
      { success: false, message: "Error fetching shift info" },
      { status: 500 },
    );
  }
}
