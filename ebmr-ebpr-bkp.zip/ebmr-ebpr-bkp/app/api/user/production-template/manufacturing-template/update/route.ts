import { JWT_SECRET } from "@/lib/auth"
import connectToDatabase from "@/lib/db"
import { NextRequest, NextResponse } from "next/server"
import jwt from 'jsonwebtoken';
import BatchManufacturingTemplate from "@/lib/models/BatchManufacturingTemplate";
import SigningHierarchy from "@/lib/models/SigningHierarchy";
import AuditLog from "@/lib/models/UserAuditLog";

export async function PUT(req: NextRequest) {
    await connectToDatabase()
    try {
        // Check Auth
        const authHeader = req.headers.get('authorization')
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
        }
        const token = authHeader.split(' ')[1]
        let decoded
        try {
            decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string; authorization: Array<{ module: string; accessLevel: string }> }
        } catch (error) {
            return NextResponse.json({ success: false, message: 'Invalid or expired token' }, { status: 401 })
        }
        const hasAccess = decoded.authorization?.some((auth: any) => auth.module === 'Batch Manufacturing Template' && auth.accessLevel.includes("update"))
        if (!hasAccess) {
            return NextResponse.json({ success: false, message: "You are not authorized to perform this action" }, { status: 403 })
        }

        const { documentId, fullTemplateData, action } = await req.json()

        if (!documentId || documentId === '-') {
            return NextResponse.json({ success: false, message: "Invalid document ID" }, { status: 400 })
        }

        if (!fullTemplateData) {
            return NextResponse.json({ success: false, message: "Template data is required" }, { status: 400 })
        }

        // Find the existing document by templateCode
        const document = await BatchManufacturingTemplate.findOne({ templateCode: documentId })
        if (!document) {
            return NextResponse.json({ success: false, message: "Document not found" }, { status: 404 })
        }

        // Only allow editing if status is 'Reverted' or 'Draft'
        if (document.status !== 'Reverted' && document.status !== 'Draft') {
            return NextResponse.json({
                success: false,
                message: `Document with status '${document.status}' cannot be edited. Only Reverted or Draft documents can be edited.`
            }, { status: 403 })
        }

        // Extract basic info for top-level fields
        const basicInfo = fullTemplateData['Basic Information'] || {}

        // Update the document fields
        document.templateName = basicInfo.templateName || document.templateName
        document.productCode = String(basicInfo.productCode || document.productCode)
        document.productName = basicInfo.productName || document.productName
        document.dosageForm = basicInfo.dosageForm || document.dosageForm
        document.templateVersion = basicInfo.templateVersion || document.templateVersion
        document.fullTemplateData = fullTemplateData

        if (action === 'submit') {
            // Get signing hierarchy to reset workflow
            const signingHierarchy = await SigningHierarchy.findOne({
                module: { $regex: new RegExp('^Batch Manufacturing Template$', "i") },
                status: "active"
            }).lean()

            // Reset signing workflow
            document.signingWorkflow = {
                isSignatureComplete: false,
                totalSignaturesRequired: signingHierarchy?.signRequired || document.signingWorkflow.totalSignaturesRequired,
                completedSignatures: 0,
                lastSignedAt: null
            }

            // Clear existing signatures
            document.signatures = []

            // Set status to Pending Signatures so user signs again
            document.status = 'Pending Signatures'
        } else {
            // action === 'save' just updates data, keep as Draft
            document.status = 'Draft'
        }

        await document.save()

        // Create audit log
        const forwarded = req.headers.get("x-forwarded-for");
        const ipAddress = forwarded
            ? forwarded.split(",")[0]
            : req.headers.get("x-real-ip") || "Unknown";

        await AuditLog.create({
            userId: decoded.id,
            userRole: decoded.role,
            moduleName: 'Batch Manufacturing Template',
            recordId: document._id,
            action: 'UPDATE',
            oldData: null,
            newData: {
                actionPerformed: action === 'submit' ? 'submit-after-edit' : 'save-edit',
                templateCode: document.templateCode,
                newStatus: document.status
            },
            changedFields: ['fullTemplateData', 'status', 'signingWorkflow', 'signatures'],
            changeReason: action === 'submit' ? 'Document edited and submitted for signing' : 'Document edited and saved as draft',
            ipAddress,
            userAgent: req.headers.get('user-agent') || "Unknown",
        });

        return NextResponse.json({
            success: true,
            message: action === 'submit'
                ? 'Document updated and submitted for signing successfully!'
                : 'Document updated successfully as draft!',
            data: {
                templateCode: document.templateCode,
                status: document.status,
            }
        }, { status: 200 })

    } catch (error) {
        console.error('Error updating batch manufacturing template:', error)
        return NextResponse.json({ success: false, message: 'Error updating batch manufacturing template' }, { status: 500 })
    }
}