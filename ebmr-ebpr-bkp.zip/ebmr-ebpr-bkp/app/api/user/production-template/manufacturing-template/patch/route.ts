import { JWT_SECRET } from "@/lib/auth";
import connectToDatabase from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import BatchManufacturingTemplate from "@/lib/models/BatchManufacturingTemplate";
import Signature from "@/lib/models/Signature";
import SigningHierarchy from "@/lib/models/SigningHierarchy";
import AuditLog from "@/lib/models/UserAuditLog";
import User from "@/lib/models/User";

export async function POST(req: NextRequest) {
  await connectToDatabase();
  try {
    // Check Auth
    const authHeader = req.headers.get("authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json(
        { success: false, message: "Unauthorized" },
        { status: 401 },
      );
    }
    const token = authHeader.split(" ")[1];
    let decoded;
    try {
      decoded = jwt.verify(token, JWT_SECRET) as {
        id: string;
        role: string;
        authorization: Array<{ module: string; accessLevel: string }>;
      };
    } catch (error) {
      return NextResponse.json(
        { success: false, message: "Invalid or expired token" },
        { status: 401 },
      );
    }
    const hasAccess = decoded.authorization?.some(
      (auth: any) =>
        auth.module === "Batch Manufacturing Template" &&
        auth.accessLevel.includes("update"),
    );
    if (!hasAccess) {
      return NextResponse.json(
        {
          success: false,
          message: "You are not authorized to perform this action",
        },
        { status: 403 },
      );
    }

    const { signingData, module, documentId } = await req.json();
    const signAction = signingData.signAction || "approved";
    const templateCode = documentId;

    if (!templateCode || templateCode === "-") {
      return NextResponse.json(
        { success: false, message: "Invalid document ID" },
        { status: 400 },
      );
    }

    // Find the existing document
    const document = await BatchManufacturingTemplate.findOne({ templateCode });
    if (!document) {
      return NextResponse.json(
        { success: false, message: "Document not found" },
        { status: 404 },
      );
    }

    // Verify signing hierarchy
    const signingHierarchy = await SigningHierarchy.findOne({
      module: { $regex: new RegExp(`^${module}$`, "i") },
      status: "active",
    }).lean();
    if (!signingHierarchy) {
      return NextResponse.json(
        {
          success: false,
          message: "No active signing hierarchy found for this module.",
        },
        { status: 404 },
      );
    }

    // Validate signing sequence
    const signingSequence = signingData.signingSequence || 0;
    const currentSequence = document.signingWorkflow?.completedSignatures || 0;
    if (currentSequence + 1 !== signingSequence) {
      return NextResponse.json(
        {
          success: false,
          message: `This document is currently at signing stage ${currentSequence}. You are authorized to sign at stage ${signingSequence}.`,
        },
        { status: 403 },
      );
    }

    // Check if user already signed
    const signatureDetails = await Signature.findById(signingData.signatureId);
    const alreadySigned = (document.signatures || []).some(
      (s: any) =>
        s.signatoryInfo?.id === signatureDetails?.signatoryId &&
        s.status === "signed",
    );
    if (alreadySigned) {
      return NextResponse.json(
        { success: false, message: "You have already signed this document" },
        { status: 403 },
      );
    }

    // Check if the signing user is authorized to modify the document
    const findSigningUser = await User.findById(
      signatureDetails?.signatoryId,
    ).lean();
    if (!findSigningUser) {
      return NextResponse.json(
        { success: false, message: "Signing user not found" },
        { status: 404 },
      );
    }

    const hasAccessToModify = findSigningUser.authorization?.some(
      (auth: any) =>
        auth.module === "Batch Manufacturing Template" &&
        auth.accessLevel.includes("update"),
    );
    if (!hasAccessToModify) {
      return NextResponse.json(
        {
          success: false,
          message:
            "You are not authorized to perform this action. Please contact your administrator.",
        },
        { status: 403 },
      );
    }

    // Push new signature to document
    document.signatures.push({
      signatureRef: signingData.signatureId,
      signatureHash: signingData.signatureHash,
      action: signAction,
      signatoryInfo: {
        id: signatureDetails?.signatoryId || "",
        name: signatureDetails?.signatoryName || "",
        designation: signatureDetails?.signatoryDesignation || "",
        department: signatureDetails?.signatoryDepartment || "",
        authorizationLevel: signatureDetails?.signatoryAuthorizationLevel || "",
        authorizationSequence:
          signatureDetails?.signatorySequence || signingSequence,
      },
      status: signAction === "approved" ? "signed" : signAction,
      signedAt: signatureDetails?.createdAt || new Date(),
    });

    // Update workflow based on action
    document.signingWorkflow.lastSignedAt =
      signatureDetails?.createdAt || new Date();

    if (signAction === "approved") {
      document.signingWorkflow.completedSignatures =
        (document.signingWorkflow.completedSignatures || 0) + 1;
      if (
        document.signingWorkflow.completedSignatures >=
        document.signingWorkflow.totalSignaturesRequired
      ) {
        document.signingWorkflow.isSignatureComplete = true;

        // When this document becomes active, retire the previous active template for the same product.
        const previousVersion = await BatchManufacturingTemplate.findOne({
          productCode: String(document.productCode),
          status: "Active",
          _id: { $ne: document._id },
        }).sort({ updatedAt: -1, createdAt: -1 });

        if (previousVersion) {
          previousVersion.status = "Inactive";
          previousVersion.supersededBy = document._id;
          previousVersion.supersededTemplateVersion = document.templateVersion;

          // Also update the status history of the superseded version for audit trail
          previousVersion.statusHistory.push({
            status: "Inactive",
            changedAt: new Date(),
            changedBy: {
              id: decoded.id,
              name: findSigningUser.fullName || "Unknown User",
              signatureRef: signingData.signatureId,
              signatureHash: signingData.signatureHash,
            },
          });
          await previousVersion.save();
        }

        // Activate the new version only after successfully superseding the previous version to maintain data integrity
        document.status = "Active";
        if (previousVersion) {
          document.supersedes = previousVersion._id;
        }

        // Also add status history for the newly activated version
        document.statusHistory.push({
          status: "Active",
          changedAt: new Date(),
          changedBy: {
            id: decoded.id,
            name: findSigningUser.fullName || "Unknown User",
            signatureRef: signingData.signatureId,
            signatureHash: signingData.signatureHash,
          },
        });
      }
    } else if (signAction === "rejected") {
      document.signingWorkflow.isSignatureComplete = true;
      document.status = "Rejected";
    } else if (signAction === "reverted") {
      document.signingWorkflow.isSignatureComplete = true;
      document.status = "Reverted";
    }

    await document.save();

    // Update Signature collection
    await Signature.findByIdAndUpdate(signingData.signatureId, {
      $set: {
        associatedRecordId: document._id,
        associatedRecordType: "BatchManufacturingTemplate",
        status: signAction === "approved" ? "signed" : signAction,
      },
      $unset: { expiresAt: "" },
    });

    // Create audit log
    const forwarded = req.headers.get("x-forwarded-for");
    const ipAddress = forwarded
      ? forwarded.split(",")[0]
      : req.headers.get("x-real-ip") || "Unknown";

    await AuditLog.create({
      userId: decoded.id,
      userRole: decoded.role,
      moduleName: "Batch Manufacturing Template",
      recordId: document._id,
      action: "UPDATE",
      oldData: null,
      newData: { actionPerformed: signAction, signingSequence },
      changedFields: ["signatures", "signingWorkflow", "status"],
      changeReason: `Signature action: ${signAction} by sequence ${signingSequence}`,
      ipAddress,
      userAgent: req.headers.get("user-agent") || "Unknown",
    });

    return NextResponse.json(
      {
        success: true,
        message: `Document ${signAction === "approved" ? "approved" : signAction === "rejected" ? "rejected" : "reverted"} successfully`,
        data: {
          status: document.status,
          completedSignatures: document.signingWorkflow.completedSignatures,
          isSignatureComplete: document.signingWorkflow.isSignatureComplete,
        },
      },
      { status: 200 },
    );
  } catch (error) {
    console.error("Error updating document signatures:", error);
    return NextResponse.json(
      { success: false, message: "Error signing document" },
      { status: 500 },
    );
  }
}
