import { JWT_SECRET } from "@/lib/auth"
import connectToDatabase from "@/lib/db"
import { NextRequest, NextResponse } from "next/server"
import jwt from 'jsonwebtoken';
import BatchManufacturingTemplate from "@/lib/models/BatchManufacturingTemplate";
import Signature from "@/lib/models/Signature";
import SigningHierarchy from "@/lib/models/SigningHierarchy";
import { generateManufacturingTemplateCode } from "@/lib/utils/generateCode";
import AuditLog from "@/lib/models/UserAuditLog";


export async function GET(req: NextRequest) {
    await connectToDatabase()
    try {
        //check Auth
        const authHeader = req.headers.get('authorization')
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
        }
        const token = authHeader.split(' ')[1]
        let decoded
        try {
            decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string; authorization: Array<{ module: string; accessLevel: string[] }> }
        } catch (error) {
            console.error('Error decoding token:', error)
            return NextResponse.json({ success: false, message: 'Invalid or expired token' }, { status: 401 })
        }
        const hasAccess = decoded.authorization?.some((auth: any) => auth.module === 'Batch Manufacturing Template' && auth.accessLevel.includes("read"))
        if (!hasAccess) {
            return NextResponse.json({ success: false, message: "You are not authorized to perform this action" }, { status: 403 })
        }

        // Get query params
        const { searchParams } = new URL(req.url)

        const page = parseInt(searchParams.get('page') || '1')
        const limit = parseInt(searchParams.get('limit') || '10')
        const search = searchParams.get('search') || ''
        const productCode = searchParams.get('productCode') || ''
        const groupByProduct = searchParams.get('groupByProduct') === 'true'

        // Build dynamic filter
        const filter: any = {};
        const id = searchParams.get('id') || '';
        if (id) {
            filter._id = id;
        }
        if (productCode) {
            filter.productCode = productCode;
        }
        if (search) {
            filter.$or = [
                { templateCode: { $regex: search, $options: 'i' } },
                { templateName: { $regex: search, $options: 'i' } },
                { productName: { $regex: search, $options: 'i' } },
                { productCode: { $regex: search, $options: 'i' } },
            ];
        }

        // If fetching by specific id, return single document
        if (id) {
            const data = await BatchManufacturingTemplate.findById(id).lean();
            if (!data) {
                return NextResponse.json({ success: false, message: 'Document not found' }, { status: 404 });
            }
            return NextResponse.json({ success: true, data }, { status: 200 });
        }

        // If grouping by product, use aggregation to avoid loading fullTemplateData
        if (groupByProduct) {
            const matchFilter: any = { ...filter };

            // Build search stage for aggregation if search is provided
            const pipeline: any[] = [
                { $match: matchFilter },
                // Convert productCode to string to handle Number/String type mismatch
                {
                    $addFields: {
                        productCodeStr: { $toString: "$productCode" }
                    }
                },
                {
                    $group: {
                        _id: '$productCodeStr',
                        productCode: { $first: '$productCodeStr' },
                        productName: { $first: '$productName' },
                        dosageForm: { $first: '$dosageForm' },
                        totalTemplates: { $sum: 1 },
                        activeTemplates: {
                            $sum: { $cond: [{ $eq: ['$status', 'Active'] }, 1, 0] }
                        },
                        pendingTemplates: {
                            $sum: { $cond: [{ $eq: ['$status', 'Pending Signatures'] }, 1, 0] }
                        },
                        draftTemplates: {
                            $sum: { $cond: [{ $eq: ['$status', 'Draft'] }, 1, 0] }
                        },
                        latestVersion: { $max: '$templateVersion' },
                        latestTemplateCode: { $first: '$templateCode' },
                        latestCreatedAt: { $max: '$createdAt' },
                    }
                },
                {
                    $project: {
                        _id: 0,
                        productCode: 1,
                        productName: 1,
                        dosageForm: 1,
                        totalTemplates: 1,
                        activeTemplates: 1,
                        pendingTemplates: 1,
                        draftTemplates: 1,
                        latestVersion: 1,
                        latestTemplateCode: 1,
                        latestCreatedAt: 1,
                    }
                },
                { $sort: { productName: 1 } },
                { $skip: (page - 1) * limit },
                { $limit: limit }
            ];

            // Count total grouped documents
            const countPipeline: any[] = [
                { $match: matchFilter },
                {
                    $addFields: {
                        productCodeStr: { $toString: "$productCode" }
                    }
                },
                {
                    $group: {
                        _id: '$productCodeStr'
                    }
                },
                { $count: 'total' }
            ];

            const [groupedData, countResult] = await Promise.all([
                BatchManufacturingTemplate.aggregate(pipeline),
                BatchManufacturingTemplate.aggregate(countPipeline)
            ]);

            const total = countResult[0]?.total || 0;

            return NextResponse.json(
                {
                    success: true,
                    data: groupedData,
                    pagination: {
                        total,
                        page,
                        limit,
                        totalPages: Math.ceil(total / limit)
                    }
                },
                { status: 200 }
            );
        }

        // Apply pagination for list queries
        const skip = (page - 1) * limit;
        const total = await BatchManufacturingTemplate.countDocuments(filter);
        const data = await BatchManufacturingTemplate.find(filter)
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit)
            .lean();

        return NextResponse.json(
            {
                success: true,
                data,
                pagination: {
                    total,
                    page,
                    limit,
                    totalPages: Math.ceil(total / limit)
                }
            },
            { status: 200 }
        )

    } catch (error) {
        console.error('Error fetching batch manufacturing templates:', error)
        return NextResponse.json({ success: false, message: 'Error fetching batch manufacturing templates' }, { status: 500 })
    }

}
export async function POST(req: NextRequest) {
    await connectToDatabase()
    try {
        //check Auth
        const authHeader = req.headers.get('authorization')
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
        }
        const token = authHeader.split(' ')[1]
        let decoded
        try {
            decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string; authorization: Array<{ module: string; accessLevel: string }> }
        } catch (error) {
            console.error('Error decoding token:', error)
            return NextResponse.json({ success: false, message: 'Invalid or expired token' }, { status: 401 })
        }
        const hasAccess = decoded.authorization?.some((auth: any) => auth.module === 'Batch Manufacturing Template' && auth.accessLevel.includes("create"))
        if (!hasAccess) {
            return NextResponse.json({ success: false, message: "You are not authorized to perform this action" }, { status: 403 })
        }

        const { signingData, fullTemplateData, module } = await req.json()
        const signAction = signingData.signAction || 'approved'

        // Get the sign details from the Signature collection using signingData.signatureId
        const signatureDetails = await Signature.findById(signingData.signatureId)

        // Get the total required signatures for this module from the SigningHierarchy collection
        const signingHierarchy = await SigningHierarchy.findOne({
            module: { $regex: new RegExp(`^${module}$`, "i") },
            status: "active"
        }).lean();
        if (!signingHierarchy) {
            return NextResponse.json({ success: false, message: "No active signing hierarchy found for this module." }, { status: 404 });
        }

        // Generate new template code using the utility function
        const prefix = 'BMT'
        const templateCode = await generateManufacturingTemplateCode(prefix)

        // Determine template status based on action
        let templateStatus = 'Pending Signatures';
        if (signAction === 'rejected') {
            templateStatus = 'Rejected';
        } else if (signAction === 'reverted') {
            templateStatus = 'Reverted';
        }

        // Ensure productCode is stored as string to avoid type mismatch in aggregations
        const productCodeValue = String(fullTemplateData['Basic Information'].productCode || '');

        const newTemplate = new BatchManufacturingTemplate({
            // Basic fields
            templateCode,
            templateName: fullTemplateData['Basic Information'].templateName,
            productCode: productCodeValue,
            productName: fullTemplateData['Basic Information'].productName,
            dosageForm: fullTemplateData['Basic Information'].dosageForm,
            status: templateStatus,

            // Complete nested data 
            fullTemplateData,

            // Versioning
            templateVersion: fullTemplateData['Basic Information'].templateVersion,

            // Initial signature entry with detailed info
            signatures: [{
                signatureRef: signingData.signatureId,
                signatureHash: signingData.signatureHash,
                action: signAction,
                signatoryInfo: {
                    id: signatureDetails?.signatoryId || '',
                    name: signatureDetails?.signatoryName || '',
                    designation: signatureDetails?.signatoryDesignation || '',
                    department: signatureDetails?.signatoryDepartment || '',
                    authorizationLevel: signatureDetails?.signatoryAuthorizationLevel || '',
                    authorizationSequence: signatureDetails?.signatorySequence || 1,
                },
                status: signAction === 'approved' ? 'signed' : signAction,
                signedAt: signatureDetails.createdAt,
            }],

            // Workflow tracking — completedSignatures only increments for approved
            signingWorkflow: {
                isSignatureComplete: signAction !== 'approved',
                totalSignaturesRequired: signingHierarchy.signRequired,
                completedSignatures: signAction === 'approved' ? 1 : 0,
                lastSignedAt: signatureDetails.createdAt
            }
        })

        // Update signature status in Signature collection based on action
        await Signature.findByIdAndUpdate(signingData.signatureId, {
            $set: {
                associatedRecordId: newTemplate._id,
                associatedRecordType: 'BatchManufacturingTemplate',
                status: signAction === 'approved' ? 'signed' : signAction,
            },
            $unset: { expiresAt: "" }
        })
        await newTemplate.save()

        // Now create audit log for template creation with user and IP details
        // Get IP properly
        const forwarded = req.headers.get("x-forwarded-for");
        const ipAddress = forwarded
            ? forwarded.split(",")[0]
            : req.headers.get("x-real-ip") || "Unknown";

        // Create audit log
        await AuditLog.create({
            userId: decoded.id,
            userRole: decoded.role,
            moduleName: 'Batch Manufacturing Template',
            recordId: newTemplate._id,
            action: 'CREATE',
            oldData: null,
            newData: newTemplate.toObject(),
            changedFields: Object.keys(fullTemplateData), // Assuming all fields from the form are changed/added
            changeReason: null,
            ipAddress,
            userAgent: req.headers.get('user-agent') || "Unknown",
        });

        return NextResponse.json({
            success: true,
            message: 'Batch manufacturing template created successfully',
            data: newTemplate._id
        }, { status: 201 })

    } catch (error) {
        console.error('Error creating batch manufacturing template:', error)
        return NextResponse.json({ success: false, message: 'Error creating batch manufacturing template' }, { status: 500 })
    }
}