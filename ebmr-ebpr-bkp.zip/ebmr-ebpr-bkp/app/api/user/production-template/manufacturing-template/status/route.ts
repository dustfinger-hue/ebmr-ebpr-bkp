import { JWT_SECRET } from "@/lib/auth";
import connectToDatabase from "@/lib/db";
import BatchManufacturingTemplate from "@/lib/models/BatchManufacturingTemplate";
import AuditLog from "@/lib/models/UserAuditLog";
import User from "@/lib/models/User";
import jwt from "jsonwebtoken";
import { NextRequest, NextResponse } from "next/server";

type TemplateStatus =
  | "Draft"
  | "Pending Signatures"
  | "Active"
  | "Inactive"
  | "Superseded"
  | "Rejected"
  | "Reverted";

const MANUAL_STATUS_HASH = "manual-status-change";

export async function PATCH(req: NextRequest) {
  await connectToDatabase();

  try {
    const authHeader = req.headers.get("authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json(
        { success: false, message: "Unauthorized" },
        { status: 401 },
      );
    }

    const token = authHeader.split(" ")[1];
    let decoded;
    try {
      decoded = jwt.verify(token, JWT_SECRET) as {
        id: string;
        role: string;
        authorization: Array<{ module: string; accessLevel: string[] }>;
      };
    } catch (error) {
      return NextResponse.json(
        { success: false, message: "Invalid or expired token" },
        { status: 401 },
      );
    }

    const hasAccess = decoded.authorization?.some(
      (auth: any) =>
        auth.module === "Batch Manufacturing Template" &&
        auth.accessLevel.includes("update"),
    );
    if (!hasAccess) {
      return NextResponse.json(
        {
          success: false,
          message: "You are not authorized to perform this action",
        },
        { status: 403 },
      );
    }

    const { documentId, newStatus, reason } = (await req.json()) as {
      documentId?: string;
      newStatus?: TemplateStatus;
      reason?: string;
    };

    if (!documentId) {
      return NextResponse.json(
        { success: false, message: "Document ID is required" },
        { status: 400 },
      );
    }

    if (!newStatus || !["Active", "Inactive"].includes(newStatus)) {
      return NextResponse.json(
        {
          success: false,
          message: "Only Active and Inactive status changes are allowed",
        },
        { status: 400 },
      );
    }

    if (!reason?.trim()) {
      return NextResponse.json(
        { success: false, message: "Reason is required" },
        { status: 400 },
      );
    }

    const document = await BatchManufacturingTemplate.findById(documentId);
    if (!document) {
      return NextResponse.json(
        { success: false, message: "Document not found" },
        { status: 404 },
      );
    }

    if (document.status === "Superseded") {
      return NextResponse.json(
        {
          success: false,
          message: "Superseded documents cannot be activated again",
        },
        { status: 400 },
      );
    }

    if (!["Active", "Inactive"].includes(document.status)) {
      return NextResponse.json(
        {
          success: false,
          message: `Status cannot be changed for '${document.status}' documents`,
        },
        { status: 400 },
      );
    }

    if (document.status === newStatus) {
      return NextResponse.json(
        { success: false, message: `Document is already ${newStatus}` },
        { status: 400 },
      );
    }

    const user = await User.findById(decoded.id).lean();
    const changedBy = {
      id: decoded.id,
      name: user?.fullName || "Unknown User",
      signatureHash: MANUAL_STATUS_HASH,
    };

    let deactivatedTemplate = null;
    if (newStatus === "Active") {
      deactivatedTemplate = await BatchManufacturingTemplate.findOne({
        _id: { $ne: document._id },
        productCode: String(document.productCode),
        status: "Active",
      }).sort({ updatedAt: -1, createdAt: -1 });

      if (deactivatedTemplate) {
        deactivatedTemplate.status = "Inactive";
        deactivatedTemplate.statusHistory.push({
          status: "Inactive",
          changedAt: new Date(),
          changedBy,
        });
        await deactivatedTemplate.save();
      }
    }

    const oldStatus = document.status;
    document.status = newStatus;
    document.statusHistory.push({
      status: newStatus,
      changedAt: new Date(),
      changedBy,
    });
    await document.save();

    const forwarded = req.headers.get("x-forwarded-for");
    const ipAddress = forwarded
      ? forwarded.split(",")[0]
      : req.headers.get("x-real-ip") || "Unknown";

    await AuditLog.create({
      userId: decoded.id,
      userRole: decoded.role,
      moduleName: "Batch Manufacturing Template",
      recordId: document._id,
      action: "UPDATE",
      oldData: { status: oldStatus },
      newData: {
        status: newStatus,
        reason,
        deactivatedTemplateCode: deactivatedTemplate?.templateCode,
      },
      changedFields: ["status", "statusHistory"],
      changeReason: reason.trim(),
      ipAddress,
      userAgent: req.headers.get("user-agent") || "Unknown",
    });

    return NextResponse.json(
      {
        success: true,
        message: "Template status updated successfully",
        data: {
          status: document.status,
          deactivatedTemplateCode: deactivatedTemplate?.templateCode,
        },
      },
      { status: 200 },
    );
  } catch (error) {
    console.error("Error updating template status:", error);
    return NextResponse.json(
      { success: false, message: "Error updating template status" },
      { status: 500 },
    );
  }
}
