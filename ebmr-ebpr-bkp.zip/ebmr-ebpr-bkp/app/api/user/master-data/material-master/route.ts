import connectToDatabase from "@/lib/db";
import MaterialMaster from "@/lib/models/MaterialMaster";
import { generateMaterialCode } from "@/lib/utils/generateCode";
import { NextRequest, NextResponse } from "next/server";
import jwt from 'jsonwebtoken';
import { JWT_SECRET } from "@/lib/auth";
import AuditLog from "@/lib/models/UserAuditLog"
import User from "@/lib/models/User";

export async function POST(req: NextRequest) {

    try {
        await connectToDatabase()

        //Check Auth
        const authHeader = req.headers.get('authorization')
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            )
        }
        const token = authHeader.split(' ')[1]
        let decoded
        try {
            decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string; authorization: Array<{ module: string; accessLevel: string[] }> }
        } catch (error) {
            console.error('Error decoding token:', error)
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            )
        }

        // RBAC Check
        if (decoded.authorization.some(auth => auth.module === 'Material Master' && auth.accessLevel.includes('create'))) {
            const body = await req.json()

            //Generate Material Code
            const materialCode = await generateMaterialCode(body.category)

            //Create material
            const material = await MaterialMaster.create({
                ...body,
                materialCode,
                createdBy: decoded.id,
                createdAt: new Date(),
            })

            // 🌍 Get IP properly
            const forwarded = req.headers.get("x-forwarded-for");
            const ipAddress = forwarded
                ? forwarded.split(",")[0]
                : req.headers.get("x-real-ip") || "Unknown";

            //Create audit log
            await AuditLog.create({
                userId: decoded.id,
                userRole: decoded.role,
                moduleName: 'Material Master',
                recordId: material._id,
                action: 'CREATE',
                oldData: null,
                newData: material.toObject(),
                changedFields: Object.keys(body),
                changeReason: null,
                ipAddress,
                userAgent: req.headers.get('user-agent') || "Unknown",
            })



            return NextResponse.json({ success: true, message: 'Material created successfully!', material }, { status: 201 })
        } else {
            return NextResponse.json(
                { success: false, message: 'Forbidden' },
                { status: 403 }
            )
        }

    } catch (error: any) {
        console.error('Error creating material:', error)
        if (error.code === 11000) {
            return NextResponse.json(
                { success: false, message: "Duplicate Material Code" },
                { status: 400 }
            );
        } else {
            return NextResponse.json(
                { success: false, message: "Internal server error" },
                { status: 500 }
            );
        }
    }
}

export async function GET(req: NextRequest) {
    await connectToDatabase()
    try {

        const { searchParams } = new URL(req.url);

        const page = parseInt(searchParams.get('page') || '1');
        const limit = parseInt(searchParams.get('limit') || '10');
        const search = searchParams.get('search') || '';
        const id = searchParams.get('id') || '';

        // Advanced filters
        const category = searchParams.get('category') || '';
        const type = searchParams.get('type') || '';
        const status = searchParams.get('status') || '';
        const storageCondition = searchParams.get('storageCondition') || '';

        const skip = (page - 1) * limit;

        const query: any = {}

        // Search functionality
        if (search) {
            query.$or = [
                { materialCode: { $regex: search, $options: 'i' } },
                { materialName: { $regex: search, $options: 'i' } },
                { shortName: { $regex: search, $options: 'i' } },
                { description: { $regex: search, $options: 'i' } },
                { category: { $regex: search, $options: 'i' } },
                { type: { $regex: search, $options: 'i' } }
            ]
        }

        // Advanced filters
        if (category) {
            query.category = category;
        }

        if (type) {
            query.type = type;
        }

        if (status) {
            query.status = status;
        }

        if (storageCondition) {
            query.storageCondition = { $in: [storageCondition] };
        }
        if (id) {
            query._id = id;
            const material = await MaterialMaster.findOne(query)
            if (!material) {
                return NextResponse.json(
                    { success: false, message: 'Material not found' },
                    { status: 404 }
                );
            }
            const createdBy = await User.findById(material.createdBy)
                .select('fullName employeeId designation')

            const updatedBy = await User.findById(material.updatedBy)
                .select('fullName employeeId designation')

            const deletedBy = await User.findById(material.updatedBy)
                .select('fullName employeeId designation')

            const materialWithCreatedBy = {
                ...material.toObject(),
                createdBy: createdBy ? {
                    fullName: createdBy.fullName,
                    employeeId: createdBy.employeeId,
                    designation: createdBy.designation
                } : null,
                updatedBy: updatedBy ? {
                    fullName: updatedBy.fullName,
                    employeeId: updatedBy.employeeId,
                    designation: updatedBy.designation
                } : null,
                deletedBy: deletedBy ? {
                    fullName: deletedBy.fullName,
                    employeeId: deletedBy.employeeId,
                    designation: deletedBy.designation
                } : null
            }


            return NextResponse.json({ success: true, message: 'Material fetched successfully', material: materialWithCreatedBy }, { status: 200 })
        }

        const materials = await MaterialMaster.find(query)
            .select('materialCode materialName description category type status createdAt _id')
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit)

        const total = await MaterialMaster.countDocuments(query)


        return NextResponse.json({
            success: true,
            message: 'Materials fetched successfully',
            materials,
            total,
            page,
            limit,
        })
    } catch (error: any) {
        console.error('Error fetching materials:', error)
        return NextResponse.json(
            { success: false, message: 'Internal server error' },
            { status: 500 })
    }
}
