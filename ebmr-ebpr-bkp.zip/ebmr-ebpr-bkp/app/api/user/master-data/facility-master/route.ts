import connectToDatabase from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import jwt from 'jsonwebtoken';
import { JWT_SECRET } from "@/lib/auth";
import FacilityMaster from "@/lib/models/FacilityMaster";
import AuditLog from "@/lib/models/UserAuditLog";
import { generateFacilityCode } from "@/lib/utils/generateCode";

export async function GET(req: NextRequest) {
    await connectToDatabase();
    try {
        const { searchParams } = new URL(req.url)

        const page = parseInt(searchParams.get('page') || '1');
        const limit = parseInt(searchParams.get('limit') || '10');
        const search = searchParams.get('search') || '';
        const facilityId = searchParams.get('facilityId') || '';
        const facilityCode = searchParams.get('facilityCode') || '';

        // Filters
        const areaType = searchParams.get('areaType') || '';
        const status = searchParams.get('status') || '';
        const department = searchParams.get('department') || '';
        const blockBuilding = searchParams.get('blockBuilding') || '';
        const cleanRoomGrade = searchParams.get('cleanRoomGrade') || '';

        // Build query
        const query: any = { isDeleted: false };

        if (search) {
            query.$or = [
                { areaName: { $regex: search, $options: 'i' } },
                { facilityCode: { $regex: search, $options: 'i' } },
                { blockBuilding: { $regex: search, $options: 'i' } },
                { floor: { $regex: search, $options: 'i' } },
            ];
        }

        if (areaType) query.areaType = areaType;
        if (status) query.status = status;
        if (department) query.department = department;
        if (blockBuilding) query.blockBuilding = blockBuilding;
        if (cleanRoomGrade) query.cleanRoomGrade = cleanRoomGrade;
        if (facilityId) query._id = facilityId;
        if (facilityCode) query.facilityCode = facilityCode;

        const skip = (page - 1) * limit;

        let facilityQuery = FacilityMaster.find(query);

        // If not single facility (list mode), select only required fields
        const isSingleFacilityMode = Boolean(facilityId || facilityCode);
        if (!isSingleFacilityMode) {
            facilityQuery = facilityQuery.select(
                "facilityCode areaName blockBuilding floor department areaType status cleanRoomGrade"
            );
        }

        const [facilities, total] = await Promise.all([
            facilityQuery
                .sort({ createdAt: -1 })
                .skip(isSingleFacilityMode ? 0 : skip)
                .limit(isSingleFacilityMode ? 1 : limit)
                .lean(),
            isSingleFacilityMode ? Promise.resolve(1) : FacilityMaster.countDocuments(query)
        ]);

        //create filter based on distinct values in the database for areaType, status, department, blockBuilding, cleanRoomGrade
        const areaTypes = await FacilityMaster.distinct("areaType", { isDeleted: false });
        const statuses = await FacilityMaster.distinct("status", { isDeleted: false });
        const departments = await FacilityMaster.distinct("department", { isDeleted: false });
        const blockBuildings = await FacilityMaster.distinct("blockBuilding", { isDeleted: false });
        const cleanRoomGrades = await FacilityMaster.distinct("cleanRoomGrade", { isDeleted: false });

        const filterOptions = {
            areaTypes,
            statuses,
            departments,
            blockBuildings,
            cleanRoomGrades
        };

        return NextResponse.json({
            success: true,
            facilities,
            total,
            filterOptions,
            page,
            limit
        });
    } catch (error) {
        console.error('Error fetching facilities:', error);
        return NextResponse.json(
            { success: false, message: 'Error fetching facilities' },
            { status: 500 }
        );
    }
}

export async function POST(req: NextRequest) {
    await connectToDatabase();
    try {
        // Check Auth
        const authHeader = req.headers.get('authorization');
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            );
        }

        const token = authHeader.split(' ')[1];
        let decoded;

        try {
            decoded = jwt.verify(token, JWT_SECRET) as {
                id: string;
                role: string;
                authorization: Array<{ module: string; accessLevel: string[] }>
            };
        } catch (error) {
            console.error('Error decoding token:', error);
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            );
        }

        // RBAC Check
        const hasAccess = decoded.authorization?.some(
            (auth) =>
                auth.module === 'Facility Master' &&
                auth.accessLevel.includes("create")
        );

        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            );
        }

        const body = await req.json();

        const {
            areaName,
            blockBuilding,
            floor,
            department,
            areaType,
            status,
        } = body;

        if (!areaName || !blockBuilding || !floor || !department || !areaType || !status) {
            return NextResponse.json(
                { success: false, message: "Missing required fields" },
                { status: 400 }
            );
        }

        // Generate Facility Code
        const prefix = 'FAC';
        const facilityCode = await generateFacilityCode(prefix);

        const facility = await FacilityMaster.create({
            ...body,
            facilityCode,
            createdBy: decoded.id,
        });

        // Get IP properly
        const forwarded = req.headers.get("x-forwarded-for");
        const ipAddress = forwarded
            ? forwarded.split(",")[0]
            : req.headers.get("x-real-ip") || "Unknown";

        // Create audit log
        await AuditLog.create({
            userId: decoded.id,
            userRole: decoded.role,
            moduleName: 'Facility Master',
            recordId: facility._id,
            action: 'CREATE',
            oldData: null,
            newData: facility.toObject(),
            changedFields: Object.keys(body),
            changeReason: null,
            ipAddress,
            userAgent: req.headers.get('user-agent') || "Unknown",
        });

        return NextResponse.json(
            {
                success: true,
                message: "Facility created successfully!",
                facilityCode: facility.facilityCode
            },
            { status: 201 }
        );

    } catch (error: any) {
        console.log('Error creating facility:', error);

        if (error.code === 11000) {
            const fields = Object.keys(error.keyPattern)[0];
            return NextResponse.json(
                { success: false, message: `Duplicate ${fields} code` },
                { status: 400 }
            );
        } else {
            return NextResponse.json(
                { success: false, message: "Internal server error" },
                { status: 500 }
            );
        }
    }
}

export async function PUT(req: NextRequest) {
    await connectToDatabase();
    try {
        // Check Auth
        const authHeader = req.headers.get('authorization');
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            );
        }

        const token = authHeader.split(' ')[1];
        let decoded;

        try {
            decoded = jwt.verify(token, JWT_SECRET) as {
                id: string;
                role: string;
                authorization: Array<{ module: string; accessLevel: string[] }>
            };
        } catch (error) {
            console.error('Error decoding token:', error);
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            );
        }

        // RBAC Check
        const hasAccess = decoded.authorization?.some(
            (auth) =>
                auth.module === 'Facility Master' &&
                auth.accessLevel.includes("update")
        );

        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            );
        }

        const body = await req.json();

        // Get existing facility details
        const existingFacility = await FacilityMaster.findById(body._id);

        if (!existingFacility) {
            return NextResponse.json(
                { success: false, message: "Facility not found" },
                { status: 404 }
            );
        }

        const updates: any = {};
        const changedFields: any = {};

        // Compare existing facility details with updated details
        Object.keys(body).forEach(key => {
            if (key === '_id' || key === 'updateReason') return;

            const newValue = body[key];
            const oldValue = existingFacility[key as keyof typeof existingFacility];

            if (JSON.stringify(newValue) !== JSON.stringify(oldValue)) {
                updates[key] = newValue;
                changedFields[key] = {
                    old: oldValue,
                    new: newValue
                };
            }
        });

        // If no changes, return success
        if (Object.keys(updates).length === 0) {
            return NextResponse.json(
                { success: true, message: "No changes made" },
                { status: 200 }
            );
        }

        // Update with reason
        const updateData: any = { ...updates };
        if (body.updateReason) {
            updateData.updateReason = body.updateReason;
        }
        updateData.updatedBy = decoded.id;

        const updatedFacility = await FacilityMaster.findByIdAndUpdate(
            body._id,
            { $set: updateData },
            { new: true }
        );

        // Get IP properly
        const forwarded = req.headers.get("x-forwarded-for");
        const ipAddress = forwarded
            ? forwarded.split(",")[0]
            : req.headers.get("x-real-ip") || "Unknown";

        // Create audit log
        await AuditLog.create({
            userId: decoded.id,
            userRole: decoded.role,
            moduleName: 'Facility Master',
            recordId: updatedFacility._id,
            action: 'UPDATE',
            oldData: Object.fromEntries(
                Object.entries(existingFacility.toObject()).filter(([key]) => changedFields[key])
            ),
            newData: Object.fromEntries(
                Object.entries(updatedFacility.toObject()).filter(([key]) => changedFields[key])
            ),
            changedFields: Object.keys(changedFields),
            changeReason: body.updateReason || null,
            ipAddress,
            userAgent: req.headers.get('user-agent') || "Unknown",
        });

        return NextResponse.json(
            {
                success: true,
                message: "Facility updated successfully!",
                facilityCode: updatedFacility.facilityCode
            },
            { status: 200 }
        );

    } catch (error) {
        console.error('Error updating facility:', error);
        return NextResponse.json(
            { success: false, message: 'Error updating facility' },
            { status: 500 }
        );
    }
}

export async function DELETE(req: NextRequest) {
    try {
        await connectToDatabase();

        // Check Auth
        const authHeader = req.headers.get('authorization');
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            );
        }

        const token = authHeader.split(' ')[1];
        let decoded;

        try {
            decoded = jwt.verify(token, JWT_SECRET) as {
                id: string;
                role: string;
                authorization: Array<{ module: string; accessLevel: string[] }>
            };
        } catch (error) {
            console.error('Error decoding token:', error);
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            );
        }

        // RBAC Check
        const hasAccess = decoded.authorization?.some(
            (auth) =>
                auth.module === 'Facility Master' &&
                auth.accessLevel.includes("delete")
        );

        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            );
        }

        const { searchParams } = new URL(req.url);
        const id = searchParams.get('id') || '';

        if (!id) {
            return NextResponse.json(
                { success: false, message: "Facility ID is required" },
                { status: 400 }
            );
        }

        // Get delete reason from request body
        let deleteReason = null;
        try {
            const body = await req.json();
            deleteReason = body.deleteReason || null;
        } catch (e) {
            // If no body, continue without delete reason
        }

        const facility = await FacilityMaster.findById(id);

        if (!facility) {
            return NextResponse.json(
                { success: false, message: "Facility not found" },
                { status: 404 }
            );
        }

        if (facility.isDeleted) {
            return NextResponse.json(
                { success: false, message: "Facility is already deleted" },
                { status: 400 }
            );
        }

        // Soft delete facility
        const deletedFacility = await FacilityMaster.findByIdAndUpdate(
            id,
            {
                isDeleted: true,
                deletedBy: decoded.id,
                deletedAt: new Date(),
                deleteReason: deleteReason,
                status: "Decommissioned"
            },
            {
                new: true,
                runValidators: true,
            }
        );

        // Get IP properly
        const forwarded = req.headers.get("x-forwarded-for");
        const ipAddress = forwarded
            ? forwarded.split(",")[0]
            : req.headers.get("x-real-ip") || "Unknown";

        // Create audit log
        await AuditLog.create({
            userId: decoded.id,
            userRole: decoded.role,
            moduleName: 'Facility Master',
            recordId: deletedFacility._id,
            action: 'DELETE',
            oldData: facility.toObject(),
            newData: {
                isDeleted: true,
                status: "Decommissioned",
                deletedBy: decoded.id,
                deletedAt: new Date(),
                deleteReason: deleteReason,
            },
            changedFields: ['isDeleted', 'status', 'deletedBy', 'deletedAt', 'deleteReason'],
            changeReason: deleteReason,
            ipAddress,
            userAgent: req.headers.get('user-agent') || "Unknown",
        });

        return NextResponse.json(
            {
                success: true,
                message: "Facility deleted successfully!",
                facilityCode: deletedFacility.facilityCode,
            },
            { status: 200 }
        );

    } catch (error) {
        console.error('Error deleting facility:', error);
        return NextResponse.json(
            { success: false, message: 'Error deleting facility' },
            { status: 500 }
        );
    }
}
