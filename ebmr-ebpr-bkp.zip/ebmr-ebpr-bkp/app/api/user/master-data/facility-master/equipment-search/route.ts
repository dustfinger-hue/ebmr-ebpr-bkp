
import dbConnect from "@/lib/db";
import EquipmentMaster from "@/lib/models/EquipmentMaster";
import FacilityMaster from "@/lib/models/FacilityMaster";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  try {
    await dbConnect();

    const { searchParams } = new URL(req.url);

    // const value = searchParams.get('search') || '';
    const page = Number(searchParams.get('page')) || 1;
    const limit = Number(searchParams.get('limit')) || 20;

    const facilityIdParam = searchParams.get('facilityId');
    const facilityIds = facilityIdParam
      ? facilityIdParam.split(',').filter(Boolean)
      : [];

    // 🎯 FACILITY BASED FILTER
    if (facilityIds.length > 0) {
      const facilities = await FacilityMaster.find({
        _id: { $in: facilityIds }
      })
        .select('_id equipment')
        .lean();

      // Step 1: Extract unique equipment codes from the facilities
      const allEquipmentsCode = [
        ...new Set(
          facilities.flatMap(f => f.equipment || [])
        )
      ];

      // If no equipment assigned to any facility, return empty array with proper message
      if (allEquipmentsCode.length === 0) {
        return NextResponse.json({
          success: true,
          equipment: [],
          page,
          limit,
          total: 0,
          message: "No equipment assigned to selected facilities"
        });
      }

      // Step 2: Query equipment based on the unique equipment codes
      // Convert string codes to numbers for proper matching
      const numericCodes = allEquipmentsCode.map(code => Number(code));
      
      const equipment = await EquipmentMaster.find({
        equipmentCode: { $in: numericCodes },
        isDeleted: false,
      })
        .select('equipmentCode equipmentName assetTag cppParameters')
        .limit(limit)
        .lean();

      // Step 3: map equipmentCode → equipment object for easy lookup
      // Handle both string and number equipmentCode from facilities
      const equipmentMap = new Map();
      equipment.forEach(e => {
        const keyStr = String(e.equipmentCode);
        const keyNum = Number(e.equipmentCode);
        equipmentMap.set(keyStr, e);
        equipmentMap.set(keyNum, e);
      });

      // Step 4: facility-wise equipment list with full details
      const facilityWiseData = facilities.map(f => {
        const facEquipments = (f.equipment || [])
          .map((code: any) => equipmentMap.get(code) || equipmentMap.get(Number(code)) || equipmentMap.get(String(code)))
          .filter(Boolean);
        
        return {
          facilityId: f._id,
          equipment: facEquipments
        };
      });

      // Return both: flat array for frontend use AND facility-wise for detailed view
      return NextResponse.json({
        success: true,
        equipment: equipment, // Flat array of equipment for easy frontend use
        equipmentByFacility: facilityWiseData, // Facility-wise breakdown
        page,
        limit,
        total: equipment.length
      });

    }

    // 🔍 SEARCH QUERY
    // const query: any = { isDeleted: false };

    // if (value.length >= 2) {
    //   query.$or = [
    //     { equipmentName: { $regex: value, $options: 'i' } },
    //     // { equipmentCode: { $regex: value, $options: 'i' } },
    //     { assetTag: { $regex: value, $options: 'i' } },
    //   ];
    // }

    // const equipment = await EquipmentMaster.find(query)
    //   .select('equipmentCode equipmentName assetTag')
    //   .limit(limit)
    //   .lean();

    const skip = (page - 1) * limit;

    const [data, total] = await Promise.all([
      EquipmentMaster.find({ isDeleted: false })
        .select('equipmentCode equipmentName assetTag cppParameters')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      EquipmentMaster.countDocuments()
    ])

    return NextResponse.json({
      success: true,
      equipment: data,
      page,
      limit,
      total
    });

  } catch (error) {
    console.error('Error fetching equipment:', error);

    return NextResponse.json(
      { success: false, message: "Error fetching equipment" },
      { status: 500 }
    );
  }
}