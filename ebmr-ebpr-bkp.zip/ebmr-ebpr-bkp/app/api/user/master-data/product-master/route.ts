import connectToDatabase from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import jwt from 'jsonwebtoken';
import { JWT_SECRET } from "@/lib/auth";
import { generatePharmaceuticalProductCode } from "@/lib/utils/generateCode";
import ProductMaster from "@/lib/models/ProductMaster";
import AuditLog from "@/lib/models/UserAuditLog";

export async function GET(req: NextRequest) {
    await connectToDatabase();
    try {
        const { searchParams } = new URL(req.url);

        const page = parseInt(searchParams.get('page') || '1');
        const limit = parseInt(searchParams.get('limit') || '10');
        const search = searchParams.get('search') || '';
        const productId = searchParams.get('productId') || '';

        // Filters
        const therapeuticClass = searchParams.get('therapeuticClass') || '';
        const storageCondition = searchParams.get('storageCondition') || '';
        const status = searchParams.get('status') || '';
        const dosageForm = searchParams.get('dosageForm') || '';
        const productCode = searchParams.get('productCode') || '';

        // Build query
        const query: any = { isDeleted: false };

        if (search) {
            const searchAsNumber = Number(search);

            query.$or = [
                { productName: { $regex: search, $options: 'i' } },
                { genericName: { $regex: search, $options: 'i' } },
            ];
            if (!isNaN(searchAsNumber)) {
                query.$or.push({ productCode: searchAsNumber });
            }
        }

        if (therapeuticClass) query.therapeuticClass = therapeuticClass;
        if (storageCondition) query.storageCondition = storageCondition;
        if (status) query.status = status;
        if (dosageForm) query.dosageForm = dosageForm;
        if (productId) query._id = productId;
        if (productCode) query.productCode = productCode;

        const skip = (page - 1) * limit;

        //Build base query first
        let productQuery = ProductMaster.find(query)

        // if not single product(list mode), select only required fields
        if (!productId) {
            productQuery = productQuery.select("productCode productName genericName shortName strength dosageForm status therapeuticClass shelfLife storageCondition gtinNumber registrationNumber")
        }

        const [products, total] = await Promise.all([
            productQuery
                .sort({ createdAt: -1 })
                .skip(productId ? 0 : skip)
                .limit(productId ? 1 : limit)
                .lean(),
            productId ? Promise.resolve(1) : ProductMaster.countDocuments(query)
        ]);

        return NextResponse.json({
            success: true,
            products,
            total,
            page,
            limit
        });
    } catch (error) {
        console.error('Error fetching products:', error);
        return NextResponse.json(
            { success: false, message: 'Error fetching products' },
            { status: 500 }
        );
    }
}

export async function POST(req: NextRequest) {
    await connectToDatabase()
    try {

        //Check Auth
        const authHeader = req.headers.get('authorization')
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            )
        }
        const token = authHeader.split(' ')[1]
        let decoded
        try {
            decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string; authorization: Array<{ module: string; accessLevel: string[] }> }
        } catch (error) {
            console.error('Error decoding token:', error)
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            )
        }

        // RBAC Check
        const hasAccess = decoded.authorization?.some(
            (auth) =>
                auth.module === 'Product Master' &&
                auth.accessLevel.includes("create")
        )
        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            )
        }

        const body = await req.json()
        const {
            productName,
            genericName,
            shortName,
            // description,
            dosageForm,
            strength,
            // packSize,
            // unit,
            // therapeuticClass,
            // drugCategory,
            // manufacturer,
            shelfLife,
            storageCondition,
            status,
            gtinNumber,
            // registrationNumber,
            // drugLicenseNumber
        } = body;

        if (!productName || !genericName || !shortName || !dosageForm || !strength || !shelfLife || !storageCondition || !status || !gtinNumber) {
            return NextResponse.json({ success: false, message: "Missing required fields" }, { status: 400 });
        }

        // Validate Shelf Life
        if (shelfLife < 1 || shelfLife > 120) {
            return NextResponse.json(
                { success: false, message: "Shelf Life must be between 1 and 120 months" },
                { status: 400 });
        }

        body.shortName = shortName.toUpperCase().trim();

        // Generate Product Code
        const prefix = 'Pharmaceutical Product';
        const productCode = await generatePharmaceuticalProductCode(prefix)

        const product = await ProductMaster.create({
            ...body,
            productCode,
            createdBy: decoded.id,
        })

        // 🌍 Get IP properly
        const forwarded = req.headers.get("x-forwarded-for");
        const ipAddress = forwarded
            ? forwarded.split(",")[0]
            : req.headers.get("x-real-ip") || "Unknown";

        //Create audit log
        await AuditLog.create({
            userId: decoded.id,
            userRole: decoded.role,
            moduleName: 'Product Master',
            recordId: product._id,
            action: 'CREATE',
            oldData: null,
            newData: product.toObject(),
            changedFields: Object.keys(body),
            changeReason: null,
            ipAddress,
            userAgent: req.headers.get('user-agent') || "Unknown",
        })

        return NextResponse.json(
            { success: true, message: "Product created successfully!", productCode: product.productCode },
            { status: 201 }
        )

    } catch (error: any) {
        console.log('Error creating pharmaceutical product:', error)
        if (error.code === 11000) {
            //Duplicate key error
            const fields = Object.keys(error.keyPattern)[0];
            return NextResponse.json(
                { success: false, message: `Duplicate ${fields} code` },
                { status: 400 }
            );
        } else {
            return NextResponse.json(
                { success: false, message: "Internal server error" },
                { status: 500 }
            );
        }
    }
}

export async function PUT(req: NextRequest) {
    await connectToDatabase()
    try {
        // Check Auth
        const authHeader = req.headers.get('authorization')
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            )
        }
        const token = authHeader.split(' ')[1]
        let decoded
        try {
            decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string; authorization: Array<{ module: string; accessLevel: string[] }> }
        } catch (error) {
            console.error('Error decoding token:', error)
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            )
        }

        // Check if the user has the required authorization level
        const hasAccess = decoded.authorization?.some(
            (auth) =>
                auth.module === 'Product Master' &&
                auth.accessLevel.includes("update")
        )
        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            )
        }

        const body = await req.json()

        //existing product details
        const existingProduct = await ProductMaster.findById(body._id)
        if (!existingProduct) {
            return NextResponse.json(
                { success: false, message: "Product not found" },
                { status: 404 }
            )
        }

        const updates: any = {}
        const changedFields: any = {}

        //compare existing product details with updated product details
        Object.keys(body).forEach(key => {
            const newValue = body[key]
            const oldValue = existingProduct[key]
            if (JSON.stringify(newValue) !== JSON.stringify(oldValue)) {
                updates[key] = newValue
                changedFields[key] = {
                    old: oldValue,
                    new: newValue
                }
            }
        })

        //if no changes, return success
        if (Object.keys(updates).length === 0) {
            return NextResponse.json(
                { success: true, message: "No changes made" },
                { status: 200 }
            )
        }

        //Update only changed fields
        const updatedProduct = await ProductMaster.findByIdAndUpdate(
            body._id,
            { $set: updates },
            { new: true }
        )

        // 🌍 Get IP properly
        const forwarded = req.headers.get("x-forwarded-for");
        const ipAddress = forwarded
            ? forwarded.split(",")[0]
            : req.headers.get("x-real-ip") || "Unknown";

        //Create audit log
        await AuditLog.create({
            userId: decoded.id,
            userRole: decoded.role,
            moduleName: 'Product Master',
            recordId: updatedProduct._id,
            action: 'UPDATE',
            oldData: Object.fromEntries(
                Object.entries(existingProduct.toObject()).filter(([key]) => changedFields[key])
            ),
            newData: Object.fromEntries(
                Object.entries(updatedProduct.toObject()).filter(([key]) => changedFields[key])
            ),
            changedFields: Object.keys(changedFields),
            changeReason: null,
            ipAddress,
            userAgent: req.headers.get('user-agent') || "Unknown",
        })
        return NextResponse.json(
            { success: true, message: "Product updated successfully!", productCode: updatedProduct.productCode },
            { status: 200 }
        )



    } catch (error) {
        console.error('Error connecting to database:', error)
        return NextResponse.json(
            { success: false, message: 'Error connecting to database' },
            { status: 500 }
        )
    }
}

export async function DELETE(req: NextRequest) {
    try {
        await connectToDatabase()

        //Check Auth
        const authHeader = req.headers.get('authorization')
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            )
        }
        const token = authHeader.split(' ')[1]
        let decoded
        try {
            decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string; authorization: Array<{ module: string; accessLevel: string[] }> }
        } catch (error) {
            console.error('Error decoding token:', error)
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            )
        }

        // Check if the user has the required authorization level
        const hasAccess = decoded.authorization?.some(
            (auth) =>
                auth.module === 'Product Master' &&
                auth.accessLevel.includes("delete")
        )
        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            )
        }

        const { searchParams } = new URL(req.url);
        const id = searchParams.get('id') || '';

        if(!id) {
            return NextResponse.json(
                { success: false, message: "Product ID is required" },
                { status: 400 }
            )
        }

        // Get delete reason from request body
        let deleteReason = null;
        try {
            const body = await req.json();
            deleteReason = body.deleteReason || null;
        } catch (e) {
            // If no body, continue without delete reason
        }

        const product = await ProductMaster.findById(id)
        if (!product) {
            return NextResponse.json(
                { success: false, message: "Product not found" },
                { status: 404 }
            )
        }
        if (product.isDeleted) {
            return NextResponse.json(
                { success: false, message: "Product is already deleted" },
                { status: 400 }
            )
        }

        // Delete product
        const deletedProduct = await ProductMaster.findByIdAndUpdate(
            id,
            {
                isDeleted: true,
                deletedBy: decoded.id,
                deletedAt: new Date(),
                deleteReason: deleteReason,
                status: "Inactive"
            },
            {
                new: true,
                runValidators: true,
            })

        // 🌍 Get IP properly
        const forwarded = req.headers.get("x-forwarded-for");
        const ipAddress = forwarded
            ? forwarded.split(",")[0]
            : req.headers.get("x-real-ip") || "Unknown";

        // create audit log
        await AuditLog.create({
            userId: decoded.id,
            userRole: decoded.role,
            moduleName: 'Product Master',
            recordId: deletedProduct._id,
            action: 'DELETE',
            oldData: product.toObject(),
            newData: {
                isDeleted: true,
                status: "Inactive",
                deletedBy: decoded.id,
                deletedAt: new Date(),
                deleteReason: deleteReason,
            },
            changedFields: ['isDeleted', 'status', 'deletedBy', 'deletedAt', 'deleteReason'],
            changeReason: deleteReason,
            ipAddress,
            userAgent: req.headers.get('user-agent') || "Unknown",
        })


        return NextResponse.json(
            {
                success: true, message: "Product deleted successfully!",
                productCode: deletedProduct.productCode,
            },
            { status: 200 }
        )

    } catch (error) {
        console.error('Error connecting to database:', error)
        return NextResponse.json(
            { success: false, message: 'Error connecting to database' },
            { status: 500 }
        )
    }
}
