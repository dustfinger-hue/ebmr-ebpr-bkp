import connectToDatabase from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import jwt from 'jsonwebtoken';
import { JWT_SECRET } from "@/lib/auth";
import EquipmentMaster from "@/lib/models/EquipmentMaster";
import AuditLog from "@/lib/models/UserAuditLog";
import { generateEquipmentCode } from "@/lib/utils/generateCode";

export async function GET(req: NextRequest) {
    await connectToDatabase();
    try {
        const { searchParams } = new URL(req.url);

        const page = parseInt(searchParams.get('page') || '1');
        const limit = parseInt(searchParams.get('limit') || '10');
        const search = searchParams.get('search') || '';
        const equipmentId = searchParams.get('equipmentId') || '';

        // Filters
        const category = searchParams.get('category') || '';
        const status = searchParams.get('status') || '';
        const equipmentType = searchParams.get('equipmentType') || '';
        const department = searchParams.get('department') || '';
        const equipmentCode = searchParams.get('equipmentCode') || '';

        // Build query
        const query: any = { isDeleted: false };

        if (search) {
            const searchAsNumber = Number(search);

            query.$or = [
                { equipmentName: { $regex: search, $options: 'i' } },
                { modelNumber: { $regex: search, $options: 'i' } },
                { serialNumber: { $regex: search, $options: 'i' } },
                { assetTag: { $regex: search, $options: 'i' } },
            ];
            if (!isNaN(searchAsNumber)) {
                query.$or.push({ equipmentCode: searchAsNumber });
            }
        }

        if (category) query.category = category;
        if (status) query.status = status;
        if (equipmentType) query.equipmentType = equipmentType;
        if (department) query.department = department;
        if (equipmentId) query._id = equipmentId;
        if (equipmentCode) query.equipmentCode = { $in: equipmentCode.split(',') };

        const skip = (page - 1) * limit;

        let equipmentQuery = EquipmentMaster.find(query);

        // If not single product (list mode), select only required fields
        if (!equipmentId) {
            equipmentQuery = equipmentQuery.select(
                "equipmentCode equipmentName equipmentType category modelNumber serialNumber manufacturer currentStatus department cppParameters"
            );
        }

        const [equipment, total] = await Promise.all([
            equipmentQuery
                .sort({ createdAt: -1 })
                .skip(equipmentId ? 0 : skip)
                .limit(equipmentId ? 1 : limit)
                .lean(),
            equipmentId ? Promise.resolve(1) : EquipmentMaster.countDocuments(query)
        ]);

        return NextResponse.json({
            success: true,
            equipment,
            total,
            page,
            limit
        });
    } catch (error) {
        console.error('Error fetching equipment:', error);
        return NextResponse.json(
            { success: false, message: 'Error fetching equipment' },
            { status: 500 }
        );
    }
}

export async function POST(req: NextRequest) {
    await connectToDatabase();
    try {
        // Check Auth
        const authHeader = req.headers.get('authorization');
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            );
        }

        const token = authHeader.split(' ')[1];
        let decoded;

        try {
            decoded = jwt.verify(token, JWT_SECRET) as {
                id: string;
                role: string;
                authorization: Array<{ module: string; accessLevel: string[] }>
            };
        } catch (error) {
            console.error('Error decoding token:', error);
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            );
        }

        // RBAC Check
        const hasAccess = decoded.authorization?.some(
            (auth) =>
                auth.module === 'Equipment Master' &&
                auth.accessLevel.includes("create")
        );

        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            );
        }

        const body = await req.json();

        const {
            equipmentName,
            equipmentType,
            category,
            currentStatus,
        } = body;

        if (!equipmentName || !equipmentType || !category || !currentStatus) {
            return NextResponse.json(
                { success: false, message: "Missing required fields" },
                { status: 400 }
            );
        }

        // Generate Equipment Code (EQ-XXXX format)
        const prefix = 'Equipment Master';
        const equipmentCode = await generateEquipmentCode(prefix)

        const equipment = await EquipmentMaster.create({
            ...body,
            equipmentCode,
            createdBy: decoded.id,
        });

        // Get IP properly
        const forwarded = req.headers.get("x-forwarded-for");
        const ipAddress = forwarded
            ? forwarded.split(",")[0]
            : req.headers.get("x-real-ip") || "Unknown";

        // Create audit log
        await AuditLog.create({
            userId: decoded.id,
            userRole: decoded.role,
            moduleName: 'Equipment Master',
            recordId: equipment._id,
            action: 'CREATE',
            oldData: null,
            newData: equipment.toObject(),
            changedFields: Object.keys(body),
            changeReason: null,
            ipAddress,
            userAgent: req.headers.get('user-agent') || "Unknown",
        });

        return NextResponse.json(
            {
                success: true,
                message: "Equipment created successfully!",
                equipmentCode: equipment.equipmentCode
            },
            { status: 201 }
        );

    } catch (error: any) {
        console.log('Error creating equipment:', error);

        if (error.code === 11000) {
            // Duplicate key error
            const fields = Object.keys(error.keyPattern)[0];
            return NextResponse.json(
                { success: false, message: `Duplicate ${fields} code` },
                { status: 400 }
            );
        } else {
            return NextResponse.json(
                { success: false, message: "Internal server error" },
                { status: 500 }
            );
        }
    }
}

export async function PUT(req: NextRequest) {
    await connectToDatabase();
    try {
        // Check Auth
        const authHeader = req.headers.get('authorization');
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            );
        }

        const token = authHeader.split(' ')[1];
        let decoded;

        try {
            decoded = jwt.verify(token, JWT_SECRET) as {
                id: string;
                role: string;
                authorization: Array<{ module: string; accessLevel: string[] }>
            };
        } catch (error) {
            console.error('Error decoding token:', error);
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            );
        }

        // RBAC Check
        const hasAccess = decoded.authorization?.some(
            (auth) =>
                auth.module === 'Equipment Master' &&
                auth.accessLevel.includes("update")
        );

        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            );
        }

        const body = await req.json();

        // Get existing equipment details
        const existingEquipment = await EquipmentMaster.findById(body._id);

        if (!existingEquipment) {
            return NextResponse.json(
                { success: false, message: "Equipment not found" },
                { status: 404 }
            );
        }

        const updates: any = {};
        const changedFields: any = {};

        // Compare existing equipment details with updated details
        Object.keys(body).forEach(key => {
            const newValue = body[key];
            const oldValue = existingEquipment[key as keyof typeof existingEquipment];

            if (JSON.stringify(newValue) !== JSON.stringify(oldValue)) {
                updates[key] = newValue;
                changedFields[key] = {
                    old: oldValue,
                    new: newValue
                };
            }
        });

        // If no changes, return success
        if (Object.keys(updates).length === 0) {
            return NextResponse.json(
                { success: true, message: "No changes made" },
                { status: 200 }
            );
        }

        // Update with reason
        const updateData: any = { ...updates };
        if (body.updateReason) {
            updateData.updateReason = body.updateReason;
        }
        updateData.updatedBy = decoded.id;

        const updatedEquipment = await EquipmentMaster.findByIdAndUpdate(
            body._id,
            { $set: updateData },
            { new: true }
        );

        // Get IP properly
        const forwarded = req.headers.get("x-forwarded-for");
        const ipAddress = forwarded
            ? forwarded.split(",")[0]
            : req.headers.get("x-real-ip") || "Unknown";

        // Create audit log
        await AuditLog.create({
            userId: decoded.id,
            userRole: decoded.role,
            moduleName: 'Equipment Master',
            recordId: updatedEquipment._id,
            action: 'UPDATE',
            oldData: Object.fromEntries(
                Object.entries(existingEquipment.toObject()).filter(([key]) => changedFields[key])
            ),
            newData: Object.fromEntries(
                Object.entries(updatedEquipment.toObject()).filter(([key]) => changedFields[key])
            ),
            changedFields: Object.keys(changedFields),
            changeReason: body.updateReason || null,
            ipAddress,
            userAgent: req.headers.get('user-agent') || "Unknown",
        });

        return NextResponse.json(
            {
                success: true,
                message: "Equipment updated successfully!",
                equipmentCode: updatedEquipment.equipmentCode
            },
            { status: 200 }
        );

    } catch (error) {
        console.error('Error updating equipment:', error);
        return NextResponse.json(
            { success: false, message: 'Error updating equipment' },
            { status: 500 }
        );
    }
}

export async function DELETE(req: NextRequest) {
    try {
        await connectToDatabase();

        // Check Auth
        const authHeader = req.headers.get('authorization');
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return NextResponse.json(
                { success: false, message: 'Unauthorized' },
                { status: 401 }
            );
        }

        const token = authHeader.split(' ')[1];
        let decoded;

        try {
            decoded = jwt.verify(token, JWT_SECRET) as {
                id: string;
                role: string;
                authorization: Array<{ module: string; accessLevel: string[] }>
            };
        } catch (error) {
            console.error('Error decoding token:', error);
            return NextResponse.json(
                { success: false, message: 'Invalid or expired token' },
                { status: 401 }
            );
        }

        // RBAC Check
        const hasAccess = decoded.authorization?.some(
            (auth) =>
                auth.module === 'Equipment Master' &&
                auth.accessLevel.includes("delete")
        );

        if (!hasAccess) {
            return NextResponse.json(
                { success: false, message: "You are not authorized to perform this action" },
                { status: 403 }
            );
        }

        const { searchParams } = new URL(req.url);
        const id = searchParams.get('id') || '';

        if (!id) {
            return NextResponse.json(
                { success: false, message: "Equipment ID is required" },
                { status: 400 }
            );
        }

        // Get delete reason from request body
        let deleteReason = null;
        try {
            const body = await req.json();
            deleteReason = body.deleteReason || null;
        } catch (e) {
            // If no body, continue without delete reason
        }

        const equipment = await EquipmentMaster.findById(id);

        if (!equipment) {
            return NextResponse.json(
                { success: false, message: "Equipment not found" },
                { status: 404 }
            );
        }

        if (equipment.isDeleted) {
            return NextResponse.json(
                { success: false, message: "Equipment is already deleted" },
                { status: 400 }
            );
        }

        // Soft delete equipment
        const deletedEquipment = await EquipmentMaster.findByIdAndUpdate(
            id,
            {
                isDeleted: true,
                deletedBy: decoded.id,
                deletedAt: new Date(),
                deleteReason: deleteReason,
                currentStatus: "Decommissioned"
            },
            {
                new: true,
                runValidators: true,
            }
        );

        // Get IP properly
        const forwarded = req.headers.get("x-forwarded-for");
        const ipAddress = forwarded
            ? forwarded.split(",")[0]
            : req.headers.get("x-real-ip") || "Unknown";

        // Create audit log
        await AuditLog.create({
            userId: decoded.id,
            userRole: decoded.role,
            moduleName: 'Equipment Master',
            recordId: deletedEquipment._id,
            action: 'DELETE',
            oldData: equipment.toObject(),
            newData: {
                isDeleted: true,
                currentStatus: "Decommissioned",
                deletedBy: decoded.id,
                deletedAt: new Date(),
                deleteReason: deleteReason,
            },
            changedFields: ['isDeleted', 'currentStatus', 'deletedBy', 'deletedAt', 'deleteReason'],
            changeReason: deleteReason,
            ipAddress,
            userAgent: req.headers.get('user-agent') || "Unknown",
        });

        return NextResponse.json(
            {
                success: true,
                message: "Equipment deleted successfully!",
                equipmentCode: deletedEquipment.equipmentCode,
            },
            { status: 200 }
        );

    } catch (error) {
        console.error('Error deleting equipment:', error);
        return NextResponse.json(
            { success: false, message: 'Error deleting equipment' },
            { status: 500 }
        );
    }
}
