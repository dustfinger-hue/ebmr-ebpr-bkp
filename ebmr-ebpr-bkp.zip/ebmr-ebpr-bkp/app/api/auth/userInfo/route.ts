import connectToDatabase from "@/lib/db"
import User from "@/lib/models/User"
import { NextRequest, NextResponse } from "next/server"

export async function GET(req: NextRequest) {
    await connectToDatabase()
    try {
        const { searchParams } = new URL(req.url)
        const id = searchParams.get('id') || ''
        const user = await User.findById(id)
        if (!user) {
            return NextResponse.json(
                { succes: false, message: 'User not found' },
                { status: 404 }
            )
        }
        return NextResponse.json(
            { success: true, message: 'User fetched successfully', user },
            { status: 200 }
        )
    } catch (error: any) {
        console.error('Error fetching user:', error)
        return NextResponse.json(
            { success: false, message: 'Internal server error' },
            { status: 500 })
    }
}