import { JWT_SECRET } from "@/lib/auth";
import connectToDatabase from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";
import jwt from 'jsonwebtoken';
import Admin from "@/lib/models/Admin";
import User from "@/lib/models/User";

export async function GET(req: NextRequest) {
   await connectToDatabase();

   const authHeader = req.headers.get('Authorization');
   if (!authHeader) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
   }

   const token = authHeader.split(' ')[1];
   if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
   }

   try {
      const decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string };

      //Fetch user from database
      let userData
      if (decoded.role === 'admin') {
         const admin = await Admin.findById(decoded.id).select('-password');
         if (!admin) {
            return NextResponse.json({ error: 'User not found' }, { status: 401 });
         }
         userData = admin;
      } else {
         //will be update later
         const user = await User.findById(decoded.id);
         if (!user) {
            return NextResponse.json({ error: 'User not found' }, { status: 401 });
         }
         userData = user;
      }
      return NextResponse.json({ userData });
   }catch (error) {
      console.error('Error fetching user data:', error);
      return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
   }

}