import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { JWT_SECRET } from "@/lib/auth";
import connectToDatabase from "@/lib/db";
import Admin from "@/lib/models/Admin";
import User from "@/lib/models/User";
import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
    await connectToDatabase();

    try {
        const { username, password } = await req.json();

        if (!username || !password) {
            return NextResponse.json(
                { success: false, message: "Missing username or password" },
                { status: 400 }
            );
        }

        const admin = await Admin.findOne({ email: username });
        const user = await User.findOne({ email: username });

        const loginUser = admin || user;

        if (!loginUser) {
            return NextResponse.json(
                { success: false, message: "Invalid username or password" },
                { status: 401 }
            );
        }

        const isValidPassword = await bcrypt.compare(password, loginUser.password);

        if (!isValidPassword) {
            return NextResponse.json(
                { success: false, message: "Invalid username or password" },
                { status: 401 }
            );
        }

        // Update last login
        loginUser.lastLogin = new Date();
        await loginUser.save();

        const JwtToken = jwt.sign(
            { id: loginUser._id, role: loginUser.role, authorization: loginUser.authorization },
            JWT_SECRET,
            { expiresIn: "24h" }
        );

        return NextResponse.json(
            { success: true, message: "Login successful", token: JwtToken },
            {
                status: 200,
                headers: {
                    "Set-Cookie": `token=${JwtToken}; HttpOnly; Path=/; Max-Age=86400; ${process.env.NODE_ENV === "production" ? "Secure;" : ""
                        } SameSite=Lax`,
                },
            }
        );

    } catch (error) {
        console.error("Login Error:", error);
        return NextResponse.json(
            { success: false, message: "Login failed" },
            { status: 500 }
        );
    }
}
