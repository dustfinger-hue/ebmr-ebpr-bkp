"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Form, Input, Button, Typography, message } from "antd";
import { UserOutlined, LockOutlined, LoginOutlined } from "@ant-design/icons";
const { Title, Text } = Typography;

export default function LoginPage() {
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (values: { username: string; password: string }) => {
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });

      const data = await res.json();

      if (!res.ok) {
        message.error(data.error || "Login failed!");
        return;
      }

      localStorage.setItem("token", data.token);

      const payload = JSON.parse(atob(data.token.split(".")[1]));
      if (payload.role === "admin") {
        message.success("Login successful! Redirecting to admin dashboard...");
        setTimeout(() => {
          router.push("/admin");
        }, 2000);
      } else {
        message.success("Login successful! Redirecting to user dashboard...");
        setTimeout(() => {
          router.push("/user");
        }, 2000);
      }
    } catch (err) {
      console.error(err);
      message.error("An error occurred during login");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-linear-to-tr from-indigo-500 to-purple-600 p-4">
      <Card style={{ maxWidth: 360, width: "100%", borderRadius: 12 }}>
        <div className="text-center mb-6">
          <div className="w-12 h-12 bg-linear-to-tr from-indigo-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-2">
            <LoginOutlined style={{ fontSize: 24, color: "#fff" }} />
          </div>
          <Title level={3} style={{ margin: 0 }}>EBMR & BPR System</Title>
          <Text type="secondary" style={{ fontSize: 12 }}>Pharmaceutical Quality Control</Text>
        </div>

        <Form layout="vertical" size="large" onFinish={handleSubmit}>
          <Form.Item label="Username" name="username" rules={[{ required: true, message: "Enter username" }]}>
            <Input prefix={<UserOutlined />} placeholder="Username" autoComplete="username" />
          </Form.Item>

          <Form.Item label="Password" name="password" rules={[{ required: true, message: "Enter password" }]}>
            <Input.Password prefix={<LockOutlined />} placeholder="Password" autoComplete="current-password" />
          </Form.Item>

          <Form.Item>
            <Button type="primary" htmlType="submit" block icon={<LoginOutlined />} loading={loading}>
              {loading ? "Signing In..." : "Sign In"}
            </Button>
          </Form.Item>
        </Form>

        <div className="mt-4 p-2 bg-gray-100 rounded border text-center text-xs text-gray-500">
          Pharmaceutical quality control and compliance management system.
        </div>
      </Card>
    </div>
  );
}
