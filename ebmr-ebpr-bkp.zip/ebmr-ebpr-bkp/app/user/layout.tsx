'use client';

import { Layout, Menu, Avatar, Dropdown, Button, Typography, message, ConfigProvider, theme, Spin } from "antd";
import {
  DashboardOutlined,
  UserOutlined,
  LogoutOutlined,
  MenuUnfoldOutlined,
  MenuFoldOutlined,
  ShopOutlined,
  DatabaseOutlined,
  SunOutlined,
  MoonOutlined,
} from "@ant-design/icons";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { IoDocumentTextOutline } from "react-icons/io5";
import { ThemeProvider, useTheme } from "@/lib/utils/ThemeContext";
import { BiSolidFactory } from "react-icons/bi";

const { Header, Sider, Content } = Layout;
const { Text } = Typography;

function UserLayoutContent({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [user, setUser] = useState<{ username: string; role: string } | null>(null);
  const router = useRouter();
  const { theme: currentTheme, toggleTheme, mounted } = useTheme();

  useEffect(() => {
    const token = localStorage.getItem("token");

    if (!token) {
      router.push("/");
      return;
    }

    const fetchUser = async () => {
      try {
        const res = await fetch("/api/auth/me", {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();
        if (res.ok) setUser({ username: data.userData.name, role: data.userData.role });
        else router.push("/");
      } catch (err) {
        console.error(err);
        router.push("/");
      }
    };
    fetchUser();
  }, [router]);

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      localStorage.removeItem("token");
      message.success("Logged out successfully");
      router.push("/");
    } catch (error) {
      console.error("Logout error:", error);
      message.error("Logout failed");
    }
  };

  const menuItems = [
    { key: 'warehouse', icon: <ShopOutlined />, label: 'Warehouse', onClick: () => router.push('/warehouse') },
    {
      key: 'master-data',
      icon: <DatabaseOutlined />,
      label: 'Master Data',
      children: [
        {
          key: 'material-master',
          label: 'Material Master',
          onClick: () => router.push('/user/master-data/material-master')
        },
        {
          key: 'product-master',
          label: 'Product Master',
          onClick: () => router.push('/user/master-data/product-master')
        },
        {
          key: 'equipment-master',
          label: 'Equipment Master',
          onClick: () => router.push('/user/master-data/equipment-master')
        },
        {
          key: 'facility-master',
          label: 'Facility Master',
          onClick: () => router.push('/user/master-data/facility-master')
        },
      ]
    },
    {
      key: 'bill-of-material',
      icon: <ShopOutlined />,
      label: 'Bill of Material',
      onClick: () => router.push('/user/bill-of-material')
    },
    {
      key: 'production-template',
      icon: <IoDocumentTextOutline size={17} />,
      label: 'Production Template',
      children: [
        {
          key: 'manufacturing-template',
          label: 'Manufacturing Template',
          onClick: () => router.push('/user/production-template/manufacturing-template')
        },
        {
          key: 'packaging-template',
          label: 'Packaging Template',
          onClick: () => router.push('/user/production-template/packaging-template')
        }
      ]
    },
    {
      key: 'manufacturingControl',
      icon: <BiSolidFactory />,
      label: 'Manufacturing Control',
      children: [
        {
          key: 'processOrderCreation',
          label: 'Process Order Creation',
          onClick: () => router.push('/user/manufacturing-control/process-order-creation')
        },
        {
          key: 'batchNumberIssuance',
          label: 'Batch Number Issuance',
          onClick: () => router.push('/user/manufacturing-control/batch-number-issuance')
        },
        {
          key: 'manufacturingExecution',
          label: 'Manufacturing Execution',
          children: [
            {
              key: 'dispensing',
              label: 'Dispensing',
              onClick: () => router.push('/user/manufacturing-control/manufacturing-execution/dispensing')
            },
            {
              key: 'AreaActivityLog',
              label: 'Area Activity Log',
              onClick: () => router.push('/user/manufacturing-control/manufacturing-execution/area-activity-log')
            },
          ]
          // onClick: () => router.push('/user/manufacturing-control/production-execution')
        }
      ]
    }
  ];

  const userMenuItems = [
    { key: "profile", icon: <UserOutlined />, label: "Profile", onClick: () => router.push("/admin/profile") },
    { key: "logout", icon: <LogoutOutlined />, label: "Logout", onClick: handleLogout },
  ];

  const isDark = currentTheme === 'dark';

  // Prevent flash by showing loading until mounted
  if (!mounted) {
    return (
      <div style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "#f5f5f5"
      }}>
        <Spin size="large" />
      </div>
    );
  }

  return (
    <ConfigProvider
      theme={{
        algorithm: isDark ? theme.darkAlgorithm : theme.defaultAlgorithm,
        token: {
          colorPrimary: '#1890ff',
          colorBgContainer: isDark ? '#141414' : '#ffffff',
          colorBgElevated: isDark ? '#1f1f1f' : '#ffffff',
          colorBgLayout: isDark ? '#000000' : '#f5f5f5',
          colorText: isDark ? '#ffffff' : '#000000',
          colorTextSecondary: isDark ? '#a6a6a6' : '#8c8c8c',
          colorBorder: isDark ? '#434343' : '#d9d9d9',
          colorBgSpotlight: isDark ? '#262626' : '#e6e6e6',
        },
      }}
    >
      <Layout style={{ minHeight: "100vh", background: isDark ? '#000' : '#f5f5f5' }}>
        <Sider
          trigger={null}
          collapsible
          collapsed={collapsed}
          theme={currentTheme as "light" | "dark"}
          width={230}
          style={{
            position: "fixed",
            height: "100vh",
            left: 0,
            top: 0,
            bottom: 0,
            overflow: "auto",
            boxShadow: "2px 0 8px rgba(0,0,0,0.05)",
            zIndex: 1000,
            background: isDark ? '#141414' : '#fff'
          }}
        >
          {/* Sidebar Header */}
          <div style={{ padding: "16px", textAlign: "center", borderBottom: isDark ? "1px solid #434343" : "1px solid #f0f0f0" }}>
            <div
              style={{
                fontSize: collapsed ? 16 : 18,
                fontWeight: "bold",
                color: "#1890ff",
                transition: "font-size 0.2s",
              }}
            >
              {collapsed ? "EBMPR" : "EBMR & BPR Admin"}
            </div>
            {!collapsed && (
              <div style={{ fontSize: 12, color: isDark ? "#a6a6a6" : "#666", marginTop: 4 }}>
                Hilton Pharma Private Limited
              </div>
            )}
          </div>

          {/* Sidebar Menu */}
          <Menu
            theme={currentTheme as "light" | "dark"}
            mode="inline"
            defaultSelectedKeys={["/admin"]}
            items={menuItems}
            style={{ borderRight: 0, background: 'transparent' }}
          />
        </Sider>

        <Layout style={{ marginLeft: collapsed ? 80 : 230, background: 'transparent' }}>
          {/* Header */}
          <Header
            style={{
              padding: "0 24px",
              background: isDark ? '#1f1f1f' : '#fff',
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              borderBottom: isDark ? "1px solid #434343" : "1px solid #f0f0f0",
              boxShadow: "0 2px 4px rgba(0,0,0,0.05)",
            }}
          >
            <div className="flex items-center gap-4">
              <Button
                type="text"
                icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
                onClick={() => setCollapsed(!collapsed)}
                style={{ fontSize: 18, width: 64, height: 64 }}
              />
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              {/* Theme Toggle Button */}
              <Button
                type="text"
                icon={isDark ? <SunOutlined /> : <MoonOutlined />}
                onClick={toggleTheme}
                style={{ fontSize: 18 }}
                title={isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}
              />

              <div style={{ textAlign: "right", fontSize: 12 }} className="flex flex-col">
                <Text strong style={{ display: "block", fontSize: 16, color: isDark ? '#fff' : '#000' }}>
                  {user?.username || "Loading..."}
                </Text>
                <Text type="secondary" style={{ fontSize: 12, color: isDark ? '#a6a6a6' : '#8c8c8c' }}>
                  {user?.role || ""}
                </Text>
              </div>

              <Dropdown menu={{ items: userMenuItems }} placement="bottomRight">
                <Avatar
                  size="large"
                  style={{ backgroundColor: "#1890ff", cursor: "pointer", border: "2px solid #1890ff" }}
                  icon={<UserOutlined />}
                />
              </Dropdown>
            </div>
          </Header>

          {/* Content */}
          <Content
            style={{
              margin: 4,
              padding: 24,
              background: isDark ? '#141414' : '#fff',
              borderRadius: 8,
              boxShadow: "0 2px 4px rgba(0,0,0,0.05)",
              height: "calc(100vh - 112px)",
              overflowY: "auto"
            }}
          >
            {children}
          </Content>
        </Layout>
      </Layout>
    </ConfigProvider>
  );
}

export default function UserLayout({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider>
      <UserLayoutContent>{children}</UserLayoutContent>
    </ThemeProvider>
  );
}
