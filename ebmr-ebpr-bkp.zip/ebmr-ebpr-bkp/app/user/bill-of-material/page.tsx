'use client';
import { Button, Card, Col, message, Row, Select, Space, Table, Tag, Tooltip, Typography, Tabs, Input } from "antd";
import { useEffect, useState } from "react";
import { FaCapsules, FaCubes, FaIndustry } from "react-icons/fa";
const { Title, Text } = Typography;
import {
  SearchOutlined,
  ReloadOutlined,
  PlusOutlined,
  FilterOutlined,
  ClearOutlined,
  DeleteTwoTone,
  EditTwoTone,
  EyeTwoTone,
  CopyOutlined
} from "@ant-design/icons";
import Search from "antd/es/input/Search";
import type { TabsProps } from 'antd';
import AddManufacturingBOM from "./components/manufacturing/Add-Manufacturing-BOM";
import AddPackingBOM from "./components/packing/Add-Packing-BOM";
import { useAuthorization } from "@/hooks/useAuthorization";
import ManufacturingBomViewModal from "./components/manufacturing/Manufacturing-Bom-View-Modal";
import PackingBomViewModal from "./components/packing/Packing-Bom-View-Modal";

export default function BillOfMaterialsPage() {

  // Packing BOM States
  const [packingBomData, setPackingBomData] = useState<any[]>([]);
  const [packingLoading, setPackingLoading] = useState(false);
  const [packingPagination, setPackingPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });
  const [packingSearchText, setPackingSearchText] = useState("");
  const [packingBomViewModal, setPackingBomViewModal] = useState(false)

  // Manufacturing BOM States
  const [manufacturingBomData, setManufacturingBomData] = useState<any[]>([]);
  const [manufacturingLoading, setManufacturingLoading] = useState(false);
  const [manufacturingPagination, setManufacturingPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });
  const [manufacturingSearchText, setManufacturingSearchText] = useState("");
  const [manufacturingBomViewModal, setManufacturingBomViewModal] = useState(false)
  const [selectedProductCode, setSelectedProductCode] = useState<string | null>(null);

  // Filter States
  const [addManufacturingBom, setAddManufacturingBom] = useState(false);
  const [addPackingBom, setAddPackingBom] = useState(false);

  useEffect(() => {
    // Load initial data for packing BOM
    getPackingBom(1, 10, "");
    getManufacturingBom(1, 10, "");
  }, []);

  const handleTabChange = (key: string) => {
    if (key === 'packing') {
      getPackingBom(packingPagination.current, packingPagination.pageSize, packingSearchText);
    } else if (key === 'manufacturing') {
      getManufacturingBom(manufacturingPagination.current, manufacturingPagination.pageSize, manufacturingSearchText);
    }
  };

  //Auth check
  const { hasAccess } = useAuthorization()
  const isCreateManufacturingBOMAuthorized = hasAccess('Manufacturing BOM', 'create')
  const isViewManufacturingBOMAuthorized = hasAccess('Manufacturing BOM', 'read')

  const isCreatePackingBOMAuthorized = hasAccess('Packaging BOM', 'create')
  const isViewPackingBOMAuthorized = hasAccess('Packaging BOM', 'read')

  // Mock data for Packing BOM
  const getPackingBom = async (page: number, limit: number, search: string) => {
    try {
      setPackingLoading(true);
      let url = `/api/user/bill-of-material/packing?page=${page}&limit=${limit}&search=${search}`;

      const token = await localStorage.getItem('token');
      const res = await fetch(url, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();
      const filteredData = search
        ? data.data.filter((item: any) =>
          item.productName.toLowerCase().includes(search.toLowerCase()) ||
          item.productCode.toLowerCase().includes(search.toLowerCase())
        )
        : data.data;

      setPackingBomData(filteredData);
      setPackingPagination(prev => ({ ...prev, total: filteredData.length }));
    } catch (error) {
      console.error(error);
      message.error("Error fetching Packing BOM data");
    } finally {
      setPackingLoading(false);
    }
  };

  const getManufacturingBom = async (page: number, limit: number, search?: string) => {
    try {
      setManufacturingLoading(true);
      // Mock data - replace with API call
      let url = `/api/user/bill-of-material/manufacturing?page=${page}&limit=${limit}&search=${search}`;

      const token = await localStorage.getItem('token');
      const res = await fetch(url, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();
      const filteredData = search
        ? data.data.filter((item: any) =>
          // item.bomCode.toLowerCase().includes(search.toLowerCase()) ||
          item.productName.toLowerCase().includes(search.toLowerCase()) ||
          item.productCode.toLowerCase().includes(search.toLowerCase())
        )
        : data.data;

      setManufacturingBomData(filteredData);
      setManufacturingPagination(prev => ({ ...prev, total: filteredData.length }));
    } catch (error) {
      console.error(error);
      message.error("Error fetching Manufacturing BOM data");
    } finally {
      setManufacturingLoading(false);
    }
  };

  // Packing BOM Columns
  const packingColumns = [
    {
      title: 'S.No',
      width: 70,
      fixed: 'left' as const,
      render: (_: any, __: any, index: number) =>
        (manufacturingPagination.current - 1) * manufacturingPagination.pageSize + index + 1
    },
    {
      title: 'Product Code',
      dataIndex: 'productCode',
      key: 'productCode',
      width: 120,
      render: (text: string) => <Text type="secondary">{text}</Text>,
    },
    {
      title: 'Product Name',
      dataIndex: 'productName',
      key: 'productName',
      width: 180,
      ellipsis: true,
      render: (text: string) => <Text strong>{text}</Text>,
    },
    {
      title: 'BOM Type',
      width: 130,
      render: (text: string) => <Tag color="blue">Packing BOM</Tag>,
    },
    {
      title: 'Total BOMs',
      dataIndex: 'totalBoms',
      key: 'totalBoms',
      width: 100,
      render: (count: number) => <Tag color="cyan">{count} Items</Tag>,
    },
    {
      title: 'Action',
      width: 120,
      fixed: "right" as const,
      render: (record: any) => {
        return (
          <Space size="small">
            <Tooltip title={isViewPackingBOMAuthorized ? "" : "You are not authorized to perform this action."}>
              <Button
                type="text"
                danger
                size="small"
                onClick={() => {
                  setPackingBomViewModal(true);
                  setSelectedProductCode(record.productCode)
                }}
                disabled={!isViewManufacturingBOMAuthorized}
                icon={<EyeTwoTone />}
              />
            </Tooltip>
          </Space>
        )
      }
    }
  ];

  // Manufacturing BOM Columns
  const manufacturingColumns = [
    {
      title: 'S.No',
      width: 70,
      fixed: 'left' as const,
      render: (_: any, __: any, index: number) =>
        (manufacturingPagination.current - 1) * manufacturingPagination.pageSize + index + 1
    },
    {
      title: 'Product Code',
      dataIndex: 'productCode',
      key: 'productCode',
      width: 120,
      render: (text: string) => <Text type="secondary">{text}</Text>,
    },
    {
      title: 'Product Name',
      dataIndex: 'productName',
      key: 'productName',
      width: 180,
      ellipsis: true,
      render: (text: string) => <Text strong>{text}</Text>,
    },
    {
      title: 'BOM Type',
      width: 130,
      render: (text: string) => <Tag color="blue">Manufacturing BOM</Tag>,
    },
    {
      title: 'Total BOMs',
      dataIndex: 'totalBoms',
      key: 'totalBoms',
      width: 100,
      render: (count: number) => <Tag color="cyan">{count} Items</Tag>,
    },
    {
      title: 'Action',
      width: 120,
      fixed: "right" as const,
      render: (record: any) => {
        return (
          <Space size="small">
            <Tooltip title={isViewManufacturingBOMAuthorized ? "" : "You are not authorized to perform this action."}>
              <Button
                type="text"
                danger
                size="small"
                onClick={() => {
                  setManufacturingBomViewModal(true);
                  setSelectedProductCode(record.productCode)
                }}
                disabled={!isViewManufacturingBOMAuthorized}
                icon={<EyeTwoTone />}
              />
            </Tooltip>
          </Space>
        )
      }
    }
  ];

  // Tab items configuration
  const tabItems: TabsProps['items'] = [
    {
      key: 'packing',
      label: (
        <span>
          <FaCubes className="inline mb-1 mr-2" />
          Packing BOM
        </span>
      ),
      children: (
        <div>
          {/* Packing BOM Filters */}
          <Row gutter={[16, 16]} style={{ marginBottom: 16 }} justify="space-between">
            <Col span={8}>
              <Search
                placeholder="Search by product code or name..."
                allowClear
                onSearch={(value) => {
                  setPackingPagination(prev => ({ ...prev, current: 1 }));
                  setPackingSearchText(value);
                  getPackingBom(1, packingPagination.pageSize, value);
                }}
                style={{ width: '100%' }}
                prefix={<SearchOutlined />}
              />
            </Col>
            <Col span={12} style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <div className="flex flex-row gap-1">
                <Tooltip title="Refresh">
                  <Button
                    onClick={() => getPackingBom(packingPagination.current, packingPagination.pageSize, packingSearchText)}
                    icon={<ReloadOutlined />}
                  />
                </Tooltip>
                <Button
                  type="primary"
                  icon={<PlusOutlined />}
                  onClick={() => setAddPackingBom(true)}
                  disabled={!isCreatePackingBOMAuthorized}
                >
                  Add Packing BOM
                </Button>
              </div>
            </Col>
          </Row>

          {/* Packing BOM Table */}
          <Table
            columns={packingColumns}
            dataSource={packingBomData}
            loading={packingLoading}
            scroll={{ x: 'max-content' }}
            pagination={{
              current: packingPagination.current,
              pageSize: packingPagination.pageSize,
              total: packingPagination.total,
              showSizeChanger: true,
              pageSizeOptions: ['10', '20', '30', '40', '50'],
              onChange: (page: number, pageSize: number) => {
                setPackingPagination(prev => ({
                  ...prev,
                  current: page,
                  pageSize: pageSize,
                }));
                getPackingBom(page, pageSize, packingSearchText);
              },
            }}
          />
        </div>
      ),
    },
    {
      key: 'manufacturing',
      label: (
        <span>
          <FaIndustry className="inline mb-1 mr-2" />
          Manufacturing BOM
        </span>
      ),
      children: (
        <div>
          {/* Manufacturing BOM Filters */}
          <Row gutter={[16, 16]} style={{ marginBottom: 16 }} justify="space-between">
            <Col span={8}>
              <Search
                placeholder="Search by product code or name..."
                allowClear
                onSearch={(value) => {
                  setManufacturingPagination(prev => ({ ...prev, current: 1 }));
                  setManufacturingSearchText(value);
                  getManufacturingBom(1, manufacturingPagination.pageSize, value);
                }}
                style={{ width: '100%' }}
                prefix={<SearchOutlined />}
              />
            </Col>
            <Col span={12} style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <div className="flex flex-row gap-1">
                <Tooltip title="Refresh">
                  <Button
                    onClick={() => getManufacturingBom(manufacturingPagination.current, manufacturingPagination.pageSize, manufacturingSearchText)}
                    icon={<ReloadOutlined />}
                  />
                </Tooltip>
                <Button
                  type="primary"
                  icon={<PlusOutlined />}
                  onClick={() => setAddManufacturingBom(true)}
                  disabled={!isCreateManufacturingBOMAuthorized}
                >
                  Add Manufacturing BOM
                </Button>
              </div>
            </Col>
          </Row>

          {/* Manufacturing BOM Table */}
          <Table
            columns={manufacturingColumns}
            dataSource={manufacturingBomData}
            loading={manufacturingLoading}
            scroll={{ x: 'max-content' }}
            pagination={{
              current: manufacturingPagination.current,
              pageSize: manufacturingPagination.pageSize,
              total: manufacturingPagination.total,
              showSizeChanger: true,
              pageSizeOptions: ['10', '20', '30', '40', '50'],
              onChange: (page: number, pageSize: number) => {
                setManufacturingPagination(prev => ({
                  ...prev,
                  current: page,
                  pageSize: pageSize,
                }));
                getManufacturingBom(page, pageSize, manufacturingSearchText);
              },
            }}
          />
        </div>
      ),
    },
  ];

  return (
    <div>
      <Title level={2}>
        <FaCapsules size={30} className="inline mb-1" /> Bill of Materials
      </Title>
      <Card>
        <Tabs
          defaultActiveKey="packing"
          items={tabItems}
          onChange={handleTabChange}
        />
      </Card>
      <AddManufacturingBOM
        open={addManufacturingBom}
        onClose={() => setAddManufacturingBom(false)}
        onSuccess={() => {
          getManufacturingBom(manufacturingPagination.current, manufacturingPagination.pageSize, manufacturingSearchText);
        }}
      />
      <ManufacturingBomViewModal
        open={manufacturingBomViewModal}
        onClose={() => {
          setManufacturingBomViewModal(false);
          setSelectedProductCode(null);
        }}
        productCode={selectedProductCode || undefined}
        onSuccess={() => {
          getManufacturingBom(manufacturingPagination.current, manufacturingPagination.pageSize, manufacturingSearchText);
        }}
      // bomId={selectedManufacturingBomId || undefined}
      />
      <AddPackingBOM
        open={addPackingBom}
        onClose={() => setAddPackingBom(false)}
        onSuccess={() => {
          getPackingBom(packingPagination.current, packingPagination.pageSize, packingSearchText);
        }}
      />
      <PackingBomViewModal
        open={packingBomViewModal}
        onClose={() => {
          setPackingBomViewModal(false);
          setSelectedProductCode(null);
        }}
        productCode={selectedProductCode || undefined}
        onSuccess={() => {
          getPackingBom(packingPagination.current, packingPagination.pageSize, packingSearchText);
        }}
      />

    </div>
  )
}
