'use client'
import { Modal, Spin, Typography, Row, Col, Table, Button, message, Tag, Badge, Empty, Space, Tooltip } from "antd";
const { Title, Text } = Typography;
import { EyeOutlined, CheckCircleOutlined, InfoCircleOutlined, CloseOutlined, EditTwoTone, EyeTwoTone, CopyOutlined } from "@ant-design/icons";
import { useEffect, useState } from "react";
import dayjs from "dayjs";
import { useAuthorization } from "@/hooks/useAuthorization";
import UpdatePackingBOM from "./Update-Packing-Bom";
import ViewPackingBOM from "./View-Packing-BOM";
import AddPackingBOM from "./Add-Packing-BOM";


interface AddPackingBOMProps {
    open: boolean;
    onClose: () => void;
    onSuccess?: () => void;
    productCode?: string;
}

interface ProductInfo {
    _id?: string;
    productCode?: number;
    productName?: string;
    genericName?: string;
    shortName?: string;
    dosageForm?: string;
    strength?: string;
    therapeuticClass?: string[];
    shelfLife?: number;
    storageCondition?: string[];
    status?: string;
    gtinNumber?: string;
    registrationNumber?: string;
}

interface Material {
    materialCode: string;
    materialName: string;
    materialCategory?: string;
    quantity: number;
    uom: string;
}

interface BOMData {
    _id: string;
    productCode: string;
    productName: string;
    bomCode: string;
    bomVersion: string;
    batchSizeSemifinished: number;
    uom: string;
    bulkSize: number;
    bulkUom: string;
    status: string;
    effectiveDate: string;
    materials: Material[];
    createdBy: string;
    createdAt: string;
    updatedAt: string;
}

export default function PackingBomViewModal({ open, onClose, onSuccess, productCode }: AddPackingBOMProps) {
    const [loading, setLoading] = useState(false);
    const [productInfo, setProductInfo] = useState<ProductInfo | null>(null);
    const [bomList, setBomList] = useState<BOMData[]>([]);
    const [editPackingBom, setEditPackingBom] = useState(false);
    const [bomData, setBomData] = useState<any>(null);
    const [viewPackingBom, setViewPackingBom] = useState(false);
    const [editingBom, setEditingBom] = useState<any>(null);
    const [copyPackingBom, setCopyPackingBom] = useState(false);

    useEffect(() => {
        if (!open || !productCode) return;

        fetchProductInfo(productCode);
        fetchBom(productCode);
    }, [open, productCode]);

    useEffect(() => {
        if (!open) {
            setProductInfo(null)
            setBomList([])
        }
    }, [open])
    const fetchProductInfo = async (productCode: string) => {
        const token = localStorage.getItem('token');
        try {
            const res = await fetch(`/api/user/master-data/product-master?productCode=${productCode}`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                }
            });
            const data = await res.json();
            if (data.success && data.products && data.products.length > 0) {
                setProductInfo(data.products[0]);
            }
        } catch (error) {
            console.error(error);
            message.error("Error fetching product info");
        }
    };

    const fetchBom = async (productCode: string) => {
        const token = localStorage.getItem('token');
        try {
            setLoading(true);
            const res = await fetch(`/api/user/bill-of-material/packing?productCode=${productCode}`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                }
            });
            const data = await res.json();
            if (data.success) {
                setBomList(data.data || []);
            }
            console.log(data.data);
        } catch (error) {
            console.error(error);
            message.error("Error fetching Packing BOM");
        } finally {
            setLoading(false);
        }
    };

    // Helper to render info row
    const renderInfoRow = (label: string, value: any, span: number = 8) => (
        <Col xs={24} sm={span}>
            <div style={{
                padding: '12px 16px',
                background: '#fafafa',
                borderRadius: 8,
                height: '100%',
                border: '1px solid #f0f0f0'
            }}>
                <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block' }}>
                    {label}
                </Text>
                <Text strong style={{ fontSize: 15, color: '#262626' }}>
                    {value || <span style={{ color: '#bfbfbf' }}>-</span>}
                </Text>
            </div>
        </Col>
    );

    // Helper to render tags
    const renderTags = (items: string[] | undefined, color: string = "blue") => {
        if (!items?.length) return <Text type="secondary">-</Text>;
        return (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {items.map((item: string) => (
                    <Tag
                        key={item}
                        color={color}
                        style={{ margin: 0, fontSize: 12, padding: '2px 10px' }}
                    >
                        {item}
                    </Tag>
                ))}
            </div>
        );
    };

    const getStatusColor = (status: string) => {
        const colors: Record<string, string> = {
            'Active': 'green',
            'Draft': 'orange',
            'Inactive': 'default',
            'Under Review': 'blue',
        };
        return colors[status] || 'blue';
    };

    const formatDate = (date: string) => {
        return date ? dayjs(date).format('DD-MMM-YYYY') : '-';
    };

    // Authorization check
    const { hasAccess } = useAuthorization();
    const isViewPackingBOMAuthorized = hasAccess('Packaging BOM', 'read');
    const isUpdatePackingBOMAuthorized = hasAccess('Packaging BOM', 'update');

    // Table columns for BOM
    const bomColumns = [
        {
            title: 'BOM Code',
            dataIndex: 'bomCode',
            key: 'bomCode',
            render: (text: string) => <Text strong style={{ color: '#1677ff' }}>{text}</Text>,
        },
        {
            title: 'Version',
            dataIndex: 'bomVersion',
            key: 'bomVersion',
            render: (text: string) => <Text>{text}</Text>,
        },
        {
            title: 'Batch Size',
            key: 'batchSize',
            render: (_: any, record: BOMData) => (
                <Text>{record.batchSizeSemifinished} {record.uom}</Text>
            ),
        },
        {
            title: 'Bulk Size',
            key: 'bulkSize',
            render: (_: any, record: BOMData) => (
                <Text>{record.bulkSize} {record.bulkUom}</Text>
            ),
        },
        {
            title: 'Materials',
            key: 'materials',
            align: 'center' as const,
            render: (_: any, record: BOMData) => (
                <Badge
                    count={record.materials?.length || 0}
                    style={{ backgroundColor: '#1890ff' }}
                    showZero={true}
                />
            ),
        },
        {
            title: 'Status',
            dataIndex: 'status',
            key: 'status',
            render: (status: string) => (
                <Tag color={getStatusColor(status)}>{status}</Tag>
            ),
        },
        {
            title: 'Effective Date',
            dataIndex: 'effectiveDate',
            key: 'effectiveDate',
            render: (date: string) => <Text>{formatDate(date)}</Text>,
        },
        {
            title: "Validity Till",
            dataIndex: 'validTill',
            key: 'validiTill',
            render: (date: string) => <Text>{formatDate(date)}</Text>,
        },
        {
            title: 'Action',
            width: 80,
            fixed: "right" as const,
            render: (record: any) => {
                return (
                    <Space size="small">
                        <Tooltip title={isViewPackingBOMAuthorized ? "" : "You are not authorized to perform this action."}>
                            <Button
                                type="text"
                                danger
                                size="small"
                                onClick={() => {
                                    setViewPackingBom(true);
                                    setBomData(record)
                                }}
                                disabled={!isViewPackingBOMAuthorized}
                                icon={<EyeTwoTone />}
                            />
                        </Tooltip>
                        <Tooltip title={isUpdatePackingBOMAuthorized ? "" : "You are not authorized to perform this action."}>
                            <Button onClick={() => {
                                setEditPackingBom(true)
                                setBomData(record)
                            }}
                                disabled={!isUpdatePackingBOMAuthorized}
                                type="text"
                                size="small"
                                icon={<EditTwoTone />}
                            />

                        </Tooltip>
                        <Tooltip title="Copy BOM">
                            <Button
                                onClick={() => {
                                    setCopyPackingBom(true);
                                    setEditingBom(record); // existing BOM data
                                }}
                                type="text"
                                size="small"
                                icon={<CopyOutlined />}
                            />
                        </Tooltip>
                    </Space>
                )
            }
        }
    ];
    const materialColumns = [
        {
            title: 'Material Code',
            dataIndex: 'materialCode',
            key: 'materialCode',
            width: 120,
            render: (_: any, record: Material) => (
                <Text copyable style={{ color: '#1677ff', fontWeight: 500 }}>
                    {record.materialCode}
                </Text>
            ),
        },
        {
            title: 'Material Name',
            dataIndex: 'materialName',
            key: 'materialName',
            width: 180,
            ellipsis: true,
            render: (_: any, record: Material) => (
                <Text strong>{record.materialName}</Text>
            ),
        },
        {
            title: 'Material Category',
            dataIndex: 'materialCategory',
            key: 'materialCategory',
            width: 180,
            ellipsis: true,
            render: (_: any, record: Material) => (
                <Text strong>{record.materialCategory}</Text>
            ),
        },
        {
            title: 'Quantity',
            dataIndex: 'quantity',
            key: 'quantity',
            width: 100,
            render: (qty: number, record: Material) => (
                <span>{qty} {record.uom}</span>
            ),
        },
        {
            title: 'UOM',
            dataIndex: 'uom',
            key: 'uom',
            width: 150,
            render: (_: any, record: Material) => (
                <Tag color="blue">{record.uom}</Tag>
            ),
        },
    ]

    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            centered
            width={1000}
            destroyOnClose
            closable={false}
            styles={{
                header: {
                    background: '#001529',
                    padding: '16px 24px',
                },
                body: { padding: 0 },
            }}
            title={
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{
                        width: 40,
                        height: 40,
                        borderRadius: 8,
                        background: 'linear-gradient(135deg, #1890ff 0%, #36cfc9 100%)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <EyeOutlined style={{ fontSize: 20, color: '#fff' }} />
                    </div>
                    <div>
                        <Title level={5} style={{ marginBottom: 0, color: '#fff' }}>
                            Packing BOM - {productInfo?.productName || 'Loading...'}
                        </Title>
                        <Text style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12 }}>
                            {productInfo?.genericName || 'View BOM information'}
                        </Text>
                    </div>
                </div>
            }
        >
            {loading && !productInfo ? (
                <div style={{ textAlign: 'center', padding: '60px 0' }}>
                    <Spin size="large" />
                    <div style={{ marginTop: 16 }}>
                        <Text type="secondary">Loading Packing BOM...</Text>
                    </div>
                </div>
            ) : (
                <div>
                    {/* Product Info Section */}
                    {productInfo && (
                        <>
                            {/* Quick Stats Bar */}
                            <div style={{
                                padding: '12px 24px',
                                background: '#fafafa',
                                borderBottom: '1px solid #f0f0f0',
                                display: 'flex',
                                gap: 24,
                                flexWrap: 'wrap'
                            }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                                    <CheckCircleOutlined style={{ color: productInfo.status === 'Active' ? '#52c41a' : '#faad14' }} />
                                    <Text strong>{productInfo.status || 'N/A'}</Text>
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                                    <InfoCircleOutlined style={{ color: '#1890ff' }} />
                                    <Text>{productInfo.dosageForm || 'N/A'}</Text>
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                                    <InfoCircleOutlined style={{ color: '#722ed1' }} />
                                    <Text>{productInfo.strength || 'N/A'}</Text>
                                </div>
                            </div>

                            {/* Product Details */}
                            <div style={{ padding: '16px 24px' }}>
                                <Row gutter={[16, 16]}>
                                    {renderInfoRow("Product Code", productInfo.productCode, 6)}
                                    {renderInfoRow("Product Name", productInfo.productName, 6)}
                                    {renderInfoRow("Generic Name", productInfo.genericName, 6)}
                                    {renderInfoRow("Short Name", productInfo.shortName, 6)}
                                    {renderInfoRow("Dosage Form", productInfo.dosageForm, 6)}
                                    {renderInfoRow("Strength", productInfo.strength, 6)}
                                    <Col xs={24} sm={12}>
                                        <div style={{
                                            padding: '12px 16px',
                                            background: '#f9f0ff',
                                            borderRadius: 8,
                                            height: '100%',
                                            border: '1px solid #d3adf7'
                                        }}>
                                            <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block' }}>
                                                Therapeutic Class
                                            </Text>
                                            <div style={{ marginTop: 4 }}>
                                                {renderTags(productInfo.therapeuticClass, 'purple')}
                                            </div>
                                        </div>
                                    </Col>
                                    {renderInfoRow("GTIN Number", productInfo.gtinNumber, 6)}
                                    {renderInfoRow("Registration Number", productInfo.registrationNumber, 6)}
                                </Row>
                            </div>
                        </>
                    )}

                    {/* BOM Table Section */}
                    <div style={{ padding: '16px 24px 24px', borderTop: '1px solid #f0f0f0' }}>
                        <div style={{ marginBottom: 16 }}>
                            <Title level={5} style={{ marginBottom: 0 }}>
                                Packing BOM List
                            </Title>
                            <Text type="secondary">
                                {bomList.length} BOM{bomList.length !== 1 ? 's' : ''} found for this product
                            </Text>
                        </div>

                        {bomList.length === 0 ? (
                            <Empty
                                description="No BOM found for this product"
                                image={Empty.PRESENTED_IMAGE_SIMPLE}
                            />
                        ) : (
                            <Table
                                dataSource={bomList}
                                columns={bomColumns}
                                expandable={{
                                    expandedRowRender: (record: BOMData) => (
                                        <div style={{ padding: '12px 24px' }}>
                                            <Table
                                                dataSource={record.materials}
                                                columns={materialColumns}
                                                pagination={false}
                                                size="small"
                                                bordered
                                                rowKey="materialCode"
                                                scroll={{ x: 500 }}
                                            />
                                        </div>
                                    )
                                }}
                                rowKey="_id"
                                pagination={{ pageSize: 5 }}
                                size="small"
                                bordered
                                scroll={{ x: true }}
                            />
                        )}
                    </div>

                    {/* Actions */}
                    <div style={{
                        padding: '16px 24px',
                        borderTop: '1px solid #f0f0f0',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        background: '#fafafa'
                    }}>
                        <Text type="secondary" style={{ fontSize: 12 }}>
                            Product Code: {productCode || 'N/A'}
                            <br />
                            Product Id: {productInfo?._id || 'N/A'}
                        </Text>
                        <Button
                            onClick={onClose}
                            icon={<CloseOutlined />}
                            type="primary"
                        >
                            Close
                        </Button>
                    </div>
                </div>
            )}
             <UpdatePackingBOM
                open={editPackingBom}
                onClose={() => {
                    setEditPackingBom(false);
                    setBomData(null);
                }}
                onSuccess={() => {
                    fetchBom(productCode as any);
                }}
                bomData={bomData}
            />
            <ViewPackingBOM
                open={viewPackingBom}
                onClose={() => {
                    setViewPackingBom(false);
                    setBomData(null);
                }}
                bomData={bomData}
            /> 
            <AddPackingBOM
                open={copyPackingBom}
                onClose={() => {
                    setCopyPackingBom(false);
                    setEditingBom(null);
                }}
                onSuccess={() => {
                    fetchBom(productCode as any);
                }}
                editData={editingBom}
            />
        </Modal>
    )
}
