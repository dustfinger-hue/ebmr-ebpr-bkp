'use client'
import { Form, Input, Modal, Select, Spin, Typography, Row, Col, DatePicker, InputNumber, Table, Button, message, Badge, Tag } from "antd";
const { Title, Text } = Typography;
import { PlusOutlined, MinusCircleOutlined } from "@ant-design/icons";
import { useEffect, useState } from "react";
import { useDebounce } from "use-debounce";
import { UOM_OPTION_PACKAGIGN_MATERIAL, UOM_OPTIONS, UOM_OPTIONS_BULK } from "@/lib/constants/Generarl";


interface AddPackingBOMProps {
    open: boolean;
    onClose: () => void;
    onSuccess?: () => void;
    editData?: any;
}

interface MaterialRow {
    key: string;
    materialCode: string;
    materialName: string;
    materialCategory: string;
    quantity: number;
    uom: string;
}

export default function AddPackingBOM({ open, onClose, onSuccess, editData }: AddPackingBOMProps) {
    const [form] = Form.useForm();
    const [loading, setLoading] = useState(false);
    const [productOptions, setProductOptions] = useState<any>([]);
    const [materialOptions, setMaterialOptions] = useState<any>([]);
    const [searchValue, setSearchValue] = useState("");
    const [materialSearchValue, setMaterialSearchValue] = useState("");
    const [referenceManufacturingBomValue, setReferenceManufacturingBomValue] = useState("");
    const [referenceManufacturingBomOptions, setReferenceManufacturingBomOptions] = useState<any>([]);
    const [materialRows, setMaterialRows] = useState<MaterialRow[]>([]);

    //Debounce the search input to limit API calls
    const [debouncedSearchValue] = useDebounce(searchValue, 500);
    const [debouncedMaterialSearchValue] = useDebounce(materialSearchValue, 500);

    useEffect(() => {
        fetchProduct(debouncedSearchValue);
    }, [debouncedSearchValue]);

    useEffect(() => {
        fetchMaterial(debouncedMaterialSearchValue);
    }, [debouncedMaterialSearchValue]);

    // Fetch all Manufacturing BOMs when modal opens
    useEffect(() => {
        if (open) {
            fetchAllManufacturingBoms();
        }
    }, [open]);

    // Reset material rows when modal closes or opens with editData
    useEffect(() => {
        if (!open) {
            setMaterialRows([]);
            form.resetFields();
            setSearchValue("");
            setMaterialSearchValue("");
            setReferenceManufacturingBomValue("");
            setReferenceManufacturingBomOptions([]);
        } else if (editData) {
            // Copy mode - pre-fill form with existing BOM data
            // Version will be auto-set by fetchLatestVersion call below (highest + 1)
            form.setFieldsValue({
                productCode: editData.productCode,
                // productName: editData.productName,
                batchSizeSemifinished: editData.batchSizeSemifinished,
                uom: editData.uom,
                bulkSize: editData.bulkSize,
                bulkUom: editData.bulkUom,
                status: 'Draft',
                effectiveDate: null,
            });
            setSearchValue(editData.productName);

            // Pre-fill materials
            if (editData.materials && editData.materials.length > 0) {
                const rows = editData.materials.map((mat: any, index: number) => ({
                    key: `material-${Date.now()}-${index}`,
                    materialCode: mat.materialCode,
                    materialName: mat.materialName,
                    quantity: mat.quantity,
                    uom: mat.uom
                }));
                setMaterialRows(rows);

                // Also set form field value for materials so they display in table
                form.setFieldValue('materials', editData.materials);
            }

            // Call fetchLatestVersion to get highest version + 1
            fetchLatestVersion(editData.productCode);
        }
    }, [open, editData, form]);

    // Auto-increment version when product is selected
    const fetchLatestVersion = async (productCode: string) => {
        console.log('fetchLatestVersion', productCode);
        try {
            const token = localStorage.getItem('token');
            const res = await fetch(`/api/user/bill-of-material/packing?productCode=${productCode}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            const data = await res.json();
            if (data.success && data.data && data.data.length > 0) {
                // Find the highest version
                const versions = data.data.map((bom: any) => parseFloat(bom.bomVersion || '0'));
                const maxVersion = Math.max(...versions);
                const newVersion = (maxVersion + 1).toFixed(1);
                form.setFieldValue('bomVersion', newVersion);
            } else {
                form.setFieldValue('bomVersion', '1.0');
            }
        } catch (error) {
            console.error('Error fetching latest version:', error);
            form.setFieldValue('bomVersion', '1.0');
        }
    };

    const fetchAllManufacturingBoms = async (productCode?: string) => {
        if (!productCode) return;
        setLoading(true);
        try {
            const token = localStorage.getItem('token');
            const res = await fetch(`/api/user/bill-of-material/manufacturing?productCode=${productCode}&limit=1000`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            const data = await res.json();
            if (data.success && data.data && data.data.length > 0) {
                const mappedData = data.data.map((bom: any) => ({
                    label:
                        // <>
                        //     <Text>{bom.productName}</Text> <br />
                        //     <div className="flex flex-row justify-between">
                        //         <Text type="secondary">{bom.bomCode}-(v{bom.bomVersion})</Text>
                        //         <Tag variant="outlined" color={bom.status === 'Active' ? 'blue' : 'default'}>
                        //             {bom.status}
                        //         </Tag>
                        //     </div>
                        // </>,
                        <div className="flex items-center justify-between w-full">
                            <span className="text-gray-900 font-medium mr-2">
                                {bom.productName}
                                <span className="text-gray-500 text-sm ml-1">
                                    ({bom.bomCode}-v{bom.bomVersion})
                                </span>
                            </span>
                            <span className={`w-3 h-3 rounded-full ${bom.status === 'Active' ? 'bg-green-500' : 'bg-gray-400'}`} title={bom.status}></span>
                        </div>,
                    value: bom.bomCode,
                    manufacturingBom: bom
                }));
                setReferenceManufacturingBomOptions(mappedData);
            }
        } catch (error) {
            console.error("Error fetching manufacturing BOMs:", error);
            message.error("An error occurred while fetching manufacturing BOMs");
        } finally {
            setLoading(false);
        }
    };

    const fetchProduct = async (search: string) => {
        if (!search) return [];
        if (search) {
            setLoading(true);
            try {
                const res = await fetch(
                    `/api/user/master-data/product-master?search=${search}&limit=10`
                );
                const data = await res.json();
                if (data.success && data.products) {
                    const mappedData = data.products.map((item: any) => ({
                        label: `${item.productName} - ${item.productCode}`,
                        value: item.productName,
                        product: item
                    }));
                    setProductOptions(mappedData);
                }
            } catch (error) {
                console.error("Error fetching products:", error);
                message.error("An error occurred while fetching products");
            } finally {
                setLoading(false);
            }
        } else {
            setProductOptions([]);
        }

    };

    const fetchMaterial = async (search: string) => {
        if (!search) {
            setMaterialOptions([]);
            return;
        }
        setLoading(true);
        try {
            const res = await fetch(
                `/api/user/master-data/material-master?search=${search}&limit=10`
            );
            const data = await res.json();
            if (data.success && data.materials) {
                const mappedData = data.materials.map((item: any) => ({
                    label: `${item.materialName}`,
                    value: item.materialName,
                    material: item
                }));
                setMaterialOptions(mappedData);
            }
        } catch (error) {
            console.error("Error fetching materials:", error);
            message.error("An error occurred while fetching materials");
        } finally {
            setLoading(false);
        }
    };

    const handleProductSearch = (value: string) => {
        setSearchValue(value);
    };

    const handleProductChange = async (value: any, option: any) => {
        if (option?.product) {
            form.setFieldValue("productCode", option.product.productCode);
            form.setFieldValue("productName", option.product.productName);
            // Auto-increment version when product is selected - always use highest version + 1
            await fetchLatestVersion(option.product.productCode);
            // Fetch all manufacturing BOMs for the selected product
            fetchAllManufacturingBoms(option.product.productCode);
        }
    };

    const handleMaterialSearch = (value: string) => {
        setMaterialSearchValue(value);
    };
    const handleReferenceManufacturingBomChange = async (value: any, option: any) => {
        if (option?.manufacturingBom?.bomCode) {
            form.setFieldValue("referenceManufacturingBom", option.manufacturingBom.bomCode);
            form.setFieldValue("batchSizeSemifinished", option.manufacturingBom.batchSizeSemifinished)
            form.setFieldValue("uom", option.manufacturingBom.uom)
            form.setFieldValue("bulkSize", option.manufacturingBom.bulkSize)
            form.setFieldValue("bulkUom", option.manufacturingBom.bulkUom)
        }
    };

    const addMaterialRow = () => {
        const newRow: MaterialRow = {
            key: `material-${Date.now()}-${Math.random()}`,
            materialCode: '',
            materialName: '',
            materialCategory: '',
            quantity: 0,
            uom: ''
        };
        setMaterialRows([...materialRows, newRow]);
    };

    const removeMaterialRow = (key: string) => {
        const updatedRows = materialRows.filter(row => row.key !== key);
        setMaterialRows(updatedRows);
        // Also update form values
        const materials = form.getFieldValue("materials") || [];
        materials.splice(materialRows.findIndex(row => row.key === key), 1);
        form.setFieldValue("materials", materials);
    };

    const handleMaterialSelect = (value: any, option: any, key: string) => {
        const updatedRows = materialRows.map(row => {
            if (row.key === key) {
                return {
                    ...row,
                    materialCode: option.material?.materialCode || '',
                    materialName: value,
                    materialCategory: option.material?.category || ''
                };
            }
            return row;
        });
        setMaterialRows(updatedRows);

        // Update form values
        const materials = form.getFieldValue("materials") || [];
        const index = materialRows.findIndex(row => row.key === key);
        if (!materials[index]) {
            materials[index] = {};
        }
        materials[index].materialCode = option.material?.materialCode || '';
        materials[index].materialName = value;
        materials[index].materialCategory = option.material?.category || '';
        form.setFieldValue("materials", materials);
    };

    const handleQuantityChange = (value: number | null, key: string) => {
        const updatedRows = materialRows.map(row => {
            if (row.key === key) {
                return { ...row, quantity: value || 0 };
            }
            return row;
        });
        setMaterialRows(updatedRows);

        // Update form values
        const materials = form.getFieldValue("materials") || [];
        const index = materialRows.findIndex(row => row.key === key);
        if (materials[index]) {
            materials[index].quantity = value || 0;
        }
        form.setFieldValue("materials", materials);
    };

    const handleUomChange = (value: string, key: string) => {
        const updatedRows = materialRows.map(row => {
            if (row.key === key) {
                return { ...row, uom: value };
            }
            return row;
        });
        setMaterialRows(updatedRows);

        // Update form values
        const materials = form.getFieldValue("materials") || [];
        const index = materialRows.findIndex(row => row.key === key);
        if (materials[index]) {
            materials[index].uom = value;
        }
        form.setFieldValue("materials", materials);
    };

    const handleFinish = async (values: FormData) => {
        try {
            setLoading(true);
            console.log(values);
            const token = localStorage.getItem('token');
            const res = await fetch(`/api/user/bill-of-material/packing`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(values)
            });
            const data = await res.json();
            if (data.success) {
                message.success(data.message || `packing BOM ${data.bomCode} created successfully!`);
                onSuccess?.();
                onClose();
            } else {
                message.error(data.message || 'An error occurred while creating the packing BOM');
            }
        } catch (error) {
            console.error("Error submitting form:", error);
            message.error("An error occurred while submitting the form");
        } finally {
            setLoading(false);
        }
    };
    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            centered
            width={900}
            destroyOnHidden
            closable={false}
            styles={{
                header: {
                    background: '#001529',
                    padding: '16px 24px',
                },
                body: { padding: 0 },
            }}
            title={
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{
                        width: 40,
                        height: 40,
                        borderRadius: 8,
                        background: 'linear-gradient(135deg, #1890ff 0%, #36cfc9 100%)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <PlusOutlined style={{ fontSize: 20, color: '#fff' }} />
                    </div>
                    <div>
                        <Title level={5} style={{ marginBottom: 0, color: '#fff' }}>
                            Add packing BOM
                        </Title>
                        <Text style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12 }}>
                            Enter packing BOM information carefully
                        </Text>
                    </div>
                </div>
            }
        >
            <Form
                form={form}
                layout="vertical"
                name="packing_bom_form"
                onFinish={handleFinish}
                initialValues={{
                    bomVersion: '1.0',
                    status: 'Draft',
                    uom: 'Tablets'
                }}
            >
                <div style={{ padding: '24px', maxHeight: '60vh', overflowY: 'auto' }}>

                    {/* Product Selection Row */}
                    <Row gutter={[16, 0]} style={{ marginBottom: 16 }}>
                        <Col xs={24} sm={12} md={8}>
                            <Form.Item
                                name="productCode"
                                label="Product Code"
                                rules={[{ required: true, message: "Enter product code" }]}
                            >
                                <Input placeholder="Auto-filled from product" disabled />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={16}>
                            <Form.Item
                                name="productName"
                                label="Product Name"
                                rules={[{ required: true, message: "Select product name" }]}
                            >
                                <Select
                                    showSearch
                                    value={searchValue}
                                    placeholder="Search Product by name or code..."
                                    style={{ width: "100%" }}
                                    defaultActiveFirstOption={false}
                                    filterOption={false}
                                    onSearch={handleProductSearch}
                                    onChange={handleProductChange}
                                    notFoundContent={loading ? <Spin size="small" /> : null}
                                    options={productOptions}
                                />
                            </Form.Item>
                        </Col>
                    </Row>

                    {/* BOM Version and Status Row */}
                    <Row gutter={[16, 0]} style={{ marginBottom: 16 }}>
                        <Col xs={24} sm={12} md={12}>
                            <Form.Item
                                name="referenceManufacturingBom"
                                label="Reference Manufacturing BOM"
                                rules={[{ required: true, message: "Select reference manufacturing BOM" }]}
                            >
                                <Select
                                    showSearch
                                    value={referenceManufacturingBomValue}
                                    placeholder="Select Manufacturing BOM..."
                                    style={{ width: "100%" }}
                                    defaultActiveFirstOption={false}
                                    filterOption={false}
                                    onChange={handleReferenceManufacturingBomChange}
                                    notFoundContent={loading ? <Spin size="small" /> : null}
                                    options={referenceManufacturingBomOptions}
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                name="bomVersion"
                                label="BOM Version"
                                rules={[{ required: true, message: "Enter BOM version" }]}
                            >
                                <Input placeholder="Enter BOM version" />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                name='status'
                                label='Status'
                                rules={[{ required: true, message: "Select status" }]}
                            >
                                <Select placeholder="Select status" options={[
                                    { value: 'Draft', label: 'Draft' },
                                    { value: 'Active', label: 'Active' },
                                    { value: 'Inactive', label: 'Inactive' },
                                    { value: 'Under Review', label: 'Under Review' },
                                ]} />
                            </Form.Item>
                        </Col>
                    </Row>

                    {/* Batch Size and UOM Row */}
                    <Row gutter={[16, 0]} style={{ marginBottom: 16 }}>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                name='batchSizeSemifinished'
                                label={<>Batch Size <Text type="secondary">(Semi-finished)</Text></>}
                                rules={[{ required: true, message: "Enter batch size" }]}
                            >
                                <InputNumber placeholder="Enter batch size" style={{ width: '100%' }} min={0} />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                name='uom'
                                label='Unit of Measure'
                                rules={[{ required: true, message: "Select unit of measure" }]}
                            >
                                <Select placeholder="Select unit of measure" options={UOM_OPTIONS} />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                name='bulkSize'
                                label={<>Batch Size <Text type="secondary">(Bulk)</Text></>}
                                rules={[{ required: true, message: "Enter bulk batch size" }]}
                            >
                                <InputNumber
                                    placeholder="Enter bulk batch size"
                                    style={{ width: '100%' }}
                                    min={0}
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={6}>
                            <Form.Item
                                name='bulkUom'
                                label='Bulk Unit of Measure'
                                rules={[{ required: true, message: "Select bulk unit of measure" }]}
                            >
                                <Select
                                    placeholder="Select bulk unit of measure"
                                    options={UOM_OPTIONS_BULK}
                                />
                            </Form.Item>
                        </Col>
                        <Col xs={24} sm={12} md={8}>
                            <Form.Item
                                name='effectiveDate'
                                label='Effective Date'
                                rules={[{ required: true, message: "Select effective date" }]}
                            >
                                <DatePicker style={{ width: '100%' }} />
                            </Form.Item>
                        </Col>
                    </Row>

                    {/* Materials Section */}
                    <div style={{ marginTop: 24, marginBottom: 16 }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                            <Title level={5} style={{ marginBottom: 0 }}>Materials</Title>
                            <Button type="dashed" onClick={addMaterialRow} icon={<PlusOutlined />}>
                                Add Material
                            </Button>
                        </div>

                        {materialRows.length === 0 ? (
                            <div style={{ textAlign: 'center', padding: '20px', border: '1px dashed #d9d9d9', borderRadius: 8 }}>
                                <Text type="secondary">No materials added yet. Click "Add Material" to add materials.</Text>
                            </div>
                        ) : (
                            <Table
                                dataSource={materialRows}
                                pagination={false}
                                size="small"
                                bordered
                                columns={[
                                    {
                                        title: 'Material Code',
                                        dataIndex: 'materialCode',
                                        key: 'materialCode',
                                        width: '20%',
                                        render: (text: string, record: MaterialRow) => (
                                            <Form.Item
                                                name={['materials', materialRows.indexOf(record), 'materialCode']}
                                                noStyle
                                            >
                                                <Input placeholder="Auto-filled" value={text} disabled />
                                            </Form.Item>
                                        )
                                    },
                                    {
                                        title: 'Material Name',
                                        dataIndex: 'materialName',
                                        key: 'materialName',
                                        width: '40%',
                                        render: (_: any, record: MaterialRow) => (
                                            <Form.Item
                                                name={['materials', materialRows.indexOf(record), 'materialName']}
                                                noStyle
                                            >
                                                <Select
                                                    showSearch
                                                    placeholder="Search material..."
                                                    style={{ width: '100%' }}
                                                    defaultActiveFirstOption={false}
                                                    filterOption={false}
                                                    onSearch={handleMaterialSearch}
                                                    onChange={(value, option) => handleMaterialSelect(value, option, record.key)}
                                                    notFoundContent={loading ? <Spin size="small" /> : null}
                                                    options={materialOptions}
                                                />
                                            </Form.Item>
                                        )
                                    },
                                    {
                                        title: 'Material Category',
                                        dataIndex: 'materialCategory',
                                        key: 'materialCategory',
                                        width: '30%',
                                        render: (text: string, record: MaterialRow) => (
                                            <Form.Item
                                                name={['materials', materialRows.indexOf(record), 'materialCategory']}
                                                noStyle
                                            >
                                                <Input placeholder="Auto-filled" value={text} disabled />
                                            </Form.Item>
                                        )
                                    },
                                    {
                                        title: 'Quantity',
                                        dataIndex: 'quantity',
                                        key: 'quantity',
                                        width: '20%',
                                        render: (_: any, record: MaterialRow) => (
                                            <Form.Item
                                                name={['materials', materialRows.indexOf(record), 'quantity']}
                                                noStyle
                                            >
                                                <InputNumber
                                                    placeholder="Enter quantity"
                                                    style={{ width: '100%' }}
                                                    min={0}
                                                    onChange={(value) => handleQuantityChange(value, record.key)}
                                                />
                                            </Form.Item>
                                        )
                                    },
                                    {
                                        title: 'UOM',
                                        dataIndex: 'uom',
                                        key: 'uom',
                                        width: '15%',
                                        render: (_: any, record: MaterialRow) => (
                                            <Form.Item
                                                name={['materials', materialRows.indexOf(record), 'uom']}
                                                noStyle
                                            >
                                                <Select
                                                    placeholder="Select UOM"
                                                    options={UOM_OPTION_PACKAGIGN_MATERIAL}
                                                    onChange={(value) => handleUomChange(value, record.key)}
                                                />
                                            </Form.Item>
                                        )
                                    },
                                    {
                                        title: 'Action',
                                        key: 'action',
                                        width: '5%',
                                        render: (_: any, record: MaterialRow) => (
                                            <Button
                                                type="text"
                                                danger
                                                icon={<MinusCircleOutlined />}
                                                onClick={() => removeMaterialRow(record.key)}
                                            />
                                        )
                                    }
                                ]}
                            />
                        )}
                    </div>
                </div>
                <div style={{ marginTop: 24, padding: '0 24px 24px' }}>
                    <Text type="secondary">All fields marked as * are required</Text>
                </div>
                <div style={{ padding: '0 24px 24px', display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
                    <Button
                        type="primary"
                        htmlType="submit"
                        loading={loading}
                    >
                        Submit
                    </Button>
                </div>
            </Form>
        </Modal>
    )
}
