'use client'
import { Modal, Spin, Typography, Row, Col, Table, Button, Tag, Badge, Empty, Card } from "antd";
const { Title, Text, Paragraph } = Typography;
import { EyeOutlined, CheckCircleOutlined, InfoCircleOutlined, CloseOutlined, CalendarOutlined } from "@ant-design/icons";
import { useEffect, useState } from "react";
import dayjs from "dayjs";

interface ViewPackingBOMProps {
    open: boolean;
    onClose: () => void;
    bomData?: any;
}

interface Material {
    materialCode: string;
    materialName: string;
    materialCategory?: string;
    quantity: number;
    uom: string;
}

export default function ViewPackingBOM({ open, onClose, bomData }: ViewPackingBOMProps) {
    const [loading, setLoading] = useState(false);

    const getStatusColor = (status: string) => {
        const colors: Record<string, string> = {
            'Active': 'green',
            'Draft': 'orange',
            'Inactive': 'default',
            'Under Review': 'blue',
        };
        return colors[status] || 'blue';
    };

    const formatDate = (date: string) => {
        return date ? dayjs(date).format('DD-MMM-YYYY') : '-';
    };

    // Materials table columns
    const materialColumns = [
        {
            title: 'Material Code',
            dataIndex: 'materialCode',
            key: 'materialCode',
            render: (text: string) => <Text strong style={{ color: '#1677ff' }}>{text}</Text>,
        },
        {
            title: 'Material Name',
            dataIndex: 'materialName',
            key: 'materialName',
        },
        {
            title: 'Material Category',
            dataIndex: 'materialCategory',
            key: 'materialCategory',
        },
        {
            title: 'Quantity',
            dataIndex: 'quantity',
            key: 'quantity',
            align: 'right' as const,
            render: (quantity: number, record: Material) => (
                <Text strong>{quantity} {record.uom}</Text>
            ),
        },
        {
            title: 'UOM',
            dataIndex: 'uom',
            key: 'uom',
            render: (_: any, record: Material) => (
                <Tag color="blue">{record.uom}</Tag>
            ),
        },
    ];

    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            centered
            width={900}
            destroyOnHidden
            closable={false}
            styles={{
                header: {
                    background: '#001529',
                    padding: '16px 24px',
                },
                body: { padding: 0 },
            }}
            title={
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{
                        width: 40,
                        height: 40,
                        borderRadius: 8,
                        background: 'linear-gradient(135deg, #1890ff 0%, #36cfc9 100%)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <EyeOutlined style={{ fontSize: 20, color: '#fff' }} />
                    </div>
                    <div>
                        <Title level={5} style={{ marginBottom: 0, color: '#fff' }}>
                            BOM Details - {bomData?.bomCode || 'Loading...'}
                        </Title>
                        <Text style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12 }}>
                            {bomData?.productName || 'View BOM information'}
                        </Text>
                    </div>
                </div>
            }
        >
            {!bomData ? (
                <div style={{ textAlign: 'center', padding: '60px 0' }}>
                    <Spin size="large" />
                    <div style={{ marginTop: 16 }}>
                        <Text type="secondary">Loading BOM details...</Text>
                    </div>
                </div>
            ) : (
                <div>
                    {/* Quick Stats Bar */}
                    <div style={{ 
                        padding: '12px 24px', 
                        background: '#fafafa', 
                        borderBottom: '1px solid #f0f0f0',
                        display: 'flex',
                        gap: 24,
                        flexWrap: 'wrap'
                    }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                            <CheckCircleOutlined style={{ color: getStatusColor(bomData.status) === 'green' ? '#52c41a' : '#faad14' }} />
                            <Text strong>{bomData.status || 'N/A'}</Text>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                            <InfoCircleOutlined style={{ color: '#1890ff' }} />
                            <Text>Version: {bomData.bomVersion || 'N/A'}</Text>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                            <CalendarOutlined style={{ color: '#722ed1' }} />
                            <Text>Effective: {formatDate(bomData.effectiveDate)}</Text>
                        </div>
                    </div>

                    {/* BOM Information Section */}
                    <div style={{ padding: '16px 24px' }}>
                        <Title level={5} style={{ marginBottom: 16 }}>
                            BOM Information
                        </Title>
                        <Row gutter={[16, 16]}>
                            <Col xs={24} sm={12}>
                                <div style={{ 
                                    padding: '12px 16px', 
                                    background: '#fafafa', 
                                    borderRadius: 8,
                                    border: '1px solid #f0f0f0'
                                }}>
                                    <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block' }}>
                                        BOM Code
                                    </Text>
                                    <Text strong style={{ fontSize: 15, color: '#1677ff' }}>
                                        {bomData.bomCode || '-'}
                                    </Text>
                                </div>
                            </Col>
                            <Col xs={24} sm={12}>
                                <div style={{ padding: '12px 16px', background: '#fafafa', borderRadius: 8, border: '1px solid #f0f0f0' }}>
                                    <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block' }}>
                                        Reference Manufacturing BOM
                                    </Text>
                                    <Text strong style={{ fontSize: 15 }}>
                                        {bomData.referenceManufacturingBom || '-'}
                                    </Text>
                                </div>
                            </Col>
                            <Col xs={24} sm={8}>
                                <div style={{ 
                                    padding: '12px 16px', 
                                    background: '#fafafa', 
                                    borderRadius: 8,
                                    border: '1px solid #f0f0f0'
                                }}>
                                    <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block' }}>
                                        Product Name
                                    </Text>
                                    <Text strong style={{ fontSize: 15 }}>
                                        {bomData.productName || '-'}
                                    </Text>
                                </div>
                            </Col>
                            <Col xs={24} sm={8}>
                                <div style={{ 
                                    padding: '12px 16px', 
                                    background: '#e6f7ff', 
                                    borderRadius: 8,
                                    border: '1px solid #91d5ff'
                                }}>
                                    <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block' }}>
                                        Batch Size (Semi-finished)
                                    </Text>
                                    <Text strong style={{ fontSize: 18, color: '#1890ff' }}>
                                        {bomData.batchSizeSemifinished} {bomData.uom}
                                    </Text>
                                </div>
                            </Col>
                            <Col xs={24} sm={8}>
                                <div style={{ 
                                    padding: '12px 16px', 
                                    background: '#f6ffed', 
                                    borderRadius: 8,
                                    border: '1px solid #b7eb8f'
                                }}>
                                    <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block' }}>
                                        Batch Size (Bulk)
                                    </Text>
                                    <Text strong style={{ fontSize: 18, color: '#52c41a' }}>
                                        {bomData.bulkSize} {bomData.bulkUom}
                                    </Text>
                                </div>
                            </Col>
                            <Col xs={24} sm={12}>
                                <div style={{ 
                                    padding: '12px 16px', 
                                    background: '#fafafa', 
                                    borderRadius: 8,
                                    border: '1px solid #f0f0f0'
                                }}>
                                    <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block' }}>
                                        Status
                                    </Text>
                                    <Tag color={getStatusColor(bomData.status)} style={{ marginTop: 4 }}>
                                        {bomData.status}
                                    </Tag>
                                </div>
                            </Col>
                            <Col xs={24} sm={12}>
                                <div style={{ 
                                    padding: '12px 16px', 
                                    background: '#fafafa', 
                                    borderRadius: 8,
                                    border: '1px solid #f0f0f0'
                                }}>
                                    <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block' }}>
                                        Effective Date
                                    </Text>
                                    <Text strong style={{ fontSize: 15 }}>
                                        {formatDate(bomData.effectiveDate)}
                                    </Text>
                                </div>
                            </Col>
                        </Row>
                    </div>

                    {/* Materials Section */}
                    <div style={{ padding: '0 24px 24px', borderTop: '1px solid #f0f0f0' }}>
                        <div style={{ marginBottom: 16, marginTop: 16 }}>
                            <Title level={5} style={{ marginBottom: 0 }}>
                                Materials
                            </Title>
                            <Text type="secondary">
                                <Badge 
                                    count={bomData.materials?.length || 0} 
                                    style={{ backgroundColor: '#1890ff' }}
                                    showZero={true}
                                /> materials in this BOM
                            </Text>
                        </div>

                        {bomData.materials?.length === 0 ? (
                            <Empty 
                                description="No materials added to this BOM" 
                                image={Empty.PRESENTED_IMAGE_SIMPLE}
                            />
                        ) : (
                            <Table
                                dataSource={bomData.materials}
                                columns={materialColumns}
                                rowKey="materialCode"
                                pagination={false}
                                size="small"
                                bordered
                            />
                        )}
                    </div>

                    {/* Actions */}
                    <div style={{ 
                        padding: '16px 24px', 
                        borderTop: '1px solid #f0f0f0',
                        display: 'flex', 
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        background: '#fafafa'
                    }}>
                        <Text type="secondary" style={{ fontSize: 12 }}>
                            Created: {formatDate(bomData.createdAt)} | Updated: {formatDate(bomData.updatedAt)}
                        </Text>
                        <Button 
                            onClick={onClose} 
                            icon={<CloseOutlined />}
                            type="primary"
                        >
                            Close
                        </Button>
                    </div>
                </div>
            )}
        </Modal>
    )
}
