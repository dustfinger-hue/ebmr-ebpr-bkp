'use client'
import { Form, Modal, Spin, Typography, Row, Col, DatePicker, Button, message, Select, Alert } from "antd";
const { Title, Text } = Typography;
import { EditOutlined } from "@ant-design/icons";
import { useEffect, useState } from "react";
import dayjs from "dayjs";

interface UpdateManufacturingBOMProps {
    open: boolean;
    onClose: () => void;
    onSuccess?: () => void;
    bomData?: any;
}

export default function UpdateManufacturingBOM({ open, onClose, onSuccess, bomData }: UpdateManufacturingBOMProps) {
    const [form] = Form.useForm();
    const [loading, setLoading] = useState(false);

    // Reset form when modal opens with new bomData
    useEffect(() => {
        if (open && bomData) {
            form.setFieldsValue({
                bomCode: bomData.bomCode,
                bomVersion: bomData.bomVersion,
                productName: bomData.productName,
                status: bomData.status,
                validTill: bomData.validTill ? dayjs(bomData.validTill) : null,
            });
        }
    }, [open, bomData, form]);

    // Reset form when modal closes
    useEffect(() => {
        if (!open) {
            form.resetFields();
        }
    }, [open, form]);

    const handleFinish = async (values: any) => {
        try {
            setLoading(true);
            const token = localStorage.getItem('token');

            const updateData = {
                status: values.status,
                validTill: values.validTill.toISOString(),
                productCode: bomData.productCode,
            };

            const res = await fetch(`/api/user/bill-of-material/manufacturing?bomId=${bomData._id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(updateData)
            });

            const data = await res.json();
            if (data.success) {
                message.success(data.message || 'BOM updated successfully!');
                onSuccess?.();
                onClose();
            } else {
                message.error(data.message || 'An error occurred while updating the BOM');
            }
        } catch (error) {
            console.error("Error updating BOM:", error);
            message.error("An error occurred while updating the BOM");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            centered
            width={500}
            destroyOnHidden
            closable={false}
            styles={{
                header: {
                    background: '#001529',
                    padding: '16px 24px',
                },
                body: { padding: 0 },
            }}
            title={
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{
                        width: 40,
                        height: 40,
                        borderRadius: 8,
                        background: 'linear-gradient(135deg, #1890ff 0%, #36cfc9 100%)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <EditOutlined style={{ fontSize: 20, color: '#fff' }} />
                    </div>
                    <div>
                        <Title level={5} style={{ marginBottom: 0, color: '#fff' }}>
                            Update BOM Status
                        </Title>
                        <Text style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12 }}>
                            Update BOM validity and status
                        </Text>
                    </div>
                </div>
            }
        >
            <Form
                form={form}
                layout="vertical"
                name="update_bom_form"
                onFinish={handleFinish}
            >
                <div style={{ padding: '24px' }}>
                    {/* BOM Info Display (Read-only) */}
                    <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
                        <Col xs={24} md={8}>
                            <div
                                style={{
                                    padding: '12px 16px',
                                    background: '#fafafa',
                                    borderRadius: 8,
                                    border: '1px solid #f0f0f0'
                                }}
                            >
                                <Text
                                    type="secondary"
                                    style={{
                                        fontSize: 11,
                                        textTransform: 'uppercase',
                                        letterSpacing: 0.5,
                                        display: 'block'
                                    }}
                                >
                                    BOM Code
                                </Text>
                                <Text strong style={{ fontSize: 13, color: '#1677ff' }}>
                                    {bomData?.bomCode || '-'}
                                </Text>
                            </div>
                        </Col>

                        <Col xs={24} md={16}>
                            <div
                                style={{
                                    padding: '12px 16px',
                                    background: '#fafafa',
                                    borderRadius: 8,
                                    border: '1px solid #f0f0f0'
                                }}
                            >
                                <Text
                                    type="secondary"
                                    style={{
                                        fontSize: 11,
                                        textTransform: 'uppercase',
                                        letterSpacing: 0.5,
                                        display: 'block'
                                    }}
                                >
                                    Product Name
                                </Text>
                                <Text strong style={{ fontSize: 13, color: '#262626' }}>
                                    {bomData?.productName || '-'}
                                </Text>
                            </div>
                        </Col>
                    </Row>

                    {/* Status Selection */}
                    <Form.Item
                        name="status"
                        label="Status"
                        rules={[{ required: true, message: "Please select status" }]}
                    >
                        <Select
                            placeholder="Select status"
                            options={[
                                { value: 'Draft', label: 'Draft' },
                                { value: 'Active', label: 'Active' },
                                { value: 'Inactive', label: 'Inactive' },
                            ]}
                        />
                    </Form.Item>

                    {/* Valid Till */}
                    <Form.Item
                        name="validTill"
                        label="Valid Till (Validity)"
                        rules={[{ required: true, message: "Please select valid till" }]}
                    >
                        <DatePicker
                            style={{ width: '100%' }}
                            placeholder="Select valid till date"
                            disabledDate={(current) => {
                                const today = dayjs().startOf('day');
                                const maxDate = dayjs().add(5, 'year');
                                return (
                                    current &&
                                    (current < today || current > maxDate)
                                )
                            }}
                        />
                    </Form.Item>
                    <Alert type="warning" title="Activating this BOM will automatically deactivate any other active BOM for this product." showIcon closable={true} style={{ marginBottom: 16 }} />
                </div>

                <div style={{
                    padding: '0 24px 24px',
                    display: 'flex',
                    gap: 12,
                    justifyContent: 'flex-end',
                    borderTop: '1px solid #f0f0f0',
                    paddingTop: 16
                }}>
                    <Button onClick={onClose}>
                        Cancel
                    </Button>
                    <Button
                        type="primary"
                        htmlType="submit"
                        loading={loading}
                    >
                        Update
                    </Button>
                </div>
            </Form>
        </Modal>
    )
}
