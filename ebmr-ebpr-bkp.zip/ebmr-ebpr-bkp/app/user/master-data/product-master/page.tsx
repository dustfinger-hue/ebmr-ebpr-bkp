'use client';
import { Button, Card, Col, message, Row, Select, Space, Table, Tag, Tooltip, Typography } from "antd";
import { useEffect, useState } from "react";
import { FaCapsules } from "react-icons/fa";
const { Title, Text } = Typography;
import {
  SearchOutlined,
  ReloadOutlined,
  PlusOutlined,
  FilterOutlined,
  ClearOutlined,
  DeleteTwoTone,
  EditTwoTone,
  EyeTwoTone
} from "@ant-design/icons";
import AddNewProducts from "./components/Add-New-Products";
import ViewProduct from "./components/Veiw-Product";
import EditProduct from "./components/Edit-Product";
import DeleteProduct from "./components/Delete-Product";
import { useAuthorization } from "@/hooks/useAuthorization";
import Search from "antd/es/input/Search";
import { Dosage_Forms, Storage_Conditions, Therapeutic_Classes } from "@/lib/constants/Generarl";

export default function PharmaceuticalProductPage() {

  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });
  const [addProductModal, setAddProductModal] = useState(false);
  const [viewProductModal, setViewProductModal] = useState(false);
  const [editProductModal, setEditProductModal] = useState(false);
  const [deleteProductModal, setDeleteProductModal] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [selectedProductForDelete, setSelectedProductForDelete] = useState<any>(null);
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  //Filter states
  const [searchText, setSearchText] = useState("");
  // const [genericFilter, setGenericFilter] = useState<string>("");
  const [therapeuticFilter, setTherapeuticFilter] = useState<string>("");
  const [storageFilter, setStorageFilter] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [dosageFilter, setDosageFilter] = useState<string>("");
  const [filterVisible, setFilterVisible] = useState(false);

  useEffect(() => {
    getProducts(pagination.current, pagination.pageSize, searchText, therapeuticFilter, storageFilter, statusFilter, dosageFilter);
  }, [pagination.current, pagination.pageSize, searchText, therapeuticFilter, storageFilter, statusFilter, dosageFilter]);

  useEffect(() => {
    setPagination(prev => ({ ...prev, current: 1 }));
  }, [searchText, therapeuticFilter, storageFilter, statusFilter, dosageFilter]);

  const getProducts = async (page: number, limit: number, search: string, therapeutic: string, storage: string, status: string, dosage: string) => {
    try {
      setLoading(true);
      let url = `/api/user/master-data/product-master?page=${page}&limit=${limit}&search=${search}`
      // if (generic) url += `&genericName=${generic}`
      if (therapeutic) url += `&therapeuticClass=${therapeutic}`
      if (storage) url += `&storageCondition=${storage}`
      if (status) url += `&status=${status}`
      if (dosage) url += `&dosageForm=${dosage}`

      const response = await fetch(url)
      const data = await response.json()

      if (data.success) {
        setProducts(data.products)
        setPagination(prev => ({
          ...prev,
          total: data.total,
        }))
      } else {
        message.error(data.message)
      }
    } catch (error) {
      console.error(error)
      message.error("Error fetching products")
    } finally {
      setLoading(false)
    }
  }

  const clearFilters = () => {
    setSearchText("");
    setTherapeuticFilter("");
    setStorageFilter("");
    setStatusFilter("");
    setDosageFilter("");
    setPagination(prev => ({ ...prev, current: 1 }));
  };

  const hasActiveFilters = () => {
    return therapeuticFilter || storageFilter || statusFilter || dosageFilter || searchText;
  };

  const handleEdit = (id: string) => {
    setSelectedProductId(id);
    setEditProductModal(true);
  }
  const handleView = (id: string) => {
    setSelectedProductId(id);
    setViewProductModal(true);
  }
  const handleDeleteClick = (record: any) => {
    setSelectedProductForDelete(record);
    setDeleteProductModal(true);
  }
  const handleDeleteSuccess = () => {
    getProducts(pagination.current, pagination.pageSize, searchText, therapeuticFilter, storageFilter, statusFilter, dosageFilter);
    setSelectedProductForDelete(null);
    setDeleteProductModal(false);
  }


  // Authorization check
  const { hasAccess } = useAuthorization();
  const isCreateProductAuthorized = hasAccess('Product Master', 'create');
  const isUpdateProductAuthorized = hasAccess('Product Master', 'update');
  const isDeleteProductAuthorized = hasAccess('Product Master', 'delete');

  const columns = [
    {
      title: 'S.No',
      width: 80,
      fixed: 'left' as const,
      render: (_: any, __: any, index: number) =>
        (pagination.current - 1) * pagination.pageSize + index + 1
    },
    {
      title: 'Product Code',
      dataIndex: 'productCode',
      key: 'productCode',
      width: 140,
      render: (text: string) => (
        <Text copyable style={{ color: '#1677ff', fontWeight: 500 }}>
          {text}
        </Text>
      ),
    },
    {
      title: 'Product Name',
      dataIndex: 'productName',
      key: 'productName',
      width: 180,
      ellipsis: true,
      render: (_: any, record: any) => (
        <div style={{ lineHeight: 1.3 }}>
          <div>
            <Text strong>{record.productName}</Text>
          </div>
          <div>
            <Text type="secondary" style={{ fontSize: 12 }}>
              {record.genericName}
            </Text>
          </div>
        </div>
      )
    },
    {
      title: 'Strength',
      dataIndex: 'strength',
      key: 'strength',
      width: 120,
      render: (_: any, record: any) => (
        <div style={{ lineHeight: 1.3 }}>
          <div>
            <Text>{record.strength}</Text>
          </div>
          <div>
            <Text type="secondary" style={{ fontSize: 12 }}>
              {record.dosageForm}
            </Text>
          </div>
        </div>
      )
    },
    {
      title: 'Therapeutic Class',
      dataIndex: 'therapeuticClass',
      key: 'therapeuticClass',
      width: 150,
      ellipsis: true,
      render: (text: [string]) =>
        <div style={{ lineHeight: 1.3 }} className="flex flex-col gap-0.5">
          {text.map((item) => (
            <div key={item}>
              <Tag color="green" variant="outlined">{item}</Tag>
            </div>
          ))}
        </div>
    },
    {
      title: 'Shelf Life',
      dataIndex: 'shelfLife',
      key: 'shelfLife',
      width: 100,
      render: (text: number) => <span>{text} months</span>,
    },
    {
      title: 'Storage Condition',
      dataIndex: 'storageCondition',
      key: 'storageCondition',
      width: 140,
      ellipsis: true,
      render: (text: [string]) =>
        <div style={{ lineHeight: 1.3 }} className="flex flex-col gap-0.5">
          {text.map((condition, index) => (
            <div key={index}>
              <Tag color="blue" variant="outlined">{condition}</Tag>
            </div>
          ))}
        </div>
    },
    {
      title: 'GTIN Number',
      dataIndex: 'gtinNumber',
      key: 'gtinNumber',
      width: 160,
      render: (text: string) => <Text type="secondary">{text || '-'}</Text>,
    },
    {
      title: 'Registration No.',
      dataIndex: 'registrationNumber',
      key: 'registrationNumber',
      width: 150,
      ellipsis: true,
      render: (text: string) => <Text type="secondary">{text || '-'}</Text>,
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: 100,
      render: (status: string) => {
        return <Tag variant="outlined" color={status === 'Active' ? 'success' : 'default'}>{status}</Tag>
      }
    },
    {
      title: 'Action',
      width: 100,
      fixed: "right" as const,
      render: (record: any) => {
        return (
          <div className="flex flex-row gap-1">
            <Button icon={<EyeTwoTone twoToneColor='green' />} variant="outlined" color="green" onClick={() => { handleView(record._id) }} />
            <Tooltip title={isUpdateProductAuthorized ? "" : "You are not authorized to perform this action. Please contact your administrator."}>
              <Button icon={<EditTwoTone />} variant="outlined" color="primary" disabled={!isUpdateProductAuthorized} onClick={() => { handleEdit(record._id) }} />
            </Tooltip>
            <Tooltip title={isDeleteProductAuthorized ? "" : "You are not authorized to perform this action. Please contact your administrator."}>
              <Button 
                icon={<DeleteTwoTone twoToneColor={'red'} />} 
                variant="outlined" 
                color="danger" 
                onClick={() => handleDeleteClick(record)}
                disabled={!isDeleteProductAuthorized}
              />
            </Tooltip>
          </div>
        )
      }
    }

  ]
  return (
    <div>
      <Title level={2}>
        <FaCapsules size={30} className="inline mb-1" /> Pharmaceutical Product
      </Title>
      <Card>

        <Row gutter={[16, 16]} style={{ marginBottom: 16 }} justify="space-between">

          <Col span={8}>
            <Search
              placeholder="Search by product code, name or generic name..."
              allowClear
              onSearch={(value) => {
                setPagination(prev => ({
                  ...prev,
                  current: 1,
                }));
                setSearchText(value);
              }}
              style={{ width: '100%' }}
              prefix={<SearchOutlined />}
            />
          </Col>
          <Col span={12} style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <div className="flex flex-row gap-1">
              <Tooltip title="Advanced Filters">
                <Button
                  type={filterVisible ? "primary" : "default"}
                  icon={<FilterOutlined />}
                  onClick={() => setFilterVisible(!filterVisible)}
                >
                  Filters {hasActiveFilters() && `(${[therapeuticFilter, storageFilter, statusFilter, dosageFilter, searchText].filter(Boolean).length})`}
                </Button>
              </Tooltip>

              {hasActiveFilters() && (
                <Tooltip title="Clear All Filters">
                  <Button
                    icon={<ClearOutlined />}
                    onClick={clearFilters}
                    danger
                  >
                    Clear
                  </Button>
                </Tooltip>
              )}
              <Tooltip title="Refresh">
                <Button
                  onClick={() => getProducts(pagination.current, pagination.pageSize, searchText, therapeuticFilter, storageFilter, statusFilter, dosageFilter)}
                  icon={<ReloadOutlined />}
                />
              </Tooltip>
              <Tooltip title={isCreateProductAuthorized ? "" : "You are not authorized to perform this action. Please contact your administrator."}>
                <Button
                  type="primary"
                  onClick={() => setAddProductModal(true)}
                  icon={<PlusOutlined />}
                  disabled={!isCreateProductAuthorized}
                >
                  Add Product
                </Button>
              </Tooltip>
            </div>

          </Col>
        </Row>

        {/* Advanced Filters Panel */}
        {filterVisible && (
          <div style={{ marginBottom: 16, padding: 16, background: '#f5f5f5', borderRadius: 8 }}>
            <Row gutter={[16, 16]}>
              <Col xs={24} sm={12} md={6}>
                <label style={{ display: 'block', marginBottom: 4, fontWeight: 500 }}>Dosage Form</label>
                <Select
                  placeholder="Select Dosage Form"
                  style={{ width: '100%' }}
                  allowClear
                  value={dosageFilter || undefined}
                  onChange={(value) => { setPagination(prev => ({ ...prev, current: 1 })); setDosageFilter(value || ""); }}
                  options={Dosage_Forms}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <label style={{ display: 'block', marginBottom: 4, fontWeight: 500 }}>Therapeutic Class</label>
                <Select
                  placeholder="Select Therapeutic Class"
                  style={{ width: '100%' }}
                  allowClear
                  value={therapeuticFilter || undefined}
                  onChange={(value) => { setPagination(prev => ({ ...prev, current: 1 })); setTherapeuticFilter(value || ""); }}
                  options={Therapeutic_Classes}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <label style={{ display: 'block', marginBottom: 4, fontWeight: 500 }}>Status</label>
                <Select
                  placeholder="Select Status"
                  style={{ width: '100%' }}
                  allowClear
                  value={statusFilter || undefined}
                  onChange={(value) => { setPagination(prev => ({ ...prev, current: 1 })); setStatusFilter(value || ""); }}
                  options={[
                    { value: 'Active', label: 'Active' },
                    { value: 'Inactive', label: 'Inactive' }
                  ]}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <label style={{ display: 'block', marginBottom: 4, fontWeight: 500 }}>Storage Condition</label>
                <Select
                  placeholder="Select Storage"
                  style={{ width: '100%' }}
                  allowClear
                  value={storageFilter || undefined}
                  onChange={(value) => { setPagination(prev => ({ ...prev, current: 1 })); setStorageFilter(value || ""); }}
                  options={Storage_Conditions}
                />
              </Col>
            </Row>
          </div>
        )}

        {/* Active Filters Display */}
        {hasActiveFilters() && (
          <div style={{ marginBottom: 16 }}>
            <Space wrap>
              <Text type="secondary">Active Filters:</Text>
              {searchText && <Tag variant="outlined" closable onClose={() => { setSearchText(""); setPagination(prev => ({ ...prev, current: 1 })); }}>Search: {searchText}</Tag>}
              {statusFilter && <Tag variant="outlined" closable onClose={() => { setStatusFilter(""); setPagination(prev => ({ ...prev, current: 1 })); }}>Status: {statusFilter}</Tag>}
              {storageFilter && <Tag variant="outlined" closable onClose={() => { setStorageFilter(""); setPagination(prev => ({ ...prev, current: 1 })); }}>Storage: {storageFilter}</Tag>}
              {dosageFilter && <Tag variant="outlined" closable onClose={() => { setDosageFilter(""); setPagination(prev => ({ ...prev, current: 1 })); }}>Dosage Form: {dosageFilter}</Tag>}
              {therapeuticFilter && <Tag variant="outlined" closable onClose={() => { setTherapeuticFilter(""); setPagination(prev => ({ ...prev, current: 1 })); }}>Therapeutic Class: {therapeuticFilter}</Tag>}
            </Space>
          </div>
        )}

        <Table
          columns={columns}
          dataSource={products}
          loading={loading}
          scroll={{ x: 'max-content' }}
          pagination={{
            current: pagination.current,
            pageSize: pagination.pageSize,
            total: pagination.total,
            showSizeChanger: true,
            pageSizeOptions: ['10', '20', '30', '40', '50'],
            onChange: (page: number, pageSize: number) => {
              setPagination(prev => ({
                ...prev,
                current: page,
                pageSize: pageSize,
              }))
            },
          }}
        />
      </Card>
      <AddNewProducts
        open={addProductModal}
        onClose={() => setAddProductModal(false)}
      // onSuccess={() => fetchMaterials(page, pageSize, searchText, categoryFilter, typeFilter, statusFilter, storageFilter)}
      />
      <ViewProduct
        open={viewProductModal}
        onClose={() => setViewProductModal(false)}
        productId={selectedProductId || undefined}
      />
      <EditProduct
        open={editProductModal}
        onClose={() => setEditProductModal(false)}
        productId={selectedProductId || undefined}
        onSuccess={() => {
          getProducts(pagination.current, pagination.pageSize, searchText, therapeuticFilter, storageFilter, statusFilter, dosageFilter);
          setSelectedProductId(null);
        }}
      />
      <DeleteProduct
        open={deleteProductModal}
        onClose={() => {
          setDeleteProductModal(false);
          setSelectedProductForDelete(null);
        }}
        product={selectedProductForDelete}
        onSuccess={handleDeleteSuccess}
      />
    </div>
  )
}
