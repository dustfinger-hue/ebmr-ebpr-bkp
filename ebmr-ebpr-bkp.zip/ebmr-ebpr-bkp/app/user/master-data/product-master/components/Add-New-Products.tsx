'use client';

import { Dosage_Forms, Drug_Categories, Drug_License_Number, Manufacturers, Pack_Presentation, Storage_Conditions, Therapeutic_Classes } from "@/lib/constants/Generarl";
import {
    Modal,
    Form,
    Input,
    Select,
    InputNumber,
    Row,
    Col,
    Button,
    Typography,
    message,
    Tabs,
    Spin,
    Space,
} from "antd";
import {
    DatabaseOutlined,
    ExperimentOutlined,
    MedicineBoxOutlined,
    EnvironmentOutlined,
    FileTextOutlined,
    CloseOutlined,
    PlusOutlined,
} from "@ant-design/icons";
import { useEffect, useState } from "react";

const { TextArea } = Input;
const { Title, Text } = Typography;

interface AddNewProductsProps {
    open: boolean;
    onClose: () => void;
    onSuccess?: () => void;
}

export default function AddNewProducts({
    open,
    onClose,
    onSuccess,
}: AddNewProductsProps) {
    const [loading, setLoading] = useState(false);
    const [form] = Form.useForm();
    const [activeTab, setActiveTab] = useState('basic');

    // Reset form and tab when modal opens
    useEffect(() => {
        if (open) {
            form.resetFields();
            setActiveTab('basic');
        }
    }, [open, form]);

    const tabFieldMap: any = {
        productName: 'basic',
        genericName: 'basic',
        shortName: 'basic',
        dosageForm: 'details',
        strength: 'details',
        shelfLife: 'storage',
        storageCondition: 'storage',
        status: 'storage',
        gtinNumber: 'regulatory',
    };

    const handleValidationFailed = (errorInfo: any) => {

        const fieldLabels: Record<string, string> = {
            productName: 'Product Name',
            genericName: 'Generic Name',
            shortName: 'Short Name',
            dosageForm: 'Dosage Form',
            strength: 'Strength',
            shelfLife: 'Shelf Life',
            storageCondition: 'Storage Condition',
            status: 'Status',
            gtinNumber: 'GTIN Number',
        };

        const missingFields = errorInfo.errorFields.map((err: any) => {
            const fieldName = err.name[0];
            return fieldLabels[fieldName] || fieldName;
        });

        message.error(`Please fill required fields: ${missingFields.join(', ')}`);

        // scroll to first error
        form.scrollToField(errorInfo.errorFields[0].name);
        const firstErrorField = errorInfo.errorFields[0].name[0];

        setActiveTab(tabFieldMap[firstErrorField]);
    };

    const handleSubmit = async () => {
        const values = form.getFieldsValue(true);

        try {
            setLoading(true);
            const res = await fetch('/api/user/master-data/product-master', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify(values)
            });

            const data = await res.json();

            if (data.success) {
                message.success(`Product ${data.productCode} created successfully!`);
                form.resetFields();
                onClose();
                if (onSuccess) onSuccess();
            } else {
                message.error(data.message);
            }

        } catch (error) {
            console.error(error);
            message.error("Failed to add product");
        } finally {
            setLoading(false);
        }
    };

    // Tab content components
    const BasicInfoTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24} sm={12} md={8}>
                    <Form.Item
                        name="productName"
                        label="Product Name"
                        rules={[{ required: true, message: "Enter product name" }]}
                    >
                        <Input placeholder="Enter product name" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item
                        name="genericName"
                        label="Generic Name"
                        rules={[{ required: true, message: "Enter generic name" }]}
                    >
                        <Input placeholder="e.g., Paracetamol" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item
                        name="shortName"
                        label="Short Name"
                        rules={[
                            { required: true, message: "Enter short name" },
                            { min: 3, message: "Minimum 3 characters required" },
                            { max: 8, message: "Maximum 8 characters allowed" },
                            {
                                pattern: /^[A-Z0-9]+$/,
                                message: "Only capital letters and numbers allowed",
                            },
                        ]}
                    >
                        <Input
                            placeholder="Example: PCM"
                            maxLength={8}
                            onInput={(e: any) => {
                                e.target.value = e.target.value.toUpperCase();
                            }}
                        />
                    </Form.Item>
                </Col>

                <Col xs={24}>
                    <Form.Item name="description" label="Description">
                        <TextArea rows={3} placeholder="Enter product description" />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const ProductDetailsTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24} sm={12} md={6}>
                    <Form.Item
                        name="dosageForm"
                        label="Dosage Form"
                        rules={[{ required: true }]}
                    >
                        <Select placeholder="Select dosage form"
                            options={Dosage_Forms}
                        />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item
                        name="strength"
                        label="Strength"
                        rules={[{ required: true }]}
                    >
                        <Input placeholder="e.g., 500mg / 10mg/5ml" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="packSize" label="Pack Size">
                        <Input placeholder="e.g., 10 Tablets / Strip" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="unit" label="Unit">
                        <Select placeholder="Select unit"
                            options={Pack_Presentation}
                        />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const ClassificationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24} md={8}>
                    <Form.Item name="therapeuticClass" label="Therapeutic Class">
                        <Select mode="multiple" allowClear placeholder="Select class"
                            options={Therapeutic_Classes}
                        />
                    </Form.Item>
                </Col>

                <Col xs={24} md={8}>
                    <Form.Item name="drugCategory" label="Drug Category">
                        <Select placeholder="Select category"
                            options={Drug_Categories}
                        />
                    </Form.Item>
                </Col>

                <Col xs={24} md={8}>
                    <Form.Item name="manufacturer" label="Manufacturer">
                        <Input placeholder="Enter manufacturer name" />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const StorageTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24} md={8}>
                    <Form.Item
                        name="shelfLife"
                        label="Shelf Life (Months)"
                        rules={[{ required: true }]}
                    >
                        <InputNumber min={1} max={120} style={{ width: "100%" }} />
                    </Form.Item>
                </Col>

                <Col xs={24} md={8}>
                    <Form.Item
                        name="storageCondition"
                        label="Storage Condition"
                        rules={[{ required: true }]}
                    >
                        <Select mode="multiple" allowClear placeholder="Select storage"
                            options={Storage_Conditions}
                        />
                    </Form.Item>
                </Col>

                <Col xs={24} md={8}>
                    <Form.Item
                        name="status"
                        label="Status"
                        rules={[{ required: true }]}
                    >
                        <Select placeholder="Select status"
                            options={[
                                { value: 'Active', label: 'Active' },
                                { value: 'Inactive', label: 'Inactive' }
                            ]}
                        />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const RegulatoryTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24} md={8}>
                    <Form.Item name="gtinNumber" label="GTIN Number"
                        rules={[
                            { required: true, message: "Enter GTIN number" },
                            {
                                pattern: /^[0-9]+$/,
                                message: "Only numbers allowed",
                            },
                        ]}
                    >
                        <Input placeholder="Enter GTIN number" />
                    </Form.Item>
                </Col>

                <Col xs={24} md={8}>
                    <Form.Item name="registrationNumber" label="Registration Number">
                        <Input placeholder="Enter registration number" />
                    </Form.Item>
                </Col>

                <Col xs={24} md={8}>
                    <Form.Item name="drugLicenseNumber" label="Drug License Number">
                        <Input disabled placeholder="Auto-generated" />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const tabItems = [
        {
            key: 'basic',
            label: (
                <span>
                    <DatabaseOutlined /> Basic Info
                </span>
            ),
            children: <BasicInfoTab />,
        },
        {
            key: 'details',
            label: (
                <span>
                    <ExperimentOutlined /> Details
                </span>
            ),
            children: <ProductDetailsTab />,
        },
        {
            key: 'class',
            label: (
                <span>
                    <MedicineBoxOutlined /> Classification
                </span>
            ),
            children: <ClassificationTab />,
        },
        {
            key: 'storage',
            label: (
                <span>
                    <EnvironmentOutlined /> Storage
                </span>
            ),
            children: <StorageTab />,
        },
        {
            key: 'regulatory',
            label: (
                <span>
                    <FileTextOutlined /> Regulatory
                </span>
            ),
            children: <RegulatoryTab />,
        },
    ];

    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            centered
            width={800}
            destroyOnHidden
            closable={false}
            styles={{
                header: {
                    background: '#001529',
                    padding: '16px 24px',
                },
                body: { padding: 0 },
            }}
            title={
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{
                        width: 40,
                        height: 40,
                        borderRadius: 8,
                        background: 'linear-gradient(135deg, #1890ff 0%, #36cfc9 100%)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <PlusOutlined style={{ fontSize: 20, color: '#fff' }} />
                    </div>
                    <div>
                        <Title level={5} style={{ marginBottom: 0, color: '#fff' }}>
                            Add New Product
                        </Title>
                        <Text style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12 }}>
                            Enter product information carefully
                        </Text>
                    </div>
                </div>
            }
        >
            <Form
                form={form}
                layout="vertical"
                size="middle"
                onFinish={handleSubmit}
                onFinishFailed={handleValidationFailed}
                initialValues={{
                    status: "Active",
                    shelfLife: 24,
                    drugLicenseNumber: Drug_License_Number,
                    manufacturer: Manufacturers,
                }}

            >
                {/* Tabs Section */}
                <div style={{ padding: '16px 24px 24px' }}>
                    <Tabs
                        activeKey={activeTab}
                        onChange={setActiveTab}
                        items={tabItems}
                        size="large"
                        style={{ marginBottom: 8 }}
                    />

                    {/* Actions */}
                    <div style={{
                        marginTop: 24,
                        paddingTop: 16,
                        borderTop: '1px solid #f0f0f0',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center'
                    }}>
                        <Text type="secondary" style={{ fontSize: 12 }}>
                            All fields marked as * are required
                        </Text>
                        <Space>
                            <Button
                                onClick={onClose}
                                icon={<CloseOutlined />}
                            >
                                Cancel
                            </Button>
                            <Button
                                type="primary"
                                htmlType="submit"
                                loading={loading}
                                icon={<PlusOutlined />}
                            >
                                Add Product
                            </Button>
                        </Space>
                    </div>
                </div>
            </Form>
        </Modal>
    );
}
