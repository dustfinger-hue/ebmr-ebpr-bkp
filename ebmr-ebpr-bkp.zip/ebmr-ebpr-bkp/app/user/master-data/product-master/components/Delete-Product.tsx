'use client';

import {
    Modal,
    Typography,
    Button,
    Space,
    Input,
    Row,
    Col,
    Spin,
    Flex,
} from "antd";
import {
    DeleteOutlined,
    CloseOutlined,
    MedicineBoxOutlined,
} from "@ant-design/icons";
import { useState, useEffect } from "react";
import { useTheme } from "@/lib/utils/ThemeContext";

const { Text, Title } = Typography;
const { TextArea } = Input;

interface ProductData {
    _id: string;
    productCode: number;
    productName: string;
    genericName: string;
    shortName: string;
    strength?: string;
    dosageForm?: string;
}

interface DeleteProductProps {
    open: boolean;
    onClose: () => void;
    product: ProductData | null;
    onSuccess?: () => void;
}

export default function DeleteProduct({
    open,
    onClose,
    product,
    onSuccess,
}: DeleteProductProps) {
    const { theme } = useTheme();
    const [loading, setLoading] = useState(false);
    const [deleteReason, setDeleteReason] = useState("");

    // Theme-aware colors
    const colors = {
        modalHeader: theme === 'dark' ? '#141414' : '#001529',
        cardBg: theme === 'dark' ? '#1f1f1f' : '#fff1f0',
        cardBorder: theme === 'dark' ? '#4d1a1a' : '#ffccc7',
        textPrimary: theme === 'dark' ? '#ffffff' : '#262626',
        textSecondary: theme === 'dark' ? '#8c8c8c' : '#8c8c8c',
        redText: theme === 'dark' ? '#ff4d4f' : '#cf1322',
        warningBg: theme === 'dark' ? '#2a2a1a' : '#fffbe6',
        warningBorder: theme === 'dark' ? '#4d4d1a' : '#ffe58f',
        divider: theme === 'dark' ? '#303030' : '#f0f0f0',
    };

    // Reset reason when modal opens
    useEffect(() => {
        if (open) {
            setDeleteReason("");
        }
    }, [open]);

    const handleDelete = async () => {
        if (!product) return;

        try {
            setLoading(true);

            const res = await fetch(
                `/api/user/master-data/product-master?id=${product._id}`,
                {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    },
                    body: JSON.stringify({ deleteReason })
                }
            );

            const data = await res.json();

            if (data.success) {
                Modal.success({
                    title: 'Product Deleted',
                    content: `Product "${product.productName}" has been deleted successfully.`,
                    onOk: () => {
                        onClose();
                        if (onSuccess) onSuccess();
                    }
                });
            } else {
                Modal.error({
                    title: 'Error',
                    content: data.message || 'Failed to delete product',
                });
            }
        } catch (error) {
            console.error(error);
            Modal.error({
                title: 'Error',
                content: 'Failed to delete product. Please try again.',
            });
        } finally {
            setLoading(false);
        }
    };

    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            centered
            width={600}
            destroyOnHidden
            styles={{
                header: {
                    background: colors.modalHeader,
                    padding: '16px 24px',
                },
                body: { padding: 0 },
            }}
            closable={false}
            title={
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{
                        width: 40,
                        height: 40,
                        borderRadius: 8,
                        background: 'linear-gradient(135deg, #ff4d4f 0%, #cf1322 100%)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <DeleteOutlined style={{ fontSize: 20, color: '#fff' }} />
                    </div>
                    <div>
                        <Title level={5} style={{ marginBottom: 0, color: '#fff' }}>
                            Delete Product
                        </Title>
                        <Text style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12 }}>
                            This action cannot be undone
                        </Text>
                    </div>
                </div>
            }
        >
            {loading ? (
                <div style={{ textAlign: 'center', padding: '60px 0' }}>
                    <Spin size="large" />
                    <div style={{ marginTop: 16 }}>
                        <Text type="secondary">Deleting product...</Text>
                    </div>
                </div>
            ) : product ? (
                <div className="mt-4">
                    {/* Product Info Card */}
                    <div style={{
                        padding: 10,
                        background: colors.cardBg,
                        borderRadius: 8,
                        border: `1px solid ${colors.cardBorder}`,
                        marginBottom: 20
                    }}>
                        <Flex align="flex-start" gap={16}>
                            <div style={{
                                width: 48,
                                height: 48,
                                borderRadius: 8,
                                background: theme === 'dark' ? '#303030' : '#fff',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                flexShrink: 0
                            }}>
                                <MedicineBoxOutlined style={{ fontSize: 24, color: '#ff4d4f' }} />
                            </div>
                            <div style={{ flex: 1 }}>
                                <Title level={5} style={{ marginBottom: 4, color: colors.redText }}>
                                    {product.productName}
                                </Title>
                                <Row gutter={[16, 8]}>
                                    <Col xs={12}>
                                        <Text type="secondary" style={{ fontSize: 12 }}>Product Code</Text>
                                        <div><Text strong style={{ color: colors.textPrimary }}>{product.productCode}</Text></div>
                                    </Col>
                                    <Col xs={12}>
                                        <Text type="secondary" style={{ fontSize: 12 }}>Short Name</Text>
                                        <div><Text strong style={{ color: colors.textPrimary }}>{product.shortName || '-'}</Text></div>
                                    </Col>
                                    <Col xs={12}>
                                        <Text type="secondary" style={{ fontSize: 12 }}>Generic Name</Text>
                                        <div><Text strong style={{ color: colors.textPrimary }}>{product.genericName || '-'}</Text></div>
                                    </Col>
                                    <Col xs={12}>
                                        <Text type="secondary" style={{ fontSize: 12 }}>Strength</Text>
                                        <div><Text strong style={{ color: colors.textPrimary }}>{product.strength || '-'}{product.dosageForm ? ` / ${product.dosageForm}` : ''}</Text></div>
                                    </Col>
                                </Row>
                            </div>
                        </Flex>
                    </div>

                    {/* Delete Reason Input */}
                    <div style={{ marginBottom: 16 }}>
                        <Text strong style={{ display: 'block', marginBottom: 8, color: colors.textPrimary }}>
                            Delete Reason <Text type="secondary" style={{ fontWeight: 'normal' }}>(Required)</Text>
                        </Text>
                        <TextArea
                            rows={3}
                            placeholder="Enter reason for deleting this product..."
                            value={deleteReason}
                            onChange={(e) => setDeleteReason(e.target.value)}
                            maxLength={500}
                            showCount
                        />
                    </div>

                    {/* Warning */}
                    <div style={{
                        padding: '12px 16px',
                        background: colors.warningBg,
                        borderRadius: 8,
                        border: `1px solid ${colors.warningBorder}`,
                        marginBottom: 24
                    }}>
                        <Text type="warning" style={{ color: '#d48806' }}>
                            ⚠️ This product will be marked as inactive and hidden from the list
                        </Text>
                    </div>

                    {/* Actions */}
                    <Flex justify="space-between" align="center" style={{
                        paddingTop: 16,
                        borderTop: `1px solid ${colors.divider}`
                    }}>
                        <Text type="secondary" style={{ fontSize: 12 }}>
                            ID: {product._id}
                        </Text>
                        <Space>
                            <Button
                                onClick={onClose}
                                icon={<CloseOutlined />}
                            >
                                Cancel
                            </Button>
                            <Button
                                type="primary"
                                danger
                                icon={<DeleteOutlined />}
                                onClick={handleDelete}
                                disabled={!deleteReason.trim()}
                            >
                                Delete Product
                            </Button>
                        </Space>
                    </Flex>
                </div>
            ) : (
                <div style={{ textAlign: 'center', padding: '40px 0' }}>
                    <Text type="secondary">No product selected</Text>
                </div>
            )}
        </Modal>
    );
}
