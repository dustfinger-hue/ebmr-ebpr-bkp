'use client';

import {
    Modal,
    Row,
    Col,
    Button,
    Typography,
    message,
    Tag,
    Spin,
    Tabs,
    Empty,
    Statistic,
    Badge,
    Flex,
} from "antd";
import { 
    MedicineBoxOutlined, 
    ExperimentOutlined, 
    DatabaseOutlined,
    EnvironmentOutlined,
    FileTextOutlined,
    CloseOutlined,
    CheckCircleOutlined,
    InfoCircleOutlined,
} from "@ant-design/icons";
import { useEffect, useState } from "react";
import { useTheme } from "@/lib/utils/ThemeContext";

const { Title, Text, Paragraph } = Typography;

interface ViewProductProps {
    open: boolean;
    onClose: () => void;
    productId?: string;
}

interface ProductData {
    productName?: string;
    genericName?: string;
    shortName?: string;
    description?: string;
    dosageForm?: string;
    strength?: string;
    packSize?: string;
    unit?: string;
    therapeuticClass?: string[];
    drugCategory?: string;
    manufacturer?: string;
    shelfLife?: number;
    storageCondition?: string[];
    status?: string;
    gtinNumber?: string;
    registrationNumber?: string;
    drugLicenseNumber?: string;
}

export default function ViewProduct({
    open,
    onClose,
    productId,
}: ViewProductProps) {
    const { theme } = useTheme();
    const [loading, setLoading] = useState(false);
    const [product, setProduct] = useState<ProductData | null>(null);
    const [activeTab, setActiveTab] = useState('basic');

    // Theme-aware colors
    const colors = {
        cardBg: theme === 'dark' ? '#1f1f1f' : '#fafafa',
        cardBorder: theme === 'dark' ? '#303030' : '#f0f0f0',
        textPrimary: theme === 'dark' ? '#ffffff' : '#262626',
        textSecondary: theme === 'dark' ? '#8c8c8c' : '#8c8c8c',
        textMuted: theme === 'dark' ? '#595959' : '#bfbfbf',
        modalHeader: theme === 'dark' ? '#141414' : '#001529',
        quickStatsBg: theme === 'dark' ? '#1f1f1f' : '#fafafa',
        statsBorder: theme === 'dark' ? '#303030' : '#f0f0f0',
        greenBg: theme === 'dark' ? '#1b2a1b' : '#f6ffed',
        greenBorder: theme === 'dark' ? '#274c27' : '#b7eb8f',
        blueBg: theme === 'dark' ? '#1a2a3a' : '#e6f7ff',
        blueBorder: theme === 'dark' ? '#1d3d5c' : '#91d5ff',
        purpleBg: theme === 'dark' ? '#1a1a2a' : '#f9f0ff',
        purpleBorder: theme === 'dark' ? '#2d2d4d' : '#d3adf7',
        redBg: theme === 'dark' ? '#2a1a1a' : '#fff1f0',
        redBorder: theme === 'dark' ? '#4d1a1a' : '#ffccc7',
    };

    useEffect(() => {
        if (open && productId) {
            fetchProduct();
        }
    }, [open, productId]);

    // Reset tab when modal opens
    useEffect(() => {
        if (open) {
            setActiveTab('basic');
        }
    }, [open]);

    const fetchProduct = async () => {
        try {
            setLoading(true);
            const res = await fetch(`/api/user/master-data/product-master?productId=${productId}`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            const data = await res.json();
            if (data.success) {
                setProduct(data.products[0]);
            } else {
                message.error(data.message);
            }
        } catch (error) {
            console.error(error);
            message.error("Failed to fetch product");
        } finally {
            setLoading(false);
        }
    };

    // Helper to render info row
    const renderInfoRow = (label: string, value: any, span: number = 8) => (
        <Col xs={24} sm={span}>
            <div style={{ 
                padding: '12px 16px', 
                background: colors.cardBg, 
                borderRadius: 8,
                height: '100%',
                border: `1px solid ${colors.cardBorder}`
            }}>
                <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block', color: colors.textSecondary }}>
                    {label}
                </Text>
                <Text strong style={{ fontSize: 15, color: colors.textPrimary }}>
                    {value || <span style={{ color: colors.textMuted }}>-</span>}
                </Text>
            </div>
        </Col>
    );

    // Helper to render tags
    const renderTags = (items: string[] | undefined, color: string = "blue") => {
        if (!items?.length) return <Text type="secondary">-</Text>;
        return (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {items.map((item: string) => (
                    <Tag 
                        key={item} 
                        color={color} 
                        style={{ margin: 0, fontSize: 12, padding: '2px 10px' }}
                    >
                        {item}
                    </Tag>
                ))}
            </div>
        );
    };

    // Tab content components
    const BasicInfoTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                {renderInfoRow("Product Name", product?.productName, 8)}
                {renderInfoRow("Generic Name", product?.genericName, 8)}
                {renderInfoRow("Short Name", product?.shortName, 8)}
                <Col xs={24}>
                    <div style={{ 
                        padding: '16px', 
                        background: colors.greenBg, 
                        borderRadius: 8,
                        border: `1px solid ${colors.greenBorder}`
                    }}>
                        <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                            Description
                        </Text>
                        <Paragraph style={{ marginBottom: 0, marginTop: 8, fontSize: 14 }}>
                            {product?.description || <Text type="secondary">No description available</Text>}
                        </Paragraph>
                    </div>
                </Col>
            </Row>
        </div>
    );

    const ProductDetailsTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                {renderInfoRow("Dosage Form", product?.dosageForm, 6)}
                {renderInfoRow("Strength", product?.strength, 6)}
                {renderInfoRow("Pack Size", product?.packSize, 6)}
                {renderInfoRow("Unit", product?.unit, 6)}
            </Row>
        </div>
    );

    const ClassificationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                <Col xs={24}>
                    <div style={{ 
                        padding: '16px', 
                        background: colors.purpleBg, 
                        borderRadius: 8,
                        border: `1px solid ${colors.purpleBorder}`
                    }}>
                        <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                            Therapeutic Class
                        </Text>
                        <div style={{ marginTop: 8 }}>
                            {renderTags(product?.therapeuticClass, 'purple')}
                        </div>
                    </div>
                </Col>
                {renderInfoRow("Drug Category", product?.drugCategory, 12)}
                {renderInfoRow("Manufacturer", product?.manufacturer, 12)}
            </Row>
        </div>
    );

    const StorageTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                <Col xs={24} sm={8}>
                    <div style={{ 
                        padding: '20px', 
                        background: colors.blueBg, 
                        borderRadius: 8,
                        border: `1px solid ${colors.blueBorder}`,
                        textAlign: 'center'
                    }}>
                        <Statistic 
                            title="Shelf Life" 
                            value={product?.shelfLife || 0} 
                            suffix="Months"
                            valueStyle={{ color: '#1890ff', fontSize: 28 }}
                        />
                    </div>
                </Col>
                <Col xs={24} sm={16}>
                    <div style={{ 
                        padding: '16px', 
                        background: colors.greenBg, 
                        borderRadius: 8,
                        border: `1px solid ${colors.greenBorder}`,
                        height: '100%'
                    }}>
                        <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                            Storage Condition
                        </Text>
                        <div style={{ marginTop: 8 }}>
                            {renderTags(product?.storageCondition, 'cyan')}
                        </div>
                    </div>
                </Col>
            </Row>
            <Row gutter={[16, 16]} style={{ marginTop: 16 }}>
                <Col xs={24}>
                    <Flex justify="space-between" align="center" style={{ 
                        padding: '12px 16px', 
                        background: product?.status === 'Active' ? colors.greenBg : colors.redBg, 
                        borderRadius: 8,
                        border: `1px solid ${product?.status === 'Active' ? colors.greenBorder : colors.redBorder}`
                    }}>
                        <div>
                            <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                                Status
                            </Text>
                            <div style={{ marginTop: 4 }}>
                                <Text strong style={{ fontSize: 16, color: colors.textPrimary }}>
                                    {product?.status || 'Unknown'}
                                </Text>
                            </div>
                        </div>
                        <Badge 
                            status={product?.status === 'Active' ? 'success' : 'default'} 
                            text={product?.status === 'Active' ? 'Active' : 'Inactive'}
                            style={{ fontSize: 14 }}
                        />
                    </Flex>
                </Col>
            </Row>
        </div>
    );

    const RegulatoryTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                {renderInfoRow("GTIN Number", product?.gtinNumber, 8)}
                {renderInfoRow("Registration Number", product?.registrationNumber, 8)}
                {renderInfoRow("Drug License Number", product?.drugLicenseNumber, 8)}
            </Row>
        </div>
    );

    const tabItems = [
        {
            key: 'basic',
            label: (
                <span>
                    <DatabaseOutlined /> Basic Info
                </span>
            ),
            children: <BasicInfoTab />,
        },
        {
            key: 'details',
            label: (
                <span>
                    <ExperimentOutlined /> Details
                </span>
            ),
            children: <ProductDetailsTab />,
        },
        {
            key: 'class',
            label: (
                <span>
                    <MedicineBoxOutlined /> Classification
                </span>
            ),
            children: <ClassificationTab />,
        },
        {
            key: 'storage',
            label: (
                <span>
                    <EnvironmentOutlined /> Storage
                </span>
            ),
            children: <StorageTab />,
        },
        {
            key: 'regulatory',
            label: (
                <span>
                    <FileTextOutlined /> Regulatory
                </span>
            ),
            children: <RegulatoryTab />,
        },
    ];

    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            centered
            width={700}
            destroyOnHidden
            closable={false}
            styles={{
                header: {
                    background: colors.modalHeader,
                    padding: '16px 24px',
                },
                body: { padding: 0 },
            }}
            title={
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{
                        width: 40,
                        height: 40,
                        borderRadius: 8,
                        background: 'linear-gradient(135deg, #1890ff 0%, #36cfc9 100%)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <MedicineBoxOutlined style={{ fontSize: 20, color: '#fff' }} />
                    </div>
                    <div>
                        <Title level={5} style={{ marginBottom: 0, color: '#fff' }}>
                            {product?.productName || 'Product Details'}
                        </Title>
                        <Text style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12 }}>
                            {product?.genericName || 'View product information'}
                        </Text>
                    </div>
                </div>
            }
        >
            {loading || !product ? (
                <div style={{ textAlign: 'center', padding: '60px 0' }}>
                    <Spin size="large" />
                    <div style={{ marginTop: 16 }}>
                        <Text type="secondary">Loading product details...</Text>
                    </div>
                </div>
            ) : (
                <div>
                    {/* Quick Stats Bar */}
                    <Flex gap={24} wrap style={{ 
                        padding: '12px 24px', 
                        background: colors.quickStatsBg, 
                        borderBottom: `1px solid ${colors.statsBorder}`
                    }}>
                        <Flex align="center" gap={6}>
                            <CheckCircleOutlined style={{ color: '#52c41a' }} />
                            <Text strong style={{ color: colors.textPrimary }}>{product?.status || 'N/A'}</Text>
                        </Flex>
                        <Flex align="center" gap={6}>
                            <InfoCircleOutlined style={{ color: '#1890ff' }} />
                            <Text style={{ color: colors.textPrimary }}>{product?.dosageForm || 'N/A'}</Text>
                        </Flex>
                        <Flex align="center" gap={6}>
                            <ExperimentOutlined style={{ color: '#722ed1' }} />
                            <Text style={{ color: colors.textPrimary }}>{product?.strength || 'N/A'}</Text>
                        </Flex>
                    </Flex>

                    {/* Tabs Section */}
                    <div style={{ padding: '16px 24px 24px' }}>
                        <Tabs 
                            activeKey={activeTab} 
                            onChange={setActiveTab}
                            items={tabItems}
                            size="large"
                            style={{ marginBottom: 8 }}
                        />
                        
                        {/* Actions */}
                        <Flex justify="space-between" align="center" style={{ 
                            marginTop: 24, 
                            paddingTop: 16, 
                            borderTop: `1px solid ${colors.statsBorder}`
                        }}>
                            <Text type="secondary" style={{ fontSize: 12 }}>
                                Product ID: {productId || 'N/A'}
                            </Text>
                            <Button 
                                onClick={onClose} 
                                icon={<CloseOutlined />}
                                type="primary"
                            >
                                Close
                            </Button>
                        </Flex>
                    </div>
                </div>
            )}
        </Modal>
    );
}
