'use client';

import {
    Modal,
    Typography,
    Button,
    Space,
    Tag,
    Divider,
    message,
    Flex,
} from "antd";
import {
    ExclamationCircleOutlined,
    CloseOutlined,
    DeleteOutlined,
    WarningOutlined,
} from "@ant-design/icons";
import { useState } from "react";
import { useTheme } from "@/lib/utils/ThemeContext";

const { Title, Text } = Typography;

interface DeleteEquipmentProps {
    open: boolean;
    onClose: () => void;
    equipment: any;
    onSuccess?: () => void;
}

export default function DeleteEquipment({
    open,
    onClose,
    equipment,
    onSuccess,
}: DeleteEquipmentProps) {
    const { theme } = useTheme();
    const [loading, setLoading] = useState(false);

    // Theme-aware colors
    const colors = {
        modalHeader: theme === 'dark' ? '#2a1a1a' : '#fff1f0',
        headerBorder: theme === 'dark' ? '#4d1a1a' : '#ffccc7',
        headerIcon: theme === 'dark' ? '#ff4d4f' : '#ff4d4f',
        headerText: theme === 'dark' ? '#ff4d4f' : '#ff4d4f',
        headerSubtext: theme === 'dark' ? '#8c8c8c' : '#666',
        warningBg: theme === 'dark' ? '#2a1a1a' : '#fff1f0',
        warningBorder: theme === 'dark' ? '#4d1a1a' : '#ffccc7',
        warningText: theme === 'dark' ? '#ff4d4f' : '#cf1322',
        cardBg: theme === 'dark' ? '#1f1f1f' : '#fafafa',
        cardBorder: theme === 'dark' ? '#303030' : '#f0f0f0',
        textPrimary: theme === 'dark' ? '#ffffff' : '#262626',
        textSecondary: theme === 'dark' ? '#8c8c8c' : '#8c8c8c',
        divider: theme === 'dark' ? '#303030' : '#f0f0f0',
    };

    const handleDelete = async () => {
        if (!equipment?._id) return;

        try {
            setLoading(true);
            
            const res = await fetch(`/api/user/master-data/equipment-master?id=${equipment._id}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify({ deleteReason: equipment.deleteReason || 'Equipment deleted' })
            });

            const data = await res.json();
            
            if (data.success) {
                message.success(`Equipment ${data.equipmentCode} deleted successfully!`);
                onClose();
                if (onSuccess) onSuccess();
            } else {
                message.error(data.message);
            }

        } catch (error) {
            console.error(error);
            message.error("Failed to delete equipment");
        } finally {
            setLoading(false);
        }
    };

    const getStatusColor = (status: string) => {
        const colors: Record<string, string> = {
            'Active': 'green',
            'Under Maintenance': 'orange',
            'Breakdown': 'red',
            'Retired': 'default',
            'Decommissioned': 'default',
        };
        return colors[status] || 'blue';
    };

    if (!equipment) return null;

    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            centered
            width={500}
            destroyOnHidden
            styles={{
                header: {
                    background: colors.modalHeader,
                    padding: '16px 24px',
                },
                body: { padding: 0 },
            }}
            title={
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{
                        width: 40,
                        height: 40,
                        borderRadius: 8,
                        background: colors.headerIcon,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <WarningOutlined style={{ fontSize: 20, color: '#fff' }} />
                    </div>
                    <div>
                        <Title level={5} style={{ marginBottom: 0, color: colors.headerText }}>
                            Delete Equipment
                        </Title>
                        <Text style={{ color: colors.headerSubtext, fontSize: 12 }}>
                            This action cannot be undone
                        </Text>
                    </div>
                </div>
            }
        >
            <div style={{ padding: '24px' }}>
                {/* Warning Message */}
                <div style={{ 
                    background: colors.warningBg, 
                    border: `1px solid ${colors.warningBorder}`, 
                    borderRadius: 8,
                    padding: '16px',
                    marginBottom: 24,
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: 12
                }}>
                    <ExclamationCircleOutlined style={{ color: colors.warningText, fontSize: 20, marginTop: 2 }} />
                    <div>
                        <Text strong style={{ color: colors.warningText }}>
                            Are you sure you want to delete this equipment?
                        </Text>
                        <div>
                            <Text type="secondary">
                                This equipment will be permanently removed from the system.
                            </Text>
                        </div>
                    </div>
                </div>

                {/* Equipment Details */}
                <div style={{ marginBottom: 24 }}>
                    <Text type="secondary" style={{ fontSize: 12, marginBottom: 8, display: 'block' }}>
                        Equipment Details:
                    </Text>
                    <div style={{ 
                        background: colors.cardBg, 
                        border: `1px solid ${colors.cardBorder}`, 
                        borderRadius: 8,
                        padding: 16
                    }}>
                        <Flex justify="space-between" style={{ marginBottom: 8 }}>
                            <Text strong style={{ color: colors.textPrimary }}>Equipment Code:</Text>
                            <Text style={{ color: colors.textPrimary }}>EQ-{equipment.equipmentCode}</Text>
                        </Flex>
                        <Flex justify="space-between" style={{ marginBottom: 8 }}>
                            <Text strong style={{ color: colors.textPrimary }}>Equipment Name:</Text>
                            <Text style={{ color: colors.textPrimary }}>{equipment.equipmentName}</Text>
                        </Flex>
                        <Flex justify="space-between" style={{ marginBottom: 8 }}>
                            <Text strong style={{ color: colors.textPrimary }}>Type:</Text>
                            <Text style={{ color: colors.textPrimary }}>{equipment.equipmentType}</Text>
                        </Flex>
                        <Flex justify="space-between" style={{ marginBottom: 8 }}>
                            <Text strong style={{ color: colors.textPrimary }}>Category:</Text>
                            <Text style={{ color: colors.textPrimary }}>{equipment.category}</Text>
                        </Flex>
                        <Flex justify="space-between">
                            <Text strong style={{ color: colors.textPrimary }}>Status:</Text>
                            <Tag color={getStatusColor(equipment.status)}>{equipment.status}</Tag>
                        </Flex>
                    </div>
                </div>

                <Divider style={{ margin: '16px 0', borderColor: colors.divider }} />

                {/* Actions */}
                <Flex justify="space-between" align="center">
                    <Button onClick={onClose} icon={<CloseOutlined />}>
                        Cancel
                    </Button>
                    <Space>
                        <Button 
                            type="primary" 
                            danger 
                            loading={loading} 
                            icon={<DeleteOutlined />}
                            onClick={handleDelete}
                        >
                            Delete Equipment
                        </Button>
                    </Space>
                </Flex>
            </div>
        </Modal>
    );
}
