'use client';

import {
    Modal,
    Row,
    Col,
    Typography,
    Tabs,
    Tag,
    Button,
    Spin,
    Statistic,
    Badge,
    Flex,
} from "antd";
import {
    DatabaseOutlined,
    EnvironmentOutlined,
    ExperimentOutlined,
    SettingOutlined,
    ToolOutlined,
    FileTextOutlined,
    CloseOutlined,
    EditOutlined,
    CheckCircleOutlined,
    InfoCircleOutlined,
    CarOutlined,
} from "@ant-design/icons";
import { useEffect, useState } from "react";
import dayjs from "dayjs";
import { useTheme } from "@/lib/utils/ThemeContext";

const { Title, Text, Paragraph } = Typography;

interface VeiwEquipmentProps {
    open: boolean;
    onClose: () => void;
    equipmentId?: string;
    equipment?: any;
    onEdit?: () => void;
}

export default function VeiwEquipment({
    open,
    onClose,
    equipmentId,
    equipment: initialEquipment,
    onEdit,
}: VeiwEquipmentProps) {
    const { theme } = useTheme();
    const [loading, setLoading] = useState(false);
    const [equipment, setEquipment] = useState<any>(null);
    const [activeTab, setActiveTab] = useState('basic');

    // Theme-aware colors
    const colors = {
        cardBg: theme === 'dark' ? '#1f1f1f' : '#fafafa',
        cardBorder: theme === 'dark' ? '#303030' : '#f0f0f0',
        textPrimary: theme === 'dark' ? '#ffffff' : '#262626',
        textSecondary: theme === 'dark' ? '#8c8c8c' : '#8c8c8c',
        textMuted: theme === 'dark' ? '#595959' : '#bfbfbf',
        modalHeader: theme === 'dark' ? '#141414' : '#001529',
        quickStatsBg: theme === 'dark' ? '#1f1f1f' : '#fafafa',
        statsBorder: theme === 'dark' ? '#303030' : '#f0f0f0',
        greenBg: theme === 'dark' ? '#1b2a1b' : '#f6ffed',
        greenBorder: theme === 'dark' ? '#274c27' : '#b7eb8f',
        blueBg: theme === 'dark' ? '#1a2a3a' : '#e6f7ff',
        blueBorder: theme === 'dark' ? '#1d3d5c' : '#91d5ff',
        orangeBg: theme === 'dark' ? '#2a2a1a' : '#fff7e6',
        orangeBorder: theme === 'dark' ? '#4d4d1a' : '#ffd591',
        redBg: theme === 'dark' ? '#2a1a1a' : '#fff1f0',
        redBorder: theme === 'dark' ? '#4d1a1a' : '#ffccc7',
    };

    useEffect(() => {
        if (open) {
            if (initialEquipment) {
                setEquipment(initialEquipment);
            } else if (equipmentId) {
                fetchEquipment();
            }
        }
    }, [open, equipmentId, initialEquipment]);

    useEffect(() => {
        if (open) {
            setActiveTab('basic');
        }
    }, [open]);

    const fetchEquipment = async () => {
        try {
            setLoading(true);
            const res = await fetch(`/api/user/master-data/equipment-master?equipmentId=${equipmentId}`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            const data = await res.json();
            if (data.success) {
                setEquipment(data.equipment[0]);
            }
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const getStatusColor = (status: string) => {
        const colors: Record<string, string> = {
            'Active': 'green',
            'Under Maintenance': 'orange',
            'Breakdown': 'red',
            'Retired': 'default',
            'Decommissioned': 'default',
        };
        return colors[status] || 'blue';
    };

    const formatDate = (date: string) => {
        return date ? dayjs(date).format('DD-MMM-YYYY') : '-';
    };

    // Helper to render info row
    const renderInfoRow = (label: string, value: any, span: number = 8) => (
        <Col xs={24} sm={span}>
            <div style={{ 
                padding: '12px 16px', 
                background: colors.cardBg, 
                borderRadius: 8,
                height: '100%',
                border: `1px solid ${colors.cardBorder}`
            }}>
                <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block', color: colors.textSecondary }}>
                    {label}
                </Text>
                <Text strong style={{ fontSize: 15, color: colors.textPrimary }}>
                    {value || <span style={{ color: colors.textMuted }}>-</span>}
                </Text>
            </div>
        </Col>
    );

    // Tab content components
    const BasicInfoTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                {renderInfoRow("Equipment Code", <Text strong style={{ color: '#1677ff', fontSize: 16 }}>{equipment?.equipmentCode}</Text>, 8)}
                {renderInfoRow("Equipment Name", equipment?.equipmentName, 8)}
                {renderInfoRow("Equipment Type", <Tag>{equipment?.equipmentType}</Tag>, 8)}
                <Col xs={24}>
                    <div style={{ 
                        padding: '16px', 
                        background: colors.greenBg, 
                        borderRadius: 8,
                        border: `1px solid ${colors.greenBorder}`
                    }}>
                        <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                            Description
                        </Text>
                        <Paragraph style={{ marginBottom: 0, marginTop: 8, fontSize: 14 }}>
                            {equipment?.description || <Text type="secondary">No description available</Text>}
                        </Paragraph>
                    </div>
                </Col>
            </Row>
        </div>
    );

    const LocationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                {renderInfoRow("Site", equipment?.site, 8)}
                {renderInfoRow("Building", equipment?.building, 8)}
                {renderInfoRow("Floor", equipment?.floor, 8)}
                {renderInfoRow("Department", equipment?.department, 8)}
                {renderInfoRow("Area", equipment?.area, 8)}
                {renderInfoRow("Room Number", equipment?.roomNumber, 8)}
                {renderInfoRow("Installation Location", equipment?.installationLocation, 12)}
            </Row>
        </div>
    );

    const QualificationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                <Col xs={24}>
                    <Flex justify="space-between" align="center" style={{ 
                        padding: '12px 16px', 
                        background: equipment?.qualificationRequired ? colors.greenBg : colors.redBg, 
                        borderRadius: 8,
                        border: `1px solid ${equipment?.qualificationRequired ? colors.greenBorder : colors.redBorder}`
                    }}>
                        <div>
                            <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                                Qualification Required
                            </Text>
                            <div style={{ marginTop: 4 }}>
                                <Text strong style={{ fontSize: 16, color: colors.textPrimary }}>
                                    {equipment?.qualificationRequired ? 'Yes' : 'No'}
                                </Text>
                            </div>
                        </div>
                        <Badge 
                            status={equipment?.qualificationRequired ? 'success' : 'warning'} 
                            text={equipment?.qualificationRequired ? 'Required' : 'Not Required'}
                        />
                    </Flex>
                </Col>
                {renderInfoRow("Qualification Status", equipment?.qualificationStatus ? <Tag color="blue">{equipment.qualificationStatus}</Tag> : '-', 8)}
                {renderInfoRow("IQ Date", formatDate(equipment?.iqDate), 8)}
                {renderInfoRow("OQ Date", formatDate(equipment?.oqDate), 8)}
                {renderInfoRow("PQ Date", formatDate(equipment?.pqDate), 8)}
            </Row>
        </div>
    );

    const CalibrationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                <Col xs={24} sm={12}>
                    <div style={{ 
                        padding: '20px', 
                        background: colors.blueBg, 
                        borderRadius: 8,
                        border: `1px solid ${colors.blueBorder}`,
                        textAlign: 'center'
                    }}>
                        <Statistic 
                            title="Calibration Frequency" 
                            value={equipment?.calibrationFrequency || 0} 
                            suffix="months"
                            valueStyle={{ color: '#1890ff', fontSize: 28 }}
                        />
                    </div>
                </Col>
                <Col xs={24} sm={12}>
                    <div style={{ 
                        padding: '20px', 
                        background: equipment?.calibrationStatus === 'Calibrated' ? colors.greenBg : colors.orangeBg, 
                        borderRadius: 8,
                        border: `1px solid ${equipment?.calibrationStatus === 'Calibrated' ? colors.greenBorder : colors.orangeBorder}`,
                        textAlign: 'center'
                    }}>
                        <Statistic 
                            title="Calibration Status" 
                            value={equipment?.calibrationStatus || 'N/A'} 
                            valueStyle={{ color: equipment?.calibrationStatus === 'Calibrated' ? '#52c41a' : '#fa8c16', fontSize: 24 }}
                        />
                    </div>
                </Col>
                {renderInfoRow("Calibration Standard", equipment?.calibrationStandard, 8)}
                {renderInfoRow("Last Calibration", formatDate(equipment?.lastCalibrationDate), 8)}
                {renderInfoRow("Next Calibration", formatDate(equipment?.nextCalibrationDate), 8)}
            </Row>
        </div>
    );

    const MaintenanceTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                <Col xs={24}>
                    <Flex justify="space-between" align="center" style={{ 
                        padding: '12px 16px', 
                        background: equipment?.maintenanceRequired ? colors.greenBg : colors.redBg, 
                        borderRadius: 8,
                        border: `1px solid ${equipment?.maintenanceRequired ? colors.greenBorder : colors.redBorder}`
                    }}>
                        <div>
                            <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                                Maintenance Required
                            </Text>
                            <div style={{ marginTop: 4 }}>
                                <Text strong style={{ fontSize: 16, color: colors.textPrimary }}>
                                    {equipment?.maintenanceRequired ? 'Yes' : 'No'}
                                </Text>
                            </div>
                        </div>
                        <Badge 
                            status={equipment?.maintenanceRequired ? 'success' : 'warning'} 
                            text={equipment?.maintenanceRequired ? 'Required' : 'Not Required'}
                        />
                    </Flex>
                </Col>
                {renderInfoRow("Maintenance Type", equipment?.maintenanceType, 8)}
                {renderInfoRow("Maintenance Frequency", equipment?.maintenanceFrequency ? `${equipment.maintenanceFrequency} months` : '-', 8)}
                {renderInfoRow("Last Maintenance", formatDate(equipment?.lastMaintenanceDate), 8)}
                {renderInfoRow("Next Maintenance", formatDate(equipment?.nextMaintenanceDate), 8)}
                {renderInfoRow("Maintenance Vendor", equipment?.maintenanceVendor, 12)}
            </Row>
        </div>
    );

    const OperationalTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                <Col xs={24} sm={12}>
                    <div style={{ 
                        padding: '20px', 
                        background: getStatusColor(equipment?.currentStatus) === 'green' ? colors.greenBg : getStatusColor(equipment?.currentStatus) === 'orange' ? colors.orangeBg : colors.redBg, 
                        borderRadius: 8,
                        border: `1px solid ${getStatusColor(equipment?.currentStatus) === 'green' ? colors.greenBorder : getStatusColor(equipment?.currentStatus) === 'orange' ? colors.orangeBorder : colors.redBorder}`,
                        textAlign: 'center'
                    }}>
                        <Statistic 
                            title="Current Status" 
                            value={equipment?.currentStatus || 'N/A'} 
                            valueStyle={{ color: getStatusColor(equipment?.currentStatus) === 'green' ? '#52c41a' : getStatusColor(equipment?.currentStatus) === 'orange' ? '#fa8c16' : '#ff4d4f', fontSize: 24 }}
                        />
                    </div>
                </Col>
                {renderInfoRow("Cleaning Status", equipment?.cleaningStatus, 12)}
                {renderInfoRow("Last Product Processed", equipment?.lastProductProcessed, 12)}
            </Row>
        </div>
    );

    const CPPTab = () => {
        const cppParams = equipment?.cppParameters || [];
        
        if (cppParams.length === 0) {
            return (
                <div style={{ textAlign: 'center', padding: 40, color: colors.textMuted }}>
                    No Critical Process Parameters defined for this equipment.
                </div>
            );
        }
        
        return (
            <div style={{ padding: '8px 0' }}>
                <Row gutter={[16, 16]}>
                    {cppParams.map((cpp: any, index: number) => (
                        <Col xs={24} sm={8} key={index}>
                            <div style={{ 
                                padding: '16px', 
                                background: colors.cardBg, 
                                borderRadius: 8,
                                border: `1px solid ${colors.cardBorder}`
                            }}>
                                <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                                    {cpp.parameterName}
                                </Text>
                                <div style={{ marginTop: 8 }}>
                                    <Text strong style={{ fontSize: 18, color: colors.textPrimary }}>
                                        {cpp.minValue ?? '-'} - {cpp.maxValue ?? '-'} {cpp.unit??'-'}
                                    </Text>
                                </div>
                            </div>
                        </Col>
                    ))}
                </Row>
            </div>
        );
    };

    const DocumentationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                {renderInfoRow("SOP Number", equipment?.sopNumber, 8)}
                {renderInfoRow("Manual Document", equipment?.manualDocument, 8)}
                {renderInfoRow("Qualification Protocol", equipment?.qualificationProtocol, 8)}
                {renderInfoRow("Calibration Certificate", equipment?.calibrationCertificate, 8)}
                {renderInfoRow("Maintenance Record", equipment?.maintenanceRecord, 8)}
            </Row>
        </div>
    );

    const tabItems = [
        {
            key: 'basic',
            label: (
                <span>
                    <DatabaseOutlined /> Basic Info
                </span>
            ),
            children: <BasicInfoTab />,
        },
        {
            key: 'location',
            label: (
                <span>
                    <EnvironmentOutlined /> Location
                </span>
            ),
            children: <LocationTab />,
        },
        {
            key: 'qualification',
            label: (
                <span>
                    <ExperimentOutlined /> Qualification
                </span>
            ),
            children: <QualificationTab />,
        },
        {
            key: 'calibration',
            label: (
                <span>
                    <SettingOutlined /> Calibration
                </span>
            ),
            children: <CalibrationTab />,
        },
        {
            key: 'maintenance',
            label: (
                <span>
                    <ToolOutlined /> Maintenance
                </span>
            ),
            children: <MaintenanceTab />,
        },
        {
            key: 'operational',
            label: (
                <span>
                    <CarOutlined /> Operational
                </span>
            ),
            children: <OperationalTab />,
        },
        {
            key: 'cpp',
            label: (
                <span>
                    <InfoCircleOutlined /> CPP
                </span>
            ),
            children: <CPPTab />,
        },
        {
            key: 'documentation',
            label: (
                <span>
                    <FileTextOutlined /> Documentation
                </span>
            ),
            children: <DocumentationTab />,
        },
    ];

    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            centered
            width={700}
            destroyOnHidden
            closable={false}
            styles={{
                header: {
                    background: colors.modalHeader,
                    padding: '16px 24px',
                },
                body: { padding: 0 },
            }}
            title={
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{
                        width: 40,
                        height: 40,
                        borderRadius: 8,
                        background: 'linear-gradient(135deg, #1890ff 0%, #36cfc9 100%)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <SettingOutlined style={{ fontSize: 20, color: '#fff' }} />
                    </div>
                    <div>
                        <Title level={5} style={{ marginBottom: 0, color: '#fff' }}>
                            {equipment?.equipmentName || 'Equipment Details'}
                        </Title>
                        <Text style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12 }}>
                            {equipment?.equipmentCode || 'View equipment information'}
                        </Text>
                    </div>
                </div>
            }
        >
            {loading || !equipment ? (
                <div style={{ textAlign: 'center', padding: '60px 0' }}>
                    <Spin size="large" />
                    <div style={{ marginTop: 16 }}>
                        <Text type="secondary">Loading equipment details...</Text>
                    </div>
                </div>
            ) : (
                <div>
                    {/* Quick Stats Bar */}
                    <Flex gap={24} wrap style={{ 
                        padding: '12px 24px', 
                        background: colors.quickStatsBg, 
                        borderBottom: `1px solid ${colors.statsBorder}`
                    }}>
                        <Flex align="center" gap={6}>
                            <CheckCircleOutlined style={{ color: getStatusColor(equipment?.currentStatus) === 'green' ? '#52c41a' : '#faad14' }} />
                            <Text strong style={{ color: colors.textPrimary }}>{equipment?.currentStatus || 'N/A'}</Text>
                        </Flex>
                        <Flex align="center" gap={6}>
                            <InfoCircleOutlined style={{ color: '#1890ff' }} />
                            <Text style={{ color: colors.textPrimary }}>{equipment?.equipmentType || 'N/A'}</Text>
                        </Flex>
                        <Flex align="center" gap={6}>
                            <ExperimentOutlined style={{ color: '#722ed1' }} />
                            <Text style={{ color: colors.textPrimary }}>{equipment?.category || 'N/A'}</Text>
                        </Flex>
                        <Flex align="center" gap={6}>
                            <EnvironmentOutlined style={{ color: '#fa8c16' }} />
                            <Text style={{ color: colors.textPrimary }}>{equipment?.building || 'N/A'}</Text>
                        </Flex>
                    </Flex>

                    {/* Tabs Section */}
                    <div style={{ padding: '16px 24px 24px' }}>
                        <Tabs 
                            activeKey={activeTab} 
                            onChange={setActiveTab}
                            items={tabItems}
                            size="large"
                            style={{ marginBottom: 8 }}
                        />
                        
                        {/* Actions */}
                        <Flex justify="space-between" align="center" style={{ 
                            marginTop: 24, 
                            paddingTop: 16, 
                            borderTop: `1px solid ${colors.statsBorder}`
                        }}>
                            <Text type="secondary" style={{ fontSize: 12 }}>
                                Created: {formatDate(equipment?.createdAt)} | Last Updated: {formatDate(equipment?.updatedAt)}
                            </Text>
                            <Flex gap={8}>
                                {onEdit && (
                                    <Button 
                                        onClick={onEdit} 
                                        icon={<EditOutlined />}
                                        type="primary"
                                    >
                                        Edit
                                    </Button>
                                )}
                                <Button 
                                    onClick={onClose} 
                                    icon={<CloseOutlined />}
                                    type="primary"
                                >
                                    Close
                                </Button>
                            </Flex>
                        </Flex>
                    </div>
                </div>
            )}
        </Modal>
    );
}
