'use client';

import {
    Equipment_Categories,
    Equipment_Types,
    Equipment_Status,
    Qualification_Status,
    Calibration_Status,
    Maintenance_Type,
} from "@/lib/constants/Generarl";
import { DEPARTMENTS } from "@/lib/constants/Department";
import {
    Modal,
    Form,
    Input,
    Select,
    InputNumber,
    Row,
    Col,
    Button,
    Typography,
    message,
    Tabs,
    Space,
    DatePicker,
    Switch,
    Spin,
} from "antd";
import {
    DatabaseOutlined,
    EnvironmentOutlined,
    ExperimentOutlined,
    SettingOutlined,
    ToolOutlined,
    InfoCircleOutlined,
    PlusOutlined,
    CloseOutlined,
    SaveOutlined,
    DeleteOutlined,
} from "@ant-design/icons";
import dayjs from "dayjs";
import { useEffect, useState } from "react";

const { TextArea } = Input;
const { Title, Text } = Typography;

interface EditEquipmentProps {
    open: boolean;
    onClose: () => void;
    equipment: any;
    onSuccess?: () => void;
}

export default function EditEquipment({
    open,
    onClose,
    equipment,
    onSuccess,
}: EditEquipmentProps) {
    const [loading, setLoading] = useState(false);
    const [fetching, setFetching] = useState(false);
    const [form] = Form.useForm();
    const [activeTab, setActiveTab] = useState('basic');
    const [equipmentData, setEquipmentData] = useState<any>(null);

    useEffect(() => {
        if (open && equipment) {
            // If full equipment object is passed, use it directly
            if (equipment.equipmentName) {
                setEquipmentData(equipment);
                populateForm(equipment);
            }
            // If only ID is passed, fetch the equipment data
            else if (equipment._id) {
                fetchEquipmentData(equipment._id);
            }
            setActiveTab('basic');
        }
    }, [open, equipment, form]);

    const fetchEquipmentData = async (id: string) => {
        try {
            setFetching(true);
            const res = await fetch(`/api/user/master-data/equipment-master?equipmentId=${id}`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            const data = await res.json();
            if (data.success && data.equipment && data.equipment[0]) {
                const equipData = data.equipment[0];
                setEquipmentData(equipData);
                populateForm(equipData);
            } else {
                message.error('Failed to fetch equipment data');
            }
        } catch (error) {
            console.error(error);
            message.error('Error fetching equipment data');
        } finally {
            setFetching(false);
        }
    };

    const toDayjs = (date?: string | Date | null) => date ? dayjs(date) : null;

    const populateForm = (data: any) => {
        form.setFieldsValue({
            ...data,
            iqDate: toDayjs(data.iqDate),
            oqDate: toDayjs(data.oqDate),
            pqDate: toDayjs(data.pqDate),
            lastCalibrationDate: toDayjs(data.lastCalibrationDate),
            nextCalibrationDate: toDayjs(data.nextCalibrationDate),
            lastMaintenanceDate: toDayjs(data.lastMaintenanceDate),
            nextMaintenanceDate: toDayjs(data.nextMaintenanceDate),
        });
    };

    const handleSubmit = async () => {
        const values = await form.validateFields().catch((error) => {
            if (error.errorFields && error.errorFields.length > 0) {
                message.error('Please fill all required fields');
            }
            return null;
        });

        if (!values) return;

        try {
            setLoading(true);

            const updateData = {
                _id: equipment._id,
                ...values,
                updateReason: values.updateReason || 'Updated equipment information',
            };

            const res = await fetch('/api/user/master-data/equipment-master', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify(updateData)
            });

            const data = await res.json();

            if (data.success) {
                message.success(`Equipment ${data.equipmentCode} updated successfully!`);
                form.resetFields();
                onClose();
                if (onSuccess) onSuccess();
            } else {
                message.error(data.message);
            }

        } catch (error) {
            console.error(error);
            message.error("Failed to update equipment");
        } finally {
            setLoading(false);
        }
    };

    // Tab Contents
    const BasicInfoTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24} sm={12} md={8}>
                    <Form.Item
                        name="equipmentName"
                        label="Equipment Name"
                        rules={[{ required: true, message: "Enter equipment name" }]}
                    >
                        <Input placeholder="Enter equipment name" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item
                        name="equipmentType"
                        label="Equipment Type"
                        rules={[{ required: true, message: "Select equipment type" }]}
                    >
                        <Select placeholder="Select type" options={Equipment_Types} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item
                        name="category"
                        label="Category"
                        rules={[{ required: true, message: "Select category" }]}
                    >
                        <Select placeholder="Select category" options={Equipment_Categories} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="modelNumber" label="Model Number">
                        <Input placeholder="Enter model number" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="serialNumber" label="Serial Number">
                        <Input placeholder="Enter serial number" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="assetTag" label="Asset Tag">
                        <Input placeholder="Enter asset tag" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="manufacturer" label="Manufacturer">
                        <Input placeholder="Enter manufacturer" />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const LocationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="site" label="Site">
                        <Input placeholder="Enter site" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="building" label="Building">
                        <Input placeholder="Enter building" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="floor" label="Floor">
                        <Input placeholder="Enter floor" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="department" label="Department">
                        <Select placeholder="Select department" options={DEPARTMENTS} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="area" label="Area">
                        <Input placeholder="Enter area" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="roomNumber" label="Room Number">
                        <Input placeholder="Enter room number" />
                    </Form.Item>
                </Col>

                <Col xs={24} md={12}>
                    <Form.Item name="installationLocation" label="Installation Location">
                        <Input placeholder="Enter installation location" />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const QualificationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24}>
                    <Form.Item name="qualificationRequired" label="Qualification Required" valuePropName="checked">
                        <Switch />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="qualificationStatus" label="Qualification Status">
                        <Select placeholder="Select status" options={Qualification_Status} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="iqDate" label="IQ Date">
                        <DatePicker style={{ width: '100%' }} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="oqDate" label="OQ Date">
                        <DatePicker style={{ width: '100%' }} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="pqDate" label="PQ Date">
                        <DatePicker style={{ width: '100%' }} />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const CalibrationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24}>
                    <Form.Item name="calibrationRequired" label="Calibration Required" valuePropName="checked">
                        <Switch />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="calibrationFrequency" label="Calibration Frequency (Months)">
                        <InputNumber min={0} style={{ width: '100%' }} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="calibrationStandard" label="Calibration Standard">
                        <Input placeholder="Enter standard" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="lastCalibrationDate" label="Last Calibration">
                        <DatePicker style={{ width: '100%' }} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="nextCalibrationDate" label="Next Calibration">
                        <DatePicker style={{ width: '100%' }} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="calibrationStatus" label="Calibration Status">
                        <Select placeholder="Select status" options={Calibration_Status} />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const MaintenanceTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24}>
                    <Form.Item name="maintenanceRequired" label="Maintenance Required" valuePropName="checked">
                        <Switch />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="maintenanceType" label="Maintenance Type">
                        <Select placeholder="Select type" options={Maintenance_Type} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="maintenanceFrequency" label="Frequency (Months)">
                        <InputNumber min={0} style={{ width: '100%' }} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="lastMaintenanceDate" label="Last Maintenance">
                        <DatePicker style={{ width: '100%' }} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={6}>
                    <Form.Item name="nextMaintenanceDate" label="Next Maintenance">
                        <DatePicker style={{ width: '100%' }} />
                    </Form.Item>
                </Col>

                <Col xs={24} md={12}>
                    <Form.Item name="maintenanceVendor" label="Maintenance Vendor">
                        <Input placeholder="Enter vendor" />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const OperationalTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24} sm={12} md={8}>
                    <Form.Item
                        name="currentStatus"
                        label="Current Status"
                        rules={[{ required: true }]}
                    >
                        <Select placeholder="Select status" options={Equipment_Status} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="cleaningStatus" label="Cleaning Status">
                        <Select placeholder="Select cleaning status" options={[
                            { value: 'Clean', label: 'Clean' },
                            { value: 'Pending', label: 'Pending' },
                            { value: 'In Progress', label: 'In Progress' },
                        ]} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="lastProductProcessed" label="Last Product Processed">
                        <Input placeholder="Enter last product processed" />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    // CPP - Critical Process Parameters
    const CPPTab = () => {
        return (
            <div style={{ padding: '8px 0' }}>
                <Form.List name="cppParameters">
                    {(fields, { add, remove }) => (
                        <>
                            <div style={{ marginBottom: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <Text type="secondary">Edit Critical Process Parameters</Text>

                                <Button
                                    type="dashed"
                                    icon={<PlusOutlined />}
                                    onClick={() => add({ parameterName: '', minValue: null, maxValue: null })}
                                >
                                    Add Parameter
                                </Button>
                            </div>

                            {fields.length === 0 && (
                                <div style={{ textAlign: 'center', padding: 40, color: '#999' }}>
                                    <Text type="secondary">No parameters added yet. Click "Add Parameter" to add CPP.</Text>
                                </div>
                            )}

                            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                                {fields.map(({ key, name }) => (
                                    <div
                                        key={key}
                                        style={{
                                            display: 'flex',
                                            gap: 8,
                                            alignItems: 'flex-start',
                                            padding: 12,
                                            background: '#141414',
                                            borderRadius: 8
                                        }}
                                    >
                                        <Form.Item
                                            name={[name, 'parameterName']}
                                            label="Parameter Name"
                                            style={{ marginBottom: 0, flex: 1 }}
                                        >
                                            <Input placeholder="e.g., Temperature, Pressure" />
                                        </Form.Item>

                                        <Form.Item
                                            name={[name, 'minValue']}
                                            label="Min Value"
                                            style={{ marginBottom: 0, width: 120 }}
                                        >
                                            <InputNumber style={{ width: '100%' }} />
                                        </Form.Item>

                                        <Form.Item
                                            name={[name, 'maxValue']}
                                            label="Max Value"
                                            style={{ marginBottom: 0, width: 120 }}
                                        >
                                            <InputNumber style={{ width: '100%' }} />
                                        </Form.Item>

                                        <Form.Item
                                            name={[name, 'unit']}
                                            label="Unit"
                                            style={{ marginBottom: 0, width: 120 }}
                                        >
                                            <Input placeholder="e.g. N, gram" style={{ width: '100%' }} />
                                        </Form.Item>
                                        
                                        <Button
                                            type="text"
                                            danger
                                            icon={<DeleteOutlined />}
                                            onClick={() => remove(name)}
                                            style={{ marginTop: 29 }}
                                        />
                                    </div>
                                ))}
                            </div>
                        </>
                    )}
                </Form.List>
            </div>
        );
    };

    const DocumentationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="sopNumber" label="SOP Number">
                        <Input placeholder="Enter SOP number" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="manualDocument" label="Manual Document">
                        <Input placeholder="Enter manual document" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="qualificationProtocol" label="Qualification Protocol">
                        <Input placeholder="Enter qualification protocol" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="calibrationCertificate" label="Calibration Certificate">
                        <Input placeholder="Enter calibration certificate" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="maintenanceRecord" label="Maintenance Record">
                        <Input placeholder="Enter maintenance record" />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const tabItems = [
        {
            key: 'basic',
            label: <span><DatabaseOutlined /> Basic Info</span>,
            children: <BasicInfoTab />,
        },
        {
            key: 'location',
            label: <span><EnvironmentOutlined /> Location</span>,
            children: <LocationTab />,
        },
        {
            key: 'qualification',
            label: <span><ExperimentOutlined /> Qualification</span>,
            children: <QualificationTab />,
        },
        {
            key: 'calibration',
            label: <span><SettingOutlined /> Calibration</span>,
            children: <CalibrationTab />,
        },
        {
            key: 'maintenance',
            label: <span><ToolOutlined /> Maintenance</span>,
            children: <MaintenanceTab />,
        },
        {
            key: 'operational',
            label: <span><InfoCircleOutlined /> Operational</span>,
            children: <OperationalTab />,
        },
        {
            key: 'cpp',
            label: <span><SettingOutlined /> CPP</span>,
            children: <CPPTab />,
        },
        {
            key: 'documentation',
            label: <span><DatabaseOutlined /> Documentation</span>,
            children: <DocumentationTab />,
        },
    ];

    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            centered
            width={800}
            destroyOnHidden
            styles={{
                header: {
                    background: '#001529',
                    padding: '16px 24px',
                },
                body: { padding: 0 },
            }}
            title={
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{
                        width: 40,
                        height: 40,
                        borderRadius: 8,
                        background: 'linear-gradient(135deg, #1890ff 0%, #36cfc9 100%)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <SettingOutlined style={{ fontSize: 20, color: '#fff' }} />
                    </div>
                    <div>
                        <Title level={5} style={{ marginBottom: 0, color: '#fff' }}>
                            Edit Equipment
                        </Title>
                        <Text style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12 }}>
                            EQ-{equipmentData?.equipmentCode || equipment?.equipmentCode} - {equipmentData?.equipmentName || 'Loading...'}
                        </Text>
                    </div>
                </div>
            }
        >
            {fetching ? (
                <div style={{ textAlign: 'center', padding: '60px 0' }}>
                    <Spin size="large" />
                    <div style={{ marginTop: 16 }}>
                        <Text type="secondary">Loading equipment details...</Text>
                    </div>
                </div>
            ) : (
                <Form form={form} layout="vertical" size="middle">
                    <div style={{ padding: '16px 24px 24px' }}>
                        <Tabs
                            activeKey={activeTab}
                            onChange={setActiveTab}
                            items={tabItems}
                            size="large"
                            style={{ marginBottom: 8 }}
                        />

                        <div style={{
                            marginTop: 24,
                            paddingTop: 16,
                            borderTop: '1px solid #f0f0f0',
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center'
                        }}>
                            <Text type="secondary" style={{ fontSize: 12 }}>
                                All fields marked as * are required
                            </Text>
                            <Space>
                                <Button onClick={onClose} icon={<CloseOutlined />}>
                                    Cancel
                                </Button>
                                <Button type="primary" loading={loading} icon={<SaveOutlined />} onClick={handleSubmit}>
                                    Save Changes
                                </Button>
                            </Space>
                        </div>
                    </div>
                </Form>
            )}
        </Modal>
    );
}
