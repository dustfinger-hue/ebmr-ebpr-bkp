'use client';

import { Button, Card, Col, message, Row, Select, Space, Table, Tag, Tooltip, Typography } from "antd";
import { useEffect, useState } from "react";
import { SettingOutlined } from "@ant-design/icons";
const { Title, Text } = Typography;
import {
  SearchOutlined,
  ReloadOutlined,
  PlusOutlined,
  FilterOutlined,
  ClearOutlined,
  DeleteTwoTone,
  EditTwoTone,
  EyeTwoTone
} from "@ant-design/icons";
import AddNewEquipment from "./components/Add-New-Equipment";
import VeiwEquipment from "./components/Veiw-Equipment";
import EditEquipment from "./components/Edit-Equipment";
import DeleteEquipment from "./components/Delete-Equipment";
import { useAuthorization } from "@/hooks/useAuthorization";
import Search from "antd/es/input/Search";
import { Equipment_Types, Equipment_Categories, Equipment_Status } from "@/lib/constants/Generarl";
import { DEPARTMENTS } from "@/lib/constants/Department";

export default function EquipmentMasterPage() {

  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });
  const [addEquipmentModal, setAddEquipmentModal] = useState(false);
  const [viewEquipmentModal, setViewEquipmentModal] = useState(false);
  const [editEquipmentModal, setEditEquipmentModal] = useState(false);
  const [deleteEquipmentModal, setDeleteEquipmentModal] = useState(false);
  const [selectedEquipmentId, setSelectedEquipmentId] = useState<string | null>(null);
  const [selectedEquipmentForDelete, setSelectedEquipmentForDelete] = useState<any>(null);
  const [equipment, setEquipment] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // Filter states
  const [searchText, setSearchText] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("");
  const [categoryFilter, setCategoryFilter] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [departmentFilter, setDepartmentFilter] = useState<string>("");
  const [filterVisible, setFilterVisible] = useState(false);

  useEffect(() => {
    getEquipment(pagination.current, pagination.pageSize, searchText, typeFilter, categoryFilter, statusFilter, departmentFilter);
  }, [pagination.current, pagination.pageSize, searchText, typeFilter, categoryFilter, statusFilter, departmentFilter]);

  useEffect(() => {
    setPagination(prev => ({ ...prev, current: 1 }));
  }, [searchText, typeFilter, categoryFilter, statusFilter, departmentFilter]);

  const getEquipment = async (
    page: number, 
    limit: number, 
    search: string, 
    type: string, 
    category: string, 
    status: string, 
    department: string
  ) => {
    try {
      setLoading(true);
      let url = `/api/user/master-data/equipment-master?page=${page}&limit=${limit}&search=${search}`;
      
      if (type) url += `&equipmentType=${type}`;
      if (category) url += `&category=${category}`;
      if (status) url += `&status=${status}`;
      if (department) url += `&department=${department}`;

      const response = await fetch(url);
      const data = await response.json();

      if (data.success) {
        setEquipment(data.equipment);
        setPagination(prev => ({
          ...prev,
          total: data.total,
        }));
      } else {
        message.error(data.message);
      }
    } catch (error) {
      console.error(error);
      message.error("Error fetching equipment");
    } finally {
      setLoading(false);
    }
  };

  const clearFilters = () => {
    setSearchText("");
    setTypeFilter("");
    setCategoryFilter("");
    setStatusFilter("");
    setDepartmentFilter("");
    setPagination(prev => ({ ...prev, current: 1 }));
  };

  const hasActiveFilters = () => {
    return typeFilter || categoryFilter || statusFilter || departmentFilter || searchText;
  };

  const handleEdit = (record: any) => {
    setSelectedEquipmentId(record._id);
    setEditEquipmentModal(true);
  };

  const handleView = (record: any) => {
    setSelectedEquipmentId(record._id);
    setViewEquipmentModal(true);
  };

  const handleDeleteClick = (record: any) => {
    setSelectedEquipmentForDelete(record);
    setDeleteEquipmentModal(true);
  };

  const handleDeleteSuccess = () => {
    getEquipment(pagination.current, pagination.pageSize, searchText, typeFilter, categoryFilter, statusFilter, departmentFilter);
    setSelectedEquipmentForDelete(null);
    setDeleteEquipmentModal(false);
  };

  const handleEditSuccess = () => {
    getEquipment(pagination.current, pagination.pageSize, searchText, typeFilter, categoryFilter, statusFilter, departmentFilter);
    setSelectedEquipmentId(null);
  };

  // Authorization check
  const { hasAccess } = useAuthorization();
  const isCreateEquipmentAuthorized = hasAccess('Equipment Master', 'create');
  const isUpdateEquipmentAuthorized = hasAccess('Equipment Master', 'update');
  const isDeleteEquipmentAuthorized = hasAccess('Equipment Master', 'delete');

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      'Active': 'green',
      'Under Maintenance': 'orange',
      'Breakdown': 'red',
      'Retired': 'default',
      'Decommissioned': 'default',
    };
    return colors[status] || 'blue';
  };

  const columns = [
    {
      title: 'S.No',
      width: 80,
      fixed: 'left' as const,
      render: (_: any, __: any, index: number) =>
        (pagination.current - 1) * pagination.pageSize + index + 1
    },
    {
      title: 'Equipment Code',
      dataIndex: 'equipmentCode',
      key: 'equipmentCode',
      width: 140,
      render: (text: number) => (
        <Text copyable style={{ color: '#1677ff', fontWeight: 500 }}>
          {text}
        </Text>
      ),
    },
    {
      title: 'Equipment Name',
      dataIndex: 'equipmentName',
      key: 'equipmentName',
      width: 200,
      ellipsis: true,
      render: (_: any, record: any) => (
        <div style={{ lineHeight: 1.3 }}>
          <div>
            <Text strong>{record.equipmentName}</Text>
          </div>
          <div>
            <Text type="secondary" style={{ fontSize: 12 }}>
              {record.modelNumber || 'N/A'}
            </Text>
          </div>
        </div>
      )
    },
    {
      title: 'Type',
      dataIndex: 'equipmentType',
      key: 'equipmentType',
      width: 120,
      render: (text: string) => <Tag>{text}</Tag>,
    },
    {
      title: 'Category',
      dataIndex: 'category',
      key: 'category',
      width: 180,
      ellipsis: true,
      render: (text: string) => <Tag color="blue">{text}</Tag>,
    },
    {
      title: 'Department',
      dataIndex: 'department',
      key: 'department',
      width: 140,
      render: (text: string) => <Text type="secondary">{text || '-'}</Text>,
    },
    {
      title: 'Serial Number',
      dataIndex: 'serialNumber',
      key: 'serialNumber',
      width: 150,
      render: (text: string) => <Text type="secondary">{text || '-'}</Text>,
    },
    {
      title: 'Manufacturer',
      dataIndex: 'manufacturer',
      key: 'manufacturer',
      width: 150,
      ellipsis: true,
      render: (text: string) => <Text type="secondary">{text || '-'}</Text>,
    },
    {
      title: 'Status',
      dataIndex: 'currentStatus',
      key: 'currentStatus',
      width: 140,
      render: (status: string) => (
        <Tag color={getStatusColor(status)}>{status}</Tag>
      ),
    },
    {
      title: 'Action',
      width: 120,
      fixed: "right" as const,
      render: (record: any) => {
        return (
          <div style={{ display: 'flex', flexDirection: 'row', gap: 4 }}>
            <Button 
              icon={<EyeTwoTone twoToneColor="green" />} 
              size="small"
              variant="outlined" 
              color="green" 
              onClick={() => handleView(record)} 
            />
            <Tooltip title={isUpdateEquipmentAuthorized ? "" : "You are not authorized to perform this action."}>
              <Button 
                icon={<EditTwoTone />} 
                size="small"
                variant="outlined" 
                color="primary" 
                disabled={!isUpdateEquipmentAuthorized} 
                onClick={() => handleEdit(record)} 
              />
            </Tooltip>
            <Tooltip title={isDeleteEquipmentAuthorized ? "" : "You are not authorized to perform this action."}>
              <Button 
                icon={<DeleteTwoTone twoToneColor="red" />} 
                size="small"
                variant="outlined" 
                color="danger" 
                onClick={() => handleDeleteClick(record)}
                disabled={!isDeleteEquipmentAuthorized}
              />
            </Tooltip>
          </div>
        )
      }
    }
  ];

  return (
    <div>
      <Title level={2}>
        <SettingOutlined style={{ marginRight: 12, color: "#1890ff" }} />
        Equipment Master
      </Title>
      <Card>

        <Row gutter={[16, 16]} style={{ marginBottom: 16 }} justify="space-between">

          <Col xs={24} md={10}>
            <Search
              placeholder="Search by equipment code, name, model or serial..."
              allowClear
              onSearch={(value) => {
                setPagination(prev => ({
                  ...prev,
                  current: 1,
                }));
                setSearchText(value);
              }}
              style={{ width: '100%' }}
              prefix={<SearchOutlined />}
            />
          </Col>
          <Col xs={24} md={14} style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <Space wrap>
              <Tooltip title="Advanced Filters">
                <Button
                  type={filterVisible ? "primary" : "default"}
                  icon={<FilterOutlined />}
                  onClick={() => setFilterVisible(!filterVisible)}
                >
                  Filters {hasActiveFilters() && `(${[typeFilter, categoryFilter, statusFilter, departmentFilter, searchText].filter(Boolean).length})`}
                </Button>
              </Tooltip>

              {hasActiveFilters() && (
                <Tooltip title="Clear All Filters">
                  <Button
                    icon={<ClearOutlined />}
                    onClick={clearFilters}
                    danger
                  >
                    Clear
                  </Button>
                </Tooltip>
              )}
              <Tooltip title="Refresh">
                <Button
                  onClick={() => getEquipment(pagination.current, pagination.pageSize, searchText, typeFilter, categoryFilter, statusFilter, departmentFilter)}
                  icon={<ReloadOutlined />}
                />
              </Tooltip>
              <Tooltip title={isCreateEquipmentAuthorized ? "" : "You are not authorized to perform this action."}>
                <Button
                  type="primary"
                  onClick={() => setAddEquipmentModal(true)}
                  icon={<PlusOutlined />}
                  disabled={!isCreateEquipmentAuthorized}
                >
                  Add Equipment
                </Button>
              </Tooltip>
            </Space>

          </Col>
        </Row>

        {/* Advanced Filters Panel */}
        {filterVisible && (
          <div style={{ marginBottom: 16, padding: 16, background: '#f5f5f5', borderRadius: 8 }}>
            <Row gutter={[16, 16]}>
              <Col xs={24} sm={12} md={6}>
                <label style={{ display: 'block', marginBottom: 4, fontWeight: 500 }}>Equipment Type</label>
                <Select
                  placeholder="Select Type"
                  style={{ width: '100%' }}
                  allowClear
                  value={typeFilter || undefined}
                  onChange={(value) => { setPagination(prev => ({ ...prev, current: 1 })); setTypeFilter(value || ""); }}
                  options={Equipment_Types}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <label style={{ display: 'block', marginBottom: 4, fontWeight: 500 }}>Category</label>
                <Select
                  placeholder="Select Category"
                  style={{ width: '100%' }}
                  allowClear
                  value={categoryFilter || undefined}
                  onChange={(value) => { setPagination(prev => ({ ...prev, current: 1 })); setCategoryFilter(value || ""); }}
                  options={Equipment_Categories}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <label style={{ display: 'block', marginBottom: 4, fontWeight: 500 }}>Status</label>
                <Select
                  placeholder="Select Status"
                  style={{ width: '100%' }}
                  allowClear
                  value={statusFilter || undefined}
                  onChange={(value) => { setPagination(prev => ({ ...prev, current: 1 })); setStatusFilter(value || ""); }}
                  options={Equipment_Status}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <label style={{ display: 'block', marginBottom: 4, fontWeight: 500 }}>Department</label>
                <Select
                  placeholder="Select Department"
                  style={{ width: '100%' }}
                  allowClear
                  value={departmentFilter || undefined}
                  onChange={(value) => { setPagination(prev => ({ ...prev, current: 1 })); setDepartmentFilter(value || ""); }}
                  options={DEPARTMENTS}
                />
              </Col>
            </Row>
          </div>
        )}

        {/* Active Filters Display */}
        {hasActiveFilters() && (
          <div style={{ marginBottom: 16 }}>
            <Space wrap>
              <Text type="secondary">Active Filters:</Text>
              {searchText && <Tag variant="outlined" closable onClose={() => { setSearchText(""); setPagination(prev => ({ ...prev, current: 1 })); }}>Search: {searchText}</Tag>}
              {statusFilter && <Tag variant="outlined" closable onClose={() => { setStatusFilter(""); setPagination(prev => ({ ...prev, current: 1 })); }}>Status: {statusFilter}</Tag>}
              {typeFilter && <Tag variant="outlined" closable onClose={() => { setTypeFilter(""); setPagination(prev => ({ ...prev, current: 1 })); }}>Type: {typeFilter}</Tag>}
              {categoryFilter && <Tag variant="outlined" closable onClose={() => { setCategoryFilter(""); setPagination(prev => ({ ...prev, current: 1 })); }}>Category: {categoryFilter}</Tag>}
              {departmentFilter && <Tag variant="outlined" closable onClose={() => { setDepartmentFilter(""); setPagination(prev => ({ ...prev, current: 1 })); }}>Department: {departmentFilter}</Tag>}
            </Space>
          </div>
        )}

        <Table
          columns={columns}
          dataSource={equipment}
          loading={loading}
          scroll={{ x: 'max-content' }}
          pagination={{
            current: pagination.current,
            pageSize: pagination.pageSize,
            total: pagination.total,
            showSizeChanger: true,
            pageSizeOptions: ['10', '20', '30', '40', '50'],
            onChange: (page: number, pageSize: number) => {
              setPagination(prev => ({
                ...prev,
                current: page,
                pageSize: pageSize,
              }));
            },
          }}
        />
      </Card>

      {/* Modals */}
      <AddNewEquipment
        open={addEquipmentModal}
        onClose={() => setAddEquipmentModal(false)}
        onSuccess={() => {
          getEquipment(pagination.current, pagination.pageSize, searchText, typeFilter, categoryFilter, statusFilter, departmentFilter);
        }}
      />

      <VeiwEquipment
        open={viewEquipmentModal}
        onClose={() => {
          setViewEquipmentModal(false);
          setSelectedEquipmentId(null);
        }}
        equipmentId={selectedEquipmentId || undefined}
        onEdit={() => {
          setViewEquipmentModal(false);
          setEditEquipmentModal(true);
        }}
      />

      <EditEquipment
        open={editEquipmentModal}
        onClose={() => {
          setEditEquipmentModal(false);
          setSelectedEquipmentId(null);
        }}
        equipment={{ _id: selectedEquipmentId }}
        onSuccess={handleEditSuccess}
      />

      <DeleteEquipment
        open={deleteEquipmentModal}
        onClose={() => {
          setDeleteEquipmentModal(false);
          setSelectedEquipmentForDelete(null);
        }}
        equipment={selectedEquipmentForDelete}
        onSuccess={handleDeleteSuccess}
      />
    </div>
  );
}
