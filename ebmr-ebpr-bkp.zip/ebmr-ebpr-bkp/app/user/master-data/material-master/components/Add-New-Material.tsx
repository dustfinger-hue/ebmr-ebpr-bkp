'use client';

import { Storage_Conditions } from "@/lib/constants/Generarl";
import { Form, Input, Modal, Select, Button, Alert, Space, Row, Col, Divider, Tooltip, Switch, message } from "antd";
import { useState } from "react";

interface AddNewMaterialProps {
    open: boolean;
    onClose: () => void;
    onSuccess: () => void;
}

export default function AddNewMaterial({ open, onClose, onSuccess }: AddNewMaterialProps) {
    const [form] = Form.useForm();
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (values: any) => {
        try {
            setLoading(true);

            const response = await fetch('/api/user/master-data/material-master', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify(values)
            });
            const data = await response.json();

            if (data.success) {
                message.success(`Material ${data.material.materialCode} created successfully!`);
                form.resetFields();
                onClose();
                onSuccess();
            } else {
                message.error(data.message);
            }
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const selectedCategory = Form.useWatch('category', form);

    const handleCategoryChange = () => {
        if (selectedCategory === 'Raw Material') {
            return [
                { value: 'Active', label: 'Active' },
                { value: 'Excipient', label: 'Excipient' },
            ]
        }
        else if (selectedCategory === 'Packaging Material') {
            return [
                { value: 'Primary', label: 'Primary' },
                { value: 'Secondary', label: 'Secondary' },
                { value: 'Tertiary', label: 'Tertiary' }
            ]
        }
        return [];
    }

    return (
        <Modal
            open={open}
            onCancel={() => {
                form.resetFields();
                onClose();
            }}
            title="Add New Material"
            footer={null}
            centered
            width={900}
        >
            <Alert
                title="Material Code will be auto-generated after saving."
                type="info"
                showIcon
                style={{ marginBottom: 20 }}
            />

            <Form
                layout="vertical"
                form={form}
                onFinish={handleSubmit}
                style={{ maxWidth: '100%' }}
                initialValues={{
                    heatSensitive: false,
                    humiditySensitive: false,
                    lightSensitive: false,
                    flammable: false,
                    corrosive: false,
                    oxidizing: false
                }}
            >
                {/* Basic Information Section */}
                <Divider orientation="horizontal" style={{ fontSize: '16px', fontWeight: 'bold' }}>
                    Basic Information
                </Divider>

                <Row gutter={16}>
                    <Col span={8}>
                        <Tooltip title="Material code is a unique identifier for the material. It is used to identify the material in the system.">
                            <Form.Item
                                label="Material Code"
                            // name="materialCode"
                            >
                                <Input disabled placeholder="Auto-generated after saving" />
                            </Form.Item>
                        </Tooltip>
                    </Col>
                    <Col span={8}>
                        <Tooltip title="Material name is the full name of the material. It is used to identify the material in the system.">
                            <Form.Item
                                label="Material Name"
                                name="materialName"
                                rules={[{ required: true, message: "Please enter material name" }]}
                            >
                                <Input placeholder="Enter material name" />
                            </Form.Item>
                        </Tooltip>
                    </Col>
                    <Col span={8}>
                        <Tooltip title="Short name is a shortened version of the material name. It is used to identify the material in the system.">
                            <Form.Item
                                label="Short Name"
                                name="shortName"
                                rules={[{ required: true }, { min: 3, message: 'Please enter short abbreviated name' }, {
                                    pattern: /^[A-Z0-9]+$/,
                                    message: "Only capital letters and numbers allowed"
                                }]}>
                                <Input placeholder="Enter short abbreviated name" />
                            </Form.Item>
                        </Tooltip>
                    </Col>
                </Row>

                <Row gutter={16}>
                    <Col span={8}>
                        <Tooltip title="Category is the type of material. It is used to identify the material in the system.">
                            <Form.Item
                                label="Category"
                                name="category"
                                rules={[{ required: true, message: "Please select category" }]}
                            >
                                <Select
                                    placeholder="Select category"
                                    options={[
                                        { value: 'Raw Material', label: 'Raw Material' },
                                        { value: 'Packaging Material', label: 'Packaging Material' }
                                    ]}
                                />
                            </Form.Item>
                        </Tooltip>
                    </Col>
                    <Col span={8}>
                        <Tooltip title="Type is the specific type of material. It is used to identify the material in the system.">
                            <Form.Item
                                label="Type"
                                name="type"
                                rules={[{ required: true, message: "Please select type" }]}
                            >
                                <Select
                                    placeholder="Select type"
                                    options={handleCategoryChange()}
                                />
                            </Form.Item>
                        </Tooltip>
                    </Col>
                    <Col span={8}>
                        <Tooltip title="Status is the current status of the material. It is used to identify the material in the system.">

                            <Form.Item
                                label="Status"
                                name="status"
                                initialValue="Active"
                                rules={[{ required: true }]}
                            >
                                <Select
                                    options={[
                                        { value: 'Active', label: 'Active' },
                                        { value: 'Inactive', label: 'Inactive' }
                                    ]}
                                />
                            </Form.Item>
                        </Tooltip>
                    </Col>
                </Row>

                <Form.Item
                    label="Description"
                    name="description"
                    rules={[{ required: true, message: "Please enter description" }]}
                >
                    <Input.TextArea rows={3} placeholder="Enter material description" />
                </Form.Item>

                {/* Storage & Measurement Section */}
                <Divider plain style={{ fontSize: '16px', fontWeight: 'bold' }}>
                    Storage & Measurement
                </Divider>

                <Row gutter={16}>
                    <Col span={12}>
                        <Form.Item
                            label='Storage Conditions'
                            name='storageCondition'
                            rules={[{ required: true, message: "Please select storage conditions" }]}
                        >
                            <Select
                                mode="multiple"
                                allowClear
                                placeholder="Select storage conditions"
                                options={Storage_Conditions}
                            />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Form.Item
                            label='Unit of Measurement'
                            name='unitOfMeasurement'
                            rules={[{ required: true, message: "Please select unit of measurement" }]}
                        >
                            <Select
                                placeholder="Select unit of measurement"
                                allowClear
                                options={[
                                    // Count units
                                    { value: 'unit', label: 'Unit' },
                                    { value: 'piece', label: 'Piece' },
                                    { value: 'pack', label: 'Pack' },
                                    { value: 'box', label: 'Box' },
                                    { value: 'drum', label: 'Drum' },
                                    { value: 'bag', label: 'Bag' },
                                    { value: 'carton', label: 'Carton' },
                                    { value: 'roll', label: 'Roll' },
                                    { value: 'bottle', label: 'Bottle' },
                                    { value: 'vial', label: 'Vial' },
                                    { value: 'ampoule', label: 'Ampoule' },
                                    { value: 'blister', label: 'Blister Pack' },

                                    // Weight units
                                    { value: 'kg', label: 'Kilogram (kg)' },
                                    { value: 'g', label: 'Gram (g)' },
                                    { value: 'mg', label: 'Milligram (mg)' },
                                    { value: 'µg', label: 'Microgram (µg)' },
                                    { value: 'lb', label: 'Pound (lb)' },
                                    { value: 'oz', label: 'Ounce (oz)' },

                                    // Volume units
                                    { value: 'L', label: 'Liter (L)' },
                                    { value: 'mL', label: 'Milliliter (mL)' },
                                    { value: 'µL', label: 'Microliter (µL)' },

                                    // Length units (for packaging materials)
                                    { value: 'm', label: 'Meter (m)' },
                                    { value: 'cm', label: 'Centimeter (cm)' },
                                    { value: 'mm', label: 'Millimeter (mm)' },
                                    { value: 'ft', label: 'Foot (ft)' },
                                    { value: 'in', label: 'Inch (in)' }
                                ]}
                            />
                        </Form.Item>
                    </Col>
                </Row>
                {/* Hazard Properties Section */}
                <Divider plain style={{ fontSize: '16px', fontWeight: 'bold' }}>
                    Hazard Properties
                </Divider>

                <Row gutter={16}>
                    <Col span={8}>
                        <Tooltip title="Material is sensitive to humidity and requires controlled moisture conditions during storage.">
                            <Form.Item
                                label="Humidity Sensitive"
                                name="humiditySensitive"
                                valuePropName="checked"
                            >
                                <Switch />
                            </Form.Item>
                        </Tooltip>
                    </Col>
                    <Col span={8}>
                        <Tooltip title="Material is sensitive to heat and requires temperature-controlled storage conditions.">
                            <Form.Item
                                label="Heat Sensitive"
                                name="heatSensitive"
                                valuePropName="checked"
                            >
                                <Switch />
                            </Form.Item>
                        </Tooltip>
                    </Col>
                    <Col span={8}>
                        <Tooltip title="Material is sensitive to light exposure and requires protection from direct light or UV radiation.">
                            <Form.Item
                                label="Light Sensitive"
                                name="lightSensitive"
                                valuePropName="checked"
                            >
                                <Switch />
                            </Form.Item>
                        </Tooltip>
                    </Col>
                </Row>

                <Row gutter={16}>
                    <Col span={8}>
                        <Tooltip title="Material is flammable and requires storage in a flammable materials cabinet with proper fire safety measures.">
                            <Form.Item
                                label="Flammable"
                                name="flammable"
                                valuePropName="checked"
                            >
                                <Switch />
                            </Form.Item>
                        </Tooltip>
                    </Col>
                    <Col span={8}>
                        <Tooltip title="Material is corrosive and can cause damage to living tissue or materials. Requires special handling and storage.">
                            <Form.Item
                                label="Corrosive"
                                name="corrosive"
                                valuePropName="checked"
                            >
                                <Switch />
                            </Form.Item>
                        </Tooltip>
                    </Col>
                    <Col span={8}>
                        <Tooltip title="Material is an oxidizing agent that can cause or enhance the combustion of other materials. Requires special storage precautions.">
                            <Form.Item
                                label="Oxidizing"
                                name="oxidizing"
                                valuePropName="checked"
                            >
                                <Switch />
                            </Form.Item>
                        </Tooltip>
                    </Col>
                </Row>



                <Form.Item style={{ marginTop: 24 }}>
                    <Space style={{ display: "flex", justifyContent: "flex-end" }}>
                        <Button onClick={onClose}>
                            Cancel
                        </Button>
                        <Button
                            type="primary"
                            htmlType="submit"
                            loading={loading}
                        >
                            Save Material
                        </Button>
                    </Space>
                </Form.Item>
            </Form>
        </Modal>
    );
}