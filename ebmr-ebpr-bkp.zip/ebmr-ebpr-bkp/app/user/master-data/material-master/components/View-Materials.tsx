'use client';

import {
    Modal,
    Card,
    Tag,
    Tabs,
    Typography,
    Space,
    Button,
    Divider,
    Row,
    Col,
    List,
    Badge,
    message,
    Spin,
    Flex,
} from 'antd';

import {
    MedicineBoxOutlined,
    AlertOutlined,
    DashboardOutlined,
    CalendarOutlined,
    UserOutlined,
    CloseOutlined,
    CheckCircleOutlined,
    CloseCircleOutlined,
    EnvironmentOutlined,
    ExperimentOutlined,
    FileTextOutlined,
    DatabaseOutlined,
} from '@ant-design/icons';

import { useState, useEffect, useMemo } from 'react';
import dayjs from 'dayjs';
import { useTheme } from '@/lib/utils/ThemeContext';

const { Text, Title, Paragraph } = Typography;

interface MaterialData {
    _id: string;
    materialCode: string;
    materialName: string;
    shortName: string;
    description: string;
    category: string;
    type: string;
    unitOfMeasurement: string;
    storageCondition: string[];
    humiditySensitive: boolean;
    heatSensitive: boolean;
    lightSensitive: boolean;
    flammable: boolean;
    corrosive: boolean;
    oxidizing: boolean;
    status: string;
    createdBy?: {
        fullName?: string;
        employeeId?: string;
        designation?: string;
    };
    createdAt: string;
    updatedBy?: {
        fullName?: string;
        employeeId?: string;
    };
    updateAt?: string;
    updateReason?: string;
    deletedBy?: {
        fullName?: string;
        employeeId?: string;
    };
    deletedAt?: string;
    deleteReason?: string;
}

interface ViewMaterialsProps {
    open: boolean;
    onClose: () => void;
    materialData?: MaterialData | null;
}

export default function ViewMaterials({ open, onClose, materialData }: ViewMaterialsProps) {
    const { theme } = useTheme();
    const [loading, setLoading] = useState(false);
    const [material, setMaterial] = useState<MaterialData | null>(null);
    const [activeTab, setActiveTab] = useState('basic');

    // Theme-aware colors
    const colors = {
        cardBg: theme === 'dark' ? '#1f1f1f' : '#fafafa',
        cardBorder: theme === 'dark' ? '#303030' : '#f0f0f0',
        textPrimary: theme === 'dark' ? '#ffffff' : '#262626',
        textSecondary: theme === 'dark' ? '#8c8c8c' : '#8c8c8c',
        textMuted: theme === 'dark' ? '#595959' : '#bfbfbf',
        modalHeader: theme === 'dark' ? '#141414' : '#001529',
        quickStatsBg: theme === 'dark' ? '#1f1f1f' : '#fafafa',
        statsBorder: theme === 'dark' ? '#303030' : '#f0f0f0',
        // Special background colors
        greenBg: theme === 'dark' ? '#1b2a1b' : '#f6ffed',
        greenBorder: theme === 'dark' ? '#274c27' : '#b7eb8f',
        blueBg: theme === 'dark' ? '#1a2a3a' : '#e6f7ff',
        blueBorder: theme === 'dark' ? '#1d3d5c' : '#91d5ff',
        yellowBg: theme === 'dark' ? '#2a2a1a' : '#fffbe6',
        yellowBorder: theme === 'dark' ? '#4d4d1a' : '#ffe58f',
        redBg: theme === 'dark' ? '#2a1a1a' : '#fff1f0',
        redBorder: theme === 'dark' ? '#4d1a1a' : '#ffccc7',
        redText: theme === 'dark' ? '#ff4d4f' : '#ff4d4f',
    };

    // Reset tab when modal opens
    useEffect(() => {
        if (open) {
            setActiveTab('basic');
        }
    }, [open]);

    useEffect(() => {
        if (open && materialData?._id) {
            fetchMaterial(materialData?._id as string);
        }
    }, [open, materialData]);

    const fetchMaterial = async (id: string) => {
        try {
            setLoading(true);
            const res = await fetch(`/api/user/master-data/material-master/?id=${id}`);
            const data = await res.json();

            if (data.success) {
                setMaterial(data.material);
            } else {
                message.error(data.message);
            }
        } catch (error) {
            console.error(error);
        }
        finally {
            setLoading(false);
        }
    };

    // Helper to render info row
    const renderInfoRow = (label: string, value: any, span: number = 8) => (
        <Col xs={24} sm={span}>
            <div style={{ 
                padding: '12px 16px', 
                background: colors.cardBg, 
                borderRadius: 8,
                height: '100%',
                border: `1px solid ${colors.cardBorder}`
            }}>
                <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block', color: colors.textSecondary }}>
                    {label}
                </Text>
                <Text strong style={{ fontSize: 15, color: colors.textPrimary }}>
                    {value || <span style={{ color: colors.textMuted }}>-</span>}
                </Text>
            </div>
        </Col>
    );

    // Helper to render tags
    const renderTags = (items: string[] | undefined, color: string = "blue") => {
        if (!items?.length) return <Text type="secondary">-</Text>;
        return (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {items.map((item: string) => (
                    <Tag 
                        key={item} 
                        color={color} 
                        style={{ margin: 0, fontSize: 12, padding: '2px 10px' }}
                    >
                        {item}
                    </Tag>
                ))}
            </div>
        );
    };

    const getCategoryColor = (category: string) => {
        const colors: Record<string, string> = {
            'Raw Material': 'blue',
            'Packaging Material': 'green',
        };
        return colors[category] || 'default';
    };

    const getTypeColor = (type: string) => {
        const colors: Record<string, string> = {
            Active: 'red',
            Excipient: 'orange',
            Primary: 'purple',
            Secondary: 'cyan',
            Tertiary: 'volcano',
        };
        return colors[type] || 'default';
    };

    const hazardProperties = useMemo(() => [
        { label: 'Humidity Sensitive', value: material?.humiditySensitive, icon: '💧' },
        { label: 'Heat Sensitive', value: material?.heatSensitive, icon: '🔥' },
        { label: 'Light Sensitive', value: material?.lightSensitive, icon: '💡' },
        { label: 'Flammable', value: material?.flammable, icon: '⚠️' },
        { label: 'Corrosive', value: material?.corrosive, icon: '🧪' },
        { label: 'Oxidizing', value: material?.oxidizing, icon: '🔵' },
    ], [material]);

    const activeHazards = useMemo(() =>
        hazardProperties.filter(h => h.value).map(h => h.label),
        [hazardProperties]);

    // Tab content components
    const BasicInfoTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                {renderInfoRow("Material Code", material?.materialCode, 8)}
                {renderInfoRow("Material Name", material?.materialName, 8)}
                {renderInfoRow("Short Name", material?.shortName, 8)}
                <Col xs={24} sm={8}>
                    <div style={{ 
                        padding: '12px 16px', 
                        background: colors.cardBg, 
                        borderRadius: 8,
                        height: '100%',
                        border: `1px solid ${colors.cardBorder}`
                    }}>
                        <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block', color: colors.textSecondary }}>
                            Status
                        </Text>
                        <Tag 
                            color={material?.status === 'Active' ? 'success' : 'default'}
                            style={{ marginTop: 4 }}
                        >
                            {material?.status || '-'}
                        </Tag>
                    </div>
                </Col>
                <Col xs={24} sm={8}>
                    <div style={{ 
                        padding: '12px 16px', 
                        background: colors.cardBg, 
                        borderRadius: 8,
                        height: '100%',
                        border: `1px solid ${colors.cardBorder}`
                    }}>
                        <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block', color: colors.textSecondary }}>
                            Category
                        </Text>
                        <Tag color={getCategoryColor(material?.category || '')} style={{ marginTop: 4 }}>
                            {material?.category || '-'}
                        </Tag>
                    </div>
                </Col>
                <Col xs={24} sm={8}>
                    <div style={{ 
                        padding: '12px 16px', 
                        background: colors.cardBg, 
                        borderRadius: 8,
                        height: '100%',
                        border: `1px solid ${colors.cardBorder}`
                    }}>
                        <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block', color: colors.textSecondary }}>
                            Type
                        </Text>
                        <Tag color={getTypeColor(material?.type || '')} style={{ marginTop: 4 }}>
                            {material?.type || '-'}
                        </Tag>
                    </div>
                </Col>
                {renderInfoRow("Unit of Measurement", material?.unitOfMeasurement, 8)}
                <Col xs={24}>
                    <div style={{ 
                        padding: '16px', 
                        background: colors.greenBg, 
                        borderRadius: 8,
                        border: `1px solid ${colors.greenBorder}`
                    }}>
                        <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                            Description
                        </Text>
                        <Paragraph style={{ marginBottom: 0, marginTop: 8, fontSize: 14 }}>
                            {material?.description || <Text type="secondary">No description available</Text>}
                        </Paragraph>
                    </div>
                </Col>
            </Row>
        </div>
    );

    const StorageTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                <Col xs={24}>
                    <div style={{ 
                        padding: '16px', 
                        background: colors.blueBg, 
                        borderRadius: 8,
                        border: `1px solid ${colors.blueBorder}`
                    }}>
                        <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                            Storage Conditions
                        </Text>
                        <div style={{ marginTop: 8 }}>
                            {renderTags(material?.storageCondition, 'blue')}
                        </div>
                    </div>
                </Col>
            </Row>
        </div>
    );

    const HazardsTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                <Col xs={24}>
                    <div style={{ 
                        padding: '16px', 
                        background: colors.redBg, 
                        borderRadius: 8,
                        border: `1px solid ${colors.redBorder}`
                    }}>
                        <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 12, display: 'block', color: colors.textSecondary }}>
                            Material Properties
                        </Text>
                        <List
                            bordered
                            dataSource={hazardProperties}
                            renderItem={(item) => (
                                <List.Item>
                                    <Space>
                                        <span>{item.icon}</span>
                                        <span style={{ color: colors.textPrimary }}>{item.label}</span>
                                    </Space>
                                    <Tag color={item.value ? 'red' : 'default'}>
                                        {item.value ? 'Yes' : 'No'}
                                    </Tag>
                                </List.Item>
                            )}
                        />
                    </div>
                </Col>
                {activeHazards.length > 0 && (
                    <Col xs={24}>
                        <div style={{ 
                            padding: '16px', 
                            background: colors.redBg, 
                            borderRadius: 8,
                            border: `1px solid ${colors.redBorder}`
                        }}>
                            <Text strong style={{ color: colors.redText }}>⚠️ Active Hazards</Text>
                            <div style={{ marginTop: 8, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                                {activeHazards.map((hazard, index) => (
                                    <Tag key={index} color="red" icon={<AlertOutlined />}>
                                        {hazard}
                                    </Tag>
                                ))}
                            </div>
                        </div>
                    </Col>
                )}
            </Row>
        </div>
    );

    const AuditTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                <Col xs={24} sm={12}>
                    <div style={{ 
                        padding: '16px', 
                        background: colors.cardBg, 
                        borderRadius: 8,
                        border: `1px solid ${colors.cardBorder}`,
                        height: '100%'
                    }}>
                        <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                            Created By
                        </Text>
                        <div style={{ marginTop: 8 }}>
                            <Space>
                                <UserOutlined />
                                <Text strong style={{ color: colors.textPrimary }}>{material?.createdBy?.fullName || 'System'}</Text>
                            </Space>
                            {material?.createdBy?.employeeId && (
                                <Text type="secondary" style={{ display: 'block' }}>
                                    ({material.createdBy.employeeId})
                                </Text>
                            )}
                            {material?.createdBy?.designation && (
                                <Text type="secondary" style={{ display: 'block' }}>
                                    {material.createdBy.designation}
                                </Text>
                            )}
                        </div>
                    </div>
                </Col>
                <Col xs={24} sm={12}>
                    <div style={{ 
                        padding: '16px', 
                        background: colors.cardBg, 
                        borderRadius: 8,
                        border: `1px solid ${colors.cardBorder}`,
                        height: '100%'
                    }}>
                        <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                            Created Date
                        </Text>
                        <div style={{ marginTop: 8 }}>
                            <Space>
                                <CalendarOutlined />
                                <Text strong style={{ color: colors.textPrimary }}>
                                    {material?.createdAt
                                        ? dayjs(material.createdAt).format('MMM D, YYYY h:mm A')
                                        : 'N/A'}
                                </Text>
                            </Space>
                        </div>
                    </div>
                </Col>

                {material?.updatedBy && (
                    <>
                        <Col xs={24} sm={12}>
                            <div style={{ 
                                padding: '16px', 
                                background: colors.yellowBg, 
                                borderRadius: 8,
                                border: `1px solid ${colors.yellowBorder}`,
                                height: '100%'
                            }}>
                                <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                                    Updated By
                                </Text>
                                <div style={{ marginTop: 8 }}>
                                    <Space>
                                        <UserOutlined />
                                        <Text strong style={{ color: colors.textPrimary }}>{material.updatedBy.fullName || 'System'}</Text>
                                    </Space>
                                    {material.updatedBy.employeeId && (
                                        <Text type="secondary" style={{ display: 'block' }}>
                                            ({material.updatedBy.employeeId})
                                        </Text>
                                    )}
                                </div>
                            </div>
                        </Col>
                        <Col xs={24} sm={12}>
                            <div style={{ 
                                padding: '16px', 
                                background: colors.yellowBg, 
                                borderRadius: 8,
                                border: `1px solid ${colors.yellowBorder}`,
                                height: '100%'
                            }}>
                                <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                                    Updated Date
                                </Text>
                                <div style={{ marginTop: 8 }}>
                                    <Space>
                                        <CalendarOutlined />
                                        <Text strong style={{ color: colors.textPrimary }}>
                                            {material.updateAt
                                                ? dayjs(material.updateAt).format('MMM D, YYYY h:mm A')
                                                : 'N/A'}
                                        </Text>
                                    </Space>
                                </div>
                            </div>
                        </Col>
                        <Col xs={24}>
                            <div style={{ 
                                padding: '12px 16px', 
                                background: colors.yellowBg, 
                                borderRadius: 8,
                                border: `1px solid ${colors.yellowBorder}`
                            }}>
                                <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                                    Update Reason
                                </Text>
                                <Text strong style={{ display: 'block', marginTop: 4, color: colors.textPrimary }}>
                                    {material.updateReason || 'No reason provided'}
                                </Text>
                            </div>
                        </Col>
                    </>
                )}

                {material?.deletedBy && (
                    <>
                        <Col xs={24} sm={12}>
                            <div style={{ 
                                padding: '16px', 
                                background: colors.redBg, 
                                borderRadius: 8,
                                border: `1px solid ${colors.redBorder}`,
                                height: '100%'
                            }}>
                                <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                                    Deleted By
                                </Text>
                                <div style={{ marginTop: 8 }}>
                                    <Space>
                                        <UserOutlined />
                                        <Text strong style={{ color: colors.textPrimary }}>{material.deletedBy.fullName || 'System'}</Text>
                                    </Space>
                                    {material.deletedBy.employeeId && (
                                        <Text type="secondary" style={{ display: 'block' }}>
                                            ({material.deletedBy.employeeId})
                                        </Text>
                                    )}
                                </div>
                            </div>
                        </Col>
                        <Col xs={24} sm={12}>
                            <div style={{ 
                                padding: '16px', 
                                background: colors.redBg, 
                                borderRadius: 8,
                                border: `1px solid ${colors.redBorder}`,
                                height: '100%'
                            }}>
                                <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                                    Deleted Date
                                </Text>
                                <div style={{ marginTop: 8 }}>
                                    <Space>
                                        <CalendarOutlined />
                                        <Text strong style={{ color: colors.textPrimary }}>
                                            {material.deletedAt
                                                ? dayjs(material.deletedAt).format('MMM D, YYYY h:mm A')
                                                : 'N/A'}
                                        </Text>
                                    </Space>
                                </div>
                            </div>
                        </Col>
                        <Col xs={24}>
                            <div style={{ 
                                padding: '12px 16px', 
                                background: colors.redBg, 
                                borderRadius: 8,
                                border: `1px solid ${colors.redBorder}`
                            }}>
                                <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                                    Delete Reason
                                </Text>
                                <Text strong style={{ display: 'block', marginTop: 4, color: colors.textPrimary }}>
                                    {material.deleteReason || 'No reason provided'}
                                </Text>
                            </div>
                        </Col>
                    </>
                )}
            </Row>
        </div>
    );

    const tabItems = [
        {
            key: 'basic',
            label: (
                <span>
                    <DatabaseOutlined /> Basic Info
                </span>
            ),
            children: <BasicInfoTab />,
        },
        {
            key: 'storage',
            label: (
                <span>
                    <EnvironmentOutlined /> Storage
                </span>
            ),
            children: <StorageTab />,
        },
        {
            key: 'hazards',
            label: (
                <span>
                    <AlertOutlined /> Hazards
                </span>
            ),
            children: <HazardsTab />,
        },
        {
            key: 'audit',
            label: (
                <span>
                    <DashboardOutlined /> Audit Trail
                </span>
            ),
            children: <AuditTab />,
        },
    ];

    const displayMaterial = material || materialData || null;

    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            centered
            width={700}
            destroyOnHidden
            styles={{
                header: {
                    background: colors.modalHeader,
                    padding: '16px 24px',
                },
                body: { padding: 0 },
            }}
            title={
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{
                        width: 40,
                        height: 40,
                        borderRadius: 8,
                        background: 'linear-gradient(135deg, #1890ff 0%, #36cfc9 100%)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <MedicineBoxOutlined style={{ fontSize: 20, color: '#fff' }} />
                    </div>
                    <div>
                        <Title level={5} style={{ marginBottom: 0, color: '#fff' }}>
                            {displayMaterial?.materialName || 'Material Details'}
                        </Title>
                        <Text style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12 }}>
                            {displayMaterial?.shortName || 'View material information'}
                        </Text>
                    </div>
                </div>
            }
        >
            {loading || !displayMaterial ? (
                <div style={{ textAlign: 'center', padding: '60px 0' }}>
                    <Spin size="large" />
                    <div style={{ marginTop: 16 }}>
                        <Text type="secondary">Loading material details...</Text>
                    </div>
                </div>
            ) : (
                <div>
                    {/* Quick Stats Bar */}
                    <Flex gap={24} wrap style={{ 
                        padding: '12px 24px', 
                        background: colors.quickStatsBg, 
                        borderBottom: `1px solid ${colors.statsBorder}`
                    }}>
                        <Flex align="center" gap={6}>
                            <CheckCircleOutlined style={{ color: displayMaterial.status === 'Active' ? '#52c41a' : '#8c8c8c' }} />
                            <Text strong style={{ color: colors.textPrimary }}>{displayMaterial.status || 'N/A'}</Text>
                        </Flex>
                        <Flex align="center" gap={6}>
                            <ExperimentOutlined style={{ color: '#722ed1' }} />
                            <Text style={{ color: colors.textPrimary }}>{displayMaterial.category || 'N/A'}</Text>
                        </Flex>
                        <Flex align="center" gap={6}>
                            <FileTextOutlined style={{ color: '#1890ff' }} />
                            <Text style={{ color: colors.textPrimary }}>{displayMaterial.type || 'N/A'}</Text>
                        </Flex>
                    </Flex>

                    {/* Tabs Section */}
                    <div style={{ padding: '16px 24px 24px' }}>
                        <Tabs 
                            activeKey={activeTab} 
                            onChange={setActiveTab}
                            items={tabItems}
                            size="large"
                            style={{ marginBottom: 8 }}
                        />
                        
                        {/* Actions */}
                        <Flex justify="space-between" align="center" style={{ 
                            marginTop: 24, 
                            paddingTop: 16, 
                            borderTop: `1px solid ${colors.statsBorder}`
                        }}>
                            <Text type="secondary" style={{ fontSize: 12 }}>
                                Material ID: {displayMaterial._id || 'N/A'}
                            </Text>
                            <Button 
                                onClick={onClose} 
                                icon={<CloseOutlined />}
                                type="primary"
                            >
                                Close
                            </Button>
                        </Flex>
                    </div>
                </div>
            )}
        </Modal>
    );
}
