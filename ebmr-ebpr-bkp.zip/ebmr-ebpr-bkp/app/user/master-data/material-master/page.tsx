'use client';

import { Card, Typography, Button, Table, Tag, Space, Input, message, Tooltip, Select, Row, Col } from "antd";
import {
  MedicineBoxOutlined,
  SearchOutlined,
  EditOutlined,
  EyeOutlined,
  ReloadOutlined,
  PlusOutlined,
  FilterOutlined,
  ClearOutlined,
  DeleteOutlined
} from "@ant-design/icons";
import { useEffect, useState } from "react";
import AddNewMaterial from "./components/Add-New-Material";
import ViewMaterials from "./components/View-Materials";
import { useAuthorization } from "@/hooks/useAuthorization";

const { Title, Text } = Typography;
const { Search } = Input;

export default function MaterialMasterPage() {

  const [materials, setMaterials] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [total, setTotal] = useState(0);
  const [searchText, setSearchText] = useState("");

  // Filter states
  const [categoryFilter, setCategoryFilter] = useState<string>("");
  const [typeFilter, setTypeFilter] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [storageFilter, setStorageFilter] = useState<string>("");
  const [filterVisible, setFilterVisible] = useState(false);

  const [addMaterialModalOpen, setAddMaterialModalOpen] = useState(false);

  // View Modal State
  const [viewModalOpen, setViewModalOpen] = useState(false);
  const [selectedMaterial, setSelectedMaterial] = useState<any>(null);

  const { hasAccess } = useAuthorization();
  const isCreateMaterialAuthorized = hasAccess('Material Master', 'create');

  // View Handler
  const handleView = (record: any) => {
    setSelectedMaterial(record);
    setViewModalOpen(true);
  };

  // Delete Handler
  // const handleDelete = async (id: string) => {
  //   try {
  //     setLoading(true);
  //     const res = await fetch(`/api/user/master-data/material-master/?id=${id}`, {
  //       method: 'DELETE',
  //       headers: {
  //         'Content-Type': 'application/json',
  //         'Authorization': `Bearer ${localStorage.getItem('token')}`
  //       },
  //     });
  //     const data = await res.json();

  //     if (data.success) {
  //       message.success(`Material ${data.material.materialCode} deleted successfully!`);
  //       fetchMaterials(page, pageSize, searchText, categoryFilter, typeFilter, statusFilter, storageFilter);
  //     } else {
  //       message.error(data.message);
  //     }
  //   } catch (error) {
  //     console.error(error);
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  useEffect(() => {
    fetchMaterials(page, pageSize, searchText, categoryFilter, typeFilter, statusFilter, storageFilter);
  }, [page, pageSize, searchText, categoryFilter, typeFilter, statusFilter, storageFilter]);

  const fetchMaterials = async (
    page: number,
    limit: number,
    search: string,
    category: string = "",
    type: string = "",
    status: string = "",
    storage: string = ""
  ) => {
    try {
      setLoading(true);

      let url = `/api/user/master-data/material-master?page=${page}&limit=${limit}&search=${search}`;

      if (category) url += `&category=${category}`;
      if (type) url += `&type=${type}`;
      if (status) url += `&status=${status}`;
      if (storage) url += `&storageCondition=${storage}`;

      const res = await fetch(url);

      const data = await res.json();

      if (data.success) {
        setMaterials(data.materials);
        setTotal(data.total);
      } else {
        message.error(data.message);
      }

    } catch (error) {
      message.error("Error fetching materials");
    } finally {
      setLoading(false);
    }
  };

  const clearFilters = () => {
    setCategoryFilter("");
    setTypeFilter("");
    setStatusFilter("");
    setStorageFilter("");
    setSearchText("");
    setPage(1);
  };

  const hasActiveFilters = () => {
    return categoryFilter || typeFilter || statusFilter || storageFilter || searchText;
  };

  const columns = [
    {
      title: "SNo",
      width: 80,
      align: "center" as const,
      render: (_: any, __: any, index: number) =>
        (page - 1) * pageSize + index + 1
    },
    {
      title: "Material Code",
      dataIndex: "materialCode",
      width: 160,
      sorter: true, // server side sorting ready
      render: (text: string) => (
        <Text copyable style={{ color: "#1677ff" }}>
          {text}
        </Text>
      )
    },
    {
      title: "Description",
      dataIndex: "description",
      ellipsis: {
        showTitle: false,
      },
      render: (text: string) => (
        <Tooltip placement="topLeft" title={text}>
          {text}
        </Tooltip>
      )
    },
    {
      title: "Category",
      dataIndex: "category",
      width: 170,
      align: "center" as const,
      render: (value: string) => {
        const colorMap: any = {
          "Raw Material": "blue",
          "Packaging Material": "green"
        };

        return (
          <Tag variant="outlined" color={colorMap[value] || "default"}>
            {value}
          </Tag>
        );
      }
    },
    {
      title: "Type",
      dataIndex: "type",
      width: 130,
      align: "center" as const,
      render: (value: string) => {
        const colorMap: any = {
          Active: "red",
          Excipient: "orange",
          Primary: "purple",
          Secondary: "cyan",
          Tertiary: "volcano"
        };

        return (
          <Tag variant="outlined" color={colorMap[value] || "default"}>
            {value}
          </Tag>
        );
      }
    },
    {
      title: "Status",
      dataIndex: "status",
      width: 140,
      align: "center" as const,
      sorter: true,
      render: (value: string) => (
        <Tag
        variant="outlined"
          color={value === "Active" ? "success" : "default"}
          style={{ fontWeight: 500 }}
        >
          {value === "Active" ? "● Active" : "● Inactive"}
        </Tag>
      )
    },
    {
      title: "Created Date",
      dataIndex: "createdAt",
      width: 180,
      sorter: true,
      render: (date: string) =>
        new Date(date).toLocaleDateString("en-GB")
    },
    {
      title: "Actions",
      width: 140,
      align: "center" as const,
      render: (_: any, record: any) => (
        <Space size="small">
          <Tooltip title="View">
            <Button
              type="text"
              icon={<EyeOutlined />}
              onClick={() => handleView(record)}
            />
          </Tooltip>

          {/* <Tooltip title="Edit">
            <Button
              type="text"
              icon={<DeleteOutlined />}
              onClick={() => handleDelete(record._id)}
            />
          </Tooltip> */}
        </Space>
      )
    }
  ];
  return (
    <div>

      <Title level={2}>
        <MedicineBoxOutlined /> Material Master
      </Title>

      <Card>

        {/* Search and Filter Header */}
        <Row gutter={[16, 16]} style={{ marginBottom: 16 }} justify="space-between">


          <Col xs={24} sm={24} md={8}>
            <Search
              placeholder="Search by code, name, description..."
              allowClear
              onSearch={(value) => {
                setPage(1);
                setSearchText(value);
              }}
              style={{ width: '100%' }}
              prefix={<SearchOutlined />}
            />
          </Col>

          <Col xs={24} sm={24} md={16}>
            <Space wrap style={{ width: '100%', justifyContent: 'flex-end' }}>
              <Tooltip title="Advanced Filters">
                <Button
                  type={filterVisible ? "primary" : "default"}
                  icon={<FilterOutlined />}
                  onClick={() => setFilterVisible(!filterVisible)}
                >
                  Filters {hasActiveFilters() && `(${[categoryFilter, typeFilter, statusFilter, storageFilter, searchText].filter(Boolean).length})`}
                </Button>
              </Tooltip>

              {hasActiveFilters() && (
                <Tooltip title="Clear All Filters">
                  <Button
                    icon={<ClearOutlined />}
                    onClick={clearFilters}
                    danger
                  >
                    Clear
                  </Button>
                </Tooltip>
              )}

              <Tooltip title="Refresh">
                <Button
                  icon={<ReloadOutlined />}
                  onClick={() => fetchMaterials(page, pageSize, searchText, categoryFilter, typeFilter, statusFilter, storageFilter)}
                />
              </Tooltip>

              <Button
                type="primary"
                disabled={!isCreateMaterialAuthorized}
                icon={<PlusOutlined />}
                onClick={() => setAddMaterialModalOpen(true)}
              >
                Add Material
              </Button>
            </Space>
          </Col>
        </Row>

        {/* Advanced Filters Panel */}
        {filterVisible && (
          <div style={{ marginBottom: 16, padding: 16, background: '#f5f5f5', borderRadius: 8 }}>
            <Row gutter={[16, 16]}>
              <Col xs={24} sm={12} md={6}>
                <label style={{ display: 'block', marginBottom: 4, fontWeight: 500 }}>Category</label>
                <Select
                  placeholder="Select Category"
                  style={{ width: '100%' }}
                  allowClear
                  value={categoryFilter || undefined}
                  onChange={(value) => { setPage(1); setCategoryFilter(value || ""); }}
                  options={[
                    { value: 'Raw Material', label: 'Raw Material' },
                    { value: 'Packaging Material', label: 'Packaging Material' }
                  ]}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <label style={{ display: 'block', marginBottom: 4, fontWeight: 500 }}>Type</label>
                <Select
                  placeholder="Select Type"
                  style={{ width: '100%' }}
                  allowClear
                  value={typeFilter || undefined}
                  onChange={(value) => { setPage(1); setTypeFilter(value || ""); }}
                  options={[
                    { value: 'Active', label: 'Active' },
                    { value: 'Excipient', label: 'Excipient' },
                    { value: 'Primary', label: 'Primary' },
                    { value: 'Secondary', label: 'Secondary' },
                    { value: 'Tertiary', label: 'Tertiary' }
                  ]}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <label style={{ display: 'block', marginBottom: 4, fontWeight: 500 }}>Status</label>
                <Select
                  placeholder="Select Status"
                  style={{ width: '100%' }}
                  allowClear
                  value={statusFilter || undefined}
                  onChange={(value) => { setPage(1); setStatusFilter(value || ""); }}
                  options={[
                    { value: 'Active', label: 'Active' },
                    { value: 'Inactive', label: 'Inactive' }
                  ]}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <label style={{ display: 'block', marginBottom: 4, fontWeight: 500 }}>Storage Condition</label>
                <Select
                  placeholder="Select Storage"
                  style={{ width: '100%' }}
                  allowClear
                  value={storageFilter || undefined}
                  onChange={(value) => { setPage(1); setStorageFilter(value || ""); }}
                  options={[
                    { value: 'Ambient (15-25°C)', label: 'Ambient (15-25°C)' },
                    { value: 'Controlled Room Temp (20-25°C)', label: 'Controlled Room Temp (20-25°C)' },
                    { value: 'Refrigerated (2-8°C)', label: 'Refrigerated (2-8°C)' },
                    { value: 'Frozen (-20°C)', label: 'Frozen (-20°C)' },
                    { value: 'Deep Frozen (-40°C or below)', label: 'Deep Frozen (-40°C or below)' },
                    { value: 'Cold Chain (2–8°C with monitoring)', label: 'Cold Chain (2–8°C with monitoring)' },
                    { value: 'Desiccated', label: 'Desiccated' },
                    { value: 'Protect From Light', label: 'Protect From Light' },
                    { value: 'Protect From Moisture', label: 'Protect From Moisture' },
                    { value: 'Nitrogen Flushed', label: 'Nitrogen Flushed' },
                    { value: 'Flammable  Cabinet Required', label: 'Flammable Cabinet Required' },
                    { value: 'Hazardous / Controlled Storage', label: 'Hazardous / Controlled Storage' },
                    { value: 'Quarantine Storage', label: 'Quarantine Storage' },
                    { value: 'Controlled Substance Vault', label: 'Controlled Substance Vault' }
                  ]}
                />
              </Col>
            </Row>
          </div>
        )}

        {/* Active Filters Display */}
        {hasActiveFilters() && (
          <div style={{ marginBottom: 16 }}>
            <Space wrap>
              <Text type="secondary">Active Filters:</Text>
              {searchText && <Tag variant="outlined" closable onClose={() => { setSearchText(""); setPage(1); }}>Search: {searchText}</Tag>}
              {categoryFilter && <Tag variant="outlined" closable onClose={() => { setCategoryFilter(""); setPage(1); }}>Category: {categoryFilter}</Tag>}
              {typeFilter && <Tag variant="outlined" closable onClose={() => { setTypeFilter(""); setPage(1); }}>Type: {typeFilter}</Tag>}
              {statusFilter && <Tag variant="outlined" closable onClose={() => { setStatusFilter(""); setPage(1); }}>Status: {statusFilter}</Tag>}
              {storageFilter && <Tag variant="outlined" closable onClose={() => { setStorageFilter(""); setPage(1); }}>Storage: {storageFilter}</Tag>}
            </Space>
          </div>
        )}

        <Table
          rowKey="_id"
          columns={columns}
          dataSource={materials}
          loading={loading}
          pagination={{
            current: page,
            pageSize: pageSize,
            total: total,
            showSizeChanger: true,
            showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} items`
          }}
          onChange={(pagination) => {
            setPage(pagination.current!);
            setPageSize(pagination.pageSize!);
          }}
        />

        <AddNewMaterial
          open={addMaterialModalOpen}
          onClose={() => setAddMaterialModalOpen(false)}
          onSuccess={() => fetchMaterials(page, pageSize, searchText, categoryFilter, typeFilter, statusFilter, storageFilter)}
        />

        <ViewMaterials
          open={viewModalOpen}
          onClose={() => setViewModalOpen(false)}
          materialData={selectedMaterial}
        />

      </Card>
    </div>
  );
}
