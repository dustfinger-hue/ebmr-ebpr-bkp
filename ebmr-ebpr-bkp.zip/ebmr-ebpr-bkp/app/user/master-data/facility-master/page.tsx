'use client';

import { Button, Card, Col, message, Row, Select, Space, Table, Tag, Tooltip, Typography } from "antd";
import { useEffect, useState } from "react";
import { SettingOutlined } from "@ant-design/icons";
const { Title, Text } = Typography;
import {
  SearchOutlined,
  ReloadOutlined,
  PlusOutlined,
  FilterOutlined,
  ClearOutlined,
  DeleteTwoTone,
  EditTwoTone,
  EyeTwoTone
} from "@ant-design/icons";

import { useAuthorization } from "@/hooks/useAuthorization";
import Search from "antd/es/input/Search";
import { DEPARTMENTS } from "@/lib/constants/Department";
import AddNewFacility from "./components/Add-New-Facility";
import DeleteFacility from "./components/Delete-Facility";
import EditFacility from "./components/Edit-Facility";
import VeiwFacility from "./components/Veiw-Facility";
import { Area_Types, Block_Options, Status_Options } from "@/lib/constants/Generarl";

export default function FacilityMasterPage() {

  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });
  const [addFacilityModal, setAddFacilityModal] = useState(false);
  const [viewFacilityModal, setViewFacilityModal] = useState(false);
  const [editFacilityModal, setEditFacilityModal] = useState(false);
  const [deleteFacilityModal, setDeleteFacilityModal] = useState(false);
  const [selectedFacilityId, setSelectedFacilityId] = useState<string | null>(null);
  const [selectedFacilityForDelete, setSelectedFacilityForDelete] = useState<any>(null);
  const [facilities, setFacilities] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // Filter states
  const [searchText, setSearchText] = useState("");
  const [areaTypeFilter, setAreaTypeFilter] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [departmentFilter, setDepartmentFilter] = useState<string>("");
  const [blockFilter, setBlockFilter] = useState<string>("");
  const [filterVisible, setFilterVisible] = useState(false);

  useEffect(() => {
    getFacilities(pagination.current, pagination.pageSize, searchText, areaTypeFilter, statusFilter, departmentFilter, blockFilter);
  }, [pagination.current, pagination.pageSize, searchText, areaTypeFilter, statusFilter, departmentFilter, blockFilter]);

  useEffect(() => {
    setPagination(prev => ({ ...prev, current: 1 }));
  }, [searchText, areaTypeFilter, statusFilter, departmentFilter, blockFilter]);

  const getFacilities = async (
    page: number,
    limit: number,
    search: string,
    areaType: string,
    status: string,
    department: string,
    block: string
  ) => {
    try {
      setLoading(true);
      let url = `/api/user/master-data/facility-master?page=${page}&limit=${limit}&search=${search}`;

      if (areaType) url += `&areaType=${areaType}`;
      if (status) url += `&status=${status}`;
      if (department) url += `&department=${department}`;
      if (block) url += `&blockBuilding=${block}`;

      const response = await fetch(url);
      const data = await response.json();

      if (data.success) {
        setFacilities(data.facilities);
        setPagination(prev => ({
          ...prev,
          total: data.total,
        }));
      } else {
        message.error(data.message);
      }
    } catch (error) {
      console.error(error);
      message.error("Error fetching facilities");
    } finally {
      setLoading(false);
    }
  };

  const clearFilters = () => {
    setSearchText("");
    setAreaTypeFilter("");
    setStatusFilter("");
    setDepartmentFilter("");
    setBlockFilter("");
    setPagination(prev => ({ ...prev, current: 1 }));
  };

  const hasActiveFilters = () => {
    return areaTypeFilter || statusFilter || departmentFilter || blockFilter || searchText;
  };

  const handleEdit = (record: any) => {
    setSelectedFacilityId(record._id);
    setEditFacilityModal(true);
  };

  const handleView = (record: any) => {
    setSelectedFacilityId(record._id);
    setViewFacilityModal(true);
  };

  const handleDeleteClick = (record: any) => {
    setSelectedFacilityForDelete(record);
    setDeleteFacilityModal(true);
  };

  const handleDeleteSuccess = () => {
    getFacilities(pagination.current, pagination.pageSize, searchText, areaTypeFilter, statusFilter, departmentFilter, blockFilter);
    setSelectedFacilityForDelete(null);
    setDeleteFacilityModal(false);
  };

  const handleEditSuccess = () => {
    getFacilities(pagination.current, pagination.pageSize, searchText, areaTypeFilter, statusFilter, departmentFilter, blockFilter);
    setSelectedFacilityId(null);
  };

  // Authorization check
  const { hasAccess } = useAuthorization();
  const isCreateFacilityAuthorized = hasAccess('Facility Master', 'create');
  const isUpdateFacilityAuthorized = hasAccess('Facility Master', 'update');
  const isDeleteFacilityAuthorized = hasAccess('Facility Master', 'delete');

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      'Active': 'green',
      'Inactive': 'default',
      'Under Maintenance': 'orange',
      'Decommissioned': 'red',
    };
    return colors[status] || 'blue';
  };

  const getGradeColor = (grade: string) => {
    const colors: Record<string, string> = {
      'A': 'green',
      'B': 'blue',
      'C': 'orange',
      'D': 'red',
      'Non Classified': 'default',
    };
    return colors[grade] || 'default';
  };

  const columns = [
    {
      title: 'S.No',
      width: 80,
      fixed: 'left' as const,
      render: (_: any, __: any, index: number) =>
        (pagination.current - 1) * pagination.pageSize + index + 1
    },
    {
      title: 'Facility Code',
      dataIndex: 'facilityCode',
      key: 'facilityCode',
      width: 140,
      render: (text: string) => (
        <Text copyable style={{ color: '#1677ff', fontWeight: 500 }}>
          {text}
        </Text>
      ),
    },
    {
      title: 'Area Name',
      dataIndex: 'areaName',
      key: 'areaName',
      width: 180,
      ellipsis: true,
      render: (_: any, record: any) => (
        <div style={{ lineHeight: 1.3 }}>
          <div>
            <Text strong>{record.areaName}</Text>
          </div>
          <div>
            <Text type="secondary" style={{ fontSize: 12 }}>
              {record.areaType || 'N/A'}
            </Text>
          </div>
        </div>
      )
    },
    {
      title: 'Block / Building',
      dataIndex: 'blockBuilding',
      key: 'blockBuilding',
      width: 160,
      render: (text: string) => <Tag>{text}</Tag>,
    },
    {
      title: 'Floor',
      dataIndex: 'floor',
      key: 'floor',
      width: 120,
    },
    {
      title: 'Department',
      dataIndex: 'department',
      key: 'department',
      width: 140,
      render: (text: string) => <Text type="secondary">{text || '-'}</Text>,
    },
    {
      title: 'Clean Room Grade',
      dataIndex: 'cleanRoomGrade',
      key: 'cleanRoomGrade',
      width: 140,
      render: (text: string) => (
        text ? <Tag color={getGradeColor(text)}>{text}</Tag> : <Text type="secondary">-</Text>
      ),
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      width: 140,
      render: (status: string) => (
        <Tag color={getStatusColor(status)}>{status}</Tag>
      ),
    },
    {
      title: 'Action',
      width: 120,
      fixed: "right" as const,
      render: (record: any) => {
        return (
          <div style={{ display: 'flex', flexDirection: 'row', gap: 4 }}>
            <Button
              icon={<EyeTwoTone twoToneColor="green" />}
              size="small"
              variant="outlined"
              color="green"
              onClick={() => handleView(record)}
            />
            <Tooltip title={isUpdateFacilityAuthorized ? "" : "You are not authorized to perform this action."}>
              <Button
                icon={<EditTwoTone />}
                size="small"
                variant="outlined"
                color="primary"
                disabled={!isUpdateFacilityAuthorized}
                onClick={() => handleEdit(record)}
              />
            </Tooltip>
            <Tooltip title={isDeleteFacilityAuthorized ? "" : "You are not authorized to perform this action."}>
              <Button
                icon={<DeleteTwoTone twoToneColor="red" />}
                size="small"
                variant="outlined"
                color="danger"
                onClick={() => handleDeleteClick(record)}
                disabled={!isDeleteFacilityAuthorized}
              />
            </Tooltip>
          </div>
        )
      }
    }
  ];

  return (
    <div>
      <Title level={2}>
        <SettingOutlined style={{ marginRight: 12, color: "#1890ff" }} />
        Facility Master
      </Title>
      <Card>

        <Row gutter={[16, 16]} style={{ marginBottom: 16 }} justify="space-between">

          <Col xs={24} md={10}>
            <Search
              placeholder="Search by facility code, area name..."
              allowClear
              onSearch={(value) => {
                setPagination(prev => ({
                  ...prev,
                  current: 1,
                }));
                setSearchText(value);
              }}
              style={{ width: '100%' }}
              prefix={<SearchOutlined />}
            />
          </Col>
          <Col xs={24} md={14} style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <Space wrap>
              <Tooltip title="Advanced Filters">
                <Button
                  type={filterVisible ? "primary" : "default"}
                  icon={<FilterOutlined />}
                  onClick={() => setFilterVisible(!filterVisible)}
                >
                  Filters {hasActiveFilters() && `(${[areaTypeFilter, statusFilter, departmentFilter, blockFilter, searchText].filter(Boolean).length})`}
                </Button>
              </Tooltip>

              {hasActiveFilters() && (
                <Tooltip title="Clear All Filters">
                  <Button
                    icon={<ClearOutlined />}
                    onClick={clearFilters}
                    danger
                  >
                    Clear
                  </Button>
                </Tooltip>
              )}
              <Tooltip title="Refresh">
                <Button
                  onClick={() => getFacilities(pagination.current, pagination.pageSize, searchText, areaTypeFilter, statusFilter, departmentFilter, blockFilter)}
                  icon={<ReloadOutlined />}
                />
              </Tooltip>
              <Tooltip title={isCreateFacilityAuthorized ? "" : "You are not authorized to perform this action."}>
                <Button
                  type="primary"
                  onClick={() => setAddFacilityModal(true)}
                  icon={<PlusOutlined />}
                  disabled={!isCreateFacilityAuthorized}
                >
                  Add Facility
                </Button>
              </Tooltip>
            </Space>

          </Col>
        </Row>

        {/* Advanced Filters Panel */}
        {filterVisible && (
          <div style={{ marginBottom: 16, padding: 16, background: '#f5f5f5', borderRadius: 8 }}>
            <Row gutter={[16, 16]}>
              <Col xs={24} sm={12} md={6}>
                <label style={{ display: 'block', marginBottom: 4, fontWeight: 500 }}>Area Type</label>
                <Select
                  placeholder="Select Area Type"
                  style={{ width: '100%' }}
                  allowClear
                  value={areaTypeFilter || undefined}
                  onChange={(value) => { setPagination(prev => ({ ...prev, current: 1 })); setAreaTypeFilter(value || ""); }}
                  options={Area_Types}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <label style={{ display: 'block', marginBottom: 4, fontWeight: 500 }}>Status</label>
                <Select
                  placeholder="Select Status"
                  style={{ width: '100%' }}
                  allowClear
                  value={statusFilter || undefined}
                  onChange={(value) => { setPagination(prev => ({ ...prev, current: 1 })); setStatusFilter(value || ""); }}
                  options={Status_Options}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <label style={{ display: 'block', marginBottom: 4, fontWeight: 500 }}>Department</label>
                <Select
                  placeholder="Select Department"
                  style={{ width: '100%' }}
                  allowClear
                  value={departmentFilter || undefined}
                  onChange={(value) => { setPagination(prev => ({ ...prev, current: 1 })); setDepartmentFilter(value || ""); }}
                  options={DEPARTMENTS}
                />
              </Col>
              <Col xs={24} sm={12} md={6}>
                <label style={{ display: 'block', marginBottom: 4, fontWeight: 500 }}>Block / Building</label>
                <Select
                  placeholder="Select Block"
                  style={{ width: '100%' }}
                  allowClear
                  value={blockFilter || undefined}
                  onChange={(value) => { setPagination(prev => ({ ...prev, current: 1 })); setBlockFilter(value || ""); }}
                  options={Block_Options}
                />
              </Col>
            </Row>
          </div>
        )}

        {/* Active Filters Display */}
        {hasActiveFilters() && (
          <div style={{ marginBottom: 16 }}>
            <Space wrap>
              <Text type="secondary">Active Filters:</Text>
              {searchText && <Tag variant="outlined" closable onClose={() => { setSearchText(""); setPagination(prev => ({ ...prev, current: 1 })); }}>Search: {searchText}</Tag>}
              {statusFilter && <Tag variant="outlined" closable onClose={() => { setStatusFilter(""); setPagination(prev => ({ ...prev, current: 1 })); }}>Status: {statusFilter}</Tag>}
              {areaTypeFilter && <Tag variant="outlined" closable onClose={() => { setAreaTypeFilter(""); setPagination(prev => ({ ...prev, current: 1 })); }}>Area Type: {areaTypeFilter}</Tag>}
              {departmentFilter && <Tag variant="outlined" closable onClose={() => { setDepartmentFilter(""); setPagination(prev => ({ ...prev, current: 1 })); }}>Department: {departmentFilter}</Tag>}
              {blockFilter && <Tag variant="outlined" closable onClose={() => { setBlockFilter(""); setPagination(prev => ({ ...prev, current: 1 })); }}>Block: {blockFilter}</Tag>}
            </Space>
          </div>
        )}

        <Table
          columns={columns}
          dataSource={facilities}
          loading={loading}
          scroll={{ x: 'max-content' }}
          pagination={{
            current: pagination.current,
            pageSize: pagination.pageSize,
            total: pagination.total,
            showSizeChanger: true,
            pageSizeOptions: ['10', '20', '30', '40', '50'],
            onChange: (page: number, pageSize: number) => {
              setPagination(prev => ({
                ...prev,
                current: page,
                pageSize: pageSize,
              }));
            },
          }}
        />
      </Card>

      {/* Modals */}
      <AddNewFacility
        open={addFacilityModal}
        onClose={() => setAddFacilityModal(false)}
        onSuccess={() => {
          getFacilities(pagination.current, pagination.pageSize, searchText, areaTypeFilter, statusFilter, departmentFilter, blockFilter);
        }}
      />

      <VeiwFacility
        open={viewFacilityModal}
        onClose={() => {
          setViewFacilityModal(false);
          setSelectedFacilityId(null);
        }}
        facilityId={selectedFacilityId || undefined}
        onEdit={() => {
          setViewFacilityModal(false);
          setEditFacilityModal(true);
        }}
      />

      <EditFacility
        open={editFacilityModal}
        onClose={() => {
          setEditFacilityModal(false);
          setSelectedFacilityId(null);
        }}
        facility={{ _id: selectedFacilityId }}
        onSuccess={handleEditSuccess}
      />

      <DeleteFacility
        open={deleteFacilityModal}
        onClose={() => {
          setDeleteFacilityModal(false);
          setSelectedFacilityForDelete(null);
        }}
        facility={selectedFacilityForDelete}
        onSuccess={handleDeleteSuccess}
      />
    </div>
  );
}
