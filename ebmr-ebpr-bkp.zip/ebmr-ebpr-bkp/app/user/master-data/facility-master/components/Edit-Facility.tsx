'use client';

import {
    Area_Types,
    Status_Options,
    Block_Options,
    CleanRoom_Grades,
    Qualification_Statuses,
    Sanitization_Options,
    Flow_Directions,
    Floor_Options
} from "@/lib/constants/Generarl";
import { DEPARTMENTS } from "@/lib/constants/Department";
import {
    Modal,
    Form,
    Input,
    Select,
    InputNumber,
    Row,
    Col,
    Button,
    Typography,
    message,
    Tabs,
    Space,
    Switch,
    Card,
    Checkbox,
    Pagination
} from "antd";
import {
    DatabaseOutlined,
    EnvironmentOutlined,
    ExperimentOutlined,
    SettingOutlined,
    ToolOutlined,
    InfoCircleOutlined,
    PlusOutlined,
    CloseOutlined,
    EditOutlined,
} from "@ant-design/icons";
import { useEffect, useState } from "react";

const { TextArea } = Input;
const { Title, Text } = Typography;

interface EditFacilityProps {
    open: boolean;
    onClose: () => void;
    facility: any;
    onSuccess?: () => void;
}

export default function EditFacility({
    open,
    onClose,
    facility,
    onSuccess,
}: EditFacilityProps) {
    const [loading, setLoading] = useState(false);
    const [form] = Form.useForm();
    const [activeTab, setActiveTab] = useState('basic');
    const [equipmentFetchModalVisible, setEquipmentFetchModalVisible] = useState(false);

    useEffect(() => {
        if (open && facility) {
            fetchFacility()
            form.resetFields();
            setActiveTab('basic');
        }
    }, [open, facility, form]);

    const fetchFacility = async () => {
        try {
            setLoading(true);
            const res = await fetch(`/api/user/master-data/facility-master?facilityId=${facility._id}`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            const data = await res.json();
            if (data.success) {
                const facilityData = data.facilities[0];

                form.setFieldsValue({
                    ...facilityData,
                    qualificationDate: facilityData.qualificationDate
                        ? new Date(facilityData.qualificationDate).toISOString().split('T')[0]
                        : null,
                });

            } else {
                message.error(data.message);
            }
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async () => {
        const values = await form.validateFields().catch((error) => {
            if (error.errorFields && error.errorFields.length > 0) {
                const fieldLabels: Record<string, string> = {
                    areaName: 'Area Name',
                    blockBuilding: 'Block / Building',
                    floor: 'Floor',
                    department: 'Department',
                    areaType: 'Area Type',
                    status: 'Status',
                };

                const missingFields = error.errorFields.map((err: any) => {
                    const fieldName = err.name[0];
                    return fieldLabels[fieldName] || fieldName;
                });

                message.error(`Please fill required fields: ${missingFields.join(', ')}`);
            }
            return null;
        });

        if (!values) return;

        try {
            setLoading(true);
            const token = localStorage.getItem('token');
            const res = await fetch('/api/user/master-data/facility-master', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    _id: facility._id,
                    ...values,
                    updateReason: values.updateReason || 'Updated facility',
                })
            });

            const data = await res.json();

            if (data.success) {
                message.success(data.message);
                form.resetFields();
                onClose();
                if (onSuccess) onSuccess();
            } else {
                message.error(data.message);
            }

        } catch (error) {
            console.error(error);
            message.error("Failed to update facility");
        } finally {
            setLoading(false);
        }
    };

    // Tab Contents
    const BasicInfoTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24} sm={12} md={8}>
                    <Form.Item
                        name="areaName"
                        label="Area Name"
                        rules={[{ required: true, message: "Enter area name" }]}
                    >
                        <Input placeholder="Enter area name" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item
                        name="blockBuilding"
                        label="Block / Building"
                        rules={[{ required: true, message: "Select block" }]}
                    >
                        <Select placeholder="Select block" options={Block_Options} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item
                        name="floor"
                        label="Floor"
                        rules={[{ required: true, message: "Select floor" }]}
                    >
                        <Select placeholder="Select floor" options={Floor_Options} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item
                        name="department"
                        label="Department"
                        rules={[{ required: true, message: "Select department" }]}
                    >
                        <Select placeholder="Select department" options={DEPARTMENTS} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item
                        name="areaType"
                        label="Area Type"
                        rules={[{ required: true, message: "Select area type" }]}
                    >
                        <Select placeholder="Select area type" options={Area_Types} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item
                        name="status"
                        label="Status"
                        rules={[{ required: true, message: "Select status" }]}
                    >
                        <Select placeholder="Select status" options={Status_Options} />
                    </Form.Item>
                </Col>

                <Col xs={24}>
                    <Form.Item name="description" label="Description">
                        <TextArea rows={2} placeholder="Enter description" />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const GmpClassificationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="cleanRoomGrade" label="Clean Room Grade">
                        <Select placeholder="Select grade" options={CleanRoom_Grades} allowClear />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="hvacZone" label="HVAC Zone">
                        <Input placeholder="e.g., AHU-03" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="differentialPressure" label="Diff. Pressure Target (Pa)">
                        <InputNumber style={{ width: '100%' }} placeholder="15" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="differentialPressureMin" label="Diff. Pressure Min (Pa)">
                        <InputNumber style={{ width: '100%' }} placeholder="10" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="differentialPressureMax" label="Diff. Pressure Max (Pa)">
                        <InputNumber style={{ width: '100%' }} placeholder="15" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="temperatureMin" label="Temp Min (°C)">
                        <InputNumber style={{ width: '100%' }} placeholder="20" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="temperatureMax" label="Temp Max (°C)">
                        <InputNumber style={{ width: '100%' }} placeholder="25" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="humidityMin" label="Humidity Min (%)">
                        <InputNumber style={{ width: '100%' }} placeholder="40" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="humidityMax" label="Humidity Max (%)">
                        <InputNumber style={{ width: '100%' }} placeholder="60" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="particulatesMax" label="Particulates Max (CFU/m³)">
                        <InputNumber style={{ width: '100%' }} min={0} placeholder="350" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="luxLevelMin" label="LUX Min">
                        <InputNumber style={{ width: '100%' }} min={0} placeholder="300" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="luxLevelMax" label="LUX Max">
                        <InputNumber style={{ width: '100%' }} min={0} placeholder="700" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="airChangesPerHour" label="Air Changes/Hour">
                        <InputNumber style={{ width: '100%' }} placeholder="20" />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const CapacityTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="areaSize" label="Area Size">
                        <InputNumber style={{ width: '100%' }} placeholder="1000" />
                    </Form.Item>
                </Col>
                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="equipment" label="Equipments">
                        <Input
                            readOnly
                            placeholder="Click to select equipment"
                            onClick={() => setEquipmentFetchModalVisible(true)}
                            suffix={
                                <Button
                                    type="text"
                                    size="small"
                                    icon={<PlusOutlined />}
                                    onClick={(e) => {
                                        e.stopPropagation(); // Prevent Input onClick
                                        setEquipmentFetchModalVisible(true);
                                    }}
                                />
                            }
                        />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="maxEquipmentAllowed" label="Max Equipment">
                        <InputNumber style={{ width: '100%' }} placeholder="10" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="maxOperatorsAllowed" label="Max Operators">
                        <InputNumber style={{ width: '100%' }} placeholder="5" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="materialFlowDirection" label="Material Flow">
                        <Select placeholder="Select" options={Flow_Directions} allowClear />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="personnelFlow" label="Personnel Flow">
                        <Select placeholder="Select" options={[
                            { label: 'Unidirectional', value: 'Unidirectional' },
                            { label: 'Bidirectional', value: 'Bidirectional' },
                        ]} allowClear />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const QualificationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24}>
                    <Form.Item name="qualificationRequired" label="Qualification Required" valuePropName="checked">
                        <Switch />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="qualificationStatus" label="Qualification Status">
                        <Select placeholder="Select" options={Qualification_Statuses} allowClear />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="qualificationDate" label="Qualification Date">
                        <Input type="date" style={{ width: '100%' }} />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="requalificationFrequency" label="Requalification Frequency (Months)">
                        <InputNumber style={{ width: '100%' }} placeholder="12" />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const MonitoringTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24}>
                    <Form.Item name="environmentalMonitoringRequired" label="Environmental Monitoring Required" valuePropName="checked">
                        <Switch />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="environmentalReference" label="Environmental Reference">
                        <Input placeholder="e.g., SOP-ENV-001 / ISO 14644" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="environmentalReferenceVersion" label="Reference Version">
                        <Input placeholder="e.g., v1.0" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="cleaningSopNumber" label="Cleaning SOP Number">
                        <Input placeholder="e.g., SOP-CLN-001" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="sanitizationFrequency" label="Sanitization Frequency">
                        <Select placeholder="Select" options={Sanitization_Options} allowClear />
                    </Form.Item>
                </Col>

                <Col xs={24}>
                    <Form.Item name="pestControlRequired" label="Pest Control Required" valuePropName="checked">
                        <Switch />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const DocumentationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 0]}>
                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="layoutDocument" label="Layout Document">
                        <Input placeholder="Document ID" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="riskAssessmentId" label="Risk Assessment ID">
                        <Input placeholder="RA-001" />
                    </Form.Item>
                </Col>

                <Col xs={24} sm={12} md={8}>
                    <Form.Item name="validationProtocol" label="Validation Protocol">
                        <Input placeholder="VP-001" />
                    </Form.Item>
                </Col>

                <Col xs={24}>
                    <Form.Item name="remarks" label="Remarks">
                        <TextArea rows={3} placeholder="Additional remarks" />
                    </Form.Item>
                </Col>

                <Col xs={24}>
                    <Form.Item name="updateReason" label="Update Reason">
                        <TextArea rows={2} placeholder="Reason for update" />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );

    const tabItems = [
        {
            key: 'basic',
            label: <span><DatabaseOutlined /> Basic Info</span>,
            children: <BasicInfoTab />,
        },
        {
            key: 'gmp',
            label: <span><EnvironmentOutlined /> GMP Classification</span>,
            children: <GmpClassificationTab />,
        },
        {
            key: 'capacity',
            label: <span><ToolOutlined /> Area Capacity</span>,
            children: <CapacityTab />,
        },
        {
            key: 'qualification',
            label: <span><ExperimentOutlined /> Qualification</span>,
            children: <QualificationTab />,
        },
        {
            key: 'monitoring',
            label: <span><SettingOutlined /> Monitoring</span>,
            children: <MonitoringTab />,
        },
        {
            key: 'documentation',
            label: <span><InfoCircleOutlined /> Documentation</span>,
            children: <DocumentationTab />,
        },
    ];

    return (
        <>
            <Modal
                open={open}
                onCancel={onClose}
                footer={null}
                centered
                width={800}
                destroyOnHidden
                styles={{
                    header: {
                        background: '#001529',
                        padding: '16px 24px',
                    },
                    body: { padding: 0 },
                }}
                title={
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                        <div style={{
                            width: 40,
                            height: 40,
                            borderRadius: 8,
                            background: 'linear-gradient(135deg, #1890ff 0%, #36cfc9 100%)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}>
                            <EditOutlined style={{ fontSize: 20, color: '#fff' }} />
                        </div>
                        <div>
                            <Title level={5} style={{ marginBottom: 0, color: '#fff' }}>
                                Edit Facility
                            </Title>
                            <Text style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12 }}>
                                Update facility information carefully
                            </Text>
                        </div>
                    </div>
                }
            >
                <Form form={form} layout="vertical" size="middle">
                    <div style={{ padding: '16px 24px 24px' }}>
                        <Tabs
                            activeKey={activeTab}
                            onChange={setActiveTab}
                            items={tabItems}
                            size="large"
                            style={{ marginBottom: 8 }}
                            tabPosition="top"
                        />

                        <div style={{
                            marginTop: 24,
                            paddingTop: 16,
                            borderTop: '1px solid #f0f0f0',
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center'
                        }}>
                            <Text type="secondary" style={{ fontSize: 12 }}>
                                All fields marked as * are required
                            </Text>
                            <Space>
                                <Button onClick={onClose} icon={<CloseOutlined />}>
                                    Cancel
                                </Button>
                                <Button type="primary" loading={loading} icon={<PlusOutlined />} onClick={handleSubmit}>
                                    Update Facility
                                </Button>
                            </Space>
                        </div>
                    </div>
                </Form>
            </Modal>
            <EquipmentFetchModal
                open={equipmentFetchModalVisible}
                onClose={() => setEquipmentFetchModalVisible(false)}
                selectedEquipment={(selected) => {
                    form.setFieldValue('equipment', selected);
                }}
            />
        </>
    );
}


export function EquipmentFetchModal({
    open,
    onClose,
    selectedEquipment,
}: {
    open: boolean;
    onClose: () => void;
    selectedEquipment: (selectedEquipment: string[]) => void;
}) {
    const [page, setPage] = useState(1);
    const [limit] = useState(10);
    const [total, setTotal] = useState(0);
    const [equipmentOptions, setEquipmentOptions] = useState<any[]>([]);
    const [loading, setLoading] = useState(false);

    // 🔥 selection states
    const [selectedValues, setSelectedValues] = useState<string[]>([]);
    const [selectedMap, setSelectedMap] = useState<Record<string, any>>({});

    // ✅ RESET - Clear selection when modal closes
    useEffect(() => {
        if (!open) {
            setSelectedValues([]);
            setSelectedMap({});
            setPage(1);
            setEquipmentOptions([]);
        }
    }, [open]);

    // ✅ Fetch API
    const fetchEquipmentList = async (pageNumber: number) => {
        setLoading(true);
        try {
            const res = await fetch(
                `/api/user/master-data/facility-master/equipment-search?page=${pageNumber}&limit=${limit}`
            );
            const data = await res.json();

            if (data.success) {
                const options = data.equipment.map((item: any) => ({
                    label: `${item.equipmentName} - ${item.equipmentCode}`,
                    value: item.equipmentCode, // ✅ unique code
                    equipment: item
                }));

                setEquipmentOptions(options);
                setTotal(data.total);
            } else {
                message.error("Failed to fetch equipment");
            }
        } catch (error) {
            message.error("Failed to fetch equipment");
        } finally {
            setLoading(false);
        }
    };

    // ✅ Fetch on open + page change
    useEffect(() => {
        if (open) {
            fetchEquipmentList(page);
        }
    }, [page, open]);

    // ✅ Checkbox change
    const onChange = (checkedValues: any[]) => {
        setSelectedValues(checkedValues);

        const newMap = { ...selectedMap };

        // add selected
        equipmentOptions.forEach((opt) => {
            if (checkedValues.includes(opt.value)) {
                newMap[opt.value] = opt.equipment;
            }
        });

        // remove unselected (current page only)
        equipmentOptions.forEach((opt) => {
            if (!checkedValues.includes(opt.value)) {
                delete newMap[opt.value];
            }
        });

        setSelectedMap(newMap);
    };

    // ✅ Select All (current page)
    const handleSelectAllCurrent = () => {
        const currentIds = equipmentOptions.map((opt) => opt.value);

        const newValues = Array.from(new Set([...selectedValues, ...currentIds]));
        const newMap = { ...selectedMap };

        equipmentOptions.forEach((opt) => {
            newMap[opt.value] = opt.equipment;
        });

        setSelectedValues(newValues);
        setSelectedMap(newMap);
    };

    // ✅ Unselect All (current page)
    const handleUnselectCurrent = () => {
        const currentIds = equipmentOptions.map((opt) => opt.value);

        const newValues = selectedValues.filter(
            (val) => !currentIds.includes(val)
        );

        const newMap = { ...selectedMap };
        currentIds.forEach((id) => delete newMap[id]);

        setSelectedValues(newValues);
        setSelectedMap(newMap);
    };

    // ✅ Page change
    const onChangePage = (p: number) => {
        setPage(p);
    };

    // ✅ Submit handler
    const handleSubmit = () => {
        const selectedList = Object.values(selectedMap).map((item: any) => item.equipmentCode);
        // console.log("FINAL SELECTED:", selectedList);
        selectedEquipment(selectedList);

        message.success(`${selectedList.length} equipment selected`);
        onClose();
    };

    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            centered
            width={800}
            destroyOnHidden
            closable={false}
            styles={{
                header: {
                    background: "#001529",
                    padding: "16px 24px"
                },
                body: { padding: 0 }
            }}
            title={
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <div
                        style={{
                            width: 40,
                            height: 40,
                            borderRadius: 8,
                            background:
                                "linear-gradient(135deg, #1890ff 0%, #36cfc9 100%)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center"
                        }}
                    >
                        <EditOutlined style={{ fontSize: 20, color: "#fff" }} />
                    </div>
                    <div>
                        <Title level={5} style={{ marginBottom: 0, color: "#fff" }}>
                            Add Equipment
                        </Title>
                        <Text style={{ color: "rgba(255,255,255,0.65)", fontSize: 12 }}>
                            Add equipment to facility
                        </Text>
                    </div>
                </div>
            }
        >
            <Card
                title={`Equipment List (Selected: ${selectedValues.length})`}
                loading={loading}
                extra={
                    <Row gutter={8}>
                        <Col>
                            <Button onClick={handleSelectAllCurrent}>
                                Select Page
                            </Button>
                        </Col>
                        <Col>
                            <Button onClick={handleUnselectCurrent}>
                                Unselect Page
                            </Button>
                        </Col>
                    </Row>
                }
            >
                {/* ✅ Scrollable list */}
                <div style={{ maxHeight: 300, overflowY: "auto" }}>
                    <Checkbox.Group
                        options={equipmentOptions}
                        value={selectedValues}
                        onChange={onChange}
                        style={{
                            display: "flex",
                            flexDirection: "column",
                            gap: 8
                        }}
                    />
                </div>

                {/* ✅ Pagination */}
                <div style={{ marginTop: 16, textAlign: "right" }}>
                    <Pagination
                        total={total}
                        pageSize={limit}
                        current={page}
                        onChange={onChangePage}
                    />
                </div>

                {/* ✅ Footer buttons */}
                <div style={{ marginTop: 16, textAlign: "right" }}>
                    <Button onClick={onClose} style={{ marginRight: 8 }}>
                        Cancel
                    </Button>
                    <Button type="primary" onClick={handleSubmit}>
                        Add Selected
                    </Button>
                </div>
            </Card>
        </Modal>
    );
}
