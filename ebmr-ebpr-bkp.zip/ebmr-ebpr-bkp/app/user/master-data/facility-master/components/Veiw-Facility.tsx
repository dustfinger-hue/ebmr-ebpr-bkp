'use client';

import {
    Modal,
    Row,
    Col,
    Button,
    Typography,
    Tag,
    Spin,
    Tabs,
    Statistic,
    Badge,
    Flex,
} from "antd";
import {
    SettingOutlined,
    DatabaseOutlined,
    EnvironmentOutlined,
    ExperimentOutlined,
    ToolOutlined,
    FileTextOutlined,
    CloseOutlined,
    CheckCircleOutlined,
    InfoCircleOutlined,
    EditOutlined,
    AimOutlined,
} from "@ant-design/icons";
import { useEffect, useMemo, useState } from "react";
import dayjs from "dayjs";
import { useTheme } from "@/lib/utils/ThemeContext";

const { Title, Text, Paragraph } = Typography;

interface VeiwFacilityProps {
    open: boolean;
    onClose: () => void;
    facilityId?: string;
    facility?: any;
    onEdit?: () => void;
}

export default function VeiwFacility({
    open,
    onClose,
    facilityId,
    facility: initialFacility,
    onEdit
}: VeiwFacilityProps) {
    const { theme } = useTheme();
    const [loading, setLoading] = useState(false);
    const [facility, setFacility] = useState<any>(null);
    const [activeTab, setActiveTab] = useState('basic');
    const [equipment, setEquipment] = useState<any[]>([]);

    // Theme-aware colors
    const colors = {
        cardBg: theme === 'dark' ? '#1f1f1f' : '#fafafa',
        cardBorder: theme === 'dark' ? '#303030' : '#f0f0f0',
        textPrimary: theme === 'dark' ? '#ffffff' : '#262626',
        textSecondary: theme === 'dark' ? '#8c8c8c' : '#8c8c8c',
        textMuted: theme === 'dark' ? '#595959' : '#bfbfbf',
        modalHeader: theme === 'dark' ? '#141414' : '#001529',
        quickStatsBg: theme === 'dark' ? '#1f1f1f' : '#fafafa',
        statsBorder: theme === 'dark' ? '#303030' : '#f0f0f0',
        // Special background colors
        greenBg: theme === 'dark' ? '#1b2a1b' : '#f6ffed',
        greenBorder: theme === 'dark' ? '#274c27' : '#b7eb8f',
        blueBg: theme === 'dark' ? '#1a2a3a' : '#e6f7ff',
        blueBorder: theme === 'dark' ? '#1d3d5c' : '#91d5ff',
        orangeBg: theme === 'dark' ? '#2a2a1a' : '#fff7e6',
        orangeBorder: theme === 'dark' ? '#4d4d1a' : '#ffd591',
        redBg: theme === 'dark' ? '#2a1a1a' : '#fff1f0',
        redBorder: theme === 'dark' ? '#4d1a1a' : '#ffccc7',
        purpleBg: theme === 'dark' ? '#1a1a2a' : '#f0f5ff',
        purpleBorder: theme === 'dark' ? '#2d2d4d' : '#adc6ff',
    };

    useEffect(() => {
        if (open) {
            // Reset state when opening modal
            setFacility(null);
            setEquipment([]);

            if (initialFacility) {
                setFacility(initialFacility);
                if (initialFacility.equipment && initialFacility.equipment.length > 0) {
                    fetchEquipment(initialFacility.equipment);
                }
            } else if (facilityId) {
                fetchFacility();
            }
        }
    }, [open, facilityId, initialFacility]);

    // Separate function to fetch equipment details
    const fetchEquipment = async (equipmentCodes: string[]) => {
        try {
            const res = await fetch(
                `/api/user/master-data/equipment-master?equipmentCode=${equipmentCodes.join(',')}`
            );
            const equipmentData = await res.json();
            if (equipmentData.success) {
                setEquipment(equipmentData.equipment.map((eq: any) => ({
                    equipmentCode: eq.equipmentCode,
                    equipmentName: eq.equipmentName
                })));
            }
        } catch (error) {
            console.error('Error fetching equipment:', error);
            setEquipment([]);
        }
    };

    useEffect(() => {
        if (open) {
            setActiveTab('basic');
        }
    }, [open]);

    const fetchFacility = async () => {
        try {
            setLoading(true);
            const res = await fetch(`/api/user/master-data/facility-master?facilityId=${facilityId}`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            const data = await res.json();
            if (data.success) {
                const facilityData = data.facilities[0];
                setFacility(facilityData);

                // Safely check and fetch equipment only if it exists and has items
                if (facilityData.equipment && facilityData.equipment.length > 0) {
                    await fetchEquipment(facilityData.equipment);
                } else {
                    setEquipment([]);
                }
            }
        } catch (error) {
            console.error(error);
            setFacility(null);
            setEquipment([]);
        } finally {
            setLoading(false);
        }
    };
    const equipmentMap = useMemo(() => {
        return Object.fromEntries(
            equipment.map((e) => [e.equipmentCode, e.equipmentName])
        );
    }, [equipment]);
    const getStatusColor = (status: string) => {
        const colors: Record<string, string> = {
            'Active': 'green',
            'Inactive': 'default',
            'Under Maintenance': 'orange',
            'Decommissioned': 'red',
        };
        return colors[status] || 'blue';
    };
    const formatDate = (date: string) => {
        return date ? dayjs(date).format('DD-MMM-YYYY') : '-';
    };

    const formatRange = (min: number | undefined | null, max: number | undefined | null, unit: string) => {
        if (min != null && max != null) {
            return `${min}-${max} ${unit}`;
        }
        return null;
    };

    // Helper to Render info row using consistent pattern from equipment view
    const renderInfoRow = (label: string, value: any, span: number = 8) => (
        <Col xs={24} sm={span}>
            <div style={{
                padding: '12px 16px',
                background: colors.cardBg,
                borderRadius: 8,
                height: '100%',
                border: `1px solid ${colors.cardBorder}`
            }}>
                <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block', color: colors.textSecondary }}>
                    {label}
                </Text>
                <Text strong style={{ fontSize: 15, color: colors.textPrimary }}>
                    {value || <span style={{ color: colors.textMuted }}>-</span>}
                </Text>
            </div>
        </Col>
    );

    // Tab content components
    const BasicInfoTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                {renderInfoRow("Facility Code", <Text strong style={{ color: '#1677ff', fontSize: 16 }}>{facility?.facilityCode}</Text>, 8)}
                {renderInfoRow("Area Name", facility?.areaName, 8)}
                {renderInfoRow("Area Type", <Tag>{facility?.areaType}</Tag>, 8)}
                <Col xs={24}>
                    <div style={{
                        padding: '16px',
                        background: colors.greenBg,
                        borderRadius: 8,
                        border: `1px solid ${colors.greenBorder}`
                    }}>
                        <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                            Description
                        </Text>
                        <Paragraph style={{ marginBottom: 0, marginTop: 8, fontSize: 14, color: colors.textPrimary }}>
                            {facility?.description || <Text type="secondary">No description available</Text>}
                        </Paragraph>
                    </div>
                </Col>
            </Row>
        </div>
    );

    const LocationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                {renderInfoRow("Block / Building", <Tag>{facility?.blockBuilding}</Tag>, 8)}
                {renderInfoRow("Floor", facility?.floor, 8)}
                {renderInfoRow("Department", facility?.department, 8)}
            </Row>
        </div>
    );

    const GmpClassificationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                <Col xs={24} sm={12}>
                    <div style={{
                        padding: '20px',
                        background: colors.greenBg,
                        borderRadius: 8,
                        border: `1px solid ${colors.greenBorder}`,
                        textAlign: 'center'
                    }}>
                        <Statistic
                            title="Clean Room Grade"
                            value={facility?.cleanRoomGrade || 'N/A'}
                            valueStyle={{ color: facility?.cleanRoomGrade === 'A' ? '#52c41a' : '#1890ff', fontSize: 28 }}
                        />
                    </div>
                </Col>
                <Col xs={24} sm={12}>
                    <div style={{
                        padding: '20px',
                        background: colors.blueBg,
                        borderRadius: 8,
                        border: `1px solid ${colors.blueBorder}`,
                        textAlign: 'center'
                    }}>
                        <Statistic
                            title="Differential Pressure"
                            value={facility?.differentialPressure || 0}
                            suffix="Pa"
                            valueStyle={{ color: '#1890ff', fontSize: 28 }}
                        />
                    </div>
                </Col>
                {renderInfoRow("Diff. Pressure Range", formatRange(facility?.differentialPressureMin, facility?.differentialPressureMax, "Pa") || (facility?.differentialPressure ? `${facility.differentialPressure} Pa` : "-"), 8)}
                {renderInfoRow("Temperature Range", facility?.temperatureMin && facility?.temperatureMax ? `${facility.temperatureMin}-${facility.temperatureMax} °C` : '-', 8)}
                {renderInfoRow("Humidity Range", facility?.humidityMin && facility?.humidityMax ? `${facility.humidityMin}-${facility.humidityMax} %` : '-', 8)}
                {renderInfoRow("Particulates Max", facility?.particulatesMax != null ? `${facility.particulatesMax} CFU/m³` : "-", 8)}
                {renderInfoRow("LUX Range", formatRange(facility?.luxLevelMin, facility?.luxLevelMax, "Lux") || "-", 8)}
                {renderInfoRow("Environmental Reference", facility?.environmentalReference || "-", 8)}
                {renderInfoRow("Reference Version", facility?.environmentalReferenceVersion || "-", 8)}
                {renderInfoRow("Air Changes/Hour", facility?.airChangesPerHour, 8)}
            </Row>
        </div>
    );

    const CapacityTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                <Col xs={24} sm={8}>
                    <div style={{
                        padding: '20px',
                        background: colors.orangeBg,
                        borderRadius: 8,
                        border: `1px solid ${colors.orangeBorder}`,
                        textAlign: 'center'
                    }}>
                        <Statistic
                            title="Area Size"
                            value={facility?.areaSize || 0}
                            suffix={facility?.areaSizeUnit || 'sq ft'}
                            valueStyle={{ color: '#fa8c16', fontSize: 24 }}
                        />
                    </div>
                </Col>
                <Col xs={24} sm={8}>
                    {renderInfoRow("Max Equipment", facility?.maxEquipmentAllowed, 8)}
                </Col>
                <Col xs={24} sm={8}>
                    {renderInfoRow("Max Operators", facility?.maxOperatorsAllowed, 8)}
                </Col>
                {renderInfoRow("Material Flow", facility?.materialFlowDirection, 8)}
                {renderInfoRow("Personnel Flow", facility?.personnelFlow, 8)}
                <Col xs={24}>
                    <div style={{
                        padding: '16px',
                        background: colors.purpleBg,
                        borderRadius: 8,
                        border: `1px solid ${colors.purpleBorder}`
                    }}>
                        <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, display: 'block', marginBottom: 8, color: colors.textSecondary }}>
                            Equipment
                        </Text>
                        {facility?.equipment && facility.equipment.length > 0 ? (
                            <Flex wrap gap={8}>
                                {facility.equipment.map((eq: string, index: number) => (
                                    <Tag key={index} color="blue" style={{ fontSize: 13, padding: '4px 10px' }}>
                                        {equipmentMap[eq] ? `${eq} - ${equipmentMap[eq]}` : eq}
                                    </Tag>
                                ))}
                            </Flex>
                        ) : (
                            <Text type="secondary" style={{ color: colors.textMuted }}>No equipment assigned</Text>
                        )}
                    </div>
                </Col>
            </Row>
        </div>
    );

    const QualificationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                <Col xs={24}>
                    <Flex justify="space-between" align="center" style={{
                        padding: '12px 16px',
                        background: facility?.qualificationRequired ? colors.greenBg : colors.redBg,
                        borderRadius: 8,
                        border: `1px solid ${facility?.qualificationRequired ? colors.greenBorder : colors.redBorder}`
                    }}>
                        <div>
                            <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                                Qualification Required
                            </Text>
                            <div style={{ marginTop: 4 }}>
                                <Text strong style={{ fontSize: 16, color: colors.textPrimary }}>
                                    {facility?.qualificationRequired ? 'Yes' : 'No'}
                                </Text>
                            </div>
                        </div>
                        <Badge
                            status={facility?.qualificationRequired ? 'success' : 'warning'}
                            text={facility?.qualificationRequired ? 'Required' : 'Not Required'}
                        />
                    </Flex>
                </Col>
                {renderInfoRow("Qualification Status", facility?.qualificationStatus ? <Tag color="blue">{facility.qualificationStatus}</Tag> : '-', 8)}
                {renderInfoRow("Qualification Date", facility?.qualificationDate ? new Date(facility.qualificationDate).toLocaleDateString() : '-', 8)}
                {renderInfoRow("Requalification Frequency", facility?.requalificationFrequency ? `${facility.requalificationFrequency} months` : '-', 8)}
            </Row>
        </div>
    );

    const MonitoringTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                <Col xs={24}>
                    <Flex justify="space-between" align="center" style={{
                        padding: '12px 16px',
                        background: facility?.environmentalMonitoringRequired ? colors.greenBg : colors.redBg,
                        borderRadius: 8,
                        border: `1px solid ${facility?.environmentalMonitoringRequired ? colors.greenBorder : colors.redBorder}`
                    }}>
                        <div>
                            <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                                Environmental Monitoring
                            </Text>
                            <div style={{ marginTop: 4 }}>
                                <Text strong style={{ fontSize: 16, color: colors.textPrimary }}>
                                    {facility?.environmentalMonitoringRequired ? 'Required' : 'Not Required'}
                                </Text>
                            </div>
                        </div>
                        <Badge
                            status={facility?.environmentalMonitoringRequired ? 'success' : 'warning'}
                            text={facility?.environmentalMonitoringRequired ? 'Required' : 'Not Required'}
                        />
                    </Flex>
                </Col>
                {renderInfoRow("Cleaning SOP", facility?.cleaningSopNumber, 8)}
                {renderInfoRow("Sanitization Frequency", facility?.sanitizationFrequency, 8)}
                <Col xs={24}>
                    <Flex justify="space-between" align="center" style={{
                        padding: '12px 16px',
                        background: facility?.pestControlRequired ? colors.orangeBg : colors.cardBg,
                        borderRadius: 8,
                        border: `1px solid ${facility?.pestControlRequired ? colors.orangeBorder : colors.cardBorder}`
                    }}>
                        <div>
                            <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                                Pest Control
                            </Text>
                            <div style={{ marginTop: 4 }}>
                                <Text strong style={{ fontSize: 16, color: colors.textPrimary }}>
                                    {facility?.pestControlRequired ? 'Required' : 'Not Required'}
                                </Text>
                            </div>
                        </div>
                        <Badge
                            status={facility?.pestControlRequired ? 'warning' : 'default'}
                            text={facility?.pestControlRequired ? 'Required' : 'Not Required'}
                        />
                    </Flex>
                </Col>
            </Row>
        </div>
    );

    const DocumentationTab = () => (
        <div style={{ padding: '8px 0' }}>
            <Row gutter={[16, 16]}>
                {renderInfoRow("Layout Document", facility?.layoutDocument, 8)}
                {renderInfoRow("Risk Assessment ID", facility?.riskAssessmentId, 8)}
                {renderInfoRow("Validation Protocol", facility?.validationProtocol, 8)}
                <Col xs={24}>
                    <div style={{
                        padding: '16px',
                        background: colors.cardBg,
                        borderRadius: 8,
                        border: `1px solid ${colors.cardBorder}`
                    }}>
                        <Text type="secondary" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5, color: colors.textSecondary }}>
                            Remarks
                        </Text>
                        <Paragraph style={{ marginBottom: 0, marginTop: 8, fontSize: 14, color: colors.textPrimary }}>
                            {facility?.remarks || <Text type="secondary">No remarks</Text>}
                        </Paragraph>
                    </div>
                </Col>
            </Row>
        </div>
    );

    const tabItems = [
        {
            key: 'basic',
            label: (
                <span>
                    <DatabaseOutlined /> Basic Info
                </span>
            ),
            children: <BasicInfoTab />,
        },
        {
            key: 'location',
            label: (
                <span>
                    <EnvironmentOutlined /> Location
                </span>
            ),
            children: <LocationTab />,
        },
        {
            key: 'gmp',
            label: (
                <span>
                    <ExperimentOutlined /> GMP
                </span>
            ),
            children: <GmpClassificationTab />,
        },
        {
            key: 'capacity',
            label: (
                <span>
                    <ToolOutlined /> Capacity
                </span>
            ),
            children: <CapacityTab />,
        },
        {
            key: 'qualification',
            label: (
                <span>
                    <CheckCircleOutlined /> Qualification
                </span>
            ),
            children: <QualificationTab />,
        },
        {
            key: 'monitoring',
            label: (
                <span>
                    <InfoCircleOutlined /> Monitoring
                </span>
            ),
            children: <MonitoringTab />,
        },
        {
            key: 'documentation',
            label: (
                <span>
                    <FileTextOutlined /> Documentation
                </span>
            ),
            children: <DocumentationTab />,
        },
    ];

    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            centered
            width={700}
            destroyOnClose
            closable={false}
            styles={{
                header: {
                    background: colors.modalHeader,
                    padding: '16px 24px',
                },
                body: { padding: 0 },
            }}
            title={
                <Flex align="center" gap={12}>
                    <div style={{
                        width: 40,
                        height: 40,
                        borderRadius: 8,
                        background: 'linear-gradient(135deg, #1890ff 0%, #36cfc9 100%)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}>
                        <AimOutlined style={{ fontSize: 20, color: '#fff' }} />
                    </div>
                    <div>
                        <Title level={5} style={{ marginBottom: 0, color: '#fff' }}>
                            {facility?.areaName || 'Facility Details'}
                        </Title>
                        <Text style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12 }}>
                            {facility?.facilityCode || 'View facility information'}
                        </Text>
                    </div>
                </Flex>
            }
        >
            {loading || !facility ? (
                <div style={{ textAlign: 'center', padding: '60px 0' }}>
                    <Spin size="large" />
                    <div style={{ marginTop: 16 }}>
                        <Text type="secondary">Loading facility details...</Text>
                    </div>
                </div>
            ) : (
                <div>
                    {/* Quick Stats Bar */}
                    <Flex gap={24} wrap style={{
                        padding: '12px 24px',
                        background: colors.quickStatsBg,
                        borderBottom: `1px solid ${colors.statsBorder}`
                    }}>
                        <Flex align="center" gap={6}>
                            <CheckCircleOutlined style={{ color: getStatusColor(facility?.status) === 'green' ? '#52c41a' : '#faad14' }} />
                            <Text strong style={{ color: colors.textPrimary }}>{facility?.status || 'N/A'}</Text>
                        </Flex>
                        <Flex align="center" gap={6}>
                            <InfoCircleOutlined style={{ color: '#1890ff' }} />
                            <Text style={{ color: colors.textPrimary }}>{facility?.areaType || 'N/A'}</Text>
                        </Flex>
                        <Flex align="center" gap={6}>
                            <ExperimentOutlined style={{ color: '#722ed1' }} />
                            <Text style={{ color: colors.textPrimary }}>{facility?.cleanRoomGrade || 'N/A'}</Text>
                        </Flex>
                        <Flex align="center" gap={6}>
                            <EnvironmentOutlined style={{ color: '#fa8c16' }} />
                            <Text style={{ color: colors.textPrimary }}>{facility?.blockBuilding || 'N/A'}</Text>
                        </Flex>
                    </Flex>

                    {/* Tabs Section */}
                    <div style={{ padding: '16px 24px 24px' }}>
                        <Tabs
                            activeKey={activeTab}
                            onChange={setActiveTab}
                            items={tabItems}
                            size="large"
                            style={{ marginBottom: 8 }}
                        />

                        {/* Actions */}
                        <Flex justify="space-between" align="center" style={{
                            marginTop: 24,
                            paddingTop: 16,
                            borderTop: `1px solid ${colors.statsBorder}`
                        }}>
                            <Text type="secondary" style={{ fontSize: 12 }}>
                                Created: {formatDate(facility?.createdAt)} | Updated: {formatDate(facility?.updatedAt)}
                            </Text>
                            <Flex gap={8}>
                                {onEdit && (
                                    <Button
                                        onClick={onEdit}
                                        icon={<EditOutlined />}
                                        type="primary"
                                    >
                                        Edit
                                    </Button>
                                )}
                                <Button
                                    onClick={onClose}
                                    icon={<CloseOutlined />}
                                    type="primary"
                                >
                                    Close
                                </Button>
                            </Flex>
                        </Flex>
                    </div>
                </div>
            )}
        </Modal>
    );
}