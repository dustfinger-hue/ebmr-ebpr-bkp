'use client';

import { Modal, Button, Typography, message, Flex } from "antd";
import { DeleteOutlined, ExclamationCircleOutlined } from "@ant-design/icons";
import { useState } from "react";
import { useTheme } from "@/lib/utils/ThemeContext";

const { Text } = Typography;

interface DeleteFacilityProps {
  open: boolean;
  onClose: () => void;
  facility: any;
  onSuccess: () => void;
}

export default function DeleteFacility({ open, onClose, facility, onSuccess }: DeleteFacilityProps) {
  const { theme } = useTheme();
  const [loading, setLoading] = useState(false);

  // Theme-aware colors
  const colors = {
    bg: theme === 'dark' ? '#1f1f1f' : '#f5f5f5',
    textPrimary: theme === 'dark' ? '#ffffff' : '#262626',
    textSecondary: theme === 'dark' ? '#8c8c8c' : '#8c8c8c',
  };

  const handleDelete = async () => {
    if (!facility?._id) return;
    
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/user/master-data/facility-master?id=${facility._id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          deleteReason: 'Deleted by user'
        }),
      });

      const data = await response.json();

      if (data.success) {
        message.success(data.message);
        onSuccess();
        onClose();
      } else {
        message.error(data.message);
      }
    } catch (error) {
      console.error('Error deleting facility:', error);
      message.error("Error deleting facility");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      title={
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <DeleteOutlined style={{ color: '#ff4d4f' }} />
          <span>Delete Facility</span>
        </div>
      }
      open={open}
      onCancel={onClose}
      footer={[
        <Button key="cancel" onClick={onClose}>
          Cancel
        </Button>,
        <Button
          key="delete"
          type="primary"
          danger
          loading={loading}
          onClick={handleDelete}
        >
          Delete
        </Button>,
      ]}
      destroyOnClose
    >
      <div style={{ textAlign: 'center', padding: '20px 0' }}>
        <ExclamationCircleOutlined style={{ fontSize: 48, color: '#faad14', marginBottom: 16 }} />
        <Text strong style={{ display: 'block', fontSize: 16, marginBottom: 8 }}>
          Are you sure you want to delete this facility?
        </Text>
        <Text type="secondary">
          This action cannot be undone. The facility will be permanently removed.
        </Text>
        
        {facility && (
          <div style={{ marginTop: 24, padding: 16, background: colors.bg, borderRadius: 8 }}>
            <Text strong style={{ color: colors.textPrimary }}>Facility Details:</Text>
            <div style={{ marginTop: 8 }}>
              <Text style={{ color: colors.textSecondary }}>Code: <Text strong style={{ color: colors.textPrimary }}>{facility.facilityCode}</Text></Text>
            </div>
            <div>
              <Text style={{ color: colors.textSecondary }}>Name: <Text strong style={{ color: colors.textPrimary }}>{facility.areaName}</Text></Text>
            </div>
            <div>
              <Text style={{ color: colors.textSecondary }}>Block: <Text strong style={{ color: colors.textPrimary }}>{facility.blockBuilding}</Text> - {facility.floor}</Text>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
}
