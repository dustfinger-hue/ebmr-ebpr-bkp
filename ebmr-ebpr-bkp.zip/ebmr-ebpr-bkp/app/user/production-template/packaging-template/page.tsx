export default function PackagingTemplatePage() {
    return (
        <div>
            Packaging Template
        </div>
    )
}