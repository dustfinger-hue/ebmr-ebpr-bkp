'use client';
import { Button, Card, Col, Input, message, Row, Table, Tag, Tooltip, Typography } from "antd";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { FaIndustry } from "react-icons/fa";
const { Title, Text } = Typography;
import {
  ReloadOutlined,
  PlusOutlined,
  SearchOutlined,
  EyeOutlined,
} from "@ant-design/icons";
import { useAuthorization } from "@/hooks/useAuthorization";
import ViewProductTemplatesModal from "./view-template/components/View-Product-Templates-Modal";

interface ProductGroupRecord {
  productCode: string;
  productName: string;
  dosageForm: string;
  totalTemplates: number;
  activeTemplates: number;
  pendingTemplates: number;
  draftTemplates: number;
  latestVersion: string;
  latestTemplateCode: string;
  latestCreatedAt: string;
}

export default function ManufacturingTemplatePage() {

  const [pagination, setPagination] = useState({
    current: 1,
    pageSize: 10,
    total: 0,
  });
  const [loading, setLoading] = useState(false);
  const [productGroups, setProductGroups] = useState<ProductGroupRecord[]>([]);
  const [searchValue, setSearchValue] = useState('');

  // View Modal State
  const [viewModalOpen, setViewModalOpen] = useState(false);
  const [selectedProductGroup, setSelectedProductGroup] = useState<{ productCode: string; productName: string; dosageForm: string } | null>(null);

  const router = useRouter();

  const fetchProductGroups = async (page: number, pageSize: number, search: string) => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const params = new URLSearchParams({
        page: page.toString(),
        limit: pageSize.toString(),
        groupByProduct: 'true',
      });
      if (search.trim()) {
        params.set('search', search.trim());
      }

      const res = await fetch(`/api/user/production-template/manufacturing-template?${params.toString()}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();

      if (data.success) {
        setProductGroups(data.data || []);
        setPagination(prev => ({
          ...prev,
          total: data.pagination?.total || 0,
          current: data.pagination?.page || page,
          pageSize: data.pagination?.limit || pageSize,
        }));
      } else {
        message.error(data.message || 'Failed to fetch templates');
      }
    } catch (error) {
      console.error('Error fetching templates:', error);
      message.error('Failed to fetch templates');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProductGroups(pagination.current, pagination.pageSize, searchValue);
  }, []);

  const handleRefresh = () => {
    fetchProductGroups(pagination.current, pagination.pageSize, searchValue);
  };

  const handleSearch = (value: string) => {
    setSearchValue(value);
    setPagination(prev => ({ ...prev, current: 1 }));
    fetchProductGroups(1, pagination.pageSize, value);
  };

  const handleTableChange = (pag: { current: number; pageSize: number }) => {
    setPagination(prev => ({
      ...prev,
      current: pag.current,
      pageSize: pag.pageSize,
    }));
    fetchProductGroups(pag.current, pag.pageSize, searchValue);
  };

  const handleAddTemplate = () => {
    router.push('/user/production-template/manufacturing-template/add-template')
  };

  const handleOpenViewModal = (record: ProductGroupRecord) => {
    setSelectedProductGroup({
      productCode: record.productCode,
      productName: record.productName,
      dosageForm: record.dosageForm,
    });
    setViewModalOpen(true);
  };

  const statusColorMap: Record<string, string> = {
    'Pending Signatures': 'orange',
    'Active': 'green',
    'Draft': 'default',
    'Superseded': 'red',
    'Rejected': 'red',
    'Reverted': 'orange',
  };

  const { hasAccess } = useAuthorization();
  const isCreateTemplateAuthorized = hasAccess('Batch Manufacturing Template', 'create');
  const isViewTemplateAuthorized = hasAccess('Batch Manufacturing Template', 'read');

  const columns = [
    {
      title: 'S.No',
      width: 70,
      fixed: 'left' as const,
      render: (_: any, __: any, index: number) =>
        (pagination.current - 1) * pagination.pageSize + index + 1
    },
    {
      title: 'Product Code',
      dataIndex: 'productCode',
      key: 'productCode',
      width: 120,
      render: (text: string) => (
        <Text copyable style={{ color: '#1677ff', fontWeight: 500 }}>
          {text}
        </Text>
      ),
    },
    {
      title: 'Product Name',
      dataIndex: 'productName',
      key: 'productName',
      width: 220,
      ellipsis: true,
      render: (text: string) => (
        <Text strong>{text}</Text>
      ),
    },
    {
      title: 'Dosage Form',
      dataIndex: 'dosageForm',
      key: 'dosageForm',
      width: 120,
      render: (text: string) => <Tag color="blue">{text}</Tag>,
    },
    {
      title: 'Total Templates',
      dataIndex: 'totalTemplates',
      key: 'totalTemplates',
      width: 130,
      align: 'center' as const,
      render: (count: number) => <Tag color="geekblue">{count}</Tag>,
    },
    {
      title: 'Status Summary',
      key: 'statusSummary',
      width: 150,
      render: (_: any, record: ProductGroupRecord) => (
        <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
          {record.activeTemplates > 0 && (
            <Tag color="green">{record.activeTemplates} Active</Tag>
          )}
          {record.pendingTemplates > 0 && (
            <Tag color="orange">{record.pendingTemplates} Pending</Tag>
          )}
          {record.draftTemplates > 0 && (
            <Tag>{record.draftTemplates} Draft</Tag>
          )}
        </div>
      ),
    },
    {
      title: 'Latest Version',
      dataIndex: 'latestVersion',
      key: 'latestVersion',
      width: 100,
      align: 'center' as const,
    },
    {
      title: 'Actions',
      key: 'actions',
      width: 80,
      fixed: 'right' as const,
      render: (_: any, record: ProductGroupRecord) => (
        <Button
          type="link"
          icon={<EyeOutlined />}
          onClick={() => handleOpenViewModal(record)}
          disabled={!isViewTemplateAuthorized}
        >
          View
        </Button>
      ),
    },
  ];

  return (
    <div>
      <Title level={2}>
        <FaIndustry size={30} className="inline mb-1" /> Manufacturing Template
      </Title>
      <Card>

        <Row gutter={[16, 16]} style={{ marginBottom: 16 }} justify="space-between">
          <Col xs={24} sm={8} md={6}>
            <Input
              placeholder="Search by product code or name..."
              prefix={<SearchOutlined />}
              value={searchValue}
              onChange={(e) => handleSearch(e.target.value)}
              allowClear
              onClear={() => handleSearch('')}
            />
          </Col>
          <Col xs={24} sm={16} md={18} style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <div className="flex flex-row gap-2">
              <Tooltip title="Refresh Data">
                <Button
                  onClick={handleRefresh}
                  icon={<ReloadOutlined />}
                >
                  Refresh
                </Button>
              </Tooltip>
              <Button
                type="primary"
                onClick={handleAddTemplate}
                icon={<PlusOutlined />}
                disabled={!isCreateTemplateAuthorized}
              >
                Add Template
              </Button>
            </div>
          </Col>
        </Row>

        <Table
          columns={columns}
          dataSource={productGroups}
          rowKey="productCode"
          loading={loading}
          scroll={{ x: 'max-content' }}
          pagination={{
            current: pagination.current,
            pageSize: pagination.pageSize,
            total: pagination.total,
            showSizeChanger: true,
            pageSizeOptions: ['10', '20', '30', '40', '50'],
            onChange: (page: number, pageSize: number) => {
              handleTableChange({ current: page, pageSize });
            },
          }}
        />
      </Card>

      {/* View Product Templates Modal */}
      <ViewProductTemplatesModal
        open={viewModalOpen}
        onClose={() => {
          setViewModalOpen(false);
          setSelectedProductGroup(null);
        }}
        onSuccess={() => {
          fetchProductGroups(pagination.current, pagination.pageSize, searchValue);
        }}
        productGroup={selectedProductGroup}
      />
    </div>
  )
}