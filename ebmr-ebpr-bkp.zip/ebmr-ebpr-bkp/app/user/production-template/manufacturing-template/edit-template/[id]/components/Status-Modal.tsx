"use client";

import {
  Alert,
  Descriptions,
  Form,
  Input,
  message,
  Modal,
  Select,
  Skeleton,
  Tag,
  Typography,
} from "antd";
import { useEffect, useMemo, useState } from "react";

const { Text } = Typography;

interface TemplateDocument {
  _id: string;
  templateCode: string;
  templateName: string;
  productCode: string;
  productName: string;
  dosageForm: string;
  status: string;
  templateVersion: string;
}

interface StatusModalProps {
  visible: boolean;
  onCancel: () => void;
  onSuccess?: () => void;
  documentId?: string | null;
}

const statusColorMap: Record<string, string> = {
  "Pending Signatures": "orange",
  Active: "green",
  Inactive: "default",
  Draft: "default",
  Superseded: "red",
  Rejected: "red",
  Reverted: "orange",
};

const allowedStatusOptions: Record<string, Array<{ label: string; value: string }>> = {
  Active: [{ label: "Inactive", value: "Inactive" }],
  Inactive: [{ label: "Active", value: "Active" }],
};

export default function StatusModal({
  visible,
  onCancel,
  onSuccess,
  documentId,
}: StatusModalProps) {
  const [form] = Form.useForm();
  const [document, setDocument] = useState<TemplateDocument | null>(null);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const selectedStatus = Form.useWatch("newStatus", form);

  const statusOptions = useMemo(() => {
    if (!document) return [];
    return allowedStatusOptions[document.status] || [];
  }, [document]);

  const isStatusChangeAllowed = statusOptions.length > 0;

  useEffect(() => {
    if (visible && documentId) {
      fetchDocumentDetails(documentId);
    }

    if (!visible) {
      form.resetFields();
      setDocument(null);
      setSubmitting(false);
    }
  }, [visible, documentId]);

  useEffect(() => {
    form.setFieldsValue({ newStatus: statusOptions[0]?.value });
  }, [form, statusOptions]);

  const fetchDocumentDetails = async (id: string) => {
    try {
      setLoading(true);
      const response = await fetch(
        `/api/user/production-template/manufacturing-template?id=${id}`,
        {
          method: "GET",
          headers: {
            authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        },
      );

      const data = await response.json();
      if (!data.success) {
        message.error(data.message || "Failed to fetch document details");
        return;
      }

      setDocument(data.data);
    } catch (error) {
      console.error("Error fetching document details:", error);
      message.error("Error fetching document details");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!document) return;

    try {
      const values = await form.validateFields();
      setSubmitting(true);

      const response = await fetch(
        "/api/user/production-template/manufacturing-template/status",
        {
          method: "PATCH",
          headers: {
            authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            documentId: document._id,
            newStatus: values.newStatus,
            reason: values.reason,
          }),
        },
      );

      const data = await response.json();
      if (!data.success) {
        message.error(data.message || "Failed to update status");
        return;
      }

      if (data.data?.deactivatedTemplateCode) {
        message.success(
          `Status updated. ${data.data.deactivatedTemplateCode} was set to Inactive.`,
        );
      } else {
        message.success(data.message || "Status updated successfully");
      }

      onSuccess?.();
      onCancel();
    } catch (error: any) {
      if (error?.errorFields) return;
      console.error("Error updating status:", error);
      message.error("Error updating status");
    } finally {
      setSubmitting(false);
    }
  };

  const renderStatusTag = (status?: string) => (
    <Tag color={statusColorMap[status || ""] || "default"}>
      {status || "-"}
    </Tag>
  );

  return (
    <Modal
      title="Change Template Status"
      open={visible}
      onCancel={onCancel}
      onOk={handleSubmit}
      okText="Update Status"
      confirmLoading={submitting}
      okButtonProps={{ disabled: loading || !isStatusChangeAllowed }}
      destroyOnClose
    >
      {loading ? (
        <Skeleton active paragraph={{ rows: 5 }} />
      ) : document ? (
        <>
          <Descriptions
            bordered
            size="small"
            column={1}
            style={{ marginBottom: 16 }}
          >
            <Descriptions.Item label="Template Code">
              <Text copyable>{document.templateCode}</Text>
            </Descriptions.Item>
            <Descriptions.Item label="Template Name">
              {document.templateName || "-"}
            </Descriptions.Item>
            <Descriptions.Item label="Product">
              {document.productName || "-"} ({document.productCode || "-"})
            </Descriptions.Item>
            <Descriptions.Item label="Version">
              {document.templateVersion || "-"}
            </Descriptions.Item>
            <Descriptions.Item label="Current Status">
              {renderStatusTag(document.status)}
            </Descriptions.Item>
          </Descriptions>

          {!isStatusChangeAllowed && (
            <Alert
              type="warning"
              showIcon
              style={{ marginBottom: 16 }}
              message={
                document.status === "Superseded"
                  ? "Superseded documents cannot be activated again."
                  : `Status cannot be changed for ${document.status} documents.`
              }
            />
          )}

          {selectedStatus === "Active" && (
            <Alert
              type="info"
              showIcon
              style={{ marginBottom: 16 }}
              message="Activating this template will set the current active template for this product to Inactive."
            />
          )}

          <Form form={form} layout="vertical" preserve={false}>
            <Form.Item
              label="New Status"
              name="newStatus"
              rules={[{ required: true, message: "Please select a status" }]}
            >
              <Select
                placeholder="Select status"
                options={statusOptions}
                disabled={!isStatusChangeAllowed}
              />
            </Form.Item>

            <Form.Item
              label="Reason"
              name="reason"
              rules={[
                { required: true, message: "Please enter a reason" },
                { min: 5, message: "Reason must be at least 5 characters" },
              ]}
            >
              <Input.TextArea
                rows={4}
                placeholder="Enter reason for status change"
                disabled={!isStatusChangeAllowed}
                maxLength={500}
                showCount
              />
            </Form.Item>
          </Form>
        </>
      ) : (
        <Alert
          type="warning"
          showIcon
          message="Document details are not available."
        />
      )}
    </Modal>
  );
}
