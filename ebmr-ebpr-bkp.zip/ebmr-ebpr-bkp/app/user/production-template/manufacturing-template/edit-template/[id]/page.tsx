'use client'
import { Tabs, Button, Card, Typography, message, Form, Breadcrumb, Space, Spin, Result } from "antd";
import { useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { ArrowLeftOutlined, HomeOutlined, SaveOutlined, CheckCircleOutlined } from "@ant-design/icons";
import BasicInfoForm from "../../add-template/components/Basic-info";
import ManufacturingBOMForm from "../../add-template/components/Manufacturing-BOM";
import { DataContext } from "@/lib/utils/DataContext";
import FacilityEquipment from "../../add-template/components/Facility-Equipment";
import ManufacturingSteps from "../../add-template/components/Manufacturing-Steps";
import CompressionParameters from "../../add-template/components/Compression-Parameters";
import CoatingSection from "../../add-template/components/Coating-Section";
import EncapsulationParameters from "../../add-template/components/Encapsulation-Parameters";
import LiquidSuspensionAndSolution from "../../add-template/components/Liquid-And-Suspension-Parameters";
import PowderFillingParameters from "../../add-template/components/Powder-Filling-Parameters";
import SemiSolidParameters from "../../add-template/components/Semisolid-Parameters";
import EditPreview from "./components/Edit-Preview";

const { Title, Text } = Typography;

export default function EditTemplatePage() {
  const [form] = Form.useForm();
  const [submitting, setSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState('1');
  const [templateData, setTemplateData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [documentInfo, setDocumentInfo] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const router = useRouter();
  const params = useParams()
  const id = params?.id as string

  useEffect(() => {
    if (!id) return

    const fetchDocument = async () => {
      setLoading(true)
      try {
        const token = localStorage.getItem('token')
        const res = await fetch(`/api/user/production-template/manufacturing-template?id=${id}`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        })
        const data = await res.json()

        if (data.success && data.data) {
          const doc = data.data

          // Only allow editing if status is 'Reverted' or 'Draft'
          if (doc.status !== 'Reverted' && doc.status !== 'Draft') {
            setError(`Document with status '${doc.status}' cannot be edited. Only Reverted or Draft documents can be edited.`)
            setLoading(false)
            return
          }

          setDocumentInfo(doc)
          // Load fullTemplateData into context
          setTemplateData(doc.fullTemplateData || {})
        } else {
          setError(data.message || 'Document not found')
        }
      } catch (error) {
        console.error('Error fetching document:', error)
        setError('Failed to fetch document')
      } finally {
        setLoading(false)
      }
    }

    fetchDocument()
  }, [id])

  const handleNext = async () => {
    try {
      const resolvedActiveTab = tabItems.some((tab) => tab.key === activeTab)
        ? activeTab
        : tabItems[tabItems.length - 1]?.key || '1';
      const currentIndex = parseInt(resolvedActiveTab);
      const nextIndex = currentIndex + 1;
      const nextKey = nextIndex.toString();

      const tabExists = tabItems.some(tab => tab.key === nextKey);
      if (tabExists) {
        setActiveTab(nextKey);
      } else {
        message.success("All steps completed!");
      }
    } catch (error) {
      console.error("Validation failed:", error);
      message.error("Please fill all required fields");
    }
  };

  const handlePrevious = async () => {
    try {
      const resolvedActiveTab = tabItems.some((tab) => tab.key === activeTab)
        ? activeTab
        : tabItems[tabItems.length - 1]?.key || '1';
      const currentIndex = parseInt(resolvedActiveTab);
      const prevIndex = currentIndex - 1;
      if (prevIndex >= 1) {
        setActiveTab(prevIndex.toString());
      }
    } catch (error) {
      console.error("Error going back:", error);
    }
  };

  const handleGoBack = () => {
    router.push("/user/production-template/manufacturing-template");
  };

  const handleSaveDraft = async () => {
    if (!documentInfo?.templateCode) {
      message.error('Document information not available')
      return
    }

    try {
      setSubmitting(true)

      const token = localStorage.getItem('token')
      const response = await fetch('/api/user/production-template/manufacturing-template/update', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          documentId: documentInfo.templateCode,
          fullTemplateData: templateData,
          action: 'save'
        })
      })

      const data = await response.json()

      if (data.success) {
        message.success("Changes saved successfully as Draft!")
        router.push("/user/production-template/manufacturing-template")
      } else {
        message.error(data.message || "Failed to save changes")
      }
    } catch (error) {
      console.error("Error saving template:", error)
      message.error("Failed to save changes")
    } finally {
      setSubmitting(false)
    }
  }

  const handleSignSubmit = async () => {
    if (!documentInfo?.templateCode) {
      message.error('Document information not available')
      return
    }

    try {
      setSubmitting(true)

      const token = localStorage.getItem('token')
      const response = await fetch('/api/user/production-template/manufacturing-template/update', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          documentId: documentInfo.templateCode,
          fullTemplateData: templateData,
          action: 'submit'
        })
      })

      const data = await response.json()

      if (data.success) {
        message.success("Document updated and submitted for signing!")
        router.push("/user/production-template/manufacturing-template")
      } else {
        message.error(data.message || "Failed to submit document")
      }
    } catch (error) {
      console.error("Error submitting template:", error)
      message.error("Failed to submit document")
    } finally {
      setSubmitting(false)
    }
  }

  const buildTabItems = () => {
    const tabs: any[] = [];
    let stepNumber = 1;
    const dosageForm = templateData?.['Basic Information']?.dosageForm;
    const isCoatingRequired = templateData?.['Basic Information']?.coatingRequired;

    // Tab 1: Basic Information
    tabs.push({
      key: stepNumber.toString(),
      label: (
        <Space>
          <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
            {stepNumber}
          </span>
          <span>Basic Information</span>
        </Space>
      ),
      children: (
        <BasicInfoForm
          form={form}
          onNext={handleNext}
          onPrevious={handlePrevious}
        />
      ),
    });
    stepNumber++;

    // Tab 2: Manufacturing BOM
    tabs.push({
      key: stepNumber.toString(),
      label: (
        <Space>
          <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
            {stepNumber}
          </span>
          <span>Manufacturing BOM</span>
        </Space>
      ),
      children: (
        <ManufacturingBOMForm
          onNext={handleNext}
          onPrevious={handlePrevious}
        />
      ),
    });
    stepNumber++;

    // Tab 3: Facility & Equipment
    tabs.push({
      key: stepNumber.toString(),
      label: (
        <Space>
          <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
            {stepNumber}
          </span>
          <span>Facility & Equipment</span>
        </Space>
      ),
      children: (
        <FacilityEquipment
          onNext={handleNext}
          onPrevious={handlePrevious}
        />
      ),
    });
    stepNumber++;

    // Tab 4: Manufacturing Steps
    tabs.push({
      key: stepNumber.toString(),
      label: (
        <Space>
          <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
            {stepNumber}
          </span>
          <span>Manufacturing Steps</span>
        </Space>
      ),
      children: (
        <ManufacturingSteps
          onNext={handleNext}
          onPrevious={handlePrevious}
        />
      ),
    });
    stepNumber++;

    // Tab 5: Dosage Form Specific Parameters
    if (dosageForm === 'Tablet') {
      tabs.push({
        key: stepNumber.toString(),
        label: (
          <Space>
            <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
              {stepNumber}
            </span>
            <span>Compression Parameters</span>
          </Space>
        ),
        children: (
          <CompressionParameters
            onNext={handleNext}
            onPrevious={handlePrevious}
          />
        ),
      });
      stepNumber++;
    }
    else if (dosageForm === 'Capsule') {
      tabs.push({
        key: stepNumber.toString(),
        label: (
          <Space>
            <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
              {stepNumber}
            </span>
            <span>Encapsulation Parameters</span>
          </Space>
        ),
        children: (
          <EncapsulationParameters
            onNext={handleNext}
            onPrevious={handlePrevious}
          />
        ),
      });
      stepNumber++;
    }
    else if (['Syrup', 'Liquid Suspension', 'Solution', 'Drop'].includes(dosageForm)) {
      tabs.push({
        key: stepNumber.toString(),
        label: (
          <Space>
            <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
              {stepNumber}
            </span>
            <span>Liquid / Suspension Parameters</span>
          </Space>
        ),
        children: (
          <LiquidSuspensionAndSolution
            onNext={handleNext}
            onPrevious={handlePrevious}
          />
        ),
      });
      stepNumber++;
    }
    else if (['Dry Powder Suspension', 'Powder'].includes(dosageForm)) {
      tabs.push({
        key: stepNumber.toString(),
        label: (
          <Space>
            <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
              {stepNumber}
            </span>
            <span>Powder Filling Parameters</span>
          </Space>
        ),
        children: (
          <PowderFillingParameters
            onNext={handleNext}
            onPrevious={handlePrevious}
          />
        ),
      });
      stepNumber++;
    }
    else if (['Cream', 'Ointment', 'Gel', 'Lotion'].includes(dosageForm)) {
      tabs.push({
        key: stepNumber.toString(),
        label: (
          <Space>
            <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
              {stepNumber}
            </span>
            <span>Semisolid Parameters</span>
          </Space>
        ),
        children: (
          <SemiSolidParameters
            onNext={handleNext}
            onPrevious={handlePrevious}
          />
        ),
      });
      stepNumber++;
    }

    // Tab: Coating Section (only for tablets with coating required)
    if (dosageForm === 'Tablet' && isCoatingRequired === true) {
      tabs.push({
        key: stepNumber.toString(),
        label: (
          <Space>
            <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
              {stepNumber}
            </span>
            <span>Coating Section</span>
          </Space>
        ),
        children: (
          <CoatingSection
            onNext={handleNext}
            onPrevious={handlePrevious}
          />
        ),
      });
      stepNumber++;
    }

    // Final Tab: Preview with Edit buttons
    tabs.push({
      key: stepNumber.toString(),
      label: (
        <Space>
          <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
            {stepNumber}
          </span>
          <span>Final Preview</span>
        </Space>
      ),
      children: (
        <EditPreview
          onPrevious={handlePrevious}
          onSaveDraft={handleSaveDraft}
          onSignSubmit={handleSignSubmit}
          submitting={submitting}
          documentInfo={documentInfo}
        />
      ),
    });

    return tabs;
  };

  // Build tabs dynamically
  const tabItems = buildTabItems();
  const resolvedActiveTab = tabItems.some((tab) => tab.key === activeTab)
    ? activeTab
    : tabItems[tabItems.length - 1]?.key || '1';

  // Loading state
  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 400 }}>
        <Spin size="large" tip="Loading template for editing..." />
      </div>
    )
  }

  // Error state (not editable)
  if (error) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 400 }}>
        <Result
          status="error"
          title="Cannot Edit Document"
          subTitle={error}
          extra={[
            <Button key="back" type="primary" onClick={() => router.push('/user/production-template/manufacturing-template')}>
              Back to Templates
            </Button>
          ]}
        />
      </div>
    )
  }

  if (!documentInfo) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 400 }}>
        <Result
          status="warning"
          title="Document Not Found"
          extra={[
            <Button key="back" type="primary" onClick={() => router.push('/user/production-template/manufacturing-template')}>
              Back to Templates
            </Button>
          ]}
        />
      </div>
    )
  }

  return (
    <Space direction="vertical" size="middle" className="w-full">
      {/* Breadcrumb Card */}
      <Card size="small">
        <Breadcrumb
          items={[
            {
              href: '/user/production-template/manufacturing-template',
              title: (
                <Space>
                  <HomeOutlined />
                  <span>Manufacturing Templates</span>
                </Space>
              ),
            },
            {
              title: `Edit: ${documentInfo.templateCode || ''}`,
            },
          ]}
        />
      </Card>

      {/* Header Card */}
      <Card>
        <Space style={{ width: '100%', justifyContent: 'space-between' }}>
          <Space size="large">
            <Button
              type="text"
              icon={<ArrowLeftOutlined />}
              onClick={handleGoBack}
            />
            <div>
              <Title level={3} style={{ margin: 0 }}>
                Edit Manufacturing Template
              </Title>
              <Text type="secondary">
                {documentInfo.templateCode} | Version: {documentInfo.templateVersion} | Status: {documentInfo.status}
              </Text>
            </div>
          </Space>

          <Space size="middle">
            <Button
              icon={<SaveOutlined />}
              onClick={handleSaveDraft}
              loading={submitting}
            >
              Save Changes
            </Button>
            <Button
              type="primary"
              icon={<CheckCircleOutlined />}
              onClick={handleSignSubmit}
              loading={submitting}
            >
              Sign & Submit
            </Button>
          </Space>
        </Space>
      </Card>

      {/* Tabs Card */}
      <Card>
        <DataContext.Provider value={{ templateData, setTemplateData }}>
          <Tabs
            activeKey={resolvedActiveTab}
            onChange={setActiveTab}
            items={tabItems}
            type="line"
            destroyInactiveTabPane={false}
          />
        </DataContext.Provider>
      </Card>
    </Space>
  );
}