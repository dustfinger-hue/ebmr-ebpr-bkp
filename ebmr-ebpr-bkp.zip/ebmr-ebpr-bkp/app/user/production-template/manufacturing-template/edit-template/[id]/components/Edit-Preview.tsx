'use client'

import { DataContext } from "@/lib/utils/DataContext"
import {
  ArrowLeftOutlined,
  CheckCircleOutlined,
  InfoCircleOutlined,
  WarningOutlined,
  FileTextOutlined,
  SettingOutlined
} from "@ant-design/icons"
import { Button, Card, Col, Descriptions, Divider, Row, Space, Table, Tag, Typography, message, Badge } from "antd"
import { useRouter } from "next/navigation"
import { useContext } from "react"

const { Title, Text } = Typography

interface EditPreviewProps {
  onPrevious: () => void
  onSaveDraft: () => void
  onSignSubmit: () => void
  submitting: boolean
  documentInfo: any
}

export default function EditPreview({ onPrevious, onSaveDraft, onSignSubmit, submitting, documentInfo }: EditPreviewProps) {
  const { templateData } = useContext(DataContext)

  const basicInfo = templateData?.['Basic Information'] || {}
  const bomData = templateData?.['Manufacturing BOM']?.bomData || {}
  const bomOtherInfo = templateData?.['Manufacturing BOM']?.otherInfo || ''
  const manufacturingSteps = templateData?.['Manufacturing Steps'] || {}
  const facilityEquipment = templateData?.['Facility Equipment'] || {}
  const coatingSection = templateData?.['Coating Section'] || {}
  const compressionParams = templateData?.['Compression Parameters'] || {}
  const encapsulationParams = templateData?.['Encapsulation Parameters'] || {}
  const liquidParams = templateData?.['Liquid Suspension Parameters'] || {}
  const rawPowderParams = templateData?.['Powder Filling Parameters'] || {}
  // Flatten nested powder params for display
  const powderParams = {
    ...(rawPowderParams.machineSetup || {}),
    ...(rawPowderParams.containerSpecs || {}),
    ...(rawPowderParams.processParams || {}),
    ...(rawPowderParams.qualityControls || {}),
    cppValues: rawPowderParams.machineSetup?.cppValues || [],
    ipqcRows: rawPowderParams.qualityControls?.ipqcRows || [],
    powderDefects: rawPowderParams.qualityControls?.powderDefects || [],
  }
  const semisolidParams = templateData?.['Semisolid Parameters'] || {}
  const dosageForm = basicInfo.dosageForm
  const coatingRequired = basicInfo.coatingRequired
  const storageConditions = Array.isArray(basicInfo.storageConditions)
    ? basicInfo.storageConditions
    : basicInfo.storageConditions
      ? [basicInfo.storageConditions]
      : []

  const Router = useRouter();

  // Material columns for BOM
  const bomMaterialColumns = [
    { title: 'Code', dataIndex: 'materialCode', key: 'materialCode', width: 120 },
    { title: 'Name', dataIndex: 'materialName', key: 'materialName', width: 180 },
    { title: 'Category', dataIndex: 'materialCategory', key: 'materialCategory', width: 120 },
    { title: 'Qty', dataIndex: 'quantity', key: 'quantity', width: 80 },
    { title: 'UOM', dataIndex: 'uom', key: 'uom', width: 60 },
    { title: 'Usage Stage', dataIndex: 'usageStage', key: 'usageStage', width: 120 },
  ]

  // IPQC columns for mini tables
  const ipqcColumns = [
    { title: 'Parameter', dataIndex: 'parameterName', key: 'parameterName', width: 180 },
    { title: 'Specification', dataIndex: 'specification', key: 'specification', width: 200 },
    { title: 'Frequency', dataIndex: 'frequency', key: 'frequency', width: 120 },
  ]

  // CPP columns
  const cppColumns = [
    { title: 'Parameter', dataIndex: 'parameterName', key: 'parameterName', width: 180 },
    { title: 'Value', dataIndex: 'value', key: 'value', width: 80 },
    { title: 'Range', key: 'range', width: 180, render: (_: any, r: any) => `${r.minValue} - ${r.maxValue} ${r.unit}` },
  ]

  // Build material map for coating steps
  const coatingMaterials = (bomData?.materials || []).filter((m: any) => m.usageStage === 'Coating')
  const coatingMaterialMap: Record<string, { materialName: string; uom: string; totalQty: number }> = {}
  coatingMaterials.forEach((m: any) => {
    coatingMaterialMap[m.materialCode] = {
      materialName: m.materialName,
      uom: m.uom,
      totalQty: Number(m.quantity || 0)
    }
  })

  const getCoatingConsumed = (materialCode: string) => {
    const steps = coatingSection?.solutionPrep?.steps || []
    return steps.reduce((total: number, step: any) => {
      const m = step.materials.find((s: any) => s.materialCode === materialCode)
      return total + Number(m?.quantity || 0)
    }, 0)
  }

  return (
    <div className="space-y-4">
      {/* ============================================ */}
      {/* SECTION 1: BASIC INFORMATION */}
      {/* ============================================ */}
      <Card style={{ marginBottom: 6 }}
        title={
          <Space>
            <InfoCircleOutlined className="text-blue-500" />
            <Title level={5} style={{ margin: 0 }}>Basic Information</Title>
          </Space>
        }
      >
        <Row gutter={[24, 16]}>
          <Col span={24}>
            <Descriptions column={3} size="small" bordered>
              <Descriptions.Item label="Template Code">{basicInfo.templateCode || documentInfo?.templateCode || '-'}</Descriptions.Item>
              <Descriptions.Item label="Version">{basicInfo.templateVersion || '-'}</Descriptions.Item>
              <Descriptions.Item label="Template Name">{basicInfo.templateName || '-'}</Descriptions.Item>
              <Descriptions.Item label="Template Type">{basicInfo.templateType || '-'}</Descriptions.Item>
              <Descriptions.Item label="Product Name">{basicInfo.productName || '-'}</Descriptions.Item>
              <Descriptions.Item label="Product Code">{basicInfo.productCode || '-'}</Descriptions.Item>
              <Descriptions.Item label="Dosage Form"><Tag color="blue">{dosageForm || '-'}</Tag></Descriptions.Item>
              <Descriptions.Item label="Strength">{basicInfo.strength || '-'}</Descriptions.Item>
              <Descriptions.Item label="Batch Size (Bulk)">{basicInfo.batchSizeBulk ? `${basicInfo.batchSizeBulk} ${basicInfo.uomBulk || ''}` : '-'}</Descriptions.Item>
              <Descriptions.Item label="Batch Size (Semi)">{basicInfo.batchSizeSemiFinished ? `${basicInfo.batchSizeSemiFinished} ${basicInfo.uomSemiFinished || ''}` : '-'}</Descriptions.Item>
              <Descriptions.Item label="Storage Conditions">
                {storageConditions.length > 0
                  ? storageConditions.map((s: string) => <Tag key={s}>{s}</Tag>)
                  : '-'}
              </Descriptions.Item>
              <Descriptions.Item label="Shelf Life">{basicInfo.shelfLife ? `${basicInfo.shelfLife} months` : '-'}</Descriptions.Item>
              <Descriptions.Item label="Drug Reg. No.">{basicInfo.drugRegistrationNumber || '-'}</Descriptions.Item>
              <Descriptions.Item label="Effective Date">{basicInfo.effectiveDate ? (typeof basicInfo.effectiveDate === 'string' ? basicInfo.effectiveDate : basicInfo.effectiveDate?.format?.('YYYY-MM-DD') || '-') : '-'}</Descriptions.Item>
              <Descriptions.Item label="Manufacturing BOM Code">{basicInfo.manufacturingBomCode || '-'}</Descriptions.Item>
              <Descriptions.Item label="Status"><Tag color={basicInfo.status === 'Active' ? 'green' : 'orange'}>{basicInfo.status || '-'}</Tag></Descriptions.Item>
            </Descriptions>
          </Col>
        </Row>
        {dosageForm === 'Tablet' && basicInfo.tabletType && (
          <div style={{ marginTop: 12 }}>
            <Text strong>Tablet Type: </Text><Tag color="purple">{basicInfo.tabletType}</Tag>
            {coatingRequired && <Tag color="cyan" style={{ marginLeft: 8 }}>Coating Required</Tag>}
          </div>
        )}
      </Card>

      {/* ============================================ */}
      {/* SECTION 2: MANUFACTURING BOM */}
      {/* ============================================ */}
      {bomData?.materials?.length > 0 && (
        <Card style={{ marginBottom: 6 }} title={
          <Space>
            <FileTextOutlined className="text-blue-500" />
            <Title level={5} style={{ margin: 0 }}>Manufacturing BOM</Title>
          </Space>
        }>
          <Descriptions column={3} size="small" style={{ marginBottom: 16 }}>
            <Descriptions.Item label="BOM Code">{bomData.bomCode || '-'}</Descriptions.Item>
            <Descriptions.Item label="Version">{bomData.bomVersion || '-'}</Descriptions.Item>
            <Descriptions.Item label="Product">{bomData.productName || '-'}</Descriptions.Item>
          </Descriptions>
          <Table
            columns={bomMaterialColumns}
            dataSource={bomData.materials}
            rowKey="materialCode"
            pagination={false}
            size="small"
            scroll={{ x: 700 }}
          />
          {/* Additional Notes / Other Info */}
          {bomOtherInfo && (
            <div style={{ marginTop: 16 }}>
              <Divider orientation="horizontal">Additional Notes & Instructions</Divider>
              <div dangerouslySetInnerHTML={{ __html: bomOtherInfo }} />
            </div>
          )}
        </Card>
      )}

      {/* ============================================ */}
      {/* SECTION 3: FACILITY & EQUIPMENT */}
      {/* ============================================ */}
      {facilityEquipment?.facilitiesWithEquipment?.length > 0 && (
        <Card style={{ marginBottom: 6 }} title={
          <Space>
            <SettingOutlined className="text-blue-500" />
            <Title level={5} style={{ margin: 0 }}>Facility & Equipment</Title>
          </Space>
        }>
          {facilityEquipment.facilitiesWithEquipment.map((facility: any, idx: number) => (
            <Card key={idx} size="small" title={facility.areaName || `Facility ${idx + 1}`} style={{ marginBottom: 12 }}>
              {facility.equipments?.map((eq: any, eqIdx: number) => (
                <Tag key={eqIdx} color="blue" style={{ marginBottom: 4 }}>{eq.equipmentName} ({eq.equipmentCode})</Tag>
              ))}
              {(!facility.equipments || facility.equipments.length === 0) && <Text type="secondary">No equipment</Text>}
            </Card>
          ))}
        </Card>
      )}

      {/* ============================================ */}
      {/* SECTION 4: MANUFACTURING STEPS */}
      {/* ============================================ */}
      {manufacturingSteps?.layers && Object.keys(manufacturingSteps.layers).length > 0 && (
        <Card style={{ marginBottom: 6 }} title={
          <Space>
            <CheckCircleOutlined className="text-blue-500" />
            <Title level={5} style={{ margin: 0 }}>Manufacturing Steps</Title>
          </Space>
        }>
          {Object.entries(manufacturingSteps.layers).map(([layerName, layerData]: [string, any]) => (
            <Card key={layerName} size="small" title={layerName} style={{ marginBottom: 12 }}>
              {layerData.lots && Object.entries(layerData.lots).map(([lotKey, lotData]: [string, any]) => (
                <div key={lotKey} style={{ marginBottom: 12 }}>
                  <Text strong style={{ fontSize: 13 }}>{lotKey.replace(/-/g, ' ').toUpperCase()}</Text>
                  <div style={{ marginTop: 8 }}>
                    {(lotData.steps || []).map((step: any, idx: number) => (
                      <Card key={step.id} size="small" style={{ marginBottom: 8 }}>
                        <Space wrap>
                          <Tag color="blue">Step {idx + 1}</Tag>
                          <Text strong>{step.stepName}</Text>
                          {step.machineName && <Tag color="purple">{step.machineName}</Tag>}
                        </Space>
                        {step.stepDescription && <div><Text type="secondary">{step.stepDescription}</Text></div>}
                        {step.materials?.length > 0 && (
                          <div style={{ marginTop: 4 }}>
                            {step.materials.map((m: any) => (
                              <Tag key={m.materialCode} color="green">{m.materialCode}: {m.quantity}</Tag>
                            ))}
                          </div>
                        )}
                        {step.cppValues?.length > 0 && (
                          <div style={{ marginTop: 4 }}>
                            {step.cppValues.map((cpp: any) => (
                              <Tag key={`${step.id}_${cpp.parameterName}`} color="geekblue">
                                {cpp.parameterName}: {cpp.value} {cpp.unit}
                              </Tag>
                            ))}
                          </div>
                        )}
                      </Card>
                    ))}
                  </div>
                </div>
              ))}
            </Card>
          ))}
        </Card>
      )}

      {/* ============================================ */}
      {/* SECTION 5: COMPRESSION PARAMETERS (Tablet) */}
      {/* ============================================ */}
      {dosageForm === 'Tablet' && compressionParams?.machineSetup && (
        <Card style={{ marginBottom: 6 }} title={
          <Space>
            <SettingOutlined className="text-orange-500" />
            <Title level={5} style={{ margin: 0 }}>Compression Parameters</Title>
          </Space>
        }>
          {/* Machine Setup */}
          <Divider orientation="horizontal">Machine Setup</Divider>
          <Descriptions column={2} size="small">
            <Descriptions.Item label="Machine Name">{compressionParams.machineSetup?.machineType || '-'}</Descriptions.Item>
            <Descriptions.Item label="Machine ID / Code">{compressionParams.machineSetup?.machineId || '-'}</Descriptions.Item>
            <Descriptions.Item label="Location">{compressionParams.machineSetup?.machineLocation || '-'}</Descriptions.Item>
            <Descriptions.Item label="Number of Stations">{compressionParams.machineSetup?.numberOfStations || '-'}</Descriptions.Item>
            <Descriptions.Item label="Operating Speed">{compressionParams.machineSetup?.operatingSpeed ? `${compressionParams.machineSetup.operatingSpeed} tabs/hr` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Max Speed">{compressionParams.machineSetup?.maxSpeed ? `${compressionParams.machineSetup.maxSpeed} tabs/hr` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Pre-Compression Type">{compressionParams.machineSetup?.preCompressionType || '-'}</Descriptions.Item>
          </Descriptions>

          {/* Machine CPP Parameters */}
          {compressionParams.machineSetup?.cppParameters?.length > 0 && (
            <>
              <Divider orientation="horizontal">CPP Parameters (Machine)</Divider>
              <Table
                columns={[
                  { title: 'Parameter', dataIndex: 'parameterName', key: 'parameterName', width: 200 },
                  { title: 'Value', dataIndex: 'minValue', key: 'minValue', width: 80, render: (v: any, r: any) => r.minValue === r.maxValue ? r.minValue : `${r.minValue} - ${r.maxValue}` },
                  { title: 'Unit', dataIndex: 'unit', key: 'unit', width: 80 },
                ]}
                dataSource={compressionParams.machineSetup.cppParameters}
                rowKey="parameterName"
                pagination={false}
                size="small"
              />
            </>
          )}

          {/* Tooling Specs */}
          <Divider orientation="horizontal">Tooling Specifications</Divider>
          <Descriptions column={2} size="small">
            <Descriptions.Item label="Tooling Type">{compressionParams.toolingSpecs?.toolingType || '-'}</Descriptions.Item>
            <Descriptions.Item label="Tooling Material">{compressionParams.toolingSpecs?.toolingMaterial || '-'}</Descriptions.Item>
            <Descriptions.Item label="Tooling Coating">{compressionParams.toolingSpecs?.toolingCoating || '-'}</Descriptions.Item>
            <Descriptions.Item label="Die Bore Size">{compressionParams.toolingSpecs?.dieBoreSize ? `${compressionParams.toolingSpecs.dieBoreSize} mm` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Die Thickness">{compressionParams.toolingSpecs?.dieThickness ? `${compressionParams.toolingSpecs.dieThickness} mm` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Upper Punch Length">{compressionParams.toolingSpecs?.upperPunchLength ? `${compressionParams.toolingSpecs.upperPunchLength} mm` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Lower Punch Length">{compressionParams.toolingSpecs?.lowerPunchLength ? `${compressionParams.toolingSpecs.lowerPunchLength} mm` : '-'}</Descriptions.Item>
          </Descriptions>

          {/* Punch Specs Table */}
          {compressionParams.toolingSpecs?.punchSpecs?.length > 0 && (
            <>
              <Divider orientation="horizontal">Punch Specifications</Divider>
              <Table
                columns={[
                  { title: 'Type', dataIndex: 'punchType', key: 'punchType', width: 80 },
                  { title: 'Shape', dataIndex: 'punchShape', key: 'punchShape', width: 100 },
                  { title: 'Diameter (mm)', dataIndex: 'punchDiameter', key: 'punchDiameter', width: 100 },
                  { title: 'Length (mm)', dataIndex: 'punchLength', key: 'punchLength', width: 100 },
                  { title: 'Cup Depth (mm)', dataIndex: 'cupDepth', key: 'cupDepth', width: 100 },
                  { title: 'Embossing', dataIndex: 'embossingType', key: 'embossingType', width: 100 },
                  { title: 'Breakline', dataIndex: 'breakline', key: 'breakline', width: 80, render: (v: boolean) => v ? <Tag color="green">Yes</Tag> : <Tag color="red">No</Tag> },
                ]}
                dataSource={compressionParams.toolingSpecs.punchSpecs}
                rowKey="id"
                pagination={false}
                size="small"
                scroll={{ x: 700 }}
              />
            </>
          )}

          {/* Compression Process Parameters */}
          {compressionParams.compressionParams && (
            <>
              <Divider orientation="horizontal">Compression Process Parameters</Divider>
              {compressionParams.compressionParams.tabletDescription && (
                <div style={{ marginBottom: 12 }}>
                  <Text strong>Tablet Description: </Text>
                  <Text>{compressionParams.compressionParams.tabletDescription}</Text>
                </div>
              )}
              <Descriptions column={2} size="small">
                <Descriptions.Item label="Target Tablet Weight">{compressionParams.compressionParams.targetTabletWeight ? `${compressionParams.compressionParams.targetTabletWeight} mg` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Weight Tolerance">{compressionParams.compressionParams.tabletWeightTolerance ? `±${compressionParams.compressionParams.tabletWeightTolerance} mg` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Target Thickness">{compressionParams.compressionParams.targetTabletThickness ? `${compressionParams.compressionParams.targetTabletThickness} mm` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Thickness Tolerance">{compressionParams.compressionParams.thicknessTolerance ? `±${compressionParams.compressionParams.thicknessTolerance} mm` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Target Hardness">{compressionParams.compressionParams.targetHardness ? `${compressionParams.compressionParams.targetHardness} kP` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Hardness Tolerance">{compressionParams.compressionParams.hardnessTolerance ? `±${compressionParams.compressionParams.hardnessTolerance} kP` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Disintegration Time">{compressionParams.compressionParams.disintegrationTime ? `${compressionParams.compressionParams.disintegrationTime} s` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Disintegration Temp">{compressionParams.compressionParams.disintegrationTemperature ? `${compressionParams.compressionParams.disintegrationTemperature} °C` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Friability Tolerance">{compressionParams.compressionParams.friabilityTolerance ? `< ${compressionParams.compressionParams.friabilityTolerance}%` : '-'}</Descriptions.Item>
              </Descriptions>
            </>
          )}

          {/* Quality Controls */}
          {compressionParams.qualityControls && (
            <>
              <Divider orientation="horizontal"><WarningOutlined className="mr-2" /> Quality Controls (IPQC)</Divider>
              <Descriptions column={2} size="small">
                <Descriptions.Item label="Weight Check Frequency">{compressionParams.qualityControls.weightCheckFrequency || '-'}</Descriptions.Item>
                <Descriptions.Item label="Hardness Check Frequency">{compressionParams.qualityControls.hardnessCheckFrequency || '-'}</Descriptions.Item>
                <Descriptions.Item label="Thickness Check Frequency">{compressionParams.qualityControls.thicknessCheckFrequency || '-'}</Descriptions.Item>
                <Descriptions.Item label="Appearance Check Frequency">{compressionParams.qualityControls.appearanceCheckFrequency || '-'}</Descriptions.Item>
                <Descriptions.Item label="Sample Size (Weight)">{compressionParams.qualityControls.sampleSizeWeight || '-'}</Descriptions.Item>
                <Descriptions.Item label="Sample Size (Hardness/Thickness)">{compressionParams.qualityControls.sampleSizeHardnessThickness || '-'}</Descriptions.Item>
                <Descriptions.Item label="Weight Rejection Limit">{compressionParams.qualityControls.weightRejectionLimit ? `±${compressionParams.qualityControls.weightRejectionLimit} mg` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Hardness Rejection Limit">{compressionParams.qualityControls.hardnessRejectionLimit ? `±${compressionParams.qualityControls.hardnessRejectionLimit} kP` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Thickness Rejection Limit">{compressionParams.qualityControls.thicknessRejectionLimit ? `±${compressionParams.qualityControls.thicknessRejectionLimit} mm` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Metal Detector Sensitivity">{compressionParams.qualityControls.metalDetectorSensitivity ? `${compressionParams.qualityControls.metalDetectorSensitivity} mm` : '-'}</Descriptions.Item>
              </Descriptions>
            </>
          )}

          {compressionParams.qualityControls?.defectTypes?.length > 0 && (
            <>
              <Divider orientation="horizontal"><WarningOutlined className="mr-2 text-red-500" /> Compressed Tablet Defects</Divider>
              <Space wrap>
                {compressionParams.qualityControls.defectTypes.map((d: string) => (
                  <Tag key={d} color="red">{d}</Tag>
                ))}
              </Space>
            </>
          )}

          {compressionParams.qualityControls?.specialInstructions && (
            <>
              <Divider orientation="horizontal">Special Instructions</Divider>
              <Text>{compressionParams.qualityControls.specialInstructions}</Text>
            </>
          )}
        </Card>
      )}

      {/* ============================================ */}
      {/* SECTION 6: ENCAPSULATION PARAMETERS (Capsule) */}
      {/* ============================================ */}
      {dosageForm === 'Capsule' && encapsulationParams?.machine && (
        <Card style={{ marginBottom: 6 }} title={
          <Space>
            <SettingOutlined className="text-orange-500" />
            <Title level={5} style={{ margin: 0 }}>Encapsulation Parameters</Title>
          </Space>
        }>
          <Descriptions column={2} size="small">
            <Descriptions.Item label="Machine">{encapsulationParams.machine}</Descriptions.Item>
            <Descriptions.Item label="Machine ID">{encapsulationParams.machineId || '-'}</Descriptions.Item>
            <Descriptions.Item label="Location">{encapsulationParams.machineLocation || '-'}</Descriptions.Item>
            <Descriptions.Item label="Capsule Size"><Tag color="blue">{encapsulationParams.capsuleSize || '-'}</Tag></Descriptions.Item>
            <Descriptions.Item label="Capsule Type">{encapsulationParams.capsuleType || '-'}</Descriptions.Item>
            <Descriptions.Item label="Color">{encapsulationParams.capsuleColor || '-'}</Descriptions.Item>
            <Descriptions.Item label="Fill Weight">{encapsulationParams.targetFillWeight || '-'} mg</Descriptions.Item>
            <Descriptions.Item label="Capsule Weight (Shell + Fill)">{encapsulationParams.targetCapsuleWeight ? `${encapsulationParams.targetCapsuleWeight} mg` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Tolerance">{encapsulationParams.fillWeightTolerance ? `±${encapsulationParams.fillWeightTolerance} mg` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Speed">{encapsulationParams.productionSpeed || '-'} caps/hr</Descriptions.Item>
            <Descriptions.Item label="Tamping Force">{encapsulationParams.tampingForce || '-'} N</Descriptions.Item>
          </Descriptions>

          {encapsulationParams.cppValues?.length > 0 && (
            <>
              <Divider><SettingOutlined className="mr-2" /> Critical Process Parameters</Divider>
              <Table columns={cppColumns} dataSource={encapsulationParams.cppValues} rowKey="parameterName" pagination={false} size="small" />
            </>
          )}

          {encapsulationParams.ipqcRows?.length > 0 && (
            <>
              <Divider><WarningOutlined className="mr-2" /> IPQC</Divider>
              <Table columns={ipqcColumns} dataSource={encapsulationParams.ipqcRows} rowKey="id" pagination={false} size="small" />
            </>
          )}
          {encapsulationParams.encapsulationDefects?.length > 0 && (
            <>
              <Divider><WarningOutlined className="mr-2 text-red-500" /> Defects</Divider>
              <Space wrap>{encapsulationParams.encapsulationDefects.map((d: string) => <Tag key={d} color="red">{d}</Tag>)}</Space>
            </>
          )}
        </Card>
      )}

      {/* ============================================ */}
      {/* SECTION 7: LIQUID / SUSPENSION PARAMS */}
      {/* ============================================ */}
      {['Syrup', 'Liquid Suspension', 'Solution', 'Drop'].includes(dosageForm) && (
        <Card style={{ marginBottom: 6 }} title={
          <Space>
            <SettingOutlined className="text-orange-500" />
            <Title level={5} style={{ margin: 0 }}>Liquid / Suspension Parameters</Title>
          </Space>
        }>
          <Descriptions column={2} size="small">
            <Descriptions.Item label="Machine">{liquidParams.machineSetup?.machine}</Descriptions.Item>
            <Descriptions.Item label="Machine ID">{liquidParams.machineSetup?.machineId || '-'}</Descriptions.Item>
            <Descriptions.Item label="Bottle Type">{liquidParams.containerSpecs?.bottleType || '-'}</Descriptions.Item>
            <Descriptions.Item label="Bottle Size">{liquidParams.containerSpecs?.bottleSize ? `${liquidParams.containerSpecs.bottleSize} ml` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Cap Type">{liquidParams.containerSpecs?.capType || '-'}</Descriptions.Item>
            <Descriptions.Item label="Seal Type">{liquidParams.containerSpecs?.sealType || '-'}</Descriptions.Item>
            <Descriptions.Item label="Closure Torque">{liquidParams.containerSpecs?.closureTorque ? `${liquidParams.containerSpecs.closureTorque} N·m` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Fill Volume">{liquidParams.processParams?.targetFillVolume ? `${liquidParams.processParams.targetFillVolume} ml` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Density">{liquidParams.processParams?.productDensity ? `${liquidParams.processParams.productDensity} g/ml` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Mix Speed">{liquidParams.processParams?.mixingSpeed ? `${liquidParams.processParams.mixingSpeed} RPM` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Mix Time">{liquidParams.processParams?.mixingTime ? `${liquidParams.processParams.mixingTime} min` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Production Speed">{liquidParams.processParams?.productionSpeed ? `${liquidParams.processParams.productionSpeed} bottles/hr` : '-'}</Descriptions.Item>
          </Descriptions>

          {liquidParams.machineSetup?.cppValues?.length > 0 && (
            <>
              <Divider><SettingOutlined className="mr-2" /> Critical Process Parameters</Divider>
              <Table columns={cppColumns} dataSource={liquidParams.machineSetup.cppValues} rowKey="parameterName" pagination={false} size="small" />
            </>
          )}

          {liquidParams.qualityControls?.ipqcRows?.length > 0 && (
            <>
              <Divider><WarningOutlined className="mr-2" /> IPQC</Divider>
              <Table columns={ipqcColumns} dataSource={liquidParams.qualityControls.ipqcRows} rowKey="id" pagination={false} size="small" />
            </>
          )}
          {liquidParams.qualityControls?.liquidDefects?.length > 0 && (
            <>
              <Divider><WarningOutlined className="mr-2 text-red-500" /> Defects</Divider>
              <Space wrap>{liquidParams.qualityControls.liquidDefects.map((d: string) => <Tag key={d} color="red">{d}</Tag>)}</Space>
            </>
          )}
        </Card>
      )}

      {/* ============================================ */}
      {/* SECTION 8: DRY POWDER / POWDER */}
      {/* ============================================ */}
      {['Dry Powder Suspension', 'Powder'].includes(dosageForm) && (
        <Card style={{ marginBottom: 6 }} title={
          <Space>
            <SettingOutlined className="text-orange-500" />
            <Title level={5} style={{ margin: 0 }}>Powder Filling Parameters</Title>
          </Space>
        }>
          <Descriptions column={2} size="small">
            <Descriptions.Item label="Machine">{powderParams.machine || '-'}</Descriptions.Item>
            <Descriptions.Item label="Machine ID">{powderParams.machineId || '-'}</Descriptions.Item>
            <Descriptions.Item label="Location">{powderParams.machineLocation || '-'}</Descriptions.Item>
            <Descriptions.Item label="Container Type">{powderParams.containerType || '-'}</Descriptions.Item>
            <Descriptions.Item label="Container / Pack Size">{powderParams.containerSize ? `${powderParams.containerSize} g` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Cap / Closure">{powderParams.capType || '-'}</Descriptions.Item>
            <Descriptions.Item label="Seal Type">{powderParams.sealType || '-'}</Descriptions.Item>
            <Descriptions.Item label="Target Fill Weight">{powderParams.targetFillWeight ? `${powderParams.targetFillWeight} g` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Fill Weight Tolerance">{powderParams.fillWeightTolerance ? `±${powderParams.fillWeightTolerance} g` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Production Speed">{powderParams.productionSpeed ? `${powderParams.productionSpeed} packs/hr` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Bulk Density">{powderParams.bulkDensity ? `${powderParams.bulkDensity} g/ml` : '-'}</Descriptions.Item>
            <Descriptions.Item label="LOD / Moisture Limit">{powderParams.lossOnDryingLimit ? `${powderParams.lossOnDryingLimit}%` : '-'}</Descriptions.Item>
          </Descriptions>

          {powderParams.cppValues?.length > 0 && (
            <>
              <Divider><SettingOutlined className="mr-2" /> Critical Process Parameters</Divider>
              <Table columns={cppColumns} dataSource={powderParams.cppValues} rowKey="parameterName" pagination={false} size="small" />
            </>
          )}

          {powderParams.ipqcRows?.length > 0 && (
            <>
              <Divider><WarningOutlined className="mr-2" /> IPQC</Divider>
              <Table columns={ipqcColumns} dataSource={powderParams.ipqcRows} rowKey="id" pagination={false} size="small" />
            </>
          )}

          {powderParams.powderDefects?.length > 0 && (
            <>
              <Divider><WarningOutlined className="mr-2 text-red-500" /> Defects</Divider>
              <Space wrap>{powderParams.powderDefects.map((d: string) => <Tag key={d} color="red">{d}</Tag>)}</Space>
            </>
          )}
        </Card>
      )}

      {/* ============================================ */}
      {/* SECTION 9: SEMISOLID PARAMETERS */}
      {/* ============================================ */}
      {['Cream', 'Ointment', 'Gel', 'Lotion'].includes(dosageForm) && semisolidParams && (
        <Card style={{ marginBottom: 6 }} title={
          <Space>
            <SettingOutlined className="text-orange-500" />
            <Title level={5} style={{ margin: 0 }}>Semisolid Parameters</Title>
          </Space>
        }>
          <Descriptions column={2} size="small">
            <Descriptions.Item label="Machine">{semisolidParams.machineSetup?.machine}</Descriptions.Item>
            <Descriptions.Item label="Machine ID">{semisolidParams.machineSetup?.machineId || '-'}</Descriptions.Item>
            <Descriptions.Item label="Container Type">{semisolidParams.containerSpecs?.containerType || '-'}</Descriptions.Item>
            <Descriptions.Item label="Container Size">{semisolidParams.containerSpecs?.containerSize ? `${semisolidParams.containerSpecs.containerSize} g` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Cap Type">{semisolidParams.containerSpecs?.capType || '-'}</Descriptions.Item>
            <Descriptions.Item label="Seal Type">{semisolidParams.containerSpecs?.sealType || '-'}</Descriptions.Item>
            <Descriptions.Item label="Fill Weight">{semisolidParams.fillParams?.targetFillWeight ? `${semisolidParams.fillParams.targetFillWeight} g` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Fill Tolerance">{semisolidParams.fillParams?.fillWeightTolerance ? `±${semisolidParams.fillParams.fillWeightTolerance} g` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Production Speed">{semisolidParams.fillParams?.productionSpeed ? `${semisolidParams.fillParams.productionSpeed} units/hr` : '-'}</Descriptions.Item>
          </Descriptions>

          {semisolidParams.machineSetup?.cppValues?.length > 0 && (
            <>
              <Divider><SettingOutlined className="mr-2" /> Critical Process Parameters</Divider>
              <Table columns={cppColumns} dataSource={semisolidParams.machineSetup.cppValues} rowKey="parameterName" pagination={false} size="small" />
            </>
          )}

          {semisolidParams.qualityControls?.ipqcRows?.length > 0 && (
            <>
              <Divider><WarningOutlined className="mr-2" /> IPQC</Divider>
              <Table columns={ipqcColumns} dataSource={semisolidParams.qualityControls.ipqcRows} rowKey="id" pagination={false} size="small" />
            </>
          )}
          {semisolidParams.qualityControls?.semisolidDefects?.length > 0 && (
            <>
              <Divider><WarningOutlined className="mr-2 text-red-500" /> Defects</Divider>
              <Space wrap>{semisolidParams.qualityControls.semisolidDefects.map((d: string) => <Tag key={d} color="red">{d}</Tag>)}</Space>
            </>
          )}
        </Card>
      )}

      {/* ============================================ */}
      {/* SECTION 10: COATING SECTION */}
      {/* ============================================ */}
      {dosageForm === 'Tablet' && coatingRequired && coatingSection && (
        <Card style={{ marginBottom: 6 }} title={
          <Space>
            <CheckCircleOutlined className="text-green-500" />
            <Title level={5} style={{ margin: 0 }}>Coating Section</Title>
          </Space>
        }>
          {coatingSection.solutionPrep?.steps?.length > 0 && (
            <>
              <Divider>Solution Preparation Steps</Divider>
              {Object.keys(coatingMaterialMap).length > 0 && (
                <Space wrap style={{ marginBottom: 12 }}>
                  {Object.entries(coatingMaterialMap).map(([code, mat]) => {
                    const consumed = getCoatingConsumed(code)
                    return (
                      <Tag key={code} color={consumed >= mat.totalQty ? 'green' : 'orange'}>
                        {mat.materialName}: {consumed}/{mat.totalQty} {mat.uom}
                      </Tag>
                    )
                  })}
                </Space>
              )}
              {coatingSection.solutionPrep.steps.map((step: any, idx: number) => (
                <Card key={step.id} size="small" style={{ marginBottom: 8 }}>
                  <Space wrap>
                    <Tag color="blue">Step {idx + 1}</Tag>
                    <Text strong>{step.stepName}</Text>
                    {step.machineName && <Tag color="purple">{step.machineName}</Tag>}
                  </Space>
                  {step.stepDescription && <div><Text type="secondary">{step.stepDescription}</Text></div>}
                  {step.materials?.length > 0 && (
                    <div style={{ marginTop: 4 }}>
                      {step.materials.map((m: any) => (
                        <Tag key={m.materialCode} color="green">
                          {coatingMaterialMap[m.materialCode]?.materialName || m.materialCode}: {m.quantity} {coatingMaterialMap[m.materialCode]?.uom || ''}
                        </Tag>
                      ))}
                    </div>
                  )}
                  {step.cppValues?.length > 0 && (
                    <div style={{ marginTop: 4 }}>
                      {step.cppValues.map((cpp: any) => (
                        <Tag key={`${step.id}_${cpp.parameterName}`} color="geekblue">
                          {cpp.parameterName}: {cpp.value} {cpp.unit}
                        </Tag>
                      ))}
                    </div>
                  )}
                </Card>
              ))}
            </>
          )}

          {coatingSection.coatingParams?.machine && (
            <>
              <Divider>Coating Parameters</Divider>
              <Descriptions column={2} size="small">
                <Descriptions.Item label="Machine">{coatingSection.coatingParams.machine}</Descriptions.Item>
                <Descriptions.Item label="Machine ID">{coatingSection.coatingParams.machineId || '-'}</Descriptions.Item>
                <Descriptions.Item label="Location">{coatingSection.coatingParams.machineLocation || '-'}</Descriptions.Item>
              </Descriptions>
              {coatingSection.coatingParams.cppValues?.length > 0 && (
                <>
                  <Divider>CPP Values</Divider>
                  <Table columns={cppColumns} dataSource={coatingSection.coatingParams.cppValues} rowKey="parameterName" pagination={false} size="small" />
                </>
              )}
              {coatingSection.coatingParams.ipqcRows?.length > 0 && (
                <>
                  <Divider><WarningOutlined className="mr-2" /> IPQC</Divider>
                  <Table columns={ipqcColumns} dataSource={coatingSection.coatingParams.ipqcRows} rowKey="id" pagination={false} size="small" />
                </>
              )}
              {coatingSection.coatingParams.coatingDefects?.length > 0 && (
                <>
                  <Divider><WarningOutlined className="mr-2 text-red-500" /> Defects</Divider>
                  <Space wrap>{coatingSection.coatingParams.coatingDefects.map((d: string) => <Tag key={d} color="red">{d}</Tag>)}</Space>
                </>
              )}
            </>
          )}
        </Card>
      )}

      {/* ============================================ */}
      {/* ACTIONS BUTTONS */}
      {/* ============================================ */}
      <div className="flex justify-end gap-2 pt-4 border-t border-gray-800">
        <Button
          icon={<ArrowLeftOutlined />}
          onClick={onPrevious}
          size="large"
        >
          Previous
        </Button>
        <Button
          icon={<CheckCircleOutlined />}
          onClick={onSaveDraft}
          size="large"
          loading={submitting}
        >
          Save Changes
        </Button>
        <Button
          type="primary"
          icon={<CheckCircleOutlined />}
          onClick={onSignSubmit}
          size="large"
          loading={submitting}
        >
          Sign & Submit
        </Button>
      </div>
    </div>
  )
}