'use client'
import { Tabs, Button, Card, Typography, message, Form, Breadcrumb, Space } from "antd";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeftOutlined, HomeOutlined, FileSearchOutlined } from "@ant-design/icons";
import BasicInfoForm from "./components/Basic-info";
import ManufacturingBOMForm from "./components/Manufacturing-BOM";
import { DataContext } from "@/lib/utils/DataContext";
import { ReferenceDataProvider } from "@/lib/utils/ReferenceDataContext";
import FacilityEquipment from "./components/Facility-Equipment";
import ManufacturingSteps from "./components/Manufacturing-Steps";
import CompressionParameters from "./components/Compression-Parameters";
import CoatingSection from "./components/Coating-Section";
import EncapsulationParameters from "./components/Encapsulation-Parameters";
import LiquidSuspensionAndSolution from "./components/Liquid-And-Suspension-Parameters";
import PowderFillingParameters from "./components/Powder-Filling-Parameters";
import SemiSolidParameters from "./components/Semisolid-Parameters";
import FinalPreview from "./components/Final-Preview";
import CopyReferenceSidebar from "./components/Copy-Reference-Sidebar";

const { Title, Text } = Typography;

export default function AddTemplatePage() {
  const [form] = Form.useForm();
  const [activeTab, setActiveTab] = useState('1');
  const [templateData, setTemplateData] = useState<any>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const router = useRouter();

  useEffect(() => {
    console.log(templateData)
  }, [templateData])

  const handleNext = async () => {
    try {
      const resolvedActiveTab = tabItems.some((tab) => tab.key === activeTab)
        ? activeTab
        : tabItems[tabItems.length - 1]?.key || '1';
      const currentIndex = parseInt(resolvedActiveTab);
      const nextIndex = currentIndex + 1;
      const nextKey = nextIndex.toString();

      // Check if next tab exists
      const tabExists = tabItems.some(tab => tab.key === nextKey);
      if (tabExists) {
        setActiveTab(nextKey);
      } else {
        message.success("All steps completed!");
      }
    } catch (error) {
      console.error("Validation failed:", error);
      message.error("Please fill all required fields");
    }
  };

  const handlePrevious = async () => {
    try {
      const resolvedActiveTab = tabItems.some((tab) => tab.key === activeTab)
        ? activeTab
        : tabItems[tabItems.length - 1]?.key || '1';
      const currentIndex = parseInt(resolvedActiveTab);
      const prevIndex = currentIndex - 1;
      if (prevIndex >= 1) {
        setActiveTab(prevIndex.toString());
      }
    } catch (error) {
      console.error("Error going back:", error);
    }
  };

  const handleGoBack = () => {
    router.push("/user/production-template/manufacturing-template");
  };

  const buildTabItems = () => {
    const tabs: any[] = [];
    let stepNumber = 1;
    const dosageForm = templateData?.['Basic Information']?.dosageForm;
    const isCoatingRequired = templateData?.['Basic Information']?.coatingRequired;

    // Tab 1: Basic Information
    tabs.push({
      key: stepNumber.toString(),
      label: (
        <Space>
          <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
            {stepNumber}
          </span>
          <span>Basic Information</span>
        </Space>
      ),
      children: (
        <BasicInfoForm
          form={form}
          onNext={handleNext}
          onPrevious={handlePrevious}
        />
      ),
    });
    stepNumber++;

    // Tab 2: Manufacturing BOM
    tabs.push({
      key: stepNumber.toString(),
      label: (
        <Space>
          <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
            {stepNumber}
          </span>
          <span>Manufacturing BOM</span>
        </Space>
      ),
      children: (
        <ManufacturingBOMForm
          onNext={handleNext}
          onPrevious={handlePrevious}
        />
      ),
    });
    stepNumber++;

    // Tab 3: Facility & Equipment
    tabs.push({
      key: stepNumber.toString(),
      label: (
        <Space>
          <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
            {stepNumber}
          </span>
          <span>Facility & Equipment</span>
        </Space>
      ),
      children: (
        <FacilityEquipment
          onNext={handleNext}
          onPrevious={handlePrevious}
        />
      ),
    });
    stepNumber++;

    // Tab 4: Manufacturing Steps
    tabs.push({
      key: stepNumber.toString(),
      label: (
        <Space>
          <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
            {stepNumber}
          </span>
          <span>Manufacturing Steps</span>
        </Space>
      ),
      children: (
        <ManufacturingSteps
          onNext={handleNext}
          onPrevious={handlePrevious}
        />
      ),
    });
    stepNumber++;

    // Tab 5: Dosage Form Specific Parameters
    if (dosageForm === 'Tablet') {
      tabs.push({
        key: stepNumber.toString(),
        label: (
          <Space>
            <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
              {stepNumber}
            </span>
            <span>Compression Parameters</span>
          </Space>
        ),
        children: (
          <CompressionParameters
            onNext={handleNext}
            onPrevious={handlePrevious}
          />
        ),
      });
      stepNumber++;
    }
    else if (dosageForm === 'Capsule') {
      tabs.push({
        key: stepNumber.toString(),
        label: (
          <Space>
            <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
              {stepNumber}
            </span>
            <span>Encapsulation Parameters</span>
          </Space>
        ),
        children: (
          <EncapsulationParameters
            onNext={handleNext}
            onPrevious={handlePrevious}
          />
        ),
      });
      stepNumber++;
    }
    else if (['Syrup', 'Liquid Suspension', 'Solution', 'Drop'].includes(dosageForm)) {
      tabs.push({
        key: stepNumber.toString(),
        label: (
          <Space>
            <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
              {stepNumber}
            </span>
            <span>Liquid / Suspension Parameters</span>
          </Space>
        ),
        children: (
          <LiquidSuspensionAndSolution
            onNext={handleNext}
            onPrevious={handlePrevious}
          />
        ),
      });
      stepNumber++;
    }
    else if (['Dry Powder Suspension', 'Powder'].includes(dosageForm)) {
      tabs.push({
        key: stepNumber.toString(),
        label: (
          <Space>
            <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
              {stepNumber}
            </span>
            <span>Powder Filling Parameters</span>
          </Space>
        ),
        children: (
          <PowderFillingParameters
            onNext={handleNext}
            onPrevious={handlePrevious}
          />
        ),
      });
      stepNumber++;
    }
    else if (['Cream', 'Ointment', 'Gel', 'Lotion'].includes(dosageForm)) {
      tabs.push({
        key: stepNumber.toString(),
        label: (
          <Space>
            <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
              {stepNumber}
            </span>
            <span>Semisolid Parameters</span>
          </Space>
        ),
        children: (
          <SemiSolidParameters
            onNext={handleNext}
            onPrevious={handlePrevious}
          />
        ),
      });
      stepNumber++;
    }

    // Tab 6: Coating Section (only for tablets with coating required)
    if (dosageForm === 'Tablet' && isCoatingRequired === true) {
      tabs.push({
        key: stepNumber.toString(),
        label: (
          <Space>
            <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
              {stepNumber}
            </span>
            <span>Coating Section</span>
          </Space>
        ),
        children: (
          <CoatingSection
            onNext={handleNext}
            onPrevious={handlePrevious}
          />
        ),
      });
      stepNumber++;
    }

    // Final Tab: Preview
    tabs.push({
      key: stepNumber.toString(),
      label: (
        <Space>
          <span className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center font-medium">
            {stepNumber}
          </span>
          <span>Final Preview</span>
        </Space>
      ),
      children: (
        <FinalPreview
          onPrevious={handlePrevious}
        />
      ),
    });

    return tabs;
  };

  // Build tabs dynamically
  const tabItems = buildTabItems();
  const resolvedActiveTab = tabItems.some((tab) => tab.key === activeTab)
    ? activeTab
    : tabItems[tabItems.length - 1]?.key || '1';

  return (
    <Space direction="vertical" size="middle" className="w-full">
      {/* Breadcrumb Card */}
      <Card size="small">
        <Breadcrumb
          items={[
            {
              href: '/user/production-template/manufacturing-template',
              title: (
                <Space>
                  <HomeOutlined />
                  <span>Manufacturing Templates</span>
                </Space>
              ),
            },
            {
              title: 'Add New Template',
            },
          ]}
        />
      </Card>

      {/* Header Card */}
      <Card>
        <Space style={{ width: '100%', justifyContent: 'space-between' }}>
          <Space size="large">
            <Button
              type="text"
              icon={<ArrowLeftOutlined />}
              onClick={handleGoBack}
            />
            <div>
              <Title level={3} style={{ margin: 0 }}>
                Add Manufacturing Template
              </Title>
              <Text type="secondary">
                Create a new manufacturing template with all required information
              </Text>
            </div>
          </Space>
        </Space>
      </Card>

      {/* Sidebar Toggle Button - Floating */}
      <Button
        type="primary"
        shape="circle"
        size="large"
        icon={<FileSearchOutlined />}
        onClick={() => setSidebarOpen(true)}
        style={{
          position: 'fixed',
          left: 16,
          top: '50%',
          transform: 'translateY(-50%)',
          zIndex: 1000,
          boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
        }}
        title="Open Reference Templates"
      />

      {/* Tabs Card */}
      <Card>
        <DataContext.Provider value={{ templateData, setTemplateData }}>
          <ReferenceDataProvider>
            {/* Reference Sidebar */}
            <CopyReferenceSidebar
              open={sidebarOpen}
              onClose={() => setSidebarOpen(false)}
              activeTab={activeTab}
            />
            <Tabs
              activeKey={resolvedActiveTab}
              onChange={setActiveTab}
              items={tabItems}
              type="line"
              destroyInactiveTabPane={false}
            />
          </ReferenceDataProvider>
        </DataContext.Provider>
      </Card>
    </Space>
  );
}
