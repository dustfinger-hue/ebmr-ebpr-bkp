'use client'

import { Card, Space, Button } from "antd"
import {
  ArrowLeftOutlined, ArrowRightOutlined,
  FileTextOutlined, SettingOutlined, AppstoreOutlined
} from "@ant-design/icons";
import { useState } from "react";
import CoatingPreview from "./coating-steps-components/Coating-Preview";
import SolutionPrepSteps from "./coating-steps-components/Solution-Prep-Steps";
import CoatingParmeters from "./coating-steps-components/Coating-Params";

interface CoatingSectionProps {
  onNext: () => void
  onPrevious: () => void
}
export default function CoatingSection({ onNext, onPrevious }: CoatingSectionProps) {
  const [currentPhase, setCurrentPhase] = useState<'solutionPrep' | 'coatingParams' | 'preview'>('solutionPrep');

  const handleNext = () => {
    onNext();
  }
  const handlePrevious = () => {
    if (onPrevious) {
      onPrevious();
    }
  };

  return (
    <>
      {/* Phase Navigation */}
      <Card size="small" style={{ marginBottom: 16 }}>
        <div className="flex flex-row justify-between items-center">
          <Space size="small">
            <Button
              type={currentPhase === 'solutionPrep' ? 'primary' : 'default'}
              onClick={() => setCurrentPhase('solutionPrep')}
              icon={<SettingOutlined />}
            >
              1. Solution Preparation
            </Button>
            <Button
              type={currentPhase === 'coatingParams' ? 'primary' : 'default'}
              onClick={() => {
                setCurrentPhase('coatingParams');
              }}
              icon={<AppstoreOutlined />}
            >
              2. Coating Parameters
            </Button>
            <Button
              type={currentPhase === 'preview' ? 'primary' : 'default'}
              onClick={() => setCurrentPhase('preview')}
              icon={<FileTextOutlined />}
            >
              3. Preview
            </Button>
          </Space>
        </div>
      </Card>

      {/* Phase Content */}
      {currentPhase === 'solutionPrep' && (
        <SolutionPrepSteps toCoatingParams={() => setCurrentPhase('coatingParams')} />
      )}
      {currentPhase === 'coatingParams' && (
        <CoatingParmeters
          onNext={()=>setCurrentPhase('preview')}
          onPrevious={handlePrevious}
        />
      )}
      {currentPhase === 'preview' && (
        <CoatingPreview
          onBackToConfig={() => setCurrentPhase('solutionPrep')}
          onBackToSteps={() => setCurrentPhase('coatingParams')}
        />
      )}
      {currentPhase === 'preview' && (

        <div className="flex justify-end gap-2 pt-4 border-t border-gray-800">
          <Button
            icon={<ArrowLeftOutlined />}
            onClick={handlePrevious}
          >
            Previous
          </Button>
          <Button
            type="primary"
            onClick={handleNext}
          >
            Next <ArrowRightOutlined />
          </Button>
        </div>
      )}
    </>
  )
}