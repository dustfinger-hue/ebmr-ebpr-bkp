'use client'

import { DataContext } from "@/lib/utils/DataContext"
import { COATING_DEFECT_TYPES, IPQC_FREQUENCY } from "@/lib/constants/Generarl"
import {
  ArrowLeftOutlined,
  ArrowRightOutlined,
  DeleteOutlined,
  PlusOutlined,
  InfoCircleOutlined,
  SettingOutlined,
  CheckCircleOutlined,
  WarningOutlined
} from "@ant-design/icons"
import { Button, Card, Col, Divider, Form, Input, InputNumber, message, Row, Select, Space, Spin, Table, Tag, Typography } from "antd"
import { useContext, useEffect, useMemo, useState } from "react"

const { Title, Text } = Typography

interface CoatingParamsProps {
  onNext: () => void
  onPrevious: () => void
}

interface IPQCRow {
  id: string
  parameterName: string
  specification: string
  frequency: string
}

interface EquipmentOption {
  label: string
  value: string
}

interface CPPParameter {
  parameterName: string
  minValue: number
  maxValue: number
  unit: string
}

const createId = () => `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`

const DEFAULT_IPQC_PARAMETERS = [
  'Weight Gain Check',
  'Appearance',
  'Film Uniformity'
]

export default function CoatingParmeters({ onNext, onPrevious }: CoatingParamsProps) {
  const [form] = Form.useForm()
  const { templateData, setTemplateData } = useContext(DataContext)
  const [equipmentOptions, setEquipmentOptions] = useState<EquipmentOption[]>([])
  const [cppLoading, setCppLoading] = useState(false)
  const [cppParameters, setCppParameters] = useState<CPPParameter[]>([])
  const [ipqcRows, setIpqcRows] = useState<IPQCRow[]>(() =>
    DEFAULT_IPQC_PARAMETERS.map((name) => ({
      id: createId(),
      parameterName: name,
      specification: '',
      frequency: ''
    }))
  )

  const machineList = useMemo(() => {
    const formattedData: any[] = []
    const equipment = templateData?.['Facility Equipment']?.facilitiesWithEquipment || []

    equipment.forEach((facility: any) => {
      facility.equipments?.forEach((equipment: any) => {
        formattedData.push({
          machineName: equipment.equipmentName,
          machineCode: equipment.equipmentCode,
          assetTag: equipment.assetTag || 'N/A',
          areaName: facility.areaName || 'N/A',
          facilityCode: facility.facilityCode || 'N/A',
          cppParameters: equipment.cppParameters?.map((param: any) => ({
            parameterName: param.parameterName,
            minValue: param.minValue,
            maxValue: param.maxValue,
            unit: param.unit || 'Not Specified',
            range: `${param.minValue} - ${param.maxValue} ${param.unit || ''}`
          })) || []
        })
      })
    })

    return formattedData
  }, [templateData])

  // Load saved data on mount
  useEffect(() => {
    const savedData = templateData?.['Coating Section']?.coatingParams
    if (savedData) {
      form.setFieldsValue(savedData)
      if (savedData.selectedMachineCode) {
        const machine = machineList.find((m) => m.machineCode === savedData.selectedMachineCode)
        if (machine) {
          setCppParameters(machine.cppParameters || [])
        }
      }
      if (savedData.ipqcRows?.length > 0) {
        setIpqcRows(savedData.ipqcRows)
      }
    }
  }, [])

  useEffect(() => {
    const equipmentList: EquipmentOption[] = []
    if (templateData?.['Facility Equipment']?.facilitiesWithEquipment) {
      templateData['Facility Equipment']?.facilitiesWithEquipment?.forEach((facility: any) => {
        facility.equipments?.forEach((equipment: any) => {
          equipmentList.push({
            label: equipment.equipmentName,
            value: equipment.equipmentCode
          })
        })
      })
    }
    setEquipmentOptions(equipmentList)
  }, [templateData?.['Facility Equipment']?.facilitiesWithEquipment])

  const handleMachineChange = (value: string, option: any) => {
    const selectedMachine = machineList.find((machine) => machine.machineCode === value)
    
    if (selectedMachine) {
      const params = selectedMachine.cppParameters?.map((param: any) => ({
        parameterName: param.parameterName,
        minValue: param.minValue,
        maxValue: param.maxValue,
        unit: param.unit || 'Not Specified'
      })) || []
      
      form.setFieldValue('machineId', selectedMachine.machineCode)
      form.setFieldValue('machineLocation', `${selectedMachine.areaName} - ${selectedMachine.facilityCode}`)
      setCppParameters(params)
    } else {
      setCppParameters([])
      form.setFieldValue('machineId', '')
      form.setFieldValue('machineLocation', '')
    }
  }

  const handleAddIpqcRow = () => {
    setIpqcRows((prev) => [
      ...prev,
      { id: createId(), parameterName: '', specification: '', frequency: '' }
    ])
  }

  const handleRemoveIpqcRow = (id: string) => {
    setIpqcRows((prev) => prev.filter((row) => row.id !== id))
  }

  const handleIpqcChange = (id: string, field: keyof IPQCRow, value: string) => {
    setIpqcRows((prev) =>
      prev.map((row) => (row.id === id ? { ...row, [field]: value } : row))
    )
  }

  const handleSaveAndNext = async () => {
    try {
      const values = await form.validateFields()

      const coatingParamsData = {
        ...values,
        cppValues: cppParameters.map((param: any) => ({
          parameterName: param.parameterName,
          value: Number(form.getFieldValue(`cpp_${param.parameterName}`) || 0),
          minValue: param.minValue,
          maxValue: param.maxValue,
          unit: param.unit
        })),
        ipqcRows: ipqcRows.filter((row) => row.parameterName && row.specification),
        selectedMachineCode: values.machine || values.machineId
      }

      setTemplateData((prev: any) => ({
        ...prev,
        ['Coating Section']: {
          ...prev?.['Coating Section'],
          coatingParams: coatingParamsData
        }
      }))

      message.success('Coating parameters saved successfully')
      onNext()
    } catch (error) {
      console.error('Validation failed:', error)
      message.error('Please fill all required fields correctly')
    }
  }

  const ipqcColumns = [
    {
      title: 'Parameter Name',
      dataIndex: 'parameterName',
      key: 'parameterName',
      width: 250,
      render: (text: string, record: IPQCRow) => (
        <Input
          value={record.parameterName}
          onChange={(e) => handleIpqcChange(record.id, 'parameterName', e.target.value)}
          placeholder="e.g., Weight Gain Check"
          size="small"
          style={{ minWidth: 180 }}
        />
      ),
    },
    {
      title: 'Specification / Limit',
      dataIndex: 'specification',
      key: 'specification',
      width: 300,
      render: (text: string, record: IPQCRow) => (
        <Input
          value={record.specification}
          onChange={(e) => handleIpqcChange(record.id, 'specification', e.target.value)}
          placeholder="e.g., 3-5% weight gain"
          size="small"
          style={{ minWidth: 200 }}
        />
      ),
    },
    {
      title: 'Frequency',
      dataIndex: 'frequency',
      key: 'frequency',
      width: 200,
      render: (text: string, record: IPQCRow) => (
        <Select
          value={record.frequency || undefined}
          onChange={(value) => handleIpqcChange(record.id, 'frequency', value)}
          placeholder="Select frequency"
          size="small"
          style={{ width: '100%' }}
          options={IPQC_FREQUENCY}
        />
      ),
    },
    {
      title: 'Actions',
      key: 'actions',
      width: 60,
      render: (_: any, record: IPQCRow) => (
        <Button
          type="text"
          danger
          icon={<DeleteOutlined />}
          onClick={() => handleRemoveIpqcRow(record.id)}
          size="small"
          disabled={DEFAULT_IPQC_PARAMETERS.includes(record.parameterName) && ipqcRows.filter((r) => r.parameterName === record.parameterName).length === 1}
        />
      ),
    },
  ]

  return (
    <div className="space-y-4">
      <Form form={form} layout="vertical" name="coating_params">
        {/* Section 1: Coating Machine */}
        <Card
          title={
            <Space>
              <SettingOutlined className="text-blue-500" />
              <Title level={5} style={{ margin: 0 }}>Coating Machine</Title>
            </Space>
          }
        >
          <Divider orientation="horizontal">
            <InfoCircleOutlined className="mr-2" />
            Machine Information
          </Divider>

          <Row gutter={[24, 16]}>
            <Col xs={24} md={12}>
              <Form.Item
                name="machine"
                label="Coating Machine"
                rules={[{ required: true, message: 'Please select a coating machine' }]}
                extra={<Text type="secondary" style={{ fontSize: 11 }}>Select coating machine</Text>}
              >
                <Select
                  placeholder="Select coating machine"
                  size="large"
                  style={{ width: '100%' }}
                  options={equipmentOptions}
                  onChange={handleMachineChange}
                  showSearch
                  optionFilterProp="label"
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={12}>
              <Form.Item
                name="machineId"
                label="Machine ID / Code"
                extra={<Text type="secondary" style={{ fontSize: 11 }}>Auto-filled from system</Text>}
              >
                <Input
                  placeholder="Auto-filled"
                  size="large"
                  disabled
                  suffix={cppLoading ? <Spin size="small" /> : ''}
                />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={[24, 16]}>
            <Col xs={24} md={12}>
              <Form.Item
                name="machineLocation"
                label="Machine Location"
                extra={<Text type="secondary" style={{ fontSize: 11 }}>Auto-filled from system</Text>}
              >
                <Input
                  placeholder="Auto-filled"
                  size="large"
                  disabled
                  suffix={cppLoading ? <Spin size="small" /> : ''}
                />
              </Form.Item>
            </Col>
          </Row>

          {cppParameters.length > 0 && (
            <>
              <Divider>
                <SettingOutlined className="mr-2" />
                Critical Process Parameters
              </Divider>
              <Row gutter={[24, 16]}>
                {cppParameters.map((param, index) => (
                  <Col xs={24} md={6} key={index}>
                    <Form.Item
                      name={['cppParameters', index, 'parameterName']}
                      initialValue={param.parameterName}
                      hidden
                    >
                      <Input />
                    </Form.Item>
                    <Form.Item
                      name={['cppParameters', index, 'unit']}
                      initialValue={param.unit}
                      hidden
                    >
                      <Input />
                    </Form.Item>
                    <Form.Item
                      label={`${param.parameterName}`}
                      name={`cpp_${param.parameterName}`}
                      extra={
                        <Text type="secondary" style={{ fontSize: 11 }}>
                          Range: {param.minValue} - {param.maxValue} {param.unit}
                        </Text>
                      }
                    >
                      <InputNumber
                        min={param.minValue}
                        max={param.maxValue}
                        placeholder={`${param.minValue} - ${param.maxValue}`}
                        size="large"
                        style={{ width: '100%' }}
                        addonAfter={param.unit}
                      />
                    </Form.Item>
                  </Col>
                ))}
              </Row>
            </>
          )}
        </Card>

        {/* Section 2: In-Process Quality Controls */}
        <Card
          title={
            <Space>
              <CheckCircleOutlined className="text-green-500" />
              <Title level={5} style={{ margin: 0 }}>In-Process Quality Controls (IPQC)</Title>
            </Space>
          }
        >
          <Divider orientation="horizontal">
            <WarningOutlined className="mr-2 text-orange-500" />
            IPQC Parameters
          </Divider>

          <Table
            columns={ipqcColumns}
            dataSource={ipqcRows}
            rowKey="id"
            pagination={false}
            size="middle"
            scroll={{ x: 700 }}
          />

          <div className="mt-3">
            <Button icon={<PlusOutlined />} onClick={handleAddIpqcRow}>
              Add IPQC Parameter
            </Button>
          </div>
        </Card>

        {/* Section 3: Coating Defects */}
        <Card
          title={
            <Space>
              <WarningOutlined className="text-red-500" />
              <Title level={5} style={{ margin: 0 }}>Coating Defects</Title>
            </Space>
          }
        >
          <Form.Item
            name="coatingDefects"
            label="Select potential coating defects"
            extra={<Text type="secondary" style={{ fontSize: 11 }}>Choose possible defects that may occur during coating</Text>}
          >
            <Select
              mode="multiple"
              allowClear
              placeholder="Select coating defects"
              options={COATING_DEFECT_TYPES}
              size="large"
              style={{ width: '100%' }}
            />
          </Form.Item>
        </Card>

        {/* Action Buttons */}
        <div className="flex justify-end gap-2">
          <Button
            icon={<ArrowLeftOutlined />}
            onClick={onPrevious}
            size="large"
          >
            Back
          </Button>
          <Button
            type="primary"
            icon={<ArrowRightOutlined />}
            onClick={handleSaveAndNext}
            size="large"
          >
            Save & Next
          </Button>
        </div>
      </Form>
    </div>
  )
}