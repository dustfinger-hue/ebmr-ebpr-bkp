'use client'

import { DataContext } from "@/lib/utils/DataContext"
import { CAPSULE_SIZES, CAPSULE_TYPES, ENCAPSULATION_DEFECT_TYPES, IPQC_FREQUENCY } from "@/lib/constants/Generarl"
import {
  ArrowLeftOutlined,
  ArrowRightOutlined,
  DeleteOutlined,
  PlusOutlined,
  InfoCircleOutlined,
  SettingOutlined,
  CheckCircleOutlined,
  WarningOutlined
} from "@ant-design/icons"
import { Button, Card, Col, Divider, Form, Input, InputNumber, message, Row, Select, Space, Table, Tag, Typography } from "antd"
import { useContext, useEffect, useMemo, useState } from "react"

const { Title, Text } = Typography

interface EncapsulationParamsProps {
  onNext: () => void
  onPrevious: () => void
}

interface IPQCRow {
  id: string
  parameterName: string
  specification: string
  frequency: string
}

interface CPPParameter {
  parameterName: string
  minValue: number
  maxValue: number
  unit: string
}

const createId = () => `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`

const DEFAULT_IPQC_PARAMETERS = [
  'Fill Weight Check',
  'Capsule Integrity Check',
  'Lock Length Check'
]

export default function EncapsulationParameters({ onNext, onPrevious }: EncapsulationParamsProps) {
  const [form] = Form.useForm()
  const { templateData, setTemplateData } = useContext(DataContext)
  const [cppParameters, setCppParameters] = useState<CPPParameter[]>([])
  const [ipqcRows, setIpqcRows] = useState<IPQCRow[]>(() =>
    DEFAULT_IPQC_PARAMETERS.map((name) => ({
      id: createId(),
      parameterName: name,
      specification: '',
      frequency: ''
    }))
  )

  const machineList = useMemo(() => {
    const formattedData: any[] = []
    const equipment = templateData?.['Facility Equipment']?.facilitiesWithEquipment || []

    equipment.forEach((facility: any) => {
      facility.equipments?.forEach((equipment: any) => {
        formattedData.push({
          machineName: equipment.equipmentName,
          machineCode: equipment.equipmentCode,
          areaName: facility.areaName || 'N/A',
          facilityCode: facility.facilityCode || 'N/A',
          cppParameters: equipment.cppParameters?.map((param: any) => ({
            parameterName: param.parameterName,
            minValue: param.minValue,
            maxValue: param.maxValue,
            unit: param.unit || 'Not Specified',
            range: `${param.minValue} - ${param.maxValue} ${param.unit || ''}`
          })) || []
        })
      })
    })

    return formattedData
  }, [templateData])

  // Load saved data on mount
  useEffect(() => {
    const savedData = templateData?.['Encapsulation Parameters']
    if (savedData) {
      form.setFieldsValue(savedData)
      if (savedData.selectedMachineCode) {
        const machine = machineList.find((m) => m.machineCode === savedData.selectedMachineCode)
        if (machine) {
          setCppParameters(machine.cppParameters || [])
        }
      }
      if (savedData.ipqcRows?.length > 0) {
        setIpqcRows(savedData.ipqcRows)
      }
    }
  }, [])

  const handleMachineChange = (value: string) => {
    const selectedMachine = machineList.find((machine) => machine.machineCode === value)

    if (selectedMachine) {
      const params = selectedMachine.cppParameters?.map((param: any) => ({
        parameterName: param.parameterName,
        minValue: param.minValue,
        maxValue: param.maxValue,
        unit: param.unit || 'Not Specified'
      })) || []

      form.setFieldValue('machineId', selectedMachine.machineCode)
      form.setFieldValue('machineLocation', `${selectedMachine.areaName} - ${selectedMachine.facilityCode}`)
      setCppParameters(params)
    } else {
      setCppParameters([])
      form.setFieldValue('machineId', '')
      form.setFieldValue('machineLocation', '')
    }
  }

  const handleAddIpqcRow = () => {
    setIpqcRows((prev) => [
      ...prev,
      { id: createId(), parameterName: '', specification: '', frequency: '' }
    ])
  }

  const handleRemoveIpqcRow = (id: string) => {
    setIpqcRows((prev) => prev.filter((row) => row.id !== id))
  }

  const handleIpqcChange = (id: string, field: keyof IPQCRow, value: string) => {
    setIpqcRows((prev) =>
      prev.map((row) => (row.id === id ? { ...row, [field]: value } : row))
    )
  }

  const handleSaveAndNext = async () => {
    try {
      const values = await form.validateFields()

      const encapsulationData = {
        ...values,
        cppValues: cppParameters.map((param: any) => ({
          parameterName: param.parameterName,
          value: Number(form.getFieldValue(`cpp_${param.parameterName}`) || 0),
          minValue: param.minValue,
          maxValue: param.maxValue,
          unit: param.unit
        })),
        ipqcRows: ipqcRows.filter((row) => row.parameterName && row.specification),
        selectedMachineCode: values.machine
      }

      setTemplateData((prev: any) => ({
        ...prev,
        ['Encapsulation Parameters']: encapsulationData
      }))

      message.success('Encapsulation parameters saved successfully')
      onNext()
    } catch (error) {
      console.error('Validation failed:', error)
      message.error('Please fill all required fields correctly')
    }
  }

  const ipqcColumns = [
    {
      title: 'Parameter Name',
      dataIndex: 'parameterName',
      key: 'parameterName',
      width: 250,
      render: (text: string, record: IPQCRow) => (
        <Input
          value={record.parameterName}
          onChange={(e) => handleIpqcChange(record.id, 'parameterName', e.target.value)}
          placeholder="e.g., Fill Weight Check"
          size="small"
          style={{ minWidth: 180 }}
        />
      ),
    },
    {
      title: 'Specification / Limit',
      dataIndex: 'specification',
      key: 'specification',
      width: 300,
      render: (text: string, record: IPQCRow) => (
        <Input
          value={record.specification}
          onChange={(e) => handleIpqcChange(record.id, 'specification', e.target.value)}
          placeholder="e.g., ±5% of target fill weight"
          size="small"
          style={{ minWidth: 200 }}
        />
      ),
    },
    {
      title: 'Frequency',
      dataIndex: 'frequency',
      key: 'frequency',
      width: 200,
      render: (text: string, record: IPQCRow) => (
        <Select
          value={record.frequency || undefined}
          onChange={(value) => handleIpqcChange(record.id, 'frequency', value)}
          placeholder="Select frequency"
          size="small"
          style={{ width: '100%' }}
          options={IPQC_FREQUENCY}
        />
      ),
    },
    {
      title: 'Actions',
      key: 'actions',
      width: 60,
      render: (_: any, record: IPQCRow) => (
        <Button
          type="text"
          danger
          icon={<DeleteOutlined />}
          onClick={() => handleRemoveIpqcRow(record.id)}
          size="small"
          disabled={DEFAULT_IPQC_PARAMETERS.includes(record.parameterName) && ipqcRows.filter((r) => r.parameterName === record.parameterName).length === 1}
        />
      ),
    },
  ]

  return (
    <div className="space-y-4">
      <Form form={form} layout="vertical" name="encapsulation_params">
        {/* Section 1: Encapsulation Machine */}
        <Card
          title={
            <Space>
              <SettingOutlined className="text-blue-500" />
              <Title level={5} style={{ margin: 0 }}>Encapsulation Machine</Title>
            </Space>
          }
        >
          <Divider orientation="horizontal">
            <InfoCircleOutlined className="mr-2" />
            Machine Information
          </Divider>

          <Row gutter={[24, 16]}>
            <Col xs={24} md={12}>
              <Form.Item
                name="machine"
                label="Encapsulation Machine"
                rules={[{ required: true, message: 'Please select an encapsulation machine' }]}
                extra={<Text type="secondary" style={{ fontSize: 11 }}>Select encapsulation machine</Text>}
              >
                <Select
                  placeholder="Select encapsulation machine"
                  size="large"
                  style={{ width: '100%' }}
                  options={machineList.map((m) => ({
                    label: `${m.machineName} - ${m.machineCode}`,
                    value: m.machineCode
                  }))}
                  onChange={handleMachineChange}
                  showSearch
                  optionFilterProp="label"
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={12}>
              <Form.Item
                name="machineId"
                label="Machine ID / Code"
                extra={<Text type="secondary" style={{ fontSize: 11 }}>Auto-filled from system</Text>}
              >
                <Input placeholder="Auto-filled" size="large" disabled />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={[24, 16]}>
            <Col xs={24} md={12}>
              <Form.Item
                name="machineLocation"
                label="Machine Location"
                extra={<Text type="secondary" style={{ fontSize: 11 }}>Auto-filled from system</Text>}
              >
                <Input placeholder="Auto-filled" size="large" disabled />
              </Form.Item>
            </Col>
          </Row>

          {cppParameters.length > 0 && (
            <>
              <Divider>
                <SettingOutlined className="mr-2" />
                Critical Process Parameters
              </Divider>
              <Row gutter={[24, 16]}>
                {cppParameters.map((param, index) => (
                  <Col xs={24} md={6} key={index}>
                    <Form.Item
                      name={['cppParameters', index, 'parameterName']}
                      initialValue={param.parameterName}
                      hidden
                    >
                      <Input />
                    </Form.Item>
                    <Form.Item
                      name={['cppParameters', index, 'unit']}
                      initialValue={param.unit}
                      hidden
                    >
                      <Input />
                    </Form.Item>
                    <Form.Item
                      label={param.parameterName}
                      name={`cpp_${param.parameterName}`}
                      extra={
                        <Text type="secondary" style={{ fontSize: 11 }}>
                          Range: {param.minValue} - {param.maxValue} {param.unit}
                        </Text>
                      }
                    >
                      <InputNumber
                        min={param.minValue}
                        max={param.maxValue}
                        placeholder={`${param.minValue} - ${param.maxValue}`}
                        size="large"
                        style={{ width: '100%' }}
                        addonAfter={param.unit}
                      />
                    </Form.Item>
                  </Col>
                ))}
              </Row>
            </>
          )}
        </Card>

        {/* Section 2: Capsule Specifications */}
        <Card
          title={
            <Space>
              <InfoCircleOutlined className="text-cyan-500" />
              <Title level={5} style={{ margin: 0 }}>Capsule Specifications</Title>
            </Space>
          }
        >
          <Row gutter={[24, 16]}>
            <Col xs={24} md={8}>
              <Form.Item
                name="capsuleSize"
                label="Capsule Size"
                rules={[{ required: true, message: 'Please select capsule size' }]}
              >
                <Select
                  placeholder="Select capsule size"
                  options={CAPSULE_SIZES}
                  size="large"
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={8}>
              <Form.Item
                name="capsuleType"
                label="Capsule Type"
                rules={[{ required: true, message: 'Please select capsule type' }]}
              >
                <Select
                  placeholder="Select capsule type"
                  options={CAPSULE_TYPES}
                  size="large"
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={8}>
              <Form.Item
                name="capsuleColor"
                label="Capsule Color"
                extra={<Text type="secondary" style={{ fontSize: 11 }}>e.g., White opaque body, Red cap</Text>}
              >
                <Input placeholder="Enter capsule color" size="large" />
              </Form.Item>
            </Col>
          </Row>
        </Card>

        {/* Section 3: Process Parameters */}
        <Card
          title={
            <Space>
              <CheckCircleOutlined className="text-blue-500" />
              <Title level={5} style={{ margin: 0 }}>Process Parameters</Title>
            </Space>
          }
        >
          <Divider orientation="horizontal">
            <InfoCircleOutlined className="mr-2" />
            Fill Parameters
          </Divider>

          <Row gutter={[24, 16]}>
            <Col xs={24} md={8}>
              <Form.Item
                name="targetFillWeight"
                label="Target Fill Weight (mg)"
                rules={[{ required: true, message: 'Required' }]}
                extra={<Text type="secondary" style={{ fontSize: 11 }}>Weight of powder per capsule</Text>}
              >
                <InputNumber
                  placeholder="e.g., 250"
                  min={0}
                  size="large"
                  style={{ width: '100%' }}
                  addonAfter="mg"
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={8}>
              <Form.Item
                name="fillWeightTolerance"
                label="Fill Weight Tolerance (±mg)"
                extra={<Text type="secondary" style={{ fontSize: 11 }}>Acceptable variation</Text>}
              >
                <InputNumber
                  placeholder="e.g., 5"
                  min={0}
                  size="large"
                  style={{ width: '100%' }}
                  addonAfter="mg"
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={8}>
              <Form.Item
                name="targetCapsuleWeight"
                label="Target Capsule Weight (mg)"
                extra={<Text type="secondary" style={{ fontSize: 11 }}>Shell + fill weight</Text>}
              >
                <InputNumber
                  placeholder="e.g., 300"
                  min={0}
                  size="large"
                  style={{ width: '100%' }}
                  addonAfter="mg"
                />
              </Form.Item>
            </Col>
          </Row>

          <Divider orientation="horizontal">
            <SettingOutlined className="mr-2" />
            Machine Settings
          </Divider>

          <Row gutter={[24, 16]}>
            <Col xs={24} md={8}>
              <Form.Item
                name="productionSpeed"
                label="Production Speed (capsules/hr)"
                extra={<Text type="secondary" style={{ fontSize: 11 }}>Target operating speed</Text>}
              >
                <InputNumber
                  placeholder="e.g., 60000"
                  min={0}
                  step={100}
                  size="large"
                  style={{ width: '100%' }}
                  addonAfter="caps/hr"
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={8}>
              <Form.Item
                name="tampingForce"
                label="Tamping Force (N)"
                extra={<Text type="secondary" style={{ fontSize: 11 }}>Force for powder filling</Text>}
              >
                <InputNumber
                  placeholder="e.g., 50"
                  min={0}
                  size="large"
                  style={{ width: '100%' }}
                  addonAfter="N"
                />
              </Form.Item>
            </Col>
          </Row>
        </Card>

        {/* Section 4: IPQC */}
        <Card
          title={
            <Space>
              <WarningOutlined className="text-orange-500" />
              <Title level={5} style={{ margin: 0 }}>In-Process Quality Controls (IPQC)</Title>
            </Space>
          }
        >
          <Table
            columns={ipqcColumns}
            dataSource={ipqcRows}
            rowKey="id"
            pagination={false}
            size="middle"
            scroll={{ x: 700 }}
          />

          <div className="mt-3">
            <Button icon={<PlusOutlined />} onClick={handleAddIpqcRow}>
              Add IPQC Parameter
            </Button>
          </div>
        </Card>

        {/* Section 5: Encapsulation Defects */}
        <Card
          title={
            <Space>
              <WarningOutlined className="text-red-500" />
              <Title level={5} style={{ margin: 0 }}>Encapsulation Defects</Title>
            </Space>
          }
        >
          <Form.Item
            name="encapsulationDefects"
            label="Select potential encapsulation defects"
            extra={<Text type="secondary" style={{ fontSize: 11 }}>Choose possible defects that may occur during encapsulation</Text>}
          >
            <Select
              mode="multiple"
              allowClear
              placeholder="Select encapsulation defects"
              options={ENCAPSULATION_DEFECT_TYPES}
              size="large"
              style={{ width: '100%' }}
            />
          </Form.Item>
        </Card>

        {/* Action Buttons */}
        <div className="flex justify-end gap-2">
          <Button
            icon={<ArrowLeftOutlined />}
            onClick={onPrevious}
            size="large"
          >
            Back
          </Button>
          <Button
            type="primary"
            icon={<ArrowRightOutlined />}
            onClick={handleSaveAndNext}
            size="large"
          >
            Save & Next
          </Button>
        </div>
      </Form>
    </div>
  )
}