'use client'
import { DataContext } from "@/lib/utils/DataContext";
import Tiptap from "@/lib/utils/Tiptap-utils/Tiptap";
import { Badge, Button, Card, Descriptions, Empty, message, Select, Space, Table, Tag, Typography, Divider } from "antd";
import { ArrowLeftOutlined, ArrowRightOutlined, CheckCircleOutlined, InfoCircleOutlined, FileTextOutlined } from "@ant-design/icons";
import dayjs from "dayjs";
import { useContext, useEffect, useState } from "react";

const { Text, Title } = Typography;

interface Material {
  materialCode: string;
  materialName: string;
  materialCategory?: string;
  quantity: number;
  uom: string;
}

interface ManufacturingBOMProps {
  onNext: () => void;
  onPrevious?: () => void;
}

export default function ManufacturingBOM({ onNext, onPrevious }: ManufacturingBOMProps) {
  // Context se data lena
  const { templateData, setTemplateData } = useContext(DataContext);

  const [loading, setLoading] = useState(false);
  const [dosageForm, setDosageForm] = useState<string>('');
  const [bomData, setBomData] = useState<any>(null);
  const [otherInfo, setOtherInfo] = useState<any>(null);
  const [usageStages, setUsageStages] = useState<any>({});

  // Restore usage stages from context on mount (for edit mode)
  useEffect(() => {
    const bomSection = templateData?.['Manufacturing BOM'];
    if (bomSection?.bomData?.materials) {
      const restoredStages: any = {};
      bomSection.bomData.materials.forEach((mat: any) => {
        if (mat.usageStage) {
          restoredStages[mat.materialCode] = mat.usageStage;
        }
      });
      if (Object.keys(restoredStages).length > 0) {
        setUsageStages(restoredStages);
      }
      if (bomSection.otherInfo) {
        setOtherInfo(bomSection.otherInfo);
      }
    }
  }, []); // Only on mount

  useEffect(() => {
    const basicInfo = templateData?.['Basic Information'];
    if (basicInfo?.manufacturingBomCode) {
      setDosageForm(basicInfo.dosageForm || '');
      fetchBOM(basicInfo.manufacturingBomCode);
    }
  }, [templateData]);

  useEffect(() => console.log(templateData), [templateData]);

  const fetchBOM = async (bomCode: string) => {
    if (!bomCode) return;
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`/api/user/bill-of-material/manufacturing?bomCode=${bomCode}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (data.success && data.data && data.data.length > 0) {
        setBomData(data.data[0]);
      } else {
        setBomData(null);
      }
    } catch (error) {
      console.error("Error fetching manufacturing BOM:", error);
      message.error("Error fetching manufacturing BOM");
    } finally {
      setLoading(false);
    }
  };

  // const tabletType = templateData?.['Basic Information']?.tabletType;
  // const isBilayer = tabletType?.includes('Bilayer') || tabletType?.includes('Tablet in Tablet');
  // const isCoatingRequired: boolean = templateData?.['Basic Information']?.coatingRequired;

  // const options: any = [];

  // if (isBilayer) {
  //   options.push(
  //     { value: 'Granulation Layer-1', label: 'Granulation Layer-1' },
  //     { value: 'Granulation Layer-2', label: 'Granulation Layer-2' }
  //   );
  // } else if (dosageForm === 'Capsule') {
  //   options.push(
  //     { value: 'Granulation', label: 'Granulation' },
  //     { value: 'Pellet Form', label: 'Pellet Form' }
  //   );
  // } else if (['Syrups', 'Liquid Suspensions', 'Solution', 'Drops', 'Ointment', 'Cream', 'Gel', 'Lotion'].includes(dosageForm)) {
  //   options.push({ value: 'Formulation', label: 'Formulation' });
  // } else if (['Dry Powder Suspension', 'Powder'].includes(dosageForm)) {
  //   options.push({ value: 'Granulation', label: 'Granulation' });
  // } else {
  //   options.push({ value: 'Granulation Single Layer', label: 'Granulation Single Layer' });
  // }

  // options.push({ value: 'Coating', label: 'Coating' });

  const tabletType = templateData?.['Basic Information']?.tabletType;
const isBilayer = tabletType?.includes('Bilayer') || tabletType?.includes('Tablet in Tablet');
const isCoatingRequired: boolean = templateData?.['Basic Information']?.coatingRequired;

const options: any = [];

if (isBilayer) {
  options.push(
    { value: 'Granulation Layer-1', label: 'Granulation Layer-1' },
    { value: 'Granulation Layer-2', label: 'Granulation Layer-2' }
  );
} else if (dosageForm === 'Capsule') {
  options.push(
    { value: 'Granulation', label: 'Granulation' },
    { value: 'Pellet Form', label: 'Pellet Form' }
  );
} else if (['Syrup', 'Liquid Suspension', 'Solution', 'Drop', 'Ointment', 'Cream', 'Gel', 'Lotion'].includes(dosageForm)) {
  options.push({ value: 'Formulation', label: 'Formulation' });
} else if (['Dry Powder Suspension', 'Powder'].includes(dosageForm)) {
  options.push({ value: 'Granulation', label: 'Granulation' });
} else {
  options.push({ value: 'Granulation Single Layer', label: 'Granulation Single Layer' });
}

// Sirf tablet-based dosage forms (ya bilayer/capsule ke alawa) mein coating add karein
const isTabletForm = !['Capsule', 'Syrup', 'Liquid Suspension', 'Solution', 'Drop', 'Ointment', 'Cream', 'Gel', 'Lotion', 'Dry Powder Suspension', 'Powder'].includes(dosageForm);

if (isCoatingRequired && isTabletForm) {
  options.push({ value: 'Coating', label: 'Coating' });
}

  const materialColumns = [
    {
      title: 'Material Code',
      dataIndex: 'materialCode',
      key: 'materialCode',
      width: 140,
      render: (_: any, record: Material) => (
        <Text copyable style={{ color: '#1677ff', fontWeight: 500, fontSize: 13 }}>
          {record.materialCode}
        </Text>
      ),
    },
    {
      title: 'Material Name',
      dataIndex: 'materialName',
      key: 'materialName',
      width: 200,
      ellipsis: true,
      render: (_: any, record: Material) => (
        <Text strong>{record.materialName}</Text>
      ),
    },
    {
      title: 'Material Category',
      dataIndex: 'materialCategory',
      key: 'materialCategory',
      width: 150,
      ellipsis: true,
      render: (_: any, record: Material) => (
        <Tag color="purple">{record.materialCategory || 'N/A'}</Tag>
      ),
    },
    {
      title: 'Quantity',
      dataIndex: 'quantity',
      key: 'quantity',
      width: 120,
      align: 'right' as const,
      render: (qty: number, record: Material) => (
        <Text strong>{qty} <span className="text-gray-500">{record.uom}</span></Text>
      ),
    },
    {
      title: 'UOM',
      dataIndex: 'uom',
      key: 'uom',
      width: 80,
      render: (_: any, record: Material) => (
        <Tag color="blue">{record.uom}</Tag>
      ),
    },
    // Conditional tab rendering for Tablet dosage form
    // ...(dosageForm === 'Tablet' ? [
    {
      title: 'Usage Stage',
      width: 160,
      key: 'usageStage',
      render: (_: any, record: any) => (
        <Select
          value={usageStages[record.materialCode]}
          placeholder="Select stage"
          onChange={(value) => {
            setUsageStages((prev: any) => ({
              ...prev,
              [record.materialCode]: value
            }));
          }}
          options={options}
          style={{ width: "100%" }}
          size="small"
        />
      ),
    },
    // ] : [])
  ];

  const formatDate = (date: string) => {
    return date ? dayjs(date).format('DD-MMM-YYYY') : '-';
  };

  const handleNext = () => {
    setTemplateData((prev: any) => {
      const newData = {
        ...(prev || {}),
        ["Manufacturing BOM"]: {
          bomData: {
            id: bomData?._id,
            productCode: bomData?.productCode,
            productName: bomData?.productName,
            bomCode: bomData?.bomCode,
            bomVersion: bomData?.bomVersion,
            materials: bomData?.materials?.map((material: any) => ({
              materialCode: material?.materialCode,
              materialName: material?.materialName,
              materialCategory: material?.materialCategory,
              quantity: material?.quantity,
              uom: material?.uom,
              usageStage: usageStages[material?.materialCode]
            }))
          },
          otherInfo: otherInfo
        }
      };
      return newData;
    });
    onNext();
    message.success("Manufacturing BOM saved successfully!");
  };

  const handlePrevious = () => {
    if (onPrevious) {
      onPrevious();
    }
  };

  return (
    <div className="py-4">
      {/* BOM Info Card */}
      <Card
        loading={loading}
        className="mb-6 shadow-sm"
        title={
          <div className="flex items-center gap-2">
            <InfoCircleOutlined className="text-blue-500" />
            <span>BOM Information</span>
          </div>
        }
      >
        {bomData ? (
          <Descriptions bordered column={{ xs: 1, sm: 2, md: 3 }} size="small">
            <Descriptions.Item label="Product Code">
              <Text code>{bomData?.productCode || '-'}</Text>
            </Descriptions.Item>
            <Descriptions.Item label="Product Name">
              <Text strong>{bomData?.productName || '-'}</Text>
            </Descriptions.Item>
            <Descriptions.Item label="BOM Code">
              <Text copyable>{bomData?.bomCode || '-'}</Text>
            </Descriptions.Item>
            <Descriptions.Item label="Version">
              <Tag color="blue">v{bomData?.bomVersion || '-'}</Tag>
            </Descriptions.Item>
            <Descriptions.Item label="Batch Size (Semi-finished)">
              <Text strong>{bomData?.batchSizeSemifinished || '-'} {bomData?.uom || ''}</Text>
            </Descriptions.Item>
            <Descriptions.Item label="Bulk Size">
              <Text strong>{bomData?.bulkSize || '-'} {bomData?.bulkUom || ''}</Text>
            </Descriptions.Item>
            <Descriptions.Item label="Status">
              <Tag color={bomData?.status === 'Active' ? 'success' : 'default'}>
                {bomData?.status || '-'}
              </Tag>
            </Descriptions.Item>
            <Descriptions.Item label="Effective Date">
              {formatDate(bomData?.effectiveDate)}
            </Descriptions.Item>
          </Descriptions>
        ) : (
          <Empty
            description={
              <span className="text-gray-500">
                Please select a Manufacturing BOM from Basic Information tab
              </span>
            }
            image={Empty.PRESENTED_IMAGE_SIMPLE}
          />
        )}
      </Card>

      {/* Materials Card */}
      {bomData && (
        <Card
          className="mb-6 shadow-sm"
          title={
            <div className="flex items-center justify-between w-full">
              <div className="flex items-center gap-2">
                <FileTextOutlined className="text-blue-500" />
                <span>Materials List</span>
              </div>
              <Badge
                count={bomData.materials?.length || 0}
                style={{ backgroundColor: '#1890ff' }}
                showZero={true}
              />
            </div>
          }
        >
          {bomData.materials?.length > 0 ? (
            <Table
              dataSource={bomData.materials}
              columns={materialColumns}
              rowKey="materialCode"
              pagination={false}
              size="middle"
              bordered
              className="mb-4"
              scroll={{ x: 'max-content' }}
            />
          ) : (
            <Empty
              description="No materials found in this BOM"
              image={Empty.PRESENTED_IMAGE_SIMPLE}
            />
          )}
        </Card>
      )}

      {/* Additional Notes Card */}
      {bomData && (
        <Card
          className="mb-6 shadow-sm"
          title={
            <div className="flex items-center gap-2">
              <FileTextOutlined className="text-blue-500" />
              <span>Additional Notes & Instructions</span>
            </div>
          }
        >
          <Tiptap value={otherInfo} onChange={(value) => setOtherInfo(value)} />
        </Card>
      )}

      {/* Action Buttons */}
      <div className="flex justify-end gap-2 pt-4 border-t border-gray-800">
        <Button
          icon={<ArrowLeftOutlined />}
          onClick={handlePrevious}
        >
          Previous
        </Button>
        <Button
          type="primary"
          onClick={handleNext}
        >
          Next <ArrowRightOutlined />
        </Button>
      </div>
    </div>
  );
}
