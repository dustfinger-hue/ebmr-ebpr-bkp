'use client'
import { Dosage_Forms, Storage_Conditions, Tabalet_Types, Template_types, UOM_OPTIONS, UOM_OPTIONS_BULK } from "@/lib/constants/Generarl";
import { Form, Input, Select, Card, Row, Col, Spin, message, Typography, Tooltip, Button, Space, InputNumber, DatePicker, Divider, Badge, Empty, Switch } from "antd";
import { QuestionCircleOutlined, InfoCircleOutlined, ArrowRightOutlined, ArrowLeftOutlined } from "@ant-design/icons";
import { useContext, useEffect, useState } from "react";
import { useDebounce } from "use-debounce";
import { DataContext } from "@/lib/utils/DataContext";

const { Title, Text } = Typography;
const { TextArea } = Input;

interface BasicInfoFormProps {
  form: any;
  onNext: () => void;
  onPrevious?: () => void;
}

export default function BasicInfoForm({ form, onNext, onPrevious }: BasicInfoFormProps) {
  const [searchValue, setSearchValue] = useState("");
  const [productOptions, setProductOptions] = useState<any>([]);
  const [referenceManufacturingBomOptions, setReferenceManufacturingBomOptions] = useState<any>([]);
  const [loading, setLoading] = useState(false);
  const [debouncedSearchValue] = useDebounce(searchValue, 500);

  // Context se data lena
  const { templateData, setTemplateData } = useContext(DataContext);
  
  // 🔄 On mount, populate form from context if data exists (for edit mode)
  useEffect(() => {
    const basicInfo = templateData?.['Basic Information'];
    if (basicInfo && Object.keys(basicInfo).length > 0) {
      // Set form values
      form.setFieldsValue({
        ...basicInfo,
        // Ensure storageConditions is set properly
        storageConditions: Array.isArray(basicInfo.storageConditions)
          ? basicInfo.storageConditions
          : basicInfo.storageConditions
            ? [basicInfo.storageConditions]
            : [],
      });

      // If product data exists, fetch product options and BOM options to populate selects
      if (basicInfo.productName) {
        setSearchValue(basicInfo.productName);
        fetchProduct(basicInfo.productName);
      }

      if (basicInfo.productCode) {
        fetchAllManufacturingBoms(basicInfo.productCode);
      }

      // Set the selected BOM in form if bomCode is available
      if (basicInfo.manufacturingBomCode) {
        form.setFieldValue('manufacturingBomCode', basicInfo.manufacturingBomCode);
      }
    }
  }, []); // Only run on mount

  const normalizeStorageConditions = (value: unknown): unknown[] => {
    if (Array.isArray(value)) return value;
    if (!value) return [];
    return [value];
  };

  const sanitizeBasicInfoValues = (values: Record<string, unknown>) => {
    const nextValues: Record<string, unknown> = {
      ...values,
      storageConditions: normalizeStorageConditions(values.storageConditions),
    };

    if (nextValues.dosageForm !== 'Tablet') {
      delete nextValues.tabletType;
      delete nextValues.coatingRequired;
    }

    return nextValues;
  };

  useEffect(() => {
    if (debouncedSearchValue) {
      fetchProduct(debouncedSearchValue);
    } else {
      setProductOptions([]);
    }
  }, [debouncedSearchValue]);

  const fetchProduct = async (search: string) => {
    if (!search) return;
    setLoading(true);
    try {
      const res = await fetch(
        `/api/user/master-data/product-master?search=${search}&limit=10`
      );
      const data = await res.json();
      if (data.success && data.products) {
        const mappedData = data.products.map((item: any) => ({
          label: `${item.productName} - ${item.productCode}`,
          value: item.productName,
          product: item
        }));
        setProductOptions(mappedData);
      }
    } catch (error) {
      console.error("Error fetching products:", error);
      message.error("Error fetching products");
    } finally {
      setLoading(false);
    }
  };

  const fetchAllManufacturingBoms = async (productCode?: string) => {
    if (!productCode) return;
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`/api/user/bill-of-material/manufacturing?productCode=${productCode}&limit=1000`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();

      if (data.success && data.data && data.data.length > 0) {
        const mappedData = data.data.map((bom: any) => ({
          label:
            <Text style={{ color: '#1677ff', fontWeight: 500, fontSize: 13 }}>
              {bom.productName} ({bom.bomCode}-{bom.bomVersion}) &nbsp;
              <Badge className="scale-150" status={bom.status === "Active" ? "success" : "default"} />
            </Text>,
          value: bom.bomCode,
          manufacturingBom: bom
        }));
        setReferenceManufacturingBomOptions(mappedData);
      } else {
        setReferenceManufacturingBomOptions([]);
      }
    } catch (error) {
      console.error("Error fetching manufacturing BOMs:", error);
      message.error("Error fetching manufacturing BOMs");
    } finally {
      setLoading(false);
    }
  };

  const handleProductChange = async (value: any, option: any) => {
    if (option?.product) {
      form.setFieldValue("productCode", option.product.productCode);
      form.setFieldValue("productName", option.product.productName);
      form.setFieldValue("dosageForm", option.product.dosageForm);
      form.setFieldValue("strength", option.product.strength);
      form.setFieldValue("shelfLife", option.product.shelfLife);
      form.setFieldValue("drugRegistrationNumber", option.product.registrationNumber);
      form.setFieldValue("storageConditions", normalizeStorageConditions(option.product.storageCondition));

      if (option.product.dosageForm !== 'Tablet') {
        form.setFieldValue("tabletType", undefined);
        form.setFieldValue("coatingRequired", undefined);
      }

      // Immediately save product info to context so sidebar can use it
      const productCode = String(option.product.productCode);
      setTemplateData((prev: any) => ({
        ...(prev || {}),
        ["Basic Information"]: {
          ...(prev?.["Basic Information"] || {}),
          productCode,
          productName: option.product.productName,
          dosageForm: option.product.dosageForm,
        }
      }));

      await fetchLatestVersion(productCode);
      fetchAllManufacturingBoms(productCode);
    }
  };

  const handleReferenceManufacturingBomChange = async (value: any, option: any) => {
    if (option?.manufacturingBom?.bomCode) {
      form.setFieldValue("manufacturingBomCode", option.manufacturingBom.bomCode);
      form.setFieldValue("manufacturingBom", option.manufacturingBom);
      form.setFieldValue("batchSizeSemiFinished", option.manufacturingBom.batchSizeSemifinished);
      form.setFieldValue("uomSemiFinished", option.manufacturingBom.uom);
      form.setFieldValue("batchSizeBulk", option.manufacturingBom.bulkSize);
      form.setFieldValue("uomBulk", option.manufacturingBom.bulkUom);
    }
  };

  const fetchLatestVersion = async (productCode: string) => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`/api/user/production-template/manufacturing-template?productCode=${productCode}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (data.success && data.data && data.data.length > 0) {
        const versions = data.data.map((bom: any) => parseFloat(bom.templateVersion || '0'));
        const maxVersion = Math.max(...versions);
        const newVersion = (maxVersion + 1).toFixed(1);
        form.setFieldValue('templateVersion', newVersion);
      } else {
        form.setFieldValue('templateVersion', '1.0');
      }
    } catch (error) {
      console.error('Error fetching latest version:', error);
      form.setFieldValue('templateVersion', '1.0');
    }
  };

  const handleNext = async (values: any) => {
    try {
      const sanitizedValues = sanitizeBasicInfoValues(values);
      // Include disabled fields (like productCode) which getFieldsValue() excludes by default
      const allFormValues = form.getFieldsValue(true);
      if (!sanitizedValues.productCode && allFormValues.productCode) {
        sanitizedValues.productCode = allFormValues.productCode;
      }
      // Ensure productCode is stored as string to match DB format
      if (sanitizedValues.productCode) {
        sanitizedValues.productCode = String(sanitizedValues.productCode);
      }
      setTemplateData((prev: any) => {
        const newData = {
          ...(prev || {}),
          ["Basic Information"]: sanitizedValues
        };
        return newData;
      });
      onNext();
      message.success("Basic information saved successfully!");
    } catch (error) {
      console.error("Validation failed:", error);
      message.error("Please fill all required fields");
    }
  };

  return (
    <Form
      form={form}
      layout="vertical"
      name="basic_info_form"
      initialValues={{
        status: "Draft",
      }}
      onFinish={handleNext}
    >
      <Card>
        {/* Section 1: Template Information */}
        <Space>
          <InfoCircleOutlined className="text-blue-500" />
          <Title level={5} style={{ margin: 0 }}>Template Information</Title>
        </Space>

        <Row gutter={[24, 16]} className="mt-4">
          <Col xs={24} sm={12} md={6}>
            <Form.Item
              name="templateCode"
              label="Template Code"
              extra={<Text type="secondary" style={{ fontSize: 11 }}>Auto-generated unique identifier</Text>}
            >
              <Input placeholder="Auto-generated" disabled />
            </Form.Item>
          </Col>

          <Col xs={24} sm={12} md={6}>
            <Form.Item
              name="templateVersion"
              label="Version"
              extra={<Text type="secondary" style={{ fontSize: 11 }}>e.g., 1.0, 2.0</Text>}
            >
              <Input placeholder="1.0" />
            </Form.Item>
          </Col>

          <Col xs={24} sm={12} md={6}>
            <Form.Item
              name="templateType"
              label="Template Type"
              // rules={[{ required: true, message: "Please select template type" }]}
              extra={<Text type="secondary" style={{ fontSize: 11 }}>Manufacturing or packaging</Text>}
            >
              <Select
                placeholder="Select type"
                options={Template_types}
                className="w-full"
              />
            </Form.Item>
          </Col>

          <Col xs={24} sm={12} md={6}>
            <Form.Item
              name="templateName"
              label="Template Name"
              // rules={[{ required: true, message: "Please enter template name" }]}
              extra={<Text type="secondary" style={{ fontSize: 11 }}>Descriptive name for template</Text>}
            >
              <Input placeholder="e.g., Tablet Template v1" />
            </Form.Item>
          </Col>
        </Row>

        <Divider />

        {/* Section 2: Product Information */}
        <Space>
          <InfoCircleOutlined className="text-blue-500" />
          <Title level={5} style={{ margin: 0 }}>Product Information</Title>
        </Space>

        <Row gutter={[24, 16]} className="mt-4">
          <Col xs={24} sm={12} md={6}>
            <Form.Item
              name="productCode"
              label="Product Code"
              extra={<Text type="secondary" style={{ fontSize: 11 }}>Auto-filled from product</Text>}
            >
              <Input placeholder="Auto-filled" disabled />
            </Form.Item>
          </Col>

          <Col xs={24} sm={12} md={8}>
            <Form.Item
              name="productName"
              label="Product Name"
              // rules={[{ required: true, message: "Please select a product" }]}
              extra={<Text type="secondary" style={{ fontSize: 11 }}>Search by name or code</Text>}
            >
              <Select
                showSearch
                value={searchValue}
                placeholder="Search product by name or code..."
                style={{ width: "100%" }}
                defaultActiveFirstOption={false}
                filterOption={false}
                onSearch={(value) => setSearchValue(value)}
                onChange={handleProductChange}
                notFoundContent={loading ? <Spin size="small" /> : null}
                options={productOptions}
              />
            </Form.Item>
          </Col>

          <Col xs={24} sm={12} md={10}>
            <Form.Item
              name="manufacturingBomCode"
              label="Manufacturing BOM"
              // rules={[{ required: true, message: "Please select BOM" }]}
              help={
                <div className="flex gap-4">
                  <span className="flex items-center gap-1 text-[10px]">
                    <Badge status="success" />
                    Active BOM
                  </span>
                  <span className="flex items-center gap-1 text-[10px]">
                    <Badge status="default" />
                    Inactive BOM
                  </span>
                </div>
              }
            >
              <Select
                showSearch
                placeholder="Select Manufacturing BOM..."
                style={{ width: "100%" }}
                defaultActiveFirstOption={false}
                filterOption={false}
                onChange={handleReferenceManufacturingBomChange}
                notFoundContent={
                  loading ?
                    <Spin size="small" /> :
                    <Empty
                      description="No BOM found"
                      image={Empty.PRESENTED_IMAGE_SIMPLE}
                    />
                }
                options={referenceManufacturingBomOptions}
              />
            </Form.Item>
          </Col>
        </Row>

        <Row gutter={[24, 16]}>

          <Col xs={24} sm={12} md={8}>
            <Form.Item
              name="strength"
              label="Strength"
            >
              <Input placeholder="e.g., 500mg" />
            </Form.Item>
          </Col>
          <Col xs={24} sm={12} md={8}>
            <Form.Item
              name="dosageForm"
              label="Dosage Form"
            >
              <Select
                placeholder="Select dosage form"
                options={Dosage_Forms}
              />
            </Form.Item>
          </Col>

          <Col xs={24} sm={12} md={8}>
            <Form.Item
              noStyle
              shouldUpdate={(prevValues, curValues) => prevValues.dosageForm !== curValues.dosageForm}
            >
              {({ getFieldValue }) => {
                const dosageForm = getFieldValue('dosageForm');
                return (
                  <Form.Item
                    name="tabletType"
                    label="Tablet Type"
                    hidden={dosageForm !== 'Tablet'}
                  >
                    <Select
                      placeholder="Select tablet type"
                      options={Tabalet_Types}
                    />
                  </Form.Item>
                );
              }}
            </Form.Item>
          </Col>
        </Row>

        {/* Coating Required toggle - visible only when dosage form is Tablet */}
        <Row gutter={[24, 16]}>
          <Col xs={24} sm={12} md={8}>
            <Form.Item
              noStyle
              shouldUpdate={(prevValues, curValues) => prevValues.dosageForm !== curValues.dosageForm}
            >
              {({ getFieldValue }) => {
                const dosageForm = getFieldValue('dosageForm');
                return (
                  <Form.Item
                    name="coatingRequired"
                    label="Coating Required?"
                    valuePropName="checked"
                    hidden={dosageForm !== 'Tablet'}
                  >
                    <Switch
                      checkedChildren="Yes"
                      unCheckedChildren="No"
                    />
                  </Form.Item>
                );
              }}
            </Form.Item>
          </Col>
        </Row>

        <Divider />

        {/* Section 3: Batch Information */}
        <Space>
          <InfoCircleOutlined className="text-blue-500" />
          <Title level={5} style={{ margin: 0 }}>Batch Information</Title>
        </Space>

        <Row gutter={[24, 16]} className="mt-4">
          <Col xs={24} sm={12} md={6}>
            <Form.Item
              name="batchSizeBulk"
              label="Batch Size (Bulk)"
              // rules={[{ required: true, message: "Required" }]}
              extra={<Text type="secondary" style={{ fontSize: 11 }}>Total bulk quantity per batch</Text>}
            >
              <InputNumber
                placeholder="Enter bulk batch size"
                style={{ width: '100%' }}
                min={0}
              />
            </Form.Item>
          </Col>

          <Col xs={24} sm={12} md={6}>
            <Form.Item
              name="uomBulk"
              label="UOM (Bulk)"
              // rules={[{ required: true, message: "Required" }]}
              extra={<Text type="secondary" style={{ fontSize: 11 }}>Unit of bulk measurement</Text>}
            >
              <Select
                placeholder="Select UOM"
                options={UOM_OPTIONS_BULK}
                style={{ width: '100%' }}
              />
            </Form.Item>
          </Col>

          <Col xs={24} sm={12} md={6}>
            <Form.Item
              name="batchSizeSemiFinished"
              label="Batch Size (Semi-Finished)"
              // rules={[{ required: true, message: "Required" }]}
              extra={<Text type="secondary" style={{ fontSize: 11 }}>Semi-finished product quantity</Text>}
            >
              <InputNumber
                placeholder="Enter semi-finished batch size"
                style={{ width: '100%' }}
                min={0}
              />
            </Form.Item>
          </Col>

          <Col xs={24} sm={12} md={6}>
            <Form.Item
              name="uomSemiFinished"
              label="UOM (Semi-Finished)"
              // rules={[{ required: true, message: "Required" }]}
              extra={<Text type="secondary" style={{ fontSize: 11 }}>Unit of semi-finished measurement</Text>}
            >
              <Select
                placeholder="Select UOM"
                options={UOM_OPTIONS}
                style={{ width: '100%' }}
              />
            </Form.Item>
          </Col>
        </Row>

        <Divider />

        {/* Section 4: Storage & Registration */}
        <Space>
          <InfoCircleOutlined className="text-blue-500" />
          <Title level={5} style={{ margin: 0 }}>Storage & Registration</Title>
        </Space>

        <Row gutter={[24, 16]} className="mt-4">
          <Col xs={24} sm={12} md={8}>
            <Form.Item
              name="storageConditions"
              label="Storage Conditions"
              extra={<Text type="secondary" style={{ fontSize: 11 }}>Temperature & humidity requirements</Text>}
            >
              <Select
                mode="multiple"
                allowClear
                placeholder="Select storage conditions"
                options={Storage_Conditions}
                className="w-full"
              />
            </Form.Item>
          </Col>

          <Col xs={24} sm={12} md={8}>
            <Form.Item
              name="shelfLife"
              label="Shelf Life"
              extra={<Text type="secondary" style={{ fontSize: 11 }}>Product validity in months</Text>}
            >
              <InputNumber
                placeholder="Enter in months"
                className="w-full"
                min={0}
                style={{ width: '100%' }}
                addonAfter="months"
              />
            </Form.Item>
          </Col>

          <Col xs={24} sm={12} md={8}>
            <Form.Item
              name="drugRegistrationNumber"
              label="Drug Registration Number"
              extra={<Text type="secondary" style={{ fontSize: 11 }}>Official drug license number</Text>}
            >
              <Input placeholder="Enter registration number" />
            </Form.Item>
          </Col>
        </Row>

        <Row gutter={[24, 16]}>
          <Col xs={24} sm={12} md={8}>
            <Form.Item
              name="effectiveDate"
              label="Effective Date"
              extra={<Text type="secondary" style={{ fontSize: 11 }}>When template becomes active</Text>}
            >
              <DatePicker
                className="w-full"
                format="YYYY-MM-DD"
                placeholder="Select date"
              />
            </Form.Item>
          </Col>

          <Col xs={24} sm={12} md={8}>
            <Form.Item
              name="status"
              label="Status"
              extra={<Text type="secondary" style={{ fontSize: 11 }}>Draft, Active, or Inactive</Text>}
            >
              <Select
                placeholder="Select status"
                options={[
                  { value: "Draft", label: "Draft" },
                  { value: "Active", label: "Active" },
                  { value: "Inactive", label: "Inactive" },
                  { value: "Under Review", label: "Under Review" },
                ]}
              />
            </Form.Item>
          </Col>
        </Row>

        <Divider />

        {/* Action Buttons */}
        <div style={{ width: '100%', justifyContent: 'flex-end' }} className="flex gap-2">

          {onPrevious && (
            <Button
              icon={<ArrowLeftOutlined />}
              onClick={onPrevious}>
              Previous
            </Button>
          )}  
          <Button
            type="primary"
            onClick={async () => {
              try {
                await form.validateFields();
                const values = form.getFieldsValue();
                handleNext(values);
              } catch (error) {
                console.error("Validation failed:", error);
                message.error("Please fill all required fields");
              }
            }}
          >
            Next <ArrowRightOutlined  />
          </Button>
        </div>
      </Card>
    </Form >
  );
}
