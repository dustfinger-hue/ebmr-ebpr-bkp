'use client'

import { DataContext } from "@/lib/utils/DataContext"
import { BOTTLE_TYPES, CAP_TYPES, IPQC_FREQUENCY, LIQUID_DEFECT_TYPES, SEAL_TYPES } from "@/lib/constants/Generarl"
import {
  ArrowLeftOutlined,
  ArrowRightOutlined,
  DeleteOutlined,
  PlusOutlined,
  InfoCircleOutlined,
  SettingOutlined,
  CheckCircleOutlined,
  WarningOutlined,
  DashboardOutlined
} from "@ant-design/icons"
import { Button, Card, Col, Descriptions, Divider, Form, Input, InputNumber, message, Row, Select, Space, Table, Tag, Typography } from "antd"
import { useContext, useEffect, useMemo, useState } from "react"

const { Title, Text } = Typography

interface LiquidParamsProps {
  onNext: () => void
  onPrevious: () => void
}

interface IPQCRow {
  id: string
  parameterName: string
  specification: string
  frequency: string
}

const createId = () => `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`

const DEFAULT_IPQC_PARAMETERS = [
  'Fill Weight Check (by weight)',
  'Appearance / Clarity',
  'pH Check'
]

export default function LiquidSuspensionAndSolution({ onNext, onPrevious }: LiquidParamsProps) {
  const [form] = Form.useForm()
  const { templateData, setTemplateData } = useContext(DataContext)
  const [activeTab, setActiveTab] = useState<'machine' | 'container' | 'process' | 'quality'>('machine')
  const tabFlow: Array<typeof activeTab> = ['machine', 'container', 'process', 'quality']
  const isLastTab = activeTab === tabFlow[tabFlow.length - 1]
  const [cppParameters, setCppParameters] = useState<any[]>([])
  const [ipqcRows, setIpqcRows] = useState<IPQCRow[]>(() =>
    DEFAULT_IPQC_PARAMETERS.map((name) => ({
      id: createId(),
      parameterName: name,
      specification: '',
      frequency: ''
    }))
  )

  // Watch density & fill volume for auto-calculation
  const targetFillVolume = Form.useWatch('targetFillVolume', form)
  const productDensity = Form.useWatch('productDensity', form)
  const fillWeightTolerance = Form.useWatch('fillWeightTolerance', form)

  // Auto-calculated values
  const calculatedFillWeight = targetFillVolume && productDensity
    ? (Number(targetFillVolume) * Number(productDensity)).toFixed(2)
    : null

  const equivalentVolumeTolerance = fillWeightTolerance && productDensity && Number(productDensity) > 0
    ? (Number(fillWeightTolerance) / Number(productDensity)).toFixed(2)
    : null

  const machineList = useMemo(() => {
    const formattedData: any[] = []
    const equipment = templateData?.['Facility Equipment']?.facilitiesWithEquipment || []

    equipment.forEach((facility: any) => {
      facility.equipments?.forEach((equipment: any) => {
        formattedData.push({
          machineName: equipment.equipmentName,
          machineCode: equipment.equipmentCode,
          areaName: facility.areaName || 'N/A',
          facilityCode: facility.facilityCode || 'N/A',
          cppParameters: equipment.cppParameters?.map((param: any) => ({
            parameterName: param.parameterName,
            minValue: param.minValue,
            maxValue: param.maxValue,
            unit: param.unit || 'Not Specified',
            range: `${param.minValue} - ${param.maxValue} ${param.unit || ''}`
          })) || []
        })
      })
    })

    return formattedData
  }, [templateData])

  // Map active tab to sub-key
  const getStageKey = (tab: string): string => {
    const stageMap: Record<string, string> = {
      machine: 'machineSetup',
      container: 'containerSpecs',
      process: 'processParams',
      quality: 'qualityControls'
    }
    return stageMap[tab] || 'machineSetup'
  }

  // Load saved data when tab changes
  useEffect(() => {
    const savedData = templateData?.['Liquid Suspension Parameters']
    if (savedData) {
      const stageKey = getStageKey(activeTab)
      const stageData = savedData[stageKey]
      if (stageData) {
        form.setFieldsValue(stageData)
      }
      if (activeTab === 'machine') {
        if (savedData.selectedMachineCode) {
          const machine = machineList.find((m) => m.machineCode === savedData.selectedMachineCode)
          if (machine) {
            setCppParameters(machine.cppParameters || [])
          }
        }
      }
      if (activeTab === 'quality') {
        if (savedData.ipqcRows?.length > 0) {
          setIpqcRows(savedData.ipqcRows)
        }
      }
    }
  }, [activeTab])

  const handleMachineChange = (value: string) => {
    const selectedMachine = machineList.find((machine) => machine.machineCode === value)

    if (selectedMachine) {
      const params = selectedMachine.cppParameters?.map((param: any) => ({
        parameterName: param.parameterName,
        minValue: param.minValue,
        maxValue: param.maxValue,
        unit: param.unit || 'Not Specified'
      })) || []

      form.setFieldValue('machineId', selectedMachine.machineCode)
      form.setFieldValue('machineLocation', `${selectedMachine.areaName} - ${selectedMachine.facilityCode}`)
      setCppParameters(params)
    } else {
      setCppParameters([])
      form.setFieldValue('machineId', '')
      form.setFieldValue('machineLocation', '')
    }
  }

  const handleAddIpqcRow = () => {
    setIpqcRows((prev) => [
      ...prev,
      { id: createId(), parameterName: '', specification: '', frequency: '' }
    ])
  }

  const handleRemoveIpqcRow = (id: string) => {
    setIpqcRows((prev) => prev.filter((row) => row.id !== id))
  }

  const handleIpqcChange = (id: string, field: keyof IPQCRow, value: string) => {
    setIpqcRows((prev) =>
      prev.map((row) => (row.id === id ? { ...row, [field]: value } : row))
    )
  }

  const handleSaveAndNext = async () => {
    try {
      const values = await form.validateFields()
      const stageKey = getStageKey(activeTab)

      const stageData: any = { ...values }

      // For machine tab, include CPP values
      if (activeTab === 'machine') {
        stageData.cppValues = cppParameters.map((param: any) => ({
          parameterName: param.parameterName,
          value: Number(form.getFieldValue(`cpp_${param.parameterName}`) || 0),
          minValue: param.minValue,
          maxValue: param.maxValue,
          unit: param.unit
        }))
        stageData.selectedMachineCode = values.machine
      }

      // For process tab, include calculated values
      if (activeTab === 'process') {
        stageData.calculatedFillWeight = calculatedFillWeight ? Number(calculatedFillWeight) : null
        stageData.equivalentVolumeTolerance = equivalentVolumeTolerance ? Number(equivalentVolumeTolerance) : null
      }

      // For quality tab, include IPQC rows
      if (activeTab === 'quality') {
        stageData.ipqcRows = ipqcRows.filter((row) => row.parameterName && row.specification)
      }

      setTemplateData((prev: any) => ({
        ...prev,
        ['Liquid Suspension Parameters']: {
          ...(prev?.['Liquid Suspension Parameters'] || {}),
          [stageKey]: stageData
        }
      }))

      message.success('Parameters saved successfully')

      if (isLastTab) {
        onNext()
        return
      }

      const nextTab = tabFlow[tabFlow.indexOf(activeTab) + 1]
      if (nextTab) {
        setActiveTab(nextTab)
      }
    } catch (error) {
      console.error('Validation failed:', error)
      message.error('Please fill all required fields correctly')
    }
  }

  const ipqcColumns = [
    {
      title: 'Parameter Name',
      dataIndex: 'parameterName',
      key: 'parameterName',
      width: 250,
      render: (text: string, record: IPQCRow) => (
        <Input
          value={record.parameterName}
          onChange={(e) => handleIpqcChange(record.id, 'parameterName', e.target.value)}
          placeholder="e.g., Fill Weight Check"
          size="small"
          style={{ minWidth: 180 }}
        />
      ),
    },
    {
      title: 'Specification / Limit',
      dataIndex: 'specification',
      key: 'specification',
      width: 300,
      render: (text: string, record: IPQCRow) => (
        <Input
          value={record.specification}
          onChange={(e) => handleIpqcChange(record.id, 'specification', e.target.value)}
          placeholder="e.g., ±5g of target weight"
          size="small"
          style={{ minWidth: 200 }}
        />
      ),
    },
    {
      title: 'Frequency',
      dataIndex: 'frequency',
      key: 'frequency',
      width: 200,
      render: (text: string, record: IPQCRow) => (
        <Select
          value={record.frequency || undefined}
          onChange={(value) => handleIpqcChange(record.id, 'frequency', value)}
          placeholder="Select frequency"
          size="small"
          style={{ width: '100%' }}
          options={IPQC_FREQUENCY}
        />
      ),
    },
    {
      title: 'Actions',
      key: 'actions',
      width: 60,
      render: (_: any, record: IPQCRow) => (
        <Button
          type="text"
          danger
          icon={<DeleteOutlined />}
          onClick={() => handleRemoveIpqcRow(record.id)}
          size="small"
          disabled={DEFAULT_IPQC_PARAMETERS.includes(record.parameterName) && ipqcRows.filter((r) => r.parameterName === record.parameterName).length === 1}
        />
      ),
    },
  ]

  const tabs = [
    { key: 'machine', label: 'Machine Setup', icon: <SettingOutlined /> },
    { key: 'container', label: 'Container Specs', icon: <InfoCircleOutlined /> },
    { key: 'process', label: 'Process Parameters', icon: <DashboardOutlined /> },
    { key: 'quality', label: 'Quality Controls', icon: <CheckCircleOutlined /> },
  ]

  return (
    <div className="space-y-4">
      {/* Tab Navigation */}
      <Card size="small" className="sticky top-0 z-10">
        <div className="flex flex-wrap gap-2">
          {tabs.map(tab => (
            <Button
              key={tab.key}
              type={activeTab === tab.key ? 'primary' : 'default'}
              icon={tab.icon}
              onClick={() => setActiveTab(tab.key as typeof activeTab)}
              className="flex-1 min-w-30"
            >
              {tab.label}
            </Button>
          ))}
        </div>
      </Card>

      <Form form={form} layout="vertical" name="liquid_params">
        {/* Tab 1: Machine Setup */}
        {activeTab === 'machine' && (
          <Card title={
            <Space>
              <SettingOutlined className="text-blue-500" />
              <Title level={5} style={{ margin: 0 }}>Filling / Mixing Machine Setup</Title>
            </Space>
          }>
            <Divider orientation="horizontal">
              <InfoCircleOutlined className="mr-2" />
              Machine Information
            </Divider>

            <Row gutter={[24, 16]}>
              <Col xs={24} md={12}>
                <Form.Item
                  name="machine"
                  label="Filling / Mixing Machine"
                  rules={[{ required: true, message: 'Please select a machine' }]}
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Select filling or mixing machine</Text>}
                >
                  <Select
                    placeholder="Select machine"
                    size="large"
                    style={{ width: '100%' }}
                    options={machineList.map((m) => ({
                      label: `${m.machineName} - ${m.machineCode}`,
                      value: m.machineCode
                    }))}
                    onChange={handleMachineChange}
                    showSearch
                    optionFilterProp="label"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={12}>
                <Form.Item
                  name="machineId"
                  label="Machine ID / Code"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Auto-filled from system</Text>}
                >
                  <Input placeholder="Auto-filled" size="large" disabled />
                </Form.Item>
              </Col>
            </Row>

            <Row gutter={[24, 16]}>
              <Col xs={24} md={12}>
                <Form.Item
                  name="machineLocation"
                  label="Machine Location"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Auto-filled from system</Text>}
                >
                  <Input placeholder="Auto-filled" size="large" disabled />
                </Form.Item>
              </Col>
            </Row>

            {cppParameters.length > 0 && (
              <>
                <Divider>
                  <SettingOutlined className="mr-2" />
                  Critical Process Parameters
                </Divider>
                <Row gutter={[24, 16]}>
                  {cppParameters.map((param, index) => (
                    <Col xs={24} md={6} key={index}>
                      <Form.Item
                        name={['cppParameters', index, 'parameterName']}
                        initialValue={param.parameterName}
                        hidden
                      >
                        <Input />
                      </Form.Item>
                      <Form.Item
                        name={['cppParameters', index, 'unit']}
                        initialValue={param.unit}
                        hidden
                      >
                        <Input />
                      </Form.Item>
                      <Form.Item
                        label={param.parameterName}
                        name={`cpp_${param.parameterName}`}
                        extra={
                          <Text type="secondary" style={{ fontSize: 11 }}>
                            Range: {param.minValue} - {param.maxValue} {param.unit}
                          </Text>
                        }
                      >
                        <InputNumber
                          min={param.minValue}
                          max={param.maxValue}
                          placeholder={`${param.minValue} - ${param.maxValue}`}
                          size="large"
                          style={{ width: '100%' }}
                          addonAfter={param.unit}
                        />
                      </Form.Item>
                    </Col>
                  ))}
                </Row>
              </>
            )}
          </Card>
        )}

        {/* Tab 2: Container Specs */}
        {activeTab === 'container' && (
          <Card title={
            <Space>
              <InfoCircleOutlined className="text-cyan-500" />
              <Title level={5} style={{ margin: 0 }}>Container Specifications</Title>
            </Space>
          }>
            <Row gutter={[24, 16]}>
              <Col xs={24} md={8}>
                <Form.Item
                  name="bottleType"
                  label="Bottle / Container Type"
                  rules={[{ required: true, message: 'Please select container type' }]}
                >
                  <Select
                    placeholder="Select container type"
                    options={BOTTLE_TYPES}
                    size="large"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="bottleSize"
                  label="Bottle Size (ml)"
                  rules={[{ required: true, message: 'Required' }]}
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Container capacity</Text>}
                >
                  <InputNumber
                    placeholder="e.g., 100"
                    min={1}
                    size="large"
                    style={{ width: '100%' }}
                    addonAfter="ml"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="capType"
                  label="Cap Type"
                  rules={[{ required: true, message: 'Please select cap type' }]}
                >
                  <Select
                    placeholder="Select cap type"
                    options={CAP_TYPES}
                    size="large"
                  />
                </Form.Item>
              </Col>
            </Row>

            <Row gutter={[24, 16]}>
              <Col xs={24} md={8}>
                <Form.Item
                  name="sealType"
                  label="Seal Type"
                >
                  <Select
                    placeholder="Select seal type"
                    options={SEAL_TYPES}
                    size="large"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="closureTorque"
                  label="Closure Torque (N·m)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Cap tightening torque</Text>}
                >
                  <InputNumber
                    placeholder="e.g., 2.5"
                    min={0}
                    step={0.1}
                    size="large"
                    style={{ width: '100%' }}
                    addonAfter="N·m"
                  />
                </Form.Item>
              </Col>
            </Row>
          </Card>
        )}

        {/* Tab 3: Process Parameters */}
        {activeTab === 'process' && (
          <Card title={
            <Space>
              <DashboardOutlined className="text-blue-500" />
              <Title level={5} style={{ margin: 0 }}>Process Parameters</Title>
            </Space>
          }>
            <Divider orientation="horizontal">
              <InfoCircleOutlined className="mr-2" />
              Fill Parameters — Density Based Weight Check
            </Divider>

            <Row gutter={[24, 16]}>
              <Col xs={24} md={8}>
                <Form.Item
                  name="targetFillVolume"
                  label="Target Fill Volume (ml)"
                  rules={[{ required: true, message: 'Required' }]}
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Nominal fill volume per container</Text>}
                >
                  <InputNumber
                    placeholder="e.g., 100"
                    min={0}
                    size="large"
                    style={{ width: '100%' }}
                    addonAfter="ml"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="productDensity"
                  label="Product Density (g/ml)"
                  rules={[{ required: true, message: 'Required' }]}
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Density for weight-based check</Text>}
                >
                  <InputNumber
                    placeholder="e.g., 1.15"
                    min={0}
                    step={0.01}
                    size="large"
                    style={{ width: '100%' }}
                    addonAfter="g/ml"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="fillWeightTolerance"
                  label="Fill Weight Tolerance (±g)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Acceptable weight variation</Text>}
                >
                  <InputNumber
                    placeholder="e.g., 5"
                    min={0}
                    size="large"
                    style={{ width: '100%' }}
                    addonAfter="g"
                  />
                </Form.Item>
              </Col>
            </Row>

            {/* Auto-calculated values display */}
            {(calculatedFillWeight || equivalentVolumeTolerance) && (
              <Card size="small" style={{ marginBottom: 16, background: '#141414' }}>
                <Descriptions column={2} size="small">
                  {calculatedFillWeight && (
                    <Descriptions.Item label="Calculated Target Fill Weight">
                      <Tag color="green">{calculatedFillWeight} g</Tag>
                    </Descriptions.Item>
                  )}
                  {equivalentVolumeTolerance && (
                    <Descriptions.Item label="Equivalent Volume Tolerance">
                      <Tag color="blue">±{equivalentVolumeTolerance} ml</Tag>
                    </Descriptions.Item>
                  )}
                </Descriptions>
                <Text type="secondary" style={{ fontSize: 12 }}>
                  * Fill weight = Volume × Density. QC checks weight instead of volume for higher accuracy.
                </Text>
              </Card>
            )}

            <Divider orientation="horizontal">
              <SettingOutlined className="mr-2" />
              Mixing Parameters
            </Divider>

            <Row gutter={[24, 16]}>
              <Col xs={24} md={8}>
                <Form.Item
                  name="mixingSpeed"
                  label="Mixing Speed (RPM)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Agitator speed during mixing</Text>}
                >
                  <InputNumber
                    placeholder="e.g., 500"
                    min={0}
                    size="large"
                    style={{ width: '100%' }}
                    addonAfter="RPM"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="mixingTime"
                  label="Mixing Time (min)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Duration of mixing/homogenization</Text>}
                >
                  <InputNumber
                    placeholder="e.g., 30"
                    min={0}
                    size="large"
                    style={{ width: '100%' }}
                    addonAfter="min"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="productionSpeed"
                  label="Production Speed (bottles/hr)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Filling line speed</Text>}
                >
                  <InputNumber
                    placeholder="e.g., 3000"
                    min={0}
                    step={100}
                    size="large"
                    style={{ width: '100%' }}
                    addonAfter="bottles/hr"
                  />
                </Form.Item>
              </Col>
            </Row>
          </Card>
        )}

        {/* Tab 4: Quality Controls */}
        {activeTab === 'quality' && (
          <>
            <Card
              title={
                <Space>
                  <WarningOutlined className="text-orange-500" />
                  <Title level={5} style={{ margin: 0 }}>In-Process Quality Controls (IPQC)</Title>
                </Space>
              }
            >
              <Table
                columns={ipqcColumns}
                dataSource={ipqcRows}
                rowKey="id"
                pagination={false}
                size="middle"
                scroll={{ x: 700 }}
              />

              <div className="mt-3">
                <Button icon={<PlusOutlined />} onClick={handleAddIpqcRow}>
                  Add IPQC Parameter
                </Button>
              </div>
            </Card>

            <Card
              title={
                <Space>
                  <WarningOutlined className="text-red-500" />
                  <Title level={5} style={{ margin: 0 }}>Liquid / Suspension Defects</Title>
                </Space>
              }
            >
              <Form.Item
                name="liquidDefects"
                label="Select potential defects"
                extra={<Text type="secondary" style={{ fontSize: 11 }}>Choose possible defects that may occur</Text>}
              >
                <Select
                  mode="multiple"
                  allowClear
                  placeholder="Select defects"
                  options={LIQUID_DEFECT_TYPES}
                  size="large"
                  style={{ width: '100%' }}
                />
              </Form.Item>
            </Card>
          </>
        )}
      </Form>

      {/* Action Buttons */}
      <div className="flex justify-end gap-2">
        <Button
          icon={<ArrowLeftOutlined />}
          onClick={onPrevious}
          size="large"
        >
          Back
        </Button>
        <Button
          type="primary"
          icon={<ArrowRightOutlined />}
          onClick={handleSaveAndNext}
          size="large"
        >
          Save & Next
        </Button>
      </div>
    </div>
  )
}