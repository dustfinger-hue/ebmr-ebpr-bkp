'use client'

import { Button, Drawer, Spin, Typography, Tag, Space, Row, Col, Empty, List, message, Segmented, Input, Badge, Alert } from "antd";
import { CopyOutlined, FileSearchOutlined, CloseOutlined, SearchOutlined, ReloadOutlined, InfoCircleOutlined } from "@ant-design/icons";
import { useContext, useEffect, useState } from "react";
import { DataContext } from "@/lib/utils/DataContext";
import { useReferenceData, TemplateRecord } from "@/lib/utils/ReferenceDataContext";
import { SectionRenderer } from "./SectionRenderers";

const { Text, Title } = Typography;

interface CopyReferenceSidebarProps {
    open: boolean;
    onClose: () => void;
    activeTab: string;
}

// Common copy helper
const copyToClipboard = (value: any, label: string) => {
    const text = typeof value === 'object' ? JSON.stringify(value, null, 2) : String(value ?? '');
    navigator.clipboard.writeText(text).then(() => {
        message.success(`Copied: ${label}`);
    }).catch(() => {
        message.error('Failed to copy');
    });
};

// Render a field with label and copy button
function FieldRow({ label, value }: { label: string; value: any }) {
    if (value === undefined || value === null || value === '') return null;

    const displayValue = typeof value === 'object' ? JSON.stringify(value, null, 2) : String(value);

    return (
        <div style={{
            padding: '6px 8px',
            borderBottom: '1px solid #f0f0f0',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'flex-start',
            gap: 8,
        }}>
            <div style={{ flex: 1, minWidth: 0 }}>
                <Text type="secondary" style={{ fontSize: 11, display: 'block', marginBottom: 2 }}>
                    {label}
                </Text>
                <Text style={{ fontSize: 13, wordBreak: 'break-word' }}>{displayValue}</Text>
            </div>
            <Button
                type="text"
                size="small"
                icon={<CopyOutlined />}
                onClick={() => copyToClipboard(value, label)}
                style={{ flexShrink: 0, marginTop: 2 }}
            />
        </div>
    );
}

// Render a JSON object as a list of field rows
function ObjectRenderer({ data, labelPrefix }: { data: Record<string, any>; labelPrefix?: string }) {
    if (!data || typeof data !== 'object') return null;

    return (
        <div>
            {Object.entries(data).map(([key, value]) => {
                const label = labelPrefix ? `${labelPrefix} > ${key}` : key;
                if (value && typeof value === 'object' && !Array.isArray(value)) {
                    return (
                        <div key={key} style={{ marginLeft: 12, borderLeft: '2px solid #e8e8e8', paddingLeft: 8, marginBottom: 4 }}>
                            <Text strong style={{ fontSize: 12, display: 'block', marginBottom: 4, color: '#595959' }}>
                                {key}
                            </Text>
                            <ObjectRenderer data={value} labelPrefix={label} />
                        </div>
                    );
                }
                if (Array.isArray(value)) {
                    return (
                        <div key={key} style={{ marginBottom: 4 }}>
                            <Text strong style={{ fontSize: 12, display: 'block', marginBottom: 4, color: '#595959' }}>
                                {key} [{value.length} items]
                            </Text>
                            {value.map((item, idx) => (
                                <div key={idx} style={{ marginLeft: 12, borderLeft: '2px solid #e8e8e8', paddingLeft: 8, marginBottom: 2 }}>
                                    {typeof item === 'object' ? (
                                        <ObjectRenderer data={item} labelPrefix={`${label}[${idx}]`} />
                                    ) : (
                                        <FieldRow label={`${label}[${idx}]`} value={item} />
                                    )}
                                </div>
                            ))}
                        </div>
                    );
                }
                return <FieldRow key={key} label={label} value={value} />;
            })}
        </div>
    );
}

export default function CopyReferenceSidebar({ open, onClose, activeTab }: CopyReferenceSidebarProps) {
    const { templateData } = useContext(DataContext);
    const {
        templates,
        setTemplates,
        selectedTemplate,
        setSelectedTemplate,
        fullTemplateData,
        setFullTemplateData,
        view,
        setView,
        searchText,
        setSearchText,
        isDetailLoaded,
        setIsDetailLoaded,
        resetReferenceData,
    } = useReferenceData();
    const [loading, setLoading] = useState(false);
    const [fetchingDetail, setFetchingDetail] = useState(false);

    const productCode = String(templateData?.['Basic Information']?.productCode || '');

    // Determine current section key from activeTab
    const getCurrentSection = (): { sectionKey: string; title: string } | null => {
        const tabNum = parseInt(activeTab);
        if (tabNum === 1) return { sectionKey: 'Basic Information', title: 'Basic Information' };
        if (tabNum === 2) return { sectionKey: 'Manufacturing BOM', title: 'Manufacturing BOM' };
        if (tabNum === 3) return { sectionKey: 'Facility Equipment', title: 'Facility & Equipment' };
        if (tabNum === 4) return { sectionKey: 'Manufacturing Steps', title: 'Manufacturing Steps' };
        if (tabNum === 5) {
            const dosageForm = templateData?.['Basic Information']?.dosageForm;
            if (dosageForm === 'Tablet') return { sectionKey: 'Compression Parameters', title: 'Compression Parameters' };
            if (dosageForm === 'Capsule') return { sectionKey: 'Encapsulation Parameters', title: 'Encapsulation Parameters' };
            if (['Syrup', 'Liquid Suspension', 'Solution', 'Drop'].includes(dosageForm)) {
                return { sectionKey: 'Liquid Suspension and Solution', title: 'Liquid/Suspension Parameters' };
            }
            if (['Dry Powder Suspension', 'Powder'].includes(dosageForm)) {
                return { sectionKey: 'Powder Filling Parameters', title: 'Powder Filling Parameters' };
            }
            if (['Cream', 'Ointment', 'Gel', 'Lotion'].includes(dosageForm)) {
                return { sectionKey: 'Semisolid Parameters', title: 'Semisolid Parameters' };
            }
            return null;
        }
        if (tabNum === 6) {
            const isCoating = templateData?.['Basic Information']?.coatingRequired === true;
            if (isCoating) return { sectionKey: 'Coating Section', title: 'Coating Section' };
            return { sectionKey: 'Basic Information', title: 'Basic Information' }; // fallback to preview tab
        }
        return null;
    };

    // Fetch templates for this product
    const fetchTemplates = async () => {
        if (!productCode) return;
        setLoading(true);
        try {
            const token = localStorage.getItem('token');
            const res = await fetch(
                `/api/user/production-template/manufacturing-template?productCode=${productCode}&limit=50`,
                {
                    headers: { Authorization: `Bearer ${token}` }
                }
            );
            const data = await res.json();
            if (data.success) {
                setTemplates(data.data || []);
            }
        } catch (err) {
            console.error('Error fetching templates:', err);
        } finally {
            setLoading(false);
        }
    };

    // Fetch full template data when user selects a template
    const handleSelectTemplate = async (tpl: TemplateRecord) => {
        setSelectedTemplate(tpl);
        setFetchingDetail(true);
        setView('detail');
        setIsDetailLoaded(false);
        try {
            const token = localStorage.getItem('token');
            const res = await fetch(
                `/api/user/production-template/manufacturing-template?id=${tpl._id}`,
                {
                    headers: { Authorization: `Bearer ${token}` }
                }
            );
            const data = await res.json();
            if (data.success && data.data) {
                setFullTemplateData(data.data.fullTemplateData || {});
                setIsDetailLoaded(true);
            }
        } catch (err) {
            console.error('Error fetching template detail:', err);
        } finally {
            setFetchingDetail(false);
        }
    };

    // Fetch templates when productCode changes (only if sidebar is open)
    useEffect(() => {
        if (open && productCode && templates.length === 0) {
            fetchTemplates();
        }
    }, [productCode]);

    // Preserve state when sidebar opens — only fetch if we don't have data yet
    useEffect(() => {
        if (open) {
            // Only reset if there's a productCode change that invalidates the current data
            // But we DON'T reset on every open - we keep the existing context
            if (templates.length === 0 && productCode) {
                fetchTemplates();
            }
        }
    }, [open]);

    // Get current section's data
    const section = getCurrentSection();
    const sectionData = section?.sectionKey && fullTemplateData?.[section.sectionKey]
        ? fullTemplateData[section.sectionKey]
        : null;

    const filteredTemplates = templates.filter(t => {
        if (!searchText) return true;
        const s = searchText.toLowerCase();
        return (
            t.templateCode?.toLowerCase().includes(s) ||
            t.templateName?.toLowerCase().includes(s) ||
            t.status?.toLowerCase().includes(s) ||
            t.templateVersion?.toLowerCase().includes(s)
        );
    });

    const statusColorMap: Record<string, string> = {
        'Pending Signatures': 'orange',
        'Active': 'green',
        'Draft': 'default',
        'Superseded': 'red',
        'Rejected': 'red',
        'Reverted': 'orange',
    };

    return (
        <Drawer
            title={
                <Space>
                    <FileSearchOutlined />
                    <span>Reference Templates</span>
                    {productCode && (
                        <Tag color="blue" style={{ marginLeft: 8 }}>{productCode}</Tag>
                    )}
                </Space>
            }
            placement="left"
            width={550}
            open={open}
            onClose={onClose}
            closable={false}
            styles={{
                header: {
                    background: '#001529',
                    padding: '12px 16px',
                },
                body: { padding: 0 },
            }}
            extra={
                <Button type="text" icon={<CloseOutlined />} onClick={onClose} style={{ color: '#fff' }} />
            }
        >
            {!productCode ? (
                <div style={{ padding: 40, textAlign: 'center' }}>
                    <Empty
                        description={
                            <Text type="secondary">
                                Please select a product in Basic Information first
                            </Text>
                        }
                    />
                </div>
            ) : (
                <>
                    {/* Toolbar */}
                    <div style={{
                        padding: '8px 12px',
                        borderBottom: '1px solid #555151',
                        display: 'flex',
                        gap: 8,
                        alignItems: 'center',
                    }}>
                        <Segmented
                            size="small"
                            value={view}
                            onChange={(v) => setView(v as 'list' | 'detail')}
                            options={[
                                { value: 'list', label: 'Templates' },
                                { value: 'detail', label: 'Detail' },
                            ]}
                            disabled={!selectedTemplate && view === 'detail'}
                        />
                        <Input
                            size="small"
                            placeholder="Search..."
                            prefix={<SearchOutlined />}
                            value={searchText}
                            onChange={e => setSearchText(e.target.value)}
                            style={{ flex: 1, minWidth: 100 }}
                            allowClear
                        />
                        <Button
                            size="small"
                            icon={<ReloadOutlined />}
                            onClick={() => {
                                resetReferenceData();
                                fetchTemplates();
                            }}
                        />
                    </div>

                    {view === 'list' ? (
                        /* Template List */
                        loading ? (
                            <div style={{ textAlign: 'center', padding: 40 }}>
                                <Spin />
                            </div>
                        ) : filteredTemplates.length === 0 ? (
                            <Empty
                                style={{ padding: 40 }}
                                description={
                                    searchText
                                        ? 'No matching templates found'
                                        : 'No templates exist for this product yet'
                                }
                            />
                        ) : (
                            <List
                                size="small"
                                dataSource={filteredTemplates}
                                renderItem={(tpl) => (
                                    <List.Item
                                        style={{
                                            cursor: 'pointer',
                                            padding: '8px 12px',
                                            background: selectedTemplate?._id === tpl._id ? '#425043' : undefined,
                                            borderBottom: '1px solid #444444',
                                        }}
                                        onClick={() => handleSelectTemplate(tpl)}
                                        actions={[
                                            <Button
                                                key="copy"
                                                type="link"
                                                size="small"
                                                icon={<CopyOutlined />}
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    handleSelectTemplate(tpl);
                                                }}
                                            >
                                                View
                                            </Button>
                                        ]}
                                    >
                                        <List.Item.Meta
                                            title={
                                                <Space size={4}>
                                                    <Text strong style={{ fontSize: 13 }}>
                                                        {tpl.templateCode}
                                                    </Text>
                                                    <Tag color={statusColorMap[tpl.status] || 'default'} style={{ fontSize: 10, lineHeight: '16px' }}>
                                                        {tpl.status}
                                                    </Tag>
                                                    <Tag style={{ fontSize: 10, lineHeight: '16px' }}>
                                                        v{tpl.templateVersion}
                                                    </Tag>
                                                </Space>
                                            }
                                            description={
                                                <Text style={{ fontSize: 12 }} ellipsis>
                                                    {tpl.templateName || 'No name'}
                                                </Text>
                                            }
                                        />
                                    </List.Item>
                                )}
                            />
                        )
                    ) : (
                        /* Detail View */
                        <>
                            {/* Selected template header */}
                            {selectedTemplate && (
                                <div style={{
                                    padding: '8px 12px',
                                    // background: '#fafafa',
                                    borderBottom: '1px solid #e63d3d',
                                }}>
                                    <Space size={4} style={{ marginBottom: 4 }}>
                                        <Text strong>{selectedTemplate.templateCode}</Text>
                                        <Tag color={statusColorMap[selectedTemplate.status] || 'default'}>
                                            {selectedTemplate.status}
                                        </Tag>
                                        <Tag>v{selectedTemplate.templateVersion}</Tag>
                                    </Space>
                                    {section && (
                                        <Badge
                                            status="processing"
                                            color="blue"
                                            text={
                                                <Text type="secondary" style={{ fontSize: 12 }}>
                                                    Viewing: {section.title}
                                                </Text>
                                            }
                                        />
                                    )}
                                </div>
                            )}

                            {/* Reference Data Alert Banner */}
                            {fullTemplateData && section && sectionData && (
                                <Alert
                                    type="info"
                                    showIcon
                                    icon={<InfoCircleOutlined />}
                                    message={
                                        <Space>
                                            <Tag color="blue" style={{ margin: 0 }}>Reference Data</Tag>
                                            <Text style={{ fontSize: 12 }}>
                                                Copying from <Text strong>{selectedTemplate?.templateCode}</Text> v{selectedTemplate?.templateVersion}
                                                {selectedTemplate?.status && (
                                                    <Tag color={statusColorMap[selectedTemplate.status] || 'default'} style={{ marginLeft: 4, fontSize: 10 }}>
                                                        {selectedTemplate.status}
                                                    </Tag>
                                                )}
                                            </Text>
                                        </Space>
                                    }
                                    style={{
                                        margin: '8px 8px 0 8px',
                                        padding: '4px 8px',
                                        borderRadius: 4,
                                    }}
                                />
                            )}

                            {/* Section data */}
                            {fetchingDetail ? (
                                <div style={{ textAlign: 'center', padding: 40 }}>
                                    <Spin tip="Loading template data..." />
                                </div>
                            ) : fullTemplateData && section && sectionData ? (
                                <SectionRenderer sectionKey={section.sectionKey} data={sectionData} />
                            ) : fullTemplateData && !sectionData ? (
                                <div style={{ padding: 20, textAlign: 'center' }}>
                                    <Empty
                                        description={
                                            <Text type="secondary">
                                                No data found for section: {section?.title}
                                            </Text>
                                        }
                                    />
                                </div>
                            ) : (
                                <div style={{ padding: 20, textAlign: 'center' }}>
                                    <Text type="secondary">Select a template to view data</Text>
                                </div>
                            )}

                            {/* Back button */}
                            <div style={{
                                padding: '8px 12px',
                                borderTop: '1px solid #f0f0f0',
                                position: 'sticky',
                                bottom: 0,
                                background: '#5a5a5a',
                            }}>
                                <Button
                                    size="small"
                                    type="text"
                                    onClick={() => {
                                        setView('list');
                                    }}
                                >
                                    ← Back to Templates
                                </Button>
                            </div>
                        </>
                    )}
                </>
            )}
        </Drawer>
    );
}