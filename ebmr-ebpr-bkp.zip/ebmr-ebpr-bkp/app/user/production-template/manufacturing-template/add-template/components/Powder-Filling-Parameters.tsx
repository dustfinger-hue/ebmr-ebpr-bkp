'use client'

import { DataContext } from "@/lib/utils/DataContext"
import { CAP_TYPES, IPQC_FREQUENCY, POWDER_CONTAINER_TYPES, POWDER_DEFECT_TYPES, SEAL_TYPES } from "@/lib/constants/Generarl"
import {
  ArrowLeftOutlined,
  ArrowRightOutlined,
  CheckCircleOutlined,
  DashboardOutlined,
  DeleteOutlined,
  InfoCircleOutlined,
  PlusOutlined,
  SettingOutlined,
  WarningOutlined
} from "@ant-design/icons"
import { Button, Card, Col, Divider, Form, Input, InputNumber, message, Row, Select, Space, Table, Typography } from "antd"
import { useContext, useEffect, useMemo, useState } from "react"

const { Title, Text } = Typography

interface PowderFillingParametersProps {
  onNext: () => void
  onPrevious: () => void
}

interface IPQCRow {
  id: string
  parameterName: string
  specification: string
  frequency: string
}

const createId = () => `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`

const DEFAULT_IPQC_PARAMETERS = [
  'Fill Weight Check',
  'Appearance / Lumps',
  'Seal Integrity'
]

export default function PowderFillingParameters({ onNext, onPrevious }: PowderFillingParametersProps) {
  const [form] = Form.useForm()
  const { templateData, setTemplateData } = useContext(DataContext)
  const [activeTab, setActiveTab] = useState<'machine' | 'container' | 'process' | 'quality'>('machine')
  const tabFlow: Array<typeof activeTab> = ['machine', 'container', 'process', 'quality']
  const isLastTab = activeTab === tabFlow[tabFlow.length - 1]
  const [cppParameters, setCppParameters] = useState<any[]>([])
  const [ipqcRows, setIpqcRows] = useState<IPQCRow[]>(() =>
    DEFAULT_IPQC_PARAMETERS.map((name) => ({
      id: createId(),
      parameterName: name,
      specification: '',
      frequency: ''
    }))
  )

  const machineList = useMemo(() => {
    const formattedData: any[] = []
    const equipment = templateData?.['Facility Equipment']?.facilitiesWithEquipment || []

    equipment.forEach((facility: any) => {
      facility.equipments?.forEach((equipment: any) => {
        formattedData.push({
          machineName: equipment.equipmentName,
          machineCode: equipment.equipmentCode,
          areaName: facility.areaName || 'N/A',
          facilityCode: facility.facilityCode || 'N/A',
          cppParameters: equipment.cppParameters?.map((param: any) => ({
            parameterName: param.parameterName,
            minValue: param.minValue,
            maxValue: param.maxValue,
            unit: param.unit || 'Not Specified'
          })) || []
        })
      })
    })

    return formattedData
  }, [templateData])

  // Map active tab to sub-key
  const getStageKey = (tab: string): string => {
    const stageMap: Record<string, string> = {
      machine: 'machineSetup',
      container: 'containerSpecs',
      process: 'processParams',
      quality: 'qualityControls'
    }
    return stageMap[tab] || 'machineSetup'
  }

  // Load saved data on mount and when tab changes
  useEffect(() => {
    const savedData = templateData?.['Powder Filling Parameters']
    if (savedData) {
      const stageKey = getStageKey(activeTab)
      const stageData = savedData[stageKey]
      if (stageData) {
        form.setFieldsValue(stageData)
      }
      if (activeTab === 'machine') {
        if (savedData.selectedMachineCode) {
          const machine = machineList.find((m) => m.machineCode === savedData.selectedMachineCode)
          if (machine) {
            setCppParameters(machine.cppParameters || [])
          }
        }
      }
      if (activeTab === 'quality' && savedData.ipqcRows?.length > 0) {
        setIpqcRows(savedData.ipqcRows)
      }
    }
  }, [activeTab])

  const handleMachineChange = (value: string) => {
    const selectedMachine = machineList.find((machine) => machine.machineCode === value)

    if (selectedMachine) {
      setCppParameters(selectedMachine.cppParameters || [])
      form.setFieldValue('machineId', selectedMachine.machineCode)
      form.setFieldValue('machineLocation', `${selectedMachine.areaName} - ${selectedMachine.facilityCode}`)
    } else {
      setCppParameters([])
      form.setFieldValue('machineId', '')
      form.setFieldValue('machineLocation', '')
    }
  }

  const handleAddIpqcRow = () => {
    setIpqcRows((prev) => [
      ...prev,
      { id: createId(), parameterName: '', specification: '', frequency: '' }
    ])
  }

  const handleRemoveIpqcRow = (id: string) => {
    setIpqcRows((prev) => prev.filter((row) => row.id !== id))
  }

  const handleIpqcChange = (id: string, field: keyof IPQCRow, value: string) => {
    setIpqcRows((prev) =>
      prev.map((row) => (row.id === id ? { ...row, [field]: value } : row))
    )
  }

  const handleSaveAndNext = async () => {
    try {
      const values = await form.validateFields()
      const stageKey = getStageKey(activeTab)

      const stageData: any = { ...values }

      // For machine tab, include CPP values and machine selection
      if (activeTab === 'machine') {
        stageData.cppValues = cppParameters.map((param: any) => ({
          parameterName: param.parameterName,
          value: Number(form.getFieldValue(`cpp_${param.parameterName}`) || 0),
          minValue: param.minValue,
          maxValue: param.maxValue,
          unit: param.unit
        }))
        stageData.selectedMachineCode = values.machine
      }

      // For quality tab, include IPQC rows and powder defects
      if (activeTab === 'quality') {
        stageData.ipqcRows = ipqcRows.filter((row) => row.parameterName && row.specification)
      }

      setTemplateData((prev: any) => ({
        ...prev,
        ['Powder Filling Parameters']: {
          ...(prev?.['Powder Filling Parameters'] || {}),
          [stageKey]: stageData
        }
      }))

      message.success('Powder filling parameters saved successfully')

      if (isLastTab) {
        onNext()
        return
      }

      const nextTab = tabFlow[tabFlow.indexOf(activeTab) + 1]
      if (nextTab) {
        setActiveTab(nextTab)
      }
    } catch (error) {
      console.error('Validation failed:', error)
      message.error('Please fill all required fields correctly')
    }
  }

  const ipqcColumns = [
    {
      title: 'Parameter Name',
      dataIndex: 'parameterName',
      key: 'parameterName',
      width: 250,
      render: (text: string, record: IPQCRow) => (
        <Input
          value={record.parameterName}
          onChange={(e) => handleIpqcChange(record.id, 'parameterName', e.target.value)}
          placeholder="e.g., Fill Weight Check"
          size="small"
          style={{ minWidth: 180 }}
        />
      ),
    },
    {
      title: 'Specification / Limit',
      dataIndex: 'specification',
      key: 'specification',
      width: 300,
      render: (text: string, record: IPQCRow) => (
        <Input
          value={record.specification}
          onChange={(e) => handleIpqcChange(record.id, 'specification', e.target.value)}
          placeholder="e.g., ±2g of target fill weight"
          size="small"
          style={{ minWidth: 200 }}
        />
      ),
    },
    {
      title: 'Frequency',
      dataIndex: 'frequency',
      key: 'frequency',
      width: 200,
      render: (text: string, record: IPQCRow) => (
        <Select
          value={record.frequency || undefined}
          onChange={(value) => handleIpqcChange(record.id, 'frequency', value)}
          placeholder="Select frequency"
          size="small"
          style={{ width: '100%' }}
          options={IPQC_FREQUENCY}
        />
      ),
    },
    {
      title: 'Actions',
      key: 'actions',
      width: 60,
      render: (_: any, record: IPQCRow) => (
        <Button
          type="text"
          danger
          icon={<DeleteOutlined />}
          onClick={() => handleRemoveIpqcRow(record.id)}
          size="small"
          disabled={DEFAULT_IPQC_PARAMETERS.includes(record.parameterName) && ipqcRows.filter((r) => r.parameterName === record.parameterName).length === 1}
        />
      ),
    },
  ]

  const tabs = [
    { key: 'machine', label: 'Machine Setup', icon: <SettingOutlined /> },
    { key: 'container', label: 'Container Specs', icon: <InfoCircleOutlined /> },
    { key: 'process', label: 'Filling Parameters', icon: <DashboardOutlined /> },
    { key: 'quality', label: 'Quality Controls', icon: <CheckCircleOutlined /> },
  ]

  return (
    <div className="space-y-4">
      <Card size="small" className="sticky top-0 z-10">
        <div className="flex flex-wrap gap-2">
          {tabs.map(tab => (
            <Button
              key={tab.key}
              type={activeTab === tab.key ? 'primary' : 'default'}
              icon={tab.icon}
              onClick={() => setActiveTab(tab.key as typeof activeTab)}
              className="flex-1 min-w-30"
            >
              {tab.label}
            </Button>
          ))}
        </div>
      </Card>

      <Form form={form} layout="vertical" name="powder_filling_params">
        {activeTab === 'machine' && (
          <Card title={
            <Space>
              <SettingOutlined className="text-blue-500" />
              <Title level={5} style={{ margin: 0 }}>Powder Filling Machine Setup</Title>
            </Space>
          }>
            <Divider orientation="horizontal">
              <InfoCircleOutlined className="mr-2" />
              Machine Information
            </Divider>

            <Row gutter={[24, 16]}>
              <Col xs={24} md={12}>
                <Form.Item
                  name="machine"
                  label="Filling / Packing Machine"
                  rules={[{ required: true, message: 'Please select a machine' }]}
                >
                  <Select
                    placeholder="Select machine"
                    size="large"
                    style={{ width: '100%' }}
                    options={machineList.map((m) => ({
                      label: `${m.machineName} - ${m.machineCode}`,
                      value: m.machineCode
                    }))}
                    onChange={handleMachineChange}
                    showSearch
                    optionFilterProp="label"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={12}>
                <Form.Item name="machineId" label="Machine ID / Code">
                  <Input placeholder="Auto-filled" size="large" disabled />
                </Form.Item>
              </Col>
            </Row>

            <Row gutter={[24, 16]}>
              <Col xs={24} md={12}>
                <Form.Item name="machineLocation" label="Machine Location">
                  <Input placeholder="Auto-filled" size="large" disabled />
                </Form.Item>
              </Col>
            </Row>

            {cppParameters.length > 0 && (
              <>
                <Divider>
                  <SettingOutlined className="mr-2" />
                  Critical Process Parameters
                </Divider>
                <Row gutter={[24, 16]}>
                  {cppParameters.map((param, index) => (
                    <Col xs={24} md={6} key={index}>
                      <Form.Item name={['cppParameters', index, 'parameterName']} initialValue={param.parameterName} hidden>
                        <Input />
                      </Form.Item>
                      <Form.Item name={['cppParameters', index, 'unit']} initialValue={param.unit} hidden>
                        <Input />
                      </Form.Item>
                      <Form.Item
                        label={param.parameterName}
                        name={`cpp_${param.parameterName}`}
                        extra={<Text type="secondary" style={{ fontSize: 11 }}>Range: {param.minValue} - {param.maxValue} {param.unit}</Text>}
                      >
                        <InputNumber
                          min={param.minValue}
                          max={param.maxValue}
                          placeholder={`${param.minValue} - ${param.maxValue}`}
                          size="large"
                          style={{ width: '100%' }}
                          addonAfter={param.unit}
                        />
                      </Form.Item>
                    </Col>
                  ))}
                </Row>
              </>
            )}
          </Card>
        )}

        {activeTab === 'container' && (
          <Card title={
            <Space>
              <InfoCircleOutlined className="text-cyan-500" />
              <Title level={5} style={{ margin: 0 }}>Container Specifications</Title>
            </Space>
          }>
            <Row gutter={[24, 16]}>
              <Col xs={24} md={8}>
                <Form.Item name="containerType" label="Container Type" rules={[{ required: true, message: 'Please select container type' }]}>
                  <Select placeholder="Select container type" options={POWDER_CONTAINER_TYPES} size="large" />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item name="containerSize" label="Container Size / Pack Size (g)" rules={[{ required: true, message: 'Required' }]}>
                  <InputNumber placeholder="e.g., 100" min={1} size="large" style={{ width: '100%' }} addonAfter="g" />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item name="capType" label="Cap / Closure Type">
                  <Select placeholder="Select cap type" options={CAP_TYPES} size="large" />
                </Form.Item>
              </Col>
            </Row>

            <Row gutter={[24, 16]}>
              <Col xs={24} md={8}>
                <Form.Item name="sealType" label="Seal Type">
                  <Select placeholder="Select seal type" options={SEAL_TYPES} size="large" />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item name="sachetFilmType" label="Sachet / Pouch Film Type">
                  <Input placeholder="e.g., PET/ALU/LDPE" size="large" />
                </Form.Item>
              </Col>
            </Row>
          </Card>
        )}

        {activeTab === 'process' && (
          <Card title={
            <Space>
              <DashboardOutlined className="text-blue-500" />
              <Title level={5} style={{ margin: 0 }}>Powder Filling Parameters</Title>
            </Space>
          }>
            <Divider orientation="horizontal">
              <InfoCircleOutlined className="mr-2" />
              Fill Parameters
            </Divider>

            <Row gutter={[24, 16]}>
              <Col xs={24} md={8}>
                <Form.Item name="targetFillWeight" label="Target Fill Weight (g)" rules={[{ required: true, message: 'Required' }]}>
                  <InputNumber placeholder="e.g., 100" min={0} size="large" style={{ width: '100%' }} addonAfter="g" />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item name="fillWeightTolerance" label="Fill Weight Tolerance (±g)">
                  <InputNumber placeholder="e.g., 2" min={0} size="large" style={{ width: '100%' }} addonAfter="g" />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item name="productionSpeed" label="Production Speed (packs/hr)">
                  <InputNumber placeholder="e.g., 3000" min={0} step={100} size="large" style={{ width: '100%' }} addonAfter="packs/hr" />
                </Form.Item>
              </Col>
            </Row>

            <Divider orientation="horizontal">
              <SettingOutlined className="mr-2" />
              Powder Handling Parameters
            </Divider>

            <Row gutter={[24, 16]}>
              <Col xs={24} md={8}>
                <Form.Item name="sieveMeshSize" label="Sieve / Mesh Size">
                  <Input placeholder="e.g., 40 mesh" size="large" />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item name="mixingSpeed" label="Blending Speed (RPM)">
                  <InputNumber placeholder="e.g., 25" min={0} size="large" style={{ width: '100%' }} addonAfter="RPM" />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item name="mixingTime" label="Blending Time (min)">
                  <InputNumber placeholder="e.g., 20" min={0} size="large" style={{ width: '100%' }} addonAfter="min" />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item name="bulkDensity" label="Bulk Density (g/ml)">
                  <InputNumber placeholder="e.g., 0.65" min={0} step={0.01} size="large" style={{ width: '100%' }} addonAfter="g/ml" />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item name="tappedDensity" label="Tapped Density (g/ml)">
                  <InputNumber placeholder="e.g., 0.78" min={0} step={0.01} size="large" style={{ width: '100%' }} addonAfter="g/ml" />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item name="lossOnDryingLimit" label="LOD / Moisture Limit (%)">
                  <InputNumber placeholder="e.g., 2" min={0} step={0.1} size="large" style={{ width: '100%' }} addonAfter="%" />
                </Form.Item>
              </Col>
            </Row>
          </Card>
        )}

        {activeTab === 'quality' && (
          <>
            <Card title={
              <Space>
                <WarningOutlined className="text-orange-500" />
                <Title level={5} style={{ margin: 0 }}>In-Process Quality Controls (IPQC)</Title>
              </Space>
            }>
              <Table columns={ipqcColumns} dataSource={ipqcRows} rowKey="id" pagination={false} size="middle" scroll={{ x: 700 }} />
              <div className="mt-3">
                <Button icon={<PlusOutlined />} onClick={handleAddIpqcRow}>Add IPQC Parameter</Button>
              </div>
            </Card>

            <Card title={
              <Space>
                <WarningOutlined className="text-red-500" />
                <Title level={5} style={{ margin: 0 }}>Powder Filling Defects</Title>
              </Space>
            }>
              <Form.Item name="powderDefects" label="Select potential defects">
                <Select
                  mode="multiple"
                  allowClear
                  placeholder="Select defects"
                  options={POWDER_DEFECT_TYPES}
                  size="large"
                  style={{ width: '100%' }}
                />
              </Form.Item>
            </Card>
          </>
        )}
      </Form>

      <div className="flex justify-end gap-2">
        <Button icon={<ArrowLeftOutlined />} onClick={onPrevious} size="large">
          Back
        </Button>
        <Button type="primary" icon={<ArrowRightOutlined />} onClick={handleSaveAndNext} size="large">
          Save & Next
        </Button>
      </div>
    </div>
  )
}