'use client'

import { Descriptions, Card, Table, Tag, Space, Typography, Badge, Divider, Empty, Row, Col } from "antd";
import {
  InfoCircleOutlined,
  FileTextOutlined,
  SettingOutlined,
  CheckCircleOutlined,
  WarningOutlined,
} from "@ant-design/icons";
import React from "react";

const { Text, Title } = Typography;

// ───────────────────────────────────────────────
// SECTION 1: BASIC INFORMATION
// ───────────────────────────────────────────────
export function BasicInfoRenderer({ data }: { data: any }) {
  if (!data || Object.keys(data).length === 0) return <Empty description="No basic info" />;

  const storageConditions = Array.isArray(data.storageConditions)
    ? data.storageConditions
    : data.storageConditions
      ? [data.storageConditions]
      : [];

  return (
    <Card size="small" style={{ margin: 8 }} title={
      <Space><InfoCircleOutlined className="text-blue-500" /><span>Basic Information</span></Space>
    }>
      <Descriptions column={1} size="small" bordered>
        <Descriptions.Item label="Template Code">{data.templateCode || '-'}</Descriptions.Item>
        <Descriptions.Item label="Version">{data.templateVersion || '-'}</Descriptions.Item>
        <Descriptions.Item label="Template Name">{data.templateName || '-'}</Descriptions.Item>
        <Descriptions.Item label="Template Type">{data.templateType || '-'}</Descriptions.Item>
        <Descriptions.Item label="Product Name">{data.productName || '-'}</Descriptions.Item>
        <Descriptions.Item label="Product Code">{data.productCode || '-'}</Descriptions.Item>
        <Descriptions.Item label="Dosage Form"><Tag color="blue">{data.dosageForm || '-'}</Tag></Descriptions.Item>
        <Descriptions.Item label="Strength">{data.strength || '-'}</Descriptions.Item>
        <Descriptions.Item label="Batch Size (Bulk)">{data.batchSizeBulk ? `${data.batchSizeBulk} ${data.uomBulk || ''}` : '-'}</Descriptions.Item>
        <Descriptions.Item label="Batch Size (Semi)">{data.batchSizeSemiFinished ? `${data.batchSizeSemiFinished} ${data.uomSemiFinished || ''}` : '-'}</Descriptions.Item>
        <Descriptions.Item label="Storage Conditions">
          {storageConditions.length > 0
            ? storageConditions.map((s: string) => <Tag key={s}>{s}</Tag>)
            : '-'}
        </Descriptions.Item>
        <Descriptions.Item label="Shelf Life">{data.shelfLife ? `${data.shelfLife} months` : '-'}</Descriptions.Item>
        <Descriptions.Item label="Drug Reg. No.">{data.drugRegistrationNumber || '-'}</Descriptions.Item>
        <Descriptions.Item label="Manufacturing BOM Code">{data.manufacturingBomCode || '-'}</Descriptions.Item>
        <Descriptions.Item label="Status"><Tag color={data.status === 'Active' ? 'green' : 'orange'}>{data.status || '-'}</Tag></Descriptions.Item>
      </Descriptions>
      {data.dosageForm === 'Tablet' && data.tabletType && (
        <div style={{ marginTop: 8 }}>
          <Text strong>Tablet Type: </Text><Tag color="purple">{data.tabletType}</Tag>
          {data.coatingRequired && <Tag color="cyan" style={{ marginLeft: 8 }}>Coating Required</Tag>}
        </div>
      )}
    </Card>
  );
}

// ───────────────────────────────────────────────
// SECTION 2: MANUFACTURING BOM
// ───────────────────────────────────────────────
export function BomRenderer({ data }: { data: any }) {
  const bomData = data?.bomData || {};
  const otherInfo = data?.otherInfo || '';
  const materials = bomData?.materials || [];

  if (materials.length === 0) return <Empty description="No BOM data" />;

  const columns = [
    { title: 'Code', dataIndex: 'materialCode', key: 'materialCode', width: 100 },
    { title: 'Name', dataIndex: 'materialName', key: 'materialName', width: 160 },
    { title: 'Category', dataIndex: 'materialCategory', key: 'materialCategory', width: 100 },
    { title: 'Qty', dataIndex: 'quantity', key: 'quantity', width: 60 },
    { title: 'UOM', dataIndex: 'uom', key: 'uom', width: 50 },
    { title: 'Usage Stage', dataIndex: 'usageStage', key: 'usageStage', width: 100 },
  ];

  return (
    <Card size="small" style={{ margin: 8 }} title={
      <Space><FileTextOutlined className="text-blue-500" /><span>Manufacturing BOM</span></Space>
    }>
      <Descriptions column={2} size="small" style={{ marginBottom: 12 }}>
        <Descriptions.Item label="BOM Code">{bomData.bomCode || '-'}</Descriptions.Item>
        <Descriptions.Item label="Version">{bomData.bomVersion || '-'}</Descriptions.Item>
        <Descriptions.Item label="Product">{bomData.productName || '-'}</Descriptions.Item>
      </Descriptions>
      <Table
        columns={columns}
        dataSource={materials}
        rowKey="materialCode"
        pagination={false}
        size="small"
        scroll={{ x: 600 }}
      />
      {otherInfo && (
        <div style={{ marginTop: 12 }}>
          <Divider orientation="horizontal">Additional Notes</Divider>
          <div dangerouslySetInnerHTML={{ __html: otherInfo }} />
        </div>
      )}
    </Card>
  );
}

// ───────────────────────────────────────────────
// SECTION 3: FACILITY & EQUIPMENT
// ───────────────────────────────────────────────
export function FacilityEquipmentRenderer({ data }: { data: any }) {
  const facilities = data?.facilitiesWithEquipment || [];
  if (facilities.length === 0) return <Empty description="No facilities/equipment" />;

  return (
    <Card size="small" style={{ margin: 8 }} title={
      <Space><SettingOutlined className="text-blue-500" /><span>Facility & Equipment</span></Space>
    }>
      {facilities.map((facility: any, idx: number) => (
        <Card key={idx} size="small" title={facility.areaName || `Facility ${idx + 1}`} style={{ marginBottom: 8 }}>
          {facility.equipments?.map((eq: any, eqIdx: number) => (
            <Tag key={eqIdx} color="blue" style={{ marginBottom: 4 }}>{eq.equipmentName} ({eq.equipmentCode})</Tag>
          ))}
          {(!facility.equipments || facility.equipments.length === 0) && <Text type="secondary">No equipment</Text>}
        </Card>
      ))}
      <div style={{ marginTop: 8 }}>
        <Text type="secondary">Total: {data.totalFacilities || facilities.length} facilities, {data.totalEquipment || 0} equipment</Text>
      </div>
    </Card>
  );
}

// ───────────────────────────────────────────────
// SECTION 4: MANUFACTURING STEPS
// ───────────────────────────────────────────────
export function ManufacturingStepsRenderer({ data }: { data: any }) {
  const layers = data?.layers || {};
  if (Object.keys(layers).length === 0) return <Empty description="No manufacturing steps" />;

  return (
    <Card size="small" style={{ margin: 8 }} title={
      <Space><CheckCircleOutlined className="text-blue-500" /><span>Manufacturing Steps</span></Space>
    }>
      {Object.entries(layers).map(([layerName, layerData]: [string, any]) => (
        <Card key={layerName} size="small" title={layerName} style={{ marginBottom: 8 }}>
          {layerData.lots && Object.entries(layerData.lots).map(([lotKey, lotData]: [string, any]) => (
            <div key={lotKey} style={{ marginBottom: 8 }}>
              <Text strong style={{ fontSize: 12 }}>{lotKey.replace(/-/g, ' ').toUpperCase()}</Text>
              <div style={{ marginTop: 4 }}>
                {(lotData.steps || []).map((step: any, idx: number) => (
                  <Card key={step.id} size="small" style={{ marginBottom: 6 }}>
                    <Space wrap>
                      <Tag color="blue">Step {idx + 1}</Tag>
                      <Text strong style={{ fontSize: 12 }}>{step.stepName}</Text>
                      {step.machineName && <Tag color="purple" style={{ fontSize: 11 }}>{step.machineName}</Tag>}
                    </Space>
                    {step.stepDescription && <div><Text type="secondary" style={{ fontSize: 12 }}>{step.stepDescription}</Text></div>}
                    {step.materials?.length > 0 && (
                      <div style={{ marginTop: 4 }}>
                        {step.materials.map((m: any) => (
                          <Tag key={m.materialCode} color="green" style={{ fontSize: 11 }}>{m.materialCode}: {m.quantity}</Tag>
                        ))}
                      </div>
                    )}
                    {step.cppValues?.length > 0 && (
                      <div style={{ marginTop: 4 }}>
                        {step.cppValues.map((cpp: any) => (
                          <Tag key={`${step.id}_${cpp.parameterName}`} color="geekblue" style={{ fontSize: 11 }}>
                            {cpp.parameterName}: {cpp.value} {cpp.unit}
                          </Tag>
                        ))}
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </Card>
      ))}
    </Card>
  );
}

// ───────────────────────────────────────────────
// SECTION 5a: COMPRESSION PARAMETERS (Tablet)
// ───────────────────────────────────────────────
export function CompressionRenderer({ data }: { data: any }) {
  if (!data?.machineSetup) return <Empty description="No compression parameters" />;

  const cppColumns = [
    { title: 'Parameter', dataIndex: 'parameterName', key: 'parameterName', width: 150 },
    { title: 'Value', dataIndex: 'minValue', key: 'minValue', width: 80, render: (v: any, r: any) => r.minValue === r.maxValue ? r.minValue : `${r.minValue} - ${r.maxValue}` },
    { title: 'Unit', dataIndex: 'unit', key: 'unit', width: 60 },
  ];

  return (
    <Card size="small" style={{ margin: 8 }} title={
      <Space><SettingOutlined className="text-orange-500" /><span>Compression Parameters</span></Space>
    }>
      <Divider orientation="horizontal">Machine Setup</Divider>
      <Descriptions column={1} size="small">
        <Descriptions.Item label="Machine Name">{data.machineSetup?.machineType || '-'}</Descriptions.Item>
        <Descriptions.Item label="Machine ID">{data.machineSetup?.machineId || '-'}</Descriptions.Item>
        <Descriptions.Item label="Location">{data.machineSetup?.machineLocation || '-'}</Descriptions.Item>
        <Descriptions.Item label="Stations">{data.machineSetup?.numberOfStations || '-'}</Descriptions.Item>
        <Descriptions.Item label="Operating Speed">{data.machineSetup?.operatingSpeed ? `${data.machineSetup.operatingSpeed} tabs/hr` : '-'}</Descriptions.Item>
        {data.machineSetup?.cppParameters?.length > 0 && (
          <>
            <Divider orientation="horizontal">CPP Parameters</Divider>
            <Table columns={cppColumns} dataSource={data.machineSetup.cppParameters} rowKey="parameterName" pagination={false} size="small" />
          </>
        )}
      </Descriptions>

      {data.toolingSpecs && (
        <>
          <Divider orientation="horizontal">Tooling Specs</Divider>
          <Descriptions column={1} size="small">
            <Descriptions.Item label="Type">{data.toolingSpecs.toolingType || '-'}</Descriptions.Item>
            <Descriptions.Item label="Material">{data.toolingSpecs.toolingMaterial || '-'}</Descriptions.Item>
            <Descriptions.Item label="Die Bore">{data.toolingSpecs.dieBoreSize ? `${data.toolingSpecs.dieBoreSize} mm` : '-'}</Descriptions.Item>
          </Descriptions>
        </>
      )}

      {data.compressionParams && (
        <>
          <Divider orientation="horizontal">Process Parameters</Divider>
          <Descriptions column={1} size="small">
            <Descriptions.Item label="Target Weight">{data.compressionParams.targetTabletWeight ? `${data.compressionParams.targetTabletWeight} mg` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Hardness">{data.compressionParams.targetHardness ? `${data.compressionParams.targetHardness} kP` : '-'}</Descriptions.Item>
            <Descriptions.Item label="Thickness">{data.compressionParams.targetTabletThickness ? `${data.compressionParams.targetTabletThickness} mm` : '-'}</Descriptions.Item>
          </Descriptions>
        </>
      )}
    </Card>
  );
}

// ───────────────────────────────────────────────
// SECTION 5b: ENCAPSULATION PARAMETERS (Capsule)
// ───────────────────────────────────────────────
export function EncapsulationRenderer({ data }: { data: any }) {
  if (!data) return <Empty description="No encapsulation parameters" />;

  return (
    <Card size="small" style={{ margin: 8 }} title={
      <Space><SettingOutlined className="text-orange-500" /><span>Encapsulation Parameters</span></Space>
    }>
      <Descriptions column={1} size="small">
        <Descriptions.Item label="Machine">{data.machine || '-'}</Descriptions.Item>
        <Descriptions.Item label="Machine ID">{data.machineId || '-'}</Descriptions.Item>
        <Descriptions.Item label="Capsule Size"><Tag color="blue">{data.capsuleSize || '-'}</Tag></Descriptions.Item>
        <Descriptions.Item label="Capsule Type">{data.capsuleType || '-'}</Descriptions.Item>
        <Descriptions.Item label="Fill Weight">{data.targetFillWeight || '-'} mg</Descriptions.Item>
        <Descriptions.Item label="Tolerance">{data.fillWeightTolerance ? `±${data.fillWeightTolerance} mg` : '-'}</Descriptions.Item>
        <Descriptions.Item label="Speed">{data.productionSpeed || '-'}</Descriptions.Item>
      </Descriptions>
    </Card>
  );
}

// ───────────────────────────────────────────────
// SECTION 5c: LIQUID / SUSPENSION PARAMETERS
// ───────────────────────────────────────────────
export function LiquidSuspensionRenderer({ data }: { data: any }) {
  if (!data) return <Empty description="No liquid/suspension parameters" />;

  const machineSetup = data?.machineSetup || {};
  const containerSpecs = data?.containerSpecs || {};
  const processParams = data?.processParams || {};

  return (
    <Card size="small" style={{ margin: 8 }} title={
      <Space><SettingOutlined className="text-orange-500" /><span>Liquid / Suspension Parameters</span></Space>
    }>
      <Descriptions column={1} size="small">
        <Descriptions.Item label="Machine">{machineSetup.machine || '-'}</Descriptions.Item>
        <Descriptions.Item label="Bottle Type">{containerSpecs.bottleType || '-'}</Descriptions.Item>
        <Descriptions.Item label="Bottle Size">{containerSpecs.bottleSize ? `${containerSpecs.bottleSize} ml` : '-'}</Descriptions.Item>
        <Descriptions.Item label="Cap Type">{containerSpecs.capType || '-'}</Descriptions.Item>
        <Descriptions.Item label="Seal Type">{containerSpecs.sealType || '-'}</Descriptions.Item>
        <Descriptions.Item label="Fill Volume">{processParams.targetFillVolume ? `${processParams.targetFillVolume} ml` : '-'}</Descriptions.Item>
        <Descriptions.Item label="Density">{processParams.productDensity ? `${processParams.productDensity} g/ml` : '-'}</Descriptions.Item>
        <Descriptions.Item label="Mix Speed">{processParams.mixingSpeed ? `${processParams.mixingSpeed} RPM` : '-'}</Descriptions.Item>
        <Descriptions.Item label="Mix Time">{processParams.mixingTime ? `${processParams.mixingTime} min` : '-'}</Descriptions.Item>
        <Descriptions.Item label="Production Speed">{processParams.productionSpeed ? `${processParams.productionSpeed} bottles/hr` : '-'}</Descriptions.Item>
      </Descriptions>
    </Card>
  );
}

// ───────────────────────────────────────────────
// SECTION 5d: POWDER FILLING PARAMETERS
// ───────────────────────────────────────────────
export function PowderFillingRenderer({ data }: { data: any }) {
  if (!data) return <Empty description="No powder filling parameters" />;

  const machineSetup = data?.machineSetup || {};
  const containerSpecs = data?.containerSpecs || {};
  const processParams = data?.processParams || {};

  return (
    <Card size="small" style={{ margin: 8 }} title={
      <Space><SettingOutlined className="text-orange-500" /><span>Powder Filling Parameters</span></Space>
    }>
      <Descriptions column={1} size="small">
        <Descriptions.Item label="Machine">{machineSetup.machine || '-'}</Descriptions.Item>
        <Descriptions.Item label="Container Type">{containerSpecs.containerType || '-'}</Descriptions.Item>
        <Descriptions.Item label="Fill Weight">{processParams.targetFillWeight ? `${processParams.targetFillWeight} g` : '-'}</Descriptions.Item>
        <Descriptions.Item label="Tolerance">{processParams.fillWeightTolerance ? `±${processParams.fillWeightTolerance} g` : '-'}</Descriptions.Item>
        <Descriptions.Item label="Production Speed">{processParams.productionSpeed ? `${processParams.productionSpeed} packs/hr` : '-'}</Descriptions.Item>
        <Descriptions.Item label="Blending Speed">{processParams.mixingSpeed ? `${processParams.mixingSpeed} RPM` : '-'}</Descriptions.Item>
        <Descriptions.Item label="Blending Time">{processParams.mixingTime ? `${processParams.mixingTime} min` : '-'}</Descriptions.Item>
      </Descriptions>
    </Card>
  );
}

// ───────────────────────────────────────────────
// SECTION 5e: SEMISOLID PARAMETERS
// ───────────────────────────────────────────────
export function SemisolidRenderer({ data }: { data: any }) {
  if (!data) return <Empty description="No semisolid parameters" />;

  const machineSetup = data?.machineSetup || {};
  const containerSpecs = data?.containerSpecs || {};
  const fillParams = data?.fillParams || {};

  return (
    <Card size="small" style={{ margin: 8 }} title={
      <Space><SettingOutlined className="text-orange-500" /><span>Semisolid Parameters</span></Space>
    }>
      <Descriptions column={1} size="small">
        <Descriptions.Item label="Machine">{machineSetup.machine || '-'}</Descriptions.Item>
        <Descriptions.Item label="Container Type">{containerSpecs.containerType || '-'}</Descriptions.Item>
        <Descriptions.Item label="Container Size">{containerSpecs.containerSize ? `${containerSpecs.containerSize} g` : '-'}</Descriptions.Item>
        <Descriptions.Item label="Fill Weight">{fillParams.targetFillWeight ? `${fillParams.targetFillWeight} g` : '-'}</Descriptions.Item>
        <Descriptions.Item label="Tolerance">{fillParams.fillWeightTolerance ? `±${fillParams.fillWeightTolerance} g` : '-'}</Descriptions.Item>
        <Descriptions.Item label="Production Speed">{fillParams.productionSpeed ? `${fillParams.productionSpeed} units/hr` : '-'}</Descriptions.Item>
      </Descriptions>
    </Card>
  );
}

// ───────────────────────────────────────────────
// SECTION 6: COATING SECTION
// ───────────────────────────────────────────────
export function CoatingRenderer({ data }: { data: any }) {
  if (!data) return <Empty description="No coating data" />;

  const solutionPrep = data?.solutionPrep || {};
  const coatingParams = data?.coatingParams || {};

  return (
    <Card size="small" style={{ margin: 8 }} title={
      <Space><CheckCircleOutlined className="text-green-500" /><span>Coating Section</span></Space>
    }>
      {solutionPrep.steps?.length > 0 && (
        <>
          <Divider orientation="horizontal">Solution Prep Steps</Divider>
          {solutionPrep.steps.map((step: any, idx: number) => (
            <Card key={step.id} size="small" style={{ marginBottom: 6 }}>
              <Space wrap>
                <Tag color="blue">Step {idx + 1}</Tag>
                <Text strong style={{ fontSize: 12 }}>{step.stepName}</Text>
                {step.machineName && <Tag color="purple" style={{ fontSize: 11 }}>{step.machineName}</Tag>}
              </Space>
              {step.materials?.length > 0 && (
                <div style={{ marginTop: 4 }}>
                  {step.materials.map((m: any) => (
                    <Tag key={m.materialCode} color="green" style={{ fontSize: 11 }}>{m.materialCode}: {m.quantity}</Tag>
                  ))}
                </div>
              )}
              {step.cppValues?.length > 0 && (
                <div style={{ marginTop: 4 }}>
                  {step.cppValues.map((cpp: any) => (
                    <Tag key={`${step.id}_${cpp.parameterName}`} color="geekblue" style={{ fontSize: 11 }}>
                      {cpp.parameterName}: {cpp.value} {cpp.unit}
                    </Tag>
                  ))}
                </div>
              )}
            </Card>
          ))}
        </>
      )}

      {coatingParams?.machine && (
        <>
          <Divider orientation="horizontal">Coating Parameters</Divider>
          <Descriptions column={1} size="small">
            <Descriptions.Item label="Machine">{coatingParams.machine || '-'}</Descriptions.Item>
            <Descriptions.Item label="Machine ID">{coatingParams.machineId || '-'}</Descriptions.Item>
            <Descriptions.Item label="Location">{coatingParams.machineLocation || '-'}</Descriptions.Item>
          </Descriptions>
        </>
      )}
    </Card>
  );
}

// ───────────────────────────────────────────────
// MAIN DISPATCHER
// ───────────────────────────────────────────────
export function SectionRenderer({ sectionKey, data }: { sectionKey: string; data: any }) {
  switch (sectionKey) {
    case 'Basic Information':
      return <BasicInfoRenderer data={data} />;
    case 'Manufacturing BOM':
      return <BomRenderer data={data} />;
    case 'Facility Equipment':
      return <FacilityEquipmentRenderer data={data} />;
    case 'Manufacturing Steps':
      return <ManufacturingStepsRenderer data={data} />;
    case 'Compression Parameters':
      return <CompressionRenderer data={data} />;
    case 'Encapsulation Parameters':
      return <EncapsulationRenderer data={data} />;
    case 'Liquid Suspension and Solution':
      return <LiquidSuspensionRenderer data={data} />;
    case 'Powder Filling Parameters':
      return <PowderFillingRenderer data={data} />;
    case 'Semisolid Parameters':
      return <SemisolidRenderer data={data} />;
    case 'Coating Section':
      return <CoatingRenderer data={data} />;
    default:
      return <Empty description={`No renderer for: ${sectionKey}`} />;
  }
}