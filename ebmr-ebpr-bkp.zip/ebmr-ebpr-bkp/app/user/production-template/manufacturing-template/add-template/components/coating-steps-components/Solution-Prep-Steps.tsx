'use client'

import { DataContext } from "@/lib/utils/DataContext"
import {
  ArrowRightOutlined,
  DeleteOutlined,
  PlusOutlined,
  SaveOutlined
} from "@ant-design/icons"
import { Button, Card, Col, Empty, Form, Input, InputNumber, message, Row, Select, Space, Tag, Typography } from "antd"
import TextArea from "antd/es/input/TextArea"
import { useContext, useEffect, useMemo, useState } from "react"

const { Text } = Typography

type MaterialAssignment = {
  materialCode: string
  quantity: number
}

type CppValue = {
  parameterName: string
  value: number
  minValue: number
  maxValue: number
  unit?: string
}

type StepRow = {
  id: string
  stepName: string
  stepDescription: string
  machineCode?: string
  machineName?: string
  materials: MaterialAssignment[]
  cppValues: CppValue[]
}

const createId = () => `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`

interface SolutionPrepStepsProps {
  toCoatingParams: () => void
}

export default function SolutionPrepSteps({ toCoatingParams }: SolutionPrepStepsProps) {
  const { templateData, setTemplateData } = useContext(DataContext)
  const [form] = Form.useForm()
  const selectedMachineCode = Form.useWatch('machine', form)
  const selectedMaterialCode = Form.useWatch('materialCode', form)

  const [steps, setSteps] = useState<StepRow[]>([])
  const [draftMaterials, setDraftMaterials] = useState<MaterialAssignment[]>([])

  // Get coating materials from BOM (usageStage === 'Coating')
  const coatingMaterials = useMemo(() => {
    const materials = templateData?.['Manufacturing BOM']?.bomData?.materials || []
    return materials.filter((m: any) => m.usageStage === 'Coating')
  }, [templateData])

  // Build a map of materialCode -> material details with total qty
  const materialMap = useMemo(() => {
    const map: Record<string, { materialName: string; uom: string; totalQty: number }> = {}
    coatingMaterials.forEach((m: any) => {
      map[m.materialCode] = {
        materialName: m.materialName,
        uom: m.uom,
        totalQty: Number(m.quantity || 0)
      }
    })
    return map
  }, [coatingMaterials])

  // Machine list from Facility & Equipment
  const machineList = useMemo(() => {
    const formattedData: any[] = []
    const equipment = templateData?.['Facility Equipment']?.facilitiesWithEquipment || []

    equipment.forEach((facility: any) => {
      facility.equipments?.forEach((equipment: any) => {
        formattedData.push({
          machineName: equipment.equipmentName,
          machineCode: equipment.equipmentCode,
          assetTag: equipment.assetTag || 'N/A',
          areaName: facility.areaName || 'N/A',
          facilityCode: facility.facilityCode || 'N/A',
          cppParameters: equipment.cppParameters?.map((param: any) => ({
            parameterName: param.parameterName,
            minValue: param.minValue,
            maxValue: param.maxValue,
            unit: param.unit || 'Not Specified',
            range: `${param.minValue} - ${param.maxValue} ${param.unit || ''}`
          })) || []
        })
      })
    })

    return formattedData
  }, [templateData])

  const activeMachine = machineList.find((machine) => machine.machineCode === selectedMachineCode)

  // Calculate consumed quantity for a material across all steps
  const getConsumedQuantity = (materialCode: string) => {
    return steps.reduce((total, step) => {
      const stepMaterial = step.materials.find((m) => m.materialCode === materialCode)
      return total + Number(stepMaterial?.quantity || 0)
    }, 0)
  }

  // Calculate remaining quantity for a material
  const getRemainingQuantity = (materialCode: string) => {
    const material = materialMap[materialCode]
    if (!material) return 0
    const consumed = getConsumedQuantity(materialCode)
    // Also account for draft materials (not yet committed to a step)
    const draftQty = draftMaterials.find((m) => m.materialCode === materialCode)?.quantity || 0
    return Math.max(material.totalQty - consumed - draftQty, 0)
  }

  // Check if all coating materials are fully consumed
  const isAllMaterialsConsumed = () => {
    const materialCodes = Object.keys(materialMap)
    if (materialCodes.length === 0) return false
    return materialCodes.every((code) => getConsumedQuantity(code) >= (materialMap[code]?.totalQty || 0))
  }

  // Load saved data on mount
  useEffect(() => {
    const savedSteps = templateData?.['Coating Section']?.solutionPrep?.steps || []
    if (savedSteps.length > 0) {
      setSteps(savedSteps)
    }
  }, [])

  const handleAddMaterialToDraft = () => {
    const materialCode = form.getFieldValue('materialCode')
    const quantity = Number(form.getFieldValue('materialQuantity'))

    if (!materialCode) {
      message.warning('Please select a material first')
      return
    }

    if (!Number.isFinite(quantity) || quantity <= 0) {
      message.warning('Please enter a valid material quantity')
      return
    }

    const material = materialMap[materialCode]
    if (!material) {
      message.error('Selected material is not a coating material')
      return
    }

    const remaining = getRemainingQuantity(materialCode) + (draftMaterials.find((m) => m.materialCode === materialCode)?.quantity || 0)

    if (quantity > remaining) {
      message.error(`Quantity cannot exceed remaining ${remaining} ${material.uom}`)
      return
    }

    setDraftMaterials((prev) => {
      const existingIndex = prev.findIndex((m) => m.materialCode === materialCode)
      if (existingIndex >= 0) {
        return prev.map((m, index) =>
          index === existingIndex ? { materialCode, quantity } : m
        )
      }
      return [...prev, { materialCode, quantity }]
    })

    form.setFieldsValue({ materialCode: undefined, materialQuantity: undefined })
  }

  const handleRemoveDraftMaterial = (materialCode: string) => {
    setDraftMaterials((prev) => prev.filter((m) => m.materialCode !== materialCode))
  }

  const handleAddStep = async () => {
    const values = await form.validateFields()

    if (draftMaterials.length === 0) {
      message.warning('Please assign at least one material to this step')
      return
    }

    const selectedMachine = machineList.find((machine) => machine.machineCode === values.machine)
    const cppValues = selectedMachine?.cppParameters?.map((param: any) => ({
      parameterName: param.parameterName,
      value: Number(form.getFieldValue(`cpp_${param.parameterName}`) || 0),
      minValue: param.minValue,
      maxValue: param.maxValue,
      unit: param.unit
    })) || []

    const nextStep: StepRow = {
      id: createId(),
      stepName: values.stepName,
      stepDescription: values.stepDescription || '',
      machineCode: values.machine,
      machineName: selectedMachine?.machineName,
      materials: [...draftMaterials],
      cppValues
    }

    const updatedSteps = [...steps, nextStep]
    setSteps(updatedSteps)
    setDraftMaterials([])
    form.resetFields()
    message.success('Step added')
  }

  const handleRemoveStep = (stepId: string) => {
    setSteps((prev) => prev.filter((step) => step.id !== stepId))
  }

  const handleSaveToContext = () => {
    if (!isAllMaterialsConsumed()) {
      message.error('All coating materials must be fully consumed before saving')
      return
    }

    setTemplateData((prev: any) => ({
      ...prev,
      ['Coating Section']: {
        ...prev?.['Coating Section'],
        solutionPrep: {
          steps
        }
      }
    }))

    message.success('Solution preparation steps saved successfully')
    toCoatingParams()
  }

  // If no coating materials found, show empty state
  if (coatingMaterials.length === 0) {
    return (
      <Card>
        <Empty
          description="No coating materials found in Manufacturing BOM. Please add materials with 'Coating' usage stage."
          image={Empty.PRESENTED_IMAGE_SIMPLE}
        />
      </Card>
    )
  }

  return (
    <Space direction="vertical" size={16} style={{ width: '100%' }}>
      {/* Material Status Cards */}
      <Card size="small">
        <Space wrap>
          {Object.entries(materialMap).map(([materialCode, material]) => {
            const remaining = getConsumedQuantity(materialCode) >= material.totalQty ? 0 : getRemainingQuantity(materialCode)
            const isFullyConsumed = getConsumedQuantity(materialCode) >= material.totalQty
            return (
              <Tag key={materialCode} color={isFullyConsumed ? 'green' : 'orange'}>
                {material.materialName}: {getConsumedQuantity(materialCode)}/{material.totalQty} {material.uom} used
                {remaining > 0 && ` (${remaining} remaining)`}
              </Tag>
            )
          })}
        </Space>
      </Card>

      {/* Step Definition Form */}
      <Card size="small" title="Define Solution Preparation Step">
        <Form layout="vertical" form={form}>
          <Row gutter={[16, 16]}>
            <Col xs={24} md={12}>
              <Form.Item
                label="Step Name"
                name="stepName"
                rules={[{ required: true, message: 'Please input the step name' }]}
              >
                <Input placeholder="e.g., Add polymer to water" />
              </Form.Item>
            </Col>

            <Col xs={24} md={12}>
              <Form.Item
                label="Machine"
                name="machine"
                rules={[{ required: true, message: 'Please select a machine' }]}
              >
                <Select
                  placeholder="Select a machine"
                  options={machineList.map((machine) => ({
                    label: `${machine.machineName} - ${machine.machineCode}`,
                    value: machine.machineCode
                  }))}
                />
              </Form.Item>
            </Col>

            <Col xs={24}>
              <Form.Item label="Description" name="stepDescription">
                <TextArea placeholder="Enter step description" rows={3} />
              </Form.Item>
            </Col>

            {activeMachine?.cppParameters?.map((param: any) => (
              <Col xs={24} md={6} key={param.parameterName}>
                <Form.Item
                  label={`${param.parameterName} (${param.unit})`}
                  name={`cpp_${param.parameterName}`}
                  rules={[{ required: true, message: `Please input value for ${param.parameterName}` }]}
                >
                  <InputNumber
                    min={param.minValue}
                    max={param.maxValue}
                    placeholder={param.range}
                    style={{ width: '100%' }}
                  />
                </Form.Item>
              </Col>
            ))}
          </Row>

          <Row gutter={[16, 16]}>
            <Col xs={24} md={12}>
              <Form.Item label="Material" name="materialCode">
                <Select
                  placeholder="Select coating material"
                  options={Object.entries(materialMap).map(([materialCode, material]) => ({
                    label: `${material.materialName} - ${materialCode} (${getRemainingQuantity(materialCode)} ${material.uom} left)`,
                    value: materialCode,
                    disabled: getRemainingQuantity(materialCode) <= 0
                  }))}
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={8}>
              <Form.Item label="Quantity" name="materialQuantity">
                <InputNumber
                  min={1}
                  placeholder="Enter quantity"
                  style={{ width: '100%' }}
                  addonAfter={materialMap[selectedMaterialCode]?.uom}
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={4}>
              <Form.Item label=" ">
                <Button block icon={<PlusOutlined />} onClick={handleAddMaterialToDraft}>
                  Add
                </Button>
              </Form.Item>
            </Col>
          </Row>

          {/* Draft Materials Tags */}
          {draftMaterials.length > 0 && (
            <Space wrap style={{ marginBottom: 16 }}>
              {draftMaterials.map((material) => (
                <Tag
                  key={material.materialCode}
                  color="blue"
                  closable
                  onClose={() => handleRemoveDraftMaterial(material.materialCode)}
                >
                  {materialMap[material.materialCode]?.materialName || material.materialCode}: {material.quantity} {materialMap[material.materialCode]?.uom}
                </Tag>
              ))}
            </Space>
          )}

          <div className="flex justify-end">
            <Button type="primary" icon={<PlusOutlined />} onClick={handleAddStep}>
              Add Step
            </Button>
          </div>
        </Form>
      </Card>

      {/* Steps List */}
      <Card
        size="small"
        title="Solution Preparation Steps"
        extra={<Tag color={isAllMaterialsConsumed() ? 'green' : 'orange'}>{isAllMaterialsConsumed() ? 'All Materials Consumed' : 'Pending Material Consumption'}</Tag>}
      >
        {steps.length > 0 ? (
          <Space direction="vertical" size={12} style={{ width: '100%' }}>
            {steps.map((step, index) => (
              <Card
                key={step.id}
                size="small"
                title={
                  <Space wrap>
                    <Tag color="blue">Step {index + 1}</Tag>
                    <Text strong>{step.stepName}</Text>
                    {step.machineName ? <Tag color="purple">{step.machineName}</Tag> : null}
                  </Space>
                }
                extra={<Button danger type="text" icon={<DeleteOutlined />} onClick={() => handleRemoveStep(step.id)} />}
              >
                {step.stepDescription ? <Text type="secondary">{step.stepDescription}</Text> : null}
                <div style={{ marginTop: 12 }}>
                  <Space wrap>
                    {step.materials.map((material) => (
                      <Tag key={`${step.id}_${material.materialCode}`} color="green">
                        {materialMap[material.materialCode]?.materialName || material.materialCode}: {material.quantity} {materialMap[material.materialCode]?.uom}
                      </Tag>
                    ))}
                    {step.cppValues.map((cpp) => (
                      <Tag key={`${step.id}_${cpp.parameterName}`} color="geekblue">
                        {cpp.parameterName}: {cpp.value} {cpp.unit}
                      </Tag>
                    ))}
                  </Space>
                </div>
              </Card>
            ))}
          </Space>
        ) : (
          <Empty description="No steps added yet" image={Empty.PRESENTED_IMAGE_SIMPLE} />
        )}
      </Card>

      {/* Action Buttons */}
      <div className="flex justify-end gap-2">
        <Button icon={<SaveOutlined />} onClick={handleSaveToContext} disabled={!isAllMaterialsConsumed() || steps.length === 0}>
          Save & Proceed to Coating Parameters
        </Button>
        <Button type="primary" icon={<ArrowRightOutlined />} onClick={handleSaveToContext} disabled={!isAllMaterialsConsumed() || steps.length === 0}>
          Proceed
        </Button>
      </div>
    </Space>
  )
}