'use client'

import { useContext } from 'react'
import { DataContext } from "@/lib/utils/DataContext"
import { Button, Card, Empty, Space, Table, Tag, Typography, Divider, Descriptions } from "antd"
import { AppstoreOutlined, SettingOutlined, CheckCircleOutlined, WarningOutlined, InfoCircleOutlined } from "@ant-design/icons"

const { Title, Text } = Typography

interface MaterialConsumption {
    materialCode: string
    quantity: number
}

interface CppValue {
    parameterName: string
    value: number
    minValue: number
    maxValue: number
    unit: string
}

interface StepRow {
    id: string
    stepName: string
    stepDescription: string
    machineCode?: string
    machineName?: string
    materials: MaterialConsumption[]
    cppValues: CppValue[]
}

interface IPQCRow {
    id: string
    parameterName: string
    specification: string
    frequency: string
}

interface CoatingPreviewProps {
    onBackToConfig?: () => void
    onBackToSteps?: () => void
}

export default function CoatingPreview({ onBackToConfig, onBackToSteps }: CoatingPreviewProps) {
    const { templateData } = useContext(DataContext)

    const solutionPrepSteps: StepRow[] = templateData?.['Coating Section']?.solutionPrep?.steps || []
    const coatingParams = templateData?.['Coating Section']?.coatingParams || {}
    const coatingMaterials = (templateData?.['Manufacturing BOM']?.bomData?.materials || []).filter((m: any) => m.usageStage === 'Coating')

    // Build material map for names
    const materialMap: Record<string, { materialName: string; uom: string; totalQty: number }> = {}
    coatingMaterials.forEach((m: any) => {
        materialMap[m.materialCode] = {
            materialName: m.materialName,
            uom: m.uom,
            totalQty: Number(m.quantity || 0)
        }
    })

    // Calculate consumed qty per material
    const getConsumedQuantity = (materialCode: string) => {
        return solutionPrepSteps.reduce((total, step) => {
            const stepMaterial = step.materials.find((m) => m.materialCode === materialCode)
            return total + Number(stepMaterial?.quantity || 0)
        }, 0)
    }

    // IPQC columns for mini table
    const ipqcColumns = [
        {
            title: 'Parameter',
            dataIndex: 'parameterName',
            key: 'parameterName',
            width: 200,
        },
        {
            title: 'Specification',
            dataIndex: 'specification',
            key: 'specification',
            width: 250,
        },
        {
            title: 'Frequency',
            dataIndex: 'frequency',
            key: 'frequency',
            width: 150,
        },
    ]

    // CPP columns for mini table
    const cppColumns = [
        {
            title: 'Parameter',
            dataIndex: 'parameterName',
            key: 'parameterName',
            width: 200,
        },
        {
            title: 'Value',
            dataIndex: 'value',
            key: 'value',
            width: 100,
        },
        {
            title: 'Range',
            key: 'range',
            width: 200,
            render: (_: any, record: CppValue) => (
                <Text>{record.minValue} - {record.maxValue} {record.unit}</Text>
            ),
        },
    ]

    if (solutionPrepSteps.length === 0) {
        return (
            <Card>
                <Empty description="No coating steps defined yet" image={Empty.PRESENTED_IMAGE_SIMPLE} />
                <div style={{ marginTop: 16, textAlign: 'center' }}>
                    <Space>
                        <Button icon={<SettingOutlined />} onClick={onBackToConfig}>
                            Go to Solution Preparation
                        </Button>
                        <Button type="primary" icon={<AppstoreOutlined />} onClick={onBackToSteps}>
                            Go to Coating Parameters
                        </Button>
                    </Space>
                </div>
            </Card>
        )
    }

    return (
        <div className="space-y-4">
            {/* Section 1: Solution Preparation Steps */}
            <Card
                title={
                    <Space>
                        <SettingOutlined className="text-blue-500" />
                        <Title level={5} style={{ margin: 0 }}>Solution Preparation Steps</Title>
                    </Space>
                }
            >
                {/* Material Status */}
                {Object.keys(materialMap).length > 0 && (
                    <>
                        <Divider orientation="horizontal">
                            <InfoCircleOutlined className="mr-2" />
                            Material Consumption Summary
                        </Divider>
                        <Space wrap style={{ marginBottom: 16 }}>
                            {Object.entries(materialMap).map(([materialCode, material]) => {
                                const consumed = getConsumedQuantity(materialCode)
                                const isFullyConsumed = consumed >= material.totalQty
                                return (
                                    <Tag key={materialCode} color={isFullyConsumed ? 'green' : 'orange'}>
                                        {material.materialName}: {consumed}/{material.totalQty} {material.uom}
                                    </Tag>
                                )
                            })}
                        </Space>
                    </>
                )}

                {/* Steps List */}
                <Divider orientation="horizontal">
                    <AppstoreOutlined className="mr-2" />
                    Steps
                </Divider>
                <div className="flex flex-col gap-3">
                    {solutionPrepSteps.map((step, index) => (
                        <Card key={step.id} size="small">
                            <div className="flex flex-col gap-2">
                                <div className="flex flex-wrap items-center gap-2">
                                    <Tag color="blue">Step {index + 1}</Tag>
                                    <Text strong>{step.stepName || "Unnamed Step"}</Text>
                                    {step.machineName ? <Tag color="orange">{step.machineName}</Tag> : null}
                                </div>
                                {step.stepDescription ? (
                                    <Text type="secondary">{step.stepDescription}</Text>
                                ) : null}

                                {/* Materials in this step */}
                                {step.materials.length > 0 && (
                                    <div className="flex flex-wrap gap-2">
                                        {step.materials.map((material) => (
                                            <Tag key={`${step.id}_${material.materialCode}`} color="green">
                                                {materialMap[material.materialCode]?.materialName || material.materialCode}: {material.quantity} {materialMap[material.materialCode]?.uom || ''}
                                            </Tag>
                                        ))}
                                    </div>
                                )}

                                {/* CPP values in this step */}
                                {step.cppValues && step.cppValues.length > 0 && (
                                    <div className="flex flex-wrap gap-2">
                                        {step.cppValues.map((cpp) => (
                                            <Tag key={`${step.id}_${cpp.parameterName}`} color="geekblue">
                                                {cpp.parameterName}: {cpp.value} {cpp.unit}
                                            </Tag>
                                        ))}
                                    </div>
                                )}
                            </div>
                        </Card>
                    ))}
                </div>
            </Card>

            {/* Section 2: Coating Parameters */}
            {coatingParams.machine && (
                <Card
                    title={
                        <Space>
                            <CheckCircleOutlined className="text-green-500" />
                            <Title level={5} style={{ margin: 0 }}>Coating Parameters</Title>
                        </Space>
                    }
                >
                    {/* Machine Info */}
                    <Divider orientation="horizontal">
                        <InfoCircleOutlined className="mr-2" />
                        Machine Information
                    </Divider>
                    <Descriptions column={2} size="small" style={{ marginBottom: 16 }}>
                        <Descriptions.Item label="Machine">{coatingParams.machine}</Descriptions.Item>
                        <Descriptions.Item label="Machine ID / Code">{coatingParams.machineId || '-'}</Descriptions.Item>
                        <Descriptions.Item label="Location" span={2}>{coatingParams.machineLocation || '-'}</Descriptions.Item>
                    </Descriptions>

                    {/* CPP Values */}
                    {coatingParams.cppValues && coatingParams.cppValues.length > 0 && (
                        <>
                            <Divider orientation="horizontal">
                                <SettingOutlined className="mr-2" />
                                Critical Process Parameters
                            </Divider>
                            <Table
                                columns={cppColumns}
                                dataSource={coatingParams.cppValues}
                                rowKey="parameterName"
                                pagination={false}
                                size="small"
                                style={{ marginBottom: 16 }}
                            />
                        </>
                    )}

                    {/* IPQC Rows */}
                    {coatingParams.ipqcRows && coatingParams.ipqcRows.length > 0 && (
                        <>
                            <Divider orientation="horizontal">
                                <WarningOutlined className="mr-2 text-orange-500" />
                                In-Process Quality Controls
                            </Divider>
                            <Table
                                columns={ipqcColumns}
                                dataSource={coatingParams.ipqcRows}
                                rowKey="id"
                                pagination={false}
                                size="small"
                                style={{ marginBottom: 16 }}
                            />
                        </>
                    )}

                    {/* Coating Defects */}
                    {coatingParams.coatingDefects && coatingParams.coatingDefects.length > 0 && (
                        <>
                            <Divider orientation="horizontal">
                                <WarningOutlined className="mr-2 text-red-500" />
                                Potential Coating Defects
                            </Divider>
                            <Space wrap>
                                {coatingParams.coatingDefects.map((defect: string) => (
                                    <Tag key={defect} color="red">{defect}</Tag>
                                ))}
                            </Space>
                        </>
                    )}
                </Card>
            )}

            {/* Navigation Buttons */}
            <div style={{ textAlign: 'center' }}>
                <Space>
                    <Button icon={<SettingOutlined />} onClick={onBackToConfig}>
                        Back to Solution Preparation
                    </Button>
                    <Button type="primary" icon={<AppstoreOutlined />} onClick={onBackToSteps}>
                        Back to Coating Parameters
                    </Button>
                </Space>
            </div>
        </div>
    )
}