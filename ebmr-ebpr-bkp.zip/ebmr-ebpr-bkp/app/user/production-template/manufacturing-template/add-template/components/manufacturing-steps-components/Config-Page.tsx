import { DataContext } from "@/lib/utils/DataContext";
import { Card, Descriptions, Badge, InputNumber, Tag, Table, Radio, Typography, Button, Space, message } from "antd";
import { use, useContext, useEffect, useState } from "react";
const { Text } = Typography
import { ArrowRightOutlined, } from "@ant-design/icons";
import { set, template } from "lodash";

interface MaterialSplitType {
    materialCode: string
    splitType: 'single' | 'split'
}
interface LotConfigData {
    numberOfLots?: number
    totalMaterials?: number
    usageStage?: string
    materialSplitTypes: { [materialCode: string]: 'single' | 'split' }
    materialSplits: {
        [materialCode: string]: {
            materialName: string,
            lots: { [lotName: string]: number; },
            totalQty: number,
            uom: string
        }
    }
    finalLotQuantities: { [materialCode: string]: { [lotName: string]: number } }
}
interface ConfigPageProps {
    toStepsDefinition: () => void
    currentPhase: 'config' | 'steps' | 'preview'
    layer?: string
}

export default function ConfigPage({ toStepsDefinition, currentPhase, layer }: ConfigPageProps) {
    const { templateData, setTemplateData } = useContext(DataContext)
    const [numberOfLots, setNumberOfLots] = useState(1);
    const [dataSource, setDataSource] = useState<any>([])
    const [selectedLayer, setSelectedLayer] = useState<string>('Granulation Single Layer')
    const [splitType, setSplitType] = useState<MaterialSplitType[]>([])
    const [lotValue, setLotValue] = useState<Record<string, number[]>>({})
    const [isDirty, setIsDirty] = useState(false)

    useEffect(() => { console.log(templateData) }, [templateData])

    useEffect(() => {
        const dataSource = templateData?.['Manufacturing BOM']?.bomData?.materials
        const filteredData = dataSource?.filter((item: any) => item.usageStage === layer)
        setDataSource(filteredData)
        setSelectedLayer(layer ?? '')
    }, [templateData['Manufacturing BOM'], layer])

    const handleSplitTypeChange = (materialCode: string, splitType: 'single' | 'split') => {
        setIsDirty(true)
        setSplitType(prev => {
            const exists = prev.find(item => item.materialCode === materialCode)
            if (exists) {
                return prev.map(item => item.materialCode === materialCode ? { ...item, splitType } : item)
            }
            return [...prev, { materialCode, splitType }]
        });
    }
    const getSplitType = (materialCode: string) => {
        return splitType.find(item => item.materialCode === materialCode)?.splitType || 'single'
    }

    const getValidLayers = (currentLayer?: string) => {
        if (currentLayer === 'Granulation Single Layer') {
            return ['Granulation Single Layer']
        }

        if (
            currentLayer === 'Granulation Layer-1' ||
            currentLayer === 'Granulation Layer-2'
        ) {
            return ['Granulation Layer-1', 'Granulation Layer-2']
        }

        return currentLayer ? [currentLayer] : []
    }

    const getRoundedInitialLots = (total: number, lots: number) => {
        if (lots <= 0) return []
        if (lots === 1) return [total]

        const baseQty = Math.floor(total / lots)
        const values = Array.from({ length: lots }, () => baseQty)
        const usedQty = baseQty * (lots - 1)
        values[lots - 1] = Math.max(total - usedQty, 0)

        return values
    }

    const getNormalizedLots = (total: number, lots: number, currentLots: number[] = []) => {
        const normalizedLots = Array.from({ length: lots }, (_, index) => currentLots[index] || 0)

        if (lots === 1) {
            return [total]
        }

        const editableSum = normalizedLots
            .slice(0, lots - 1)
            .reduce((sum, value) => sum + (Number(value) || 0), 0)

        normalizedLots[lots - 1] = Math.max(total - editableSum, 0)
        return normalizedLots
    }

    useEffect(() => {
        if (!dataSource?.length) {
            setLotValue({})
            return
        }

        const nextLotValues: Record<string, number[]> = {}

        dataSource.forEach((record: any) => {
            const materialCode = record.materialCode
            const currentLots = lotValue[materialCode]

            if (currentLots?.length === numberOfLots) {
                nextLotValues[materialCode] = getNormalizedLots(record.quantity, numberOfLots, currentLots)
                return
            }

            nextLotValues[materialCode] = getRoundedInitialLots(record.quantity, numberOfLots)
        })

        const hasChanged = JSON.stringify(nextLotValues) !== JSON.stringify(lotValue)
        if (hasChanged) {
            setLotValue(nextLotValues)
        }
    }, [dataSource, numberOfLots])

    useEffect(() => {
        setIsDirty(false)
    }, [layer])

    const validateLotConfiguration = () => {
        if (!dataSource?.length) {
            message.error('No materials found to save')
            return false
        }

        for (const record of dataSource) {
            const type = getSplitType(record.materialCode)

            if (type === 'single') {
                continue
            }

            const lots = getNormalizedLots(record.quantity, numberOfLots, lotValue[record.materialCode] || [])
            const totalAssigned = lots.reduce((sum, value) => sum + (Number(value) || 0), 0)
            const hasInvalidValue = lots.some(value => value < 0 || Number.isNaN(Number(value)))

            if (hasInvalidValue) {
                message.error(`Invalid lot quantity found for ${record.materialName}`)
                return false
            }

            if (totalAssigned !== record.quantity) {
                message.error(`Split quantity mismatch for ${record.materialName}`)
                return false
            }
        }

        return true
    }

    const handleSaveConfiguration = () => {
        if (!validateLotConfiguration()) {
            return
        }

        const currentLayerKey = layer ?? selectedLayer ?? 'Default Layer'
        const validLayers = getValidLayers(layer ?? selectedLayer)

        const materials = dataSource.reduce((acc: Record<string, any>, record: any) => {
            const type = getSplitType(record.materialCode)
            const normalizedLots = type === 'single'
                ? [record.quantity]
                : getNormalizedLots(record.quantity, numberOfLots, lotValue[record.materialCode] || [])

            acc[record.materialCode] = {
                materialName: record.materialName,
                uom: record.uom,
                splitType: type,
                lots: normalizedLots
            }

            return acc
        }, {})

        setTemplateData((prev: any) => {
            const existingLayers = prev?.['Manufacturing Lot Configuration']?.layers || {}
            const sanitizedLayers = Object.fromEntries(
                Object.entries(existingLayers).filter(([layerKey]) => validLayers.includes(layerKey))
            )

            return {
                ...prev,
                ['Manufacturing Lot Configuration']: {
                    layers: {
                        ...sanitizedLayers,
                        [currentLayerKey]: {
                            numberOfLots,
                            materials
                        }
                    }
                }
            }
        })

        setIsDirty(false)
        message.success(currentLayerKey + ' added to ' + ' Lot Configuration')
    }

    const validLayers = getValidLayers(layer ?? selectedLayer)
    const savedLayers = templateData?.['Manufacturing Lot Configuration']?.layers || {}
    const hasSavedAllRequiredLayers = validLayers.every((layerKey) => {
        const layerConfig = savedLayers[layerKey]
        return layerConfig?.numberOfLots && Object.keys(layerConfig?.materials || {}).length > 0
    })
    const isProceedDisabled = isDirty || !hasSavedAllRequiredLayers

    const lotColumns = [
        {
            title: 'Material Code',
            dataIndex: 'materialCode',
            key: 'materialCode',
            width: 130,
            render: (code: string) => <Text copyable style={{ color: '#1677ff' }}>{code}</Text>
        },
        {
            title: 'Material Name',
            dataIndex: 'materialName',
            key: 'materialName',
            width: 180,
            render: (name: string) => <Text strong>{name}</Text>
        },
        {
            title: 'Total Qty',
            key: 'totalQty',
            width: 120,
            render: (_: any, record: any) => (
                <Text>{record.quantity} <Tag>{record.uom}</Tag></Text>
            )
        },
        ...(
            numberOfLots > 1 ? [{
                title: 'Type',
                key: 'splitType',
                width: 150,
                render: (_: any, record: any) => (
                    <Radio.Group
                        value={getSplitType(record.materialCode)}
                        onChange={(e) => handleSplitTypeChange(record.materialCode, e.target.value)
                        }
                        size="small"
                    >
                        <Radio.Button value="single">Single</Radio.Button>
                        <Radio.Button value="split">Split</Radio.Button>
                    </Radio.Group >
                )
            }] : []
        ),
        ...Array.from({ length: numberOfLots }, (_, i) => ({
            title: `Lot ${i + 1}`,
            key: `lot_${i + 1}`,
            width: 100,
            dataIndex: `lot_${i + 1}`,
            render: (_: any, record: any) => {
                const type = getSplitType(record.materialCode)
                if (type === 'single') {
                    if (numberOfLots === 1) {
                        return <Tag color="green">{record.quantity} <Tag>{record.uom}</Tag></Tag>
                    }
                    return <Tag color="default">Not Applicable</Tag>
                }
                return (
                    <InputNumber
                        size="small"
                        min={0}
                        max={i === numberOfLots - 1
                            ? record.quantity
                            : Math.max(
                                record.quantity - ((lotValue[record.materialCode] || [])
                                    .slice(0, numberOfLots - 1)
                                    .reduce((sum, value, index) => index === i ? sum : sum + (Number(value) || 0), 0)),
                                0
                            )}
                        value={lotValue[record.materialCode]?.[i]}
                        disabled={i === numberOfLots - 1}
                        onChange={(val) => {
                            setIsDirty(true)
                            const updated = { ...lotValue }
                            const rowArray = Array.from(
                                { length: numberOfLots },
                                (_, index) => updated[record.materialCode]?.[index] || 0
                            )

                            rowArray[i] = Number(val) || 0
                            updated[record.materialCode] = getNormalizedLots(record.quantity, numberOfLots, rowArray)
                            setLotValue(updated)
                        }}
                    />
                )
            }
        })),
        ...(numberOfLots > 1 ? [{
            title: 'Final Lot',
            dataIndex: 'finalLot',
            key: 'finalLot',
            width: 100,
            render: (_: any, record: any) => {
                if (splitType.find(item => item.materialCode === record.materialCode)?.splitType === 'single') {
                    return <Tag color="green">{record.quantity}</Tag>;
                }
                return (
                    <Tag color="default">Not Applicable</Tag>
                );
            }
        }] : []),
    ]

    return (
        <>
            <Card
                title="Number of Lots for Manufacturing"
                style={{ marginBottom: 16 }}
            >
                <Descriptions bordered size="small" column={3}>
                    <Descriptions.Item label="Total Materials">
                        <Badge
                            color={'blue'}
                            count={dataSource.length || 0} showZero
                        />
                    </Descriptions.Item>
                    <Descriptions.Item label="Number of Lots">
                        <InputNumber
                            min={1}
                            max={10}
                            value={numberOfLots}
                            onChange={(val) => {
                                setIsDirty(true)
                                setNumberOfLots(val || 1)
                            }}
                        />
                    </Descriptions.Item>
                    <Descriptions.Item label="Usage Stage">
                        <Tag color="green">{layer}</Tag>
                    </Descriptions.Item>
                </Descriptions>
            </Card>
            <Card title="Material Distribution Across Lots">
                <Table
                    dataSource={dataSource}
                    columns={lotColumns}
                    rowKey="materialCode"
                    pagination={false}
                    size="small"
                    bordered
                    scroll={{ x: 'max-content' }}
                    style={{ marginBottom: 16 }}
                />
                <div className="flex justify-end pt-4 border-t border-gray-800">
                    <Button onClick={handleSaveConfiguration} style={{ marginRight: 8 }}>
                        Save Configuration
                    </Button>
                    <Button
                        onClick={toStepsDefinition}
                        disabled={isProceedDisabled}
                    >
                        Proceed to Steps Definition <ArrowRightOutlined />
                    </Button>
                </div>


            </Card>
        </>
    )
}
