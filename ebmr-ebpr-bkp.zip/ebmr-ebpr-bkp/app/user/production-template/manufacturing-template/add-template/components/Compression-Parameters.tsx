'use client'

import { Card, Form, Input, InputNumber, Select, Row, Col, Divider, Space, Button, Typography, message, Tooltip, Switch, Table, Badge, Tag, Spin } from "antd"
import {
  ArrowLeftOutlined,
  ArrowRightOutlined,
  InfoCircleOutlined,
  SettingOutlined,
  PlusOutlined,
  DeleteOutlined,
  WarningOutlined,
  CheckCircleOutlined,
  DashboardOutlined,
  ControlOutlined,
  ThunderboltOutlined,
  ScheduleOutlined
} from "@ant-design/icons"
import { useContext, useState, useCallback, useEffect, act, useMemo } from "react"
import { DataContext } from "@/lib/utils/DataContext"
import { COMPRESSED_TABLET_DEFECT_TYPES, EMBOSSING_TYPES, IPQC_FREQUENCY, PUNCH_SHAPES, TOOLING_COATINGS, TOOLING_MATERIALS, TOOLING_TYPES } from "@/lib/constants/Generarl"

const { Title, Text } = Typography
const { Option } = Select

// Compression Machine Types
const MACHINE_TYPES = [
  { value: 'Single Punch', label: 'Single Punch Press' },
  { value: 'Rotary', label: 'Rotary Tablet Press' },
  { value: 'High Speed Rotary', label: 'High Speed Rotary Press' },
  { value: 'Bilayer', label: 'Bilayer Tablet Press' },
  { value: 'Multi-Layer', label: 'Multi-Layer Press' },
]

// Pre-Compression Options
const PRE_COMPRESSION_OPTIONS = [
  { value: 'None', label: 'None' },
  { value: 'De-aeration', label: 'De-aeration' },
  { value: 'Pre-compression', label: 'Pre-compression' },
  { value: 'Both', label: 'Both (De-aeration + Pre-compression)' },
]

interface CompressionParametersProps {
  onNext: () => void
  onPrevious: () => void
}

interface PunchSpec {
  id: string
  punchType: 'Upper' | 'Lower'
  punchShape: string
  punchDiameter: number
  punchLength: number
  cupDepth: number
  embossingType: string
  embossingText: string
  breakline: boolean
  breaklineDepth: number
}

interface EquipmentOption {
  label: string
  value: string
}

interface CPPParameter {
  parameterName: string
  minValue: number
  maxValue: number
  unit: string
}

export default function CompressionParameters({ onNext, onPrevious }: CompressionParametersProps) {
  const [form] = Form.useForm()
  const { templateData, setTemplateData } = useContext(DataContext)
  const [punchSpecs, setPunchSpecs] = useState<PunchSpec[]>([])
  const [activeTab, setActiveTab] = useState<'machine' | 'tooling' | 'parameters' | 'quality'>('machine')
  const [cppLoading, setCppLoading] = useState(false)
  const [cppParameters, setCppParameters] = useState<CPPParameter[]>([])
  const tabFlow: Array<typeof activeTab> = ['machine', 'tooling', 'parameters', 'quality']
  const isLastTab = activeTab === tabFlow[tabFlow.length - 1]

  // Map active tab to sub-key
  const getStageKey = useCallback((tab: string): string => {
    const stageMap: Record<string, string> = {
      machine: 'machineSetup',
      tooling: 'toolingSpecs',
      parameters: 'compressionParams',
      quality: 'qualityControls'
    }
    return stageMap[tab] || 'machineSetup'
  }, [])

  // Load saved data on mount
  const loadData = useCallback(() => {
    const savedData = templateData?.['Compression Parameters']
    if (savedData) {
      const stageKey = getStageKey(activeTab)
      const stageData = savedData[stageKey]
      if (stageData) {
        form.setFieldsValue(stageData)
        if (activeTab === 'tooling' && stageData.punchSpecs) {
          setPunchSpecs(stageData.punchSpecs)
        }
      }
    }
  }, [form, templateData, activeTab, getStageKey])

  // useEffect(() => { console.log(templateData) }, [templateData, activeTab])

  const machineList = useMemo(() => {
    const formattedData: any[] = []
    const equipment = templateData?.['Facility Equipment']?.facilitiesWithEquipment || []

    equipment.forEach((facility: any) => {
      facility.equipments?.forEach((equipment: any) => {
        formattedData.push({
          machineName: equipment.equipmentName,
          machineCode: equipment.equipmentCode,
          areaName: facility.areaName || 'N/A',
          facilityCode: facility.facilityCode || 'N/A',
          cppParameters: equipment.cppParameters?.map((param: any) => ({
            parameterName: param.parameterName,
            minValue: param.minValue,
            maxValue: param.maxValue,
            unit: param.unit || 'Not Specified',
            range: `${param.minValue} - ${param.maxValue} ${param.unit || ''}`
          })) || []
        })
      })
    })

    return formattedData
  }, [templateData])

  // Load data when tab changes
  useEffect(() => {
    loadData()
  }, [loadData, activeTab])

  const handleSaveAndNext = async () => {
    try {
      const values = await form.validateFields()
      const stageKey = getStageKey(activeTab)
      const compressionData = {
        ...values,
        ...(activeTab === 'tooling' ? { punchSpecs } : {}),
        updatedAt: new Date().toISOString()
      }

      setTemplateData((prev: any) => ({
        ...prev,
        ['Compression Parameters']: {
          ...(prev?.['Compression Parameters'] || {}),
          [stageKey]: compressionData
        }
      }))

      message.success('Compression parameters saved successfully!')
      if (isLastTab) {
        onNext()
        return
      }

      const nextTab = tabFlow[tabFlow.indexOf(activeTab) + 1]
      if (nextTab) {
        setActiveTab(nextTab)
      }
    } catch (error) {
      console.error('Validation failed:', error)
      message.error('Please fill all required fields correctly')
    }
  }

  const handleSave = async () => {
    try {
      const values = await form.validateFields({ recursive: true })
      const stageKey = getStageKey(activeTab)
      const compressionData = {
        ...values,
        ...(activeTab === 'tooling' ? { punchSpecs } : {}),
        updatedAt: new Date().toISOString()
      }

      setTemplateData((prev: any) => ({
        ...prev,
        ['Compression Parameters']: {
          ...(prev?.['Compression Parameters'] || {}),
          [stageKey]: compressionData
        }
      }))

      message.success('Compression parameters saved!')
    } catch (error) {
      console.error('Validation failed:', error)
      message.error('Please check your input')
    }
  }

  const addPunchSpec = () => {
    const newSpec: PunchSpec = {
      id: Date.now().toString(),
      punchType: 'Upper',
      punchShape: 'Round',
      punchDiameter: 0,
      punchLength: 0,
      cupDepth: 0,
      embossingType: 'None',
      embossingText: '',
      breakline: false,
      breaklineDepth: 0,
    }
    setPunchSpecs([...punchSpecs, newSpec])
  }

  const removePunchSpec = (id: string) => {
    setPunchSpecs(punchSpecs.filter(spec => spec.id !== id))
  }

  const updatePunchSpec = (id: string, field: keyof PunchSpec, value: any) => {
    setPunchSpecs(punchSpecs.map(spec =>
      spec.id === id ? { ...spec, [field]: value } : spec
    ))
  }

  const handleMachineChange = async (value: string, option: any) => {
    setCppLoading(true)
    const selectedMachine = machineList.find((machine) => machine.machineCode === value)

    if (selectedMachine) {
      const params = selectedMachine.cppParameters?.map((param: any) => ({
        parameterName: param.parameterName,
        minValue: param.minValue,
        maxValue: param.maxValue,
        unit: param.unit || 'Not Specified'
      })) || []
      setCppLoading(false)
      form.setFieldValue('machineId', selectedMachine.machineCode)
      form.setFieldValue('machineLocation', `${selectedMachine.areaName} - ${selectedMachine.facilityCode}`)
      setCppParameters(params)

    } else {
      setCppLoading(false)
      setCppParameters([])
      form.setFieldValue('machineId', '')
      form.setFieldValue('machineLocation', '')
    }
  }

  const punchColumns = [
    {
      title: 'Punch Type',
      dataIndex: 'punchType',
      key: 'punchType',
      width: 120,
      render: (text: string, record: PunchSpec) => (
        <Select
          value={record.punchType}
          onChange={(val) => updatePunchSpec(record.id, 'punchType', val)}
          size="small"
          style={{ width: '100%' }}
        >
          <Option value="Upper">Upper</Option>
          <Option value="Lower">Lower</Option>
        </Select>
      ),
    },
    {
      title: 'Shape',
      dataIndex: 'punchShape',
      key: 'punchShape',
      width: 120,
      render: (text: string, record: PunchSpec) => (
        <Select
          value={record.punchShape}
          onChange={(val) => updatePunchSpec(record.id, 'punchShape', val)}
          size="small"
          style={{ width: '100%' }}
          options={PUNCH_SHAPES}
        />
      ),
    },
    {
      title: 'Diameter (mm)',
      dataIndex: 'punchDiameter',
      key: 'punchDiameter',
      width: 120,
      render: (text: number, record: PunchSpec) => (
        <InputNumber
          value={record.punchDiameter}
          onChange={(val) => updatePunchSpec(record.id, 'punchDiameter', val || 0)}
          size="small"
          min={0}
          max={50}
          step={0.1}
          style={{ width: '100%' }}
          placeholder="0.0"
        />
      ),
    },
    {
      title: 'Length (mm)',
      dataIndex: 'punchLength',
      key: 'punchLength',
      width: 120,
      render: (text: number, record: PunchSpec) => (
        <InputNumber
          value={record.punchLength}
          onChange={(val) => updatePunchSpec(record.id, 'punchLength', val || 0)}
          size="small"
          min={0}
          max={200}
          step={0.1}
          style={{ width: '100%' }}
          placeholder="0.0"
        />
      ),
    },
    {
      title: 'Cup Depth (mm)',
      dataIndex: 'cupDepth',
      key: 'cupDepth',
      width: 120,
      render: (text: number, record: PunchSpec) => (
        <InputNumber
          value={record.cupDepth}
          onChange={(val) => updatePunchSpec(record.id, 'cupDepth', val || 0)}
          size="small"
          min={0}
          max={10}
          step={0.01}
          style={{ width: '100%' }}
          placeholder="0.00"
        />
      ),
    },
    {
      title: 'Embossing',
      dataIndex: 'embossingType',
      key: 'embossingType',
      width: 130,
      render: (text: string, record: PunchSpec) => (
        <Select
          value={record.embossingType}
          onChange={(val) => updatePunchSpec(record.id, 'embossingType', val)}
          size="small"
          style={{ width: '100%' }}
          options={EMBOSSING_TYPES}
        />
      ),
    },
    {
      title: 'Breakline',
      dataIndex: 'breakline',
      key: 'breakline',
      width: 90,
      render: (text: boolean, record: PunchSpec) => (
        <Switch
          checked={record.breakline}
          onChange={(checked) => updatePunchSpec(record.id, 'breakline', checked)}
          size="small"
        />
      ),
    },
    {
      title: 'Actions',
      key: 'actions',
      width: 60,
      render: (_: any, record: PunchSpec) => (
        <Button
          type="text"
          danger
          icon={<DeleteOutlined />}
          onClick={() => removePunchSpec(record.id)}
          size="small"
        />
      ),
    },
  ]

  const tabs = [
    { key: 'machine', label: 'Machine Setup', icon: <SettingOutlined /> },
    { key: 'tooling', label: 'Tooling Specs', icon: <ControlOutlined /> },
    { key: 'parameters', label: 'Compression Params', icon: <DashboardOutlined /> },
    { key: 'quality', label: 'Quality Controls', icon: <CheckCircleOutlined /> },
  ]

  return (
    <div className="space-y-4">
      {/* Tab Navigation */}
      <Card size="small" className="sticky top-0 z-10">
        <div className="flex flex-wrap gap-2">
          {tabs.map(tab => (
            <Button
              key={tab.key}
              type={activeTab === tab.key ? 'primary' : 'default'}
              icon={tab.icon}
              onClick={() => setActiveTab(tab.key as typeof activeTab)}
              className="flex-1 min-w-30"
            >
              {tab.label}
            </Button>
          ))}
        </div>
      </Card>

      <Form form={form} layout="vertical" name="compression_parameters">
        {/* Tab 1: Machine Setup */}
        {activeTab === 'machine' && (
          <Card title={
            <Space>
              <SettingOutlined className="text-blue-500" />
              <Title level={5} style={{ margin: 0 }}>Compression Machine Setup</Title>
            </Space>
          }>
            <Divider orientation="horizontal">
              <InfoCircleOutlined className="mr-2" />
              Machine Information
            </Divider>

            <Row gutter={[24, 16]}>
              <Col xs={24} md={12}>
                <Form.Item
                  name="machineType"
                  label="Machine Type"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Select the compression machine type</Text>}
                >
                  <Select
                    placeholder="Select machine"
                    size="large"
                    style={{ width: '100%' }}
                    options={machineList.map((m) => ({
                      label: `${m.machineName} - ${m.machineCode}`,
                      value: m.machineCode
                    }))}
                    value={''}
                    onChange={handleMachineChange}
                    showSearch
                    optionFilterProp="label"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={12}>
                <Form.Item
                  name="machineId"
                  label="Machine ID / Number"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Unique machine identifier</Text>}
                >
                  <Input
                    placeholder="e.g., COMP-001"
                    size="large"
                    disabled={true}
                    suffix={cppLoading ? <Spin size="small" /> : ''}
                  />
                </Form.Item>
              </Col>
            </Row>

            <Row gutter={[24, 16]}>
              <Col xs={24} md={8}>
                <Form.Item
                  name="machineLocation"
                  label="Machine Location"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Department/Area location</Text>}
                >
                  <Input
                    placeholder="e.g., Granulation Section"
                    size="large"
                    suffix={cppLoading ? <Spin size="small" /> : ''}
                    disabled={true}
                  />
                </Form.Item>
              </Col>
              <Col xs={24} md={8}>
                <Form.Item
                  name="numberOfStations"
                  label="Number of Stations"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>For rotary presses</Text>}
                >
                  <InputNumber
                    placeholder="e.g., 35"
                    min={1}
                    max={100}
                    style={{ width: '100%' }}
                    size="large"
                  />
                </Form.Item>
              </Col>
              <Col xs={24} md={8}>
                <Form.Item
                  name="preCompressionType"
                  label="Pre-Compression Type"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Type of pre-compression</Text>}
                >
                  <Select
                    placeholder="Select type"
                    options={PRE_COMPRESSION_OPTIONS}
                    size="large"
                  />
                </Form.Item>
              </Col>
            </Row>

            <Divider>
              <SettingOutlined className="mr-2" />
              Critical Process Parameters
            </Divider>

            <Row >
              {cppParameters?.length > 0 &&
                cppParameters.map((param, index) => (
                  <div className="mr-5" key={index}>
                    <div className="flex items-cener justify-between flex-col w-ful">
                      <div className="borde border-b pb-2 mb-2 border-[#303030]">
                        <Text>{param.parameterName}</Text>
                      </div>
                      <div className="flex flex-row justify-between w-full gap-2">
                        {/* Hidden fields */}
                        <Form.Item
                          name={['cppParameters', index, 'parameterName']}
                          initialValue={param.parameterName}
                          hidden
                        >
                          <Input />
                        </Form.Item>

                        <Form.Item
                          name={['cppParameters', index, 'unit']}
                          initialValue={param.unit}
                          hidden
                        >
                          <Input />
                        </Form.Item>
                        <Form.Item
                          name={['cppParameters', index, 'minValue']}
                          label="Min"
                          extra={<Text type="secondary" style={{ fontSize: 11 }}>Min: {param.minValue} {param.unit}</Text>}
                        >
                          <InputNumber
                            min={param.minValue}
                            max={param.maxValue}
                            addonAfter={param.unit}
                            size="medium"
                            placeholder={param.minValue.toLocaleString()}
                          />
                        </Form.Item>

                        <Form.Item
                          name={['cppParameters', index, 'maxValue']}
                          label="Max"
                          extra={<Text type="secondary" style={{ fontSize: 11 }}>Max: {param.maxValue} {param.unit}</Text>}
                        >
                          <InputNumber
                            placeholder={param.maxValue.toLocaleString()}
                            min={param.minValue}
                            max={param.maxValue}
                            addonAfter={param.unit}
                            size="medium" />
                        </Form.Item>
                      </div>
                    </div>
                  </div>
                ))}
            </Row>
            <Divider>
              <ThunderboltOutlined className="mr-2 text-blue-500" />
              Speed & Output Settings
            </Divider>
            <Row gutter={[24, 16]}>
              <Col xs={24} md={8}>
                <Form.Item
                  name="maxSpeed"
                  label="Maximum Speed (tablets/hour)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Theoretical maximum output</Text>}
                >
                  <InputNumber
                    placeholder="e.g., 10000"
                    min={0}
                    step={100}
                    style={{ width: '100%' }}
                    size="large"
                    addonAfter="tabs/hr"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="operatingSpeed"
                  label="Operating Speed (tablets/hour)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Normal operating speed</Text>}
                >
                  <InputNumber
                    placeholder="e.g., 8000"
                    min={0}
                    step={100}
                    style={{ width: '100%' }}
                    size="large"
                    addonAfter="tabs/hr"
                  />
                </Form.Item>
              </Col>
            </Row>
          </Card>
        )}

        {/* Tab 2: Tooling Specifications */}
        {activeTab === 'tooling' && (
          <Card title={
            <Space>
              <ControlOutlined className="text-blue-500" />
              <Title level={5} style={{ margin: 0 }}>Tooling Specifications</Title>
            </Space>
          }>
            <Divider orientation="horizontal">
              <InfoCircleOutlined className="mr-2" />
              Punch & Die Specifications
            </Divider>

            <Row gutter={[24, 16]}>
              <Col xs={24} md={8}>
                <Form.Item
                  name="toolingType"
                  label="Tooling Type"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Punch barrel diameter standard</Text>}
                >
                  <Select
                    placeholder="Select tooling type"
                    options={TOOLING_TYPES}
                    size="large"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="toolingMaterial"
                  label="Tooling Material"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Punch/die material grade</Text>}
                >
                  <Select
                    placeholder="Select material"
                    size="large"
                    options={TOOLING_MATERIALS}
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="toolingCoating"
                  label="Tooling Coating"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Surface coating/treatment</Text>}
                >
                  <Select
                    placeholder="Select coating"
                    size="large"
                    options={TOOLING_COATINGS}
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={6}>
                <Form.Item
                  name="dieBoreSize"
                  label="Die Bore Size (mm)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Die hole diameter</Text>}
                >
                  <InputNumber
                    placeholder="0.0"
                    min={0}
                    max={50}
                    step={0.01}
                    style={{ width: '100%' }}
                    size="large"
                    addonAfter="mm"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={6}>
                <Form.Item
                  name="dieThickness"
                  label="Die Thickness (mm)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Die ring thickness</Text>}
                >
                  <InputNumber
                    placeholder="0.0"
                    min={0}
                    max={100}
                    step={0.1}
                    style={{ width: '100%' }}
                    size="large"
                    addonAfter="mm"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={6}>
                <Form.Item
                  name="upperPunchLength"
                  label="Upper Punch Length (mm)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Overall upper punch length</Text>}
                >
                  <InputNumber
                    placeholder="0.0"
                    min={0}
                    max={200}
                    step={0.1}
                    style={{ width: '100%' }}
                    size="large"
                    addonAfter="mm"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={6}>
                <Form.Item
                  name="lowerPunchLength"
                  label="Lower Punch Length (mm)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Overall lower punch length</Text>}
                >
                  <InputNumber
                    placeholder="0.0"
                    min={0}
                    max={200}
                    step={0.1}
                    style={{ width: '100%' }}
                    size="large"
                    addonAfter="mm"
                  />
                </Form.Item>
              </Col>
            </Row>

            <Divider />

            <Space className="mb-3">
              <Title level={5} style={{ margin: 0 }}>
                Punch Specifications Table
              </Title>
              <Tooltip title="Add new punch specification">
                <Button
                  type="primary"
                  icon={<PlusOutlined />}
                  onClick={addPunchSpec}
                  size="small"
                >
                  Add Punch
                </Button>
              </Tooltip>
            </Space>

            {punchSpecs.length > 0 ? (
              <div className="overflow-x-auto">
                <Table
                  columns={punchColumns}
                  dataSource={punchSpecs}
                  rowKey="id"
                  pagination={false}
                  size="middle"
                  scroll={{ x: 900 }}
                />
              </div>
            ) : (
              <div className="text-center py-8 text-gray-400">
                <ControlOutlined className="text-4xl mb-2" />
                <p>No punch specifications added yet. Click "Add Punch" to begin.</p>
              </div>
            )}
          </Card>
        )}

        {/* Tab 3: Compression Parameters */}
        {activeTab === 'parameters' && (
          <Card title={
            <Space>
              <DashboardOutlined className="text-blue-500" />
              <Title level={5} style={{ margin: 0 }}>Compression Process Parameters</Title>
            </Space>
          }>
            <Divider orientation="horizontal">
              <InfoCircleOutlined className="mr-2" />
              Tablet Description
            </Divider>

            <Row gutter={[24, 16]}>
              <Col xs={24} md={24}>
                <Form.Item
                  name="tabletDescription"
                  label="Tablet Description"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Description of the tablet</Text>}
                >
                  <Input.TextArea
                    rows={2}
                    placeholder="Enter any description of the tablet..."
                    size="large"
                  />
                </Form.Item>
              </Col>
            </Row>

            <Divider orientation="horizontal">
              <InfoCircleOutlined className="mr-2" />
              Main Compression Settings
            </Divider>

            <Row gutter={[24, 16]}>
              <Col xs={24} md={8}>
                <Form.Item
                  name="targetTabletWeight"
                  label="Target Tablet Weight (mg)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Individual tablet weight</Text>}
                >
                  <InputNumber
                    placeholder="0"
                    min={0}
                    step={1}
                    style={{ width: '100%' }}
                    size="large"
                    addonAfter="mg"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="tabletWeightTolerance"
                  label="Weight Tolerance (±mg)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Acceptable weight variation</Text>}
                >
                  <InputNumber
                    placeholder="5"
                    min={0}
                    step={0.5}
                    style={{ width: '100%' }}
                    size="large"
                    addonAfter="mg"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="targetTabletThickness"
                  label="Target Tablet Thickness (mm)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Final tablet thickness</Text>}
                >
                  <InputNumber
                    placeholder="0.0"
                    min={0}
                    max={30}
                    step={0.01}
                    style={{ width: '100%' }}
                    size="large"
                    addonAfter="mm"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="thicknessTolerance"
                  label="Thickness Tolerance (±mm)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Acceptable thickness variation</Text>}
                >
                  <InputNumber
                    placeholder="0.05"
                    min={0}
                    max={5}
                    step={0.01}
                    style={{ width: '100%' }}
                    size="large"
                    addonAfter="mm"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="targetHardness"
                  label="Target Hardness (kP)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Tablet crushing strength</Text>}
                >
                  <InputNumber
                    placeholder="0"
                    min={0}
                    max={100}
                    step={1}
                    style={{ width: '100%' }}
                    size="large"
                    addonAfter="kP"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="hardnessTolerance"
                  label="Hardness Tolerance (±kP)"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Acceptable hardness variation</Text>}
                >
                  <InputNumber
                    placeholder="2"
                    min={0}
                    max={20}
                    step={0.5}
                    style={{ width: '100%' }}
                    size="large"
                    addonAfter="kP"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="disintegrationTime"
                  label="Disintegration Time (s)"
                  // rules={[{ required: true, message: 'Please input Disintegration Time!' }]}
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Time required for disintegration</Text>}
                >
                  <InputNumber
                    placeholder="0.0"
                    min={0}
                    max={100}
                    step={0.1}
                    style={{ width: '100%' }}
                    size="large"
                    addonAfter="s"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="disintegrationTemperature"
                  label="Disintegration Temperature (°C)"
                  // rules={[{ required: true, message: 'Please input Disintegration Temperature!' }]}
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Temperature required for disintegration</Text>}
                >
                  <InputNumber
                    placeholder="0.0"
                    min={0}
                    max={100}
                    step={0.1}
                    style={{ width: '100%' }}
                    size="large"
                    addonAfter="°C"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="friabilityTolerance"
                  label="Friability Tolerance (<1%)"
                  // rules={[{ required: true, message: 'Please input Friability Tolerance!' }]}
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Friability tolerance</Text>}
                >
                  <InputNumber
                    placeholder="0.0"
                    min={0}
                    max={100}
                    step={0.1}
                    style={{ width: '100%' }}
                    size="large"
                    addonAfter="%"
                  />
                </Form.Item>
              </Col>
            </Row>


          </Card>
        )}

        {/* Tab 4: Quality Controls */}
        {activeTab === 'quality' && (
          <Card title={
            <Space>
              <CheckCircleOutlined className="text-green-500" />
              <Title level={5} style={{ margin: 0 }}>Quality Control Parameters</Title>
            </Space>
          }>
            <Divider orientation="horizontal">
              <WarningOutlined className="mr-2 text-orange-500" />
              In-Process Quality Controls (IPQC)
            </Divider>

            <Row gutter={[24, 16]}>
              <Col xs={24} md={8}>
                <Form.Item
                  name="weightCheckFrequency"
                  label="Weight Check Frequency"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>How often to check tablet weight</Text>}
                >
                  <Select
                    placeholder="Select frequency"
                    size="large"
                    options={IPQC_FREQUENCY}
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="hardnessCheckFrequency"
                  label="Hardness Check Frequency"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>How often to check hardness</Text>}
                >
                  <Select
                    placeholder="Select frequency"
                    size="large"
                    options={IPQC_FREQUENCY}
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="thicknessCheckFrequency"
                  label="Thickness Check Frequency"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>How often to check thickness</Text>}
                >
                  <Select
                    placeholder="Select frequency"
                    size="large"
                    options={IPQC_FREQUENCY}
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="sampleSizeWeight"
                  label="Sample Size for Weight"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Number of tablets per sample</Text>}
                >
                  <InputNumber
                    placeholder="20"
                    min={1}
                    max={100}
                    style={{ width: '100%' }}
                    size="large"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="sampleSizeHardnessThickness"
                  label="Sample Size for Hardness/Thickness"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Number of tablets to test</Text>}
                >
                  <InputNumber
                    placeholder="10"
                    min={1}
                    max={50}
                    style={{ width: '100%' }}
                    size="large"
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item
                  name="appearanceCheckFrequency"
                  label="Appearance Check Frequency"
                  extra={<Text type="secondary" style={{ fontSize: 11 }}>Visual inspection frequency</Text>}
                >
                  <Select
                    placeholder="Select frequency"
                    size="large"
                    options={IPQC_FREQUENCY}
                  />
                </Form.Item>
              </Col>
            </Row>

            <Divider />

            <Space direction="vertical" size="middle" style={{ width: '100%' }}>
              <Title level={5}>
                <WarningOutlined className="mr-2 text-orange-500" />
                Rejection Criteria
              </Title>

              <Row gutter={[24, 16]}>
                <Col xs={24} md={6}>
                  <Form.Item
                    name="weightRejectionLimit"
                    label="Weight Rejection Limit (±%)"
                    extra={<Text type="secondary" style={{ fontSize: 11 }}>Auto-reject if exceeded</Text>}
                  >
                    <InputNumber
                      placeholder="5"
                      min={0}
                      max={50}
                      step={0.5}
                      style={{ width: '100%' }}
                      size="large"
                      addonAfter="%"
                    />
                  </Form.Item>
                </Col>

                <Col xs={24} md={6}>
                  <Form.Item
                    name="hardnessRejectionLimit"
                    label="Hardness Rejection Limit (±%)"
                    extra={<Text type="secondary" style={{ fontSize: 11 }}>Auto-reject if exceeded</Text>}
                  >
                    <InputNumber
                      placeholder="20"
                      min={0}
                      max={100}
                      step={1}
                      style={{ width: '100%' }}
                      size="large"
                      addonAfter="%"
                    />
                  </Form.Item>
                </Col>

                <Col xs={24} md={6}>
                  <Form.Item
                    name="thicknessRejectionLimit"
                    label="Thickness Rejection Limit (±%)"
                    extra={<Text type="secondary" style={{ fontSize: 11 }}>Auto-reject if exceeded</Text>}
                  >
                    <InputNumber
                      placeholder="10"
                      min={0}
                      max={50}
                      step={1}
                      style={{ width: '100%' }}
                      size="large"
                      addonAfter="%"
                    />
                  </Form.Item>
                </Col>

                <Col xs={24} md={6}>
                  <Form.Item
                    name="metalDetectorSensitivity"
                    label="Metal Detector Sensitivity"
                    extra={<Text type="secondary" style={{ fontSize: 11 }}>Detection sensitivity in mm</Text>}
                  >
                    <InputNumber
                      placeholder="1.5"
                      min={0}
                      max={10}
                      step={0.1}
                      style={{ width: '100%' }}
                      size="large"
                      addonAfter="mm Fe"
                    />
                  </Form.Item>
                </Col>
              </Row>

              <Row gutter={[24, 16]}>
                <Col xs={24} md={12}>
                  <Form.Item
                    name="defectTypes"
                    label="Critical Defect Types to Monitor"
                    extra={<Text type="secondary" style={{ fontSize: 11 }}>Select all that apply</Text>}
                  >
                    <Select
                      mode="multiple"
                      placeholder="Select defect types"
                      size="large"
                      style={{ width: '100%' }}
                      options={COMPRESSED_TABLET_DEFECT_TYPES}
                    />
                  </Form.Item>
                </Col>

                {/* <Col xs={24} md={12}>
                  <Form.Item
                    name="rejectionAction"
                    label="On Rejection Trigger"
                    extra={<Text type="secondary" style={{ fontSize: 11 }}>Action when limits exceeded</Text>}
                  >
                    <Select
                      placeholder="Select action"
                      size="large"
                    >
                      <Option value="Alert Only">Alert Operator Only</Option>
                      <Option value="Stop Feeder">Stop Feeder</Option>
                      <Option value="Stop Machine">Stop Machine</Option>
                      <Option value="Divert">Divert to Reject Bin</Option>
                    </Select>
                  </Form.Item>
                </Col> */}
              </Row>
            </Space>

            <Divider />

            <Space direction="vertical" size="middle" style={{ width: '100%' }}>
              <Title level={5}>
                <InfoCircleOutlined className="mr-2 text-blue-500" />
                Additional Notes
              </Title>

              <Row gutter={[24, 16]}>
                <Col xs={24}>
                  <Form.Item
                    name="specialInstructions"
                    label="Special Instructions / Notes"
                    extra={<Text type="secondary" style={{ fontSize: 11 }}>Any special considerations for this compression process</Text>}
                  >
                    <Input.TextArea
                      rows={4}
                      placeholder="Enter any special instructions, warnings, or notes for the compression process..."
                      size="large"
                    />
                  </Form.Item>
                </Col>
              </Row>
            </Space>
          </Card>
        )}

        {/* Action Buttons */}
        <Card size="small" className="mt-4">
          <div className="flex justify-end gap-3">
            <Button
              icon={<ArrowLeftOutlined />}
              onClick={onPrevious}
              size="large"
            >
              Previous
            </Button>
            <Button
              onClick={handleSave}
              size="large"
            >
              Save Draft
            </Button>
            <Button
              type="primary"
              icon={<ArrowRightOutlined />}
              onClick={handleSaveAndNext}
              size="large"
            >
              {isLastTab ? 'Next' : 'Save & Continue'}
            </Button>
          </div>
        </Card>
      </Form>
    </div>
  )
}
