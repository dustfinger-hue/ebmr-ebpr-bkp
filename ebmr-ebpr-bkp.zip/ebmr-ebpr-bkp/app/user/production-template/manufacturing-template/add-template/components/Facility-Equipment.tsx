'use client'
import {
  Button,
  Card,
  message,
  Table,
  Input,
  Tag,
  Empty,
  Checkbox,
  Typography,
  Drawer,
  Statistic,
  Row,
  Col,
  List,
} from "antd";
import {
  SearchOutlined,
  ReloadOutlined,
  EyeOutlined,
  ArrowLeftOutlined,
  ArrowRightOutlined,
} from "@ant-design/icons";
import { useContext, useEffect, useState } from "react";
import { Key } from "antd/es/table/interface";
import { DataContext } from "@/lib/utils/DataContext";

const { Search } = Input;

interface Pagination {
  current: number;
  pageSize: number;
  total: number;
}

interface Filters {
  status: string | null;
  cleanRoomGrade: string | null;
  department: string | null;
  blockBuilding: string | null;
  areaType: string | null;
}

interface FacilityEquipmentProps {
  onNext: () => void;
  onPrevious: () => void;
}

export default function FacilityEquipment({ onNext, onPrevious }: FacilityEquipmentProps) {
  const [data, setData] = useState<any[]>([]);
  const [facilityMap, setFacilityMap] = useState<Record<string, any>>({});

  const [loading, setLoading] = useState(false);

  const [pagination, setPagination] = useState<Pagination>({
    current: 1,
    pageSize: 10,
    total: 0
  });

  const [searchText, setSearchText] = useState("");

  const [filters, setFilters] = useState<Filters>({
    status: null,
    cleanRoomGrade: null,
    department: null,
    blockBuilding: null,
    areaType: null
  });

  // Data context - direct from context
  const { templateData: dataFromContext, setTemplateData } = useContext(DataContext);

  // ✅ selection states
  const [selectedFacilities, setSelectedFacilities] = useState<Key[]>([]);
  const [selectedEquipment, setSelectedEquipment] = useState<Record<string, string[]>>({});
  // Track whether we've restored from context (for edit mode)
  const [contextRestored, setContextRestored] = useState(false);
  const [initialFetchDone, setInitialFetchDone] = useState(false);

  // 🔲 DRAWER STATE
  const [drawerOpen, setDrawerOpen] = useState(false);

  // 📊 CALCULATE TOTALS
  const totalSelectedEquipment = Object.values(selectedEquipment).flat().length;

  // 🔥 equipment change
  const handleEquipmentChange = (facilityId: string, values: any[]) => {
    setSelectedEquipment(prev => ({
      ...prev,
      [facilityId]: values
    }));
  };

  // 🔥 API CALL
  const fetchData = async (
    pag: Pagination = pagination,
    filt: Filters = filters,
    search: string = searchText
  ) => {
    setLoading(true);
    const token = localStorage.getItem("token");

    const query = new URLSearchParams({
      page: String(pag.current),
      limit: String(pag.pageSize),
      search: search || "",
      status: filt.status || "",
      cleanRoomGrade: filt.cleanRoomGrade || "",
      department: filt.department || "",
      blockBuilding: filt.blockBuilding || "",
      areaType: filt.areaType || ""
    });

    try {
      const res = await fetch(
        `/api/user/master-data/facility-master?${query}`,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      const result = await res.json();

      if (result.success) {

        if (result.facilities?.length > 0) {
          const ids = result.facilities.map((f: any) => f._id);

          const equipRes = await fetch(
            `/api/user/master-data/facility-master/equipment-search?facilityId=${ids.join(",")}`,
            {
              headers: { Authorization: `Bearer ${token}` }
            }
          );

          const equipResult = await equipRes.json();

          const equipData = equipResult.equipmentByFacility || [];

          // 🔥 merge
          const merged = result.facilities.map((f: any) => {
            const match = equipData.find((e: any) => e.facilityId === f._id);
            return {
              ...f,
              equipment: match?.equipment || []
            };
          });

          setData(merged);

          // 🔥 GLOBAL MAP (IMPORTANT)
          setFacilityMap(prev => {
            const updated = { ...prev };
            merged.forEach((f: any) => {
              updated[f._id] = f;
            });
            return updated;
          });
        } else {
          setData([]);
        }

        setPagination({
          current: result.page,
          pageSize: result.limit,
          total: result.total
        });

      }
    } catch {
      message.error("Error fetching data");
    } finally {
      setLoading(false);
    }
  };

  // 🔥 INITIAL LOAD
  useEffect(() => {
    fetchData().then(() => {
      setInitialFetchDone(true);
    });
  }, []);

  // 🔄 LOAD FROM CONTEXT - After initial fetch completes, restore selections (for edit mode)
  useEffect(() => {
    if (!initialFetchDone || contextRestored) return;

    const facilityData = dataFromContext?.['Facility Equipment'];
    if (!facilityData) return;

    // Only restore if we have the facilities in our facilityMap
    const hasFacilitiesInMap = facilityData.selectedFacilities?.some(
      (id: Key) => facilityMap[String(id)]
    );

    if (!hasFacilitiesInMap && facilityData.selectedFacilities?.length > 0) {
      // Facility map not yet populated - retry later when data finishes loading
      return;
    }

    // Derive facility IDs from selectedFacilities or fallback to selectedEquipment keys
    let facilityIds: Key[] = [];
    if (facilityData.selectedFacilities && facilityData.selectedFacilities.length > 0) {
      facilityIds = facilityData.selectedFacilities;
    } else if (facilityData.selectedEquipment && Object.keys(facilityData.selectedEquipment).length > 0) {
      // Fallback: use equipment keys as facility IDs
      facilityIds = Object.keys(facilityData.selectedEquipment);
    }

    if (facilityIds.length > 0) {
      setSelectedFacilities(facilityIds);
    }

    if (facilityData.selectedEquipment && Object.keys(facilityData.selectedEquipment).length > 0) {
      setSelectedEquipment(facilityData.selectedEquipment);
    }

    setContextRestored(true);
  }, [initialFetchDone, facilityMap, dataFromContext, contextRestored]);

  // 🔍 SEARCH
  const handleSearch = (value: string) => {
    setSearchText(value);
    fetchData({ ...pagination, current: 1 }, filters, value);
  };

  // 🔄 RESET
  const handleReset = () => {
    setSearchText("");
    setFilters({
      status: null,
      cleanRoomGrade: null,
      department: null,
      blockBuilding: null,
      areaType: null
    });

    fetchData({ current: 1, pageSize: 10, total: 0 });
  };

  // 📊 TABLE CHANGE
  const handleTableChange = (pag: any) => {
    fetchData({
      current: pag.current,
      pageSize: pag.pageSize,
      total: pagination.total
    });
  };

  // 🔥 FINAL SELECTED DATA - Save to context
  const handleNext = () => {
    const result = selectedFacilities.map((id) => {
      const facility = facilityMap[String(id)];

      return {
        facilityId: id,
        facilityCode: facility?.facilityCode,
        areaName: facility?.areaName,

        equipments: (facility?.equipment || [])
          .filter((eq: any) =>
            (selectedEquipment[String(id)] || []).includes(eq.equipmentCode)
          )
      };
    });

    // Save to context
    const facilityData = {
      selectedEquipment: selectedEquipment,
      selectedFacilities: selectedFacilities,
      facilitiesWithEquipment: result,
      totalFacilities: selectedFacilities.length,
      totalEquipment: totalSelectedEquipment
    };

    // Update context
    setTemplateData((prev: any) => ({
      ...prev,
      ['Facility Equipment']: facilityData
    }));

    message.success(`Saved ${selectedFacilities.length} facilities and ${totalSelectedEquipment} equipment to template`);
    onNext();
  };

  const handlePrevious = () => {
    if (onPrevious) {
      onPrevious();
    }
  };

  // 📊 COLUMNS
  const columns = [
    { title: "Code", dataIndex: "facilityCode" },
    { title: "Name", dataIndex: "areaName" },
    { title: "Department", dataIndex: "department" },
    {
      title: "Status",
      dataIndex: "status",
      render: (text: string) => (
        <Tag color={text === "Active" ? "green" : "default"}>
          {text}
        </Tag>
      )
    }
  ];

  return (
    <Card title="Facility & Equipment">

      {/* 🔍 SEARCH */}
      <div className="flex gap-3 mb-4">
        <Search
          placeholder="Search..."
          allowClear
          enterButton={<SearchOutlined />}
          onSearch={handleSearch}
          style={{ width: 250 }}
        />

        <Button icon={<ReloadOutlined />} onClick={handleReset}>
          Reset
        </Button>
      </div>

      {/* 📊 STATS ROW - Only show when facilities selected */}
      {selectedFacilities.length > 0 && (
        <div style={{ marginBottom: 16 }}>
          <Row gutter={16}>
            <Col span={8}>
              <Card size="small">
                <Statistic
                  title="Facilities Selected"
                  value={selectedFacilities.length}
                  prefix="🏭"
                  valueStyle={{ color: '#1890ff' }}
                />
              </Card>
            </Col>
            <Col span={8}>
              <Card size="small">
                <Statistic
                  title="Equipment Selected"
                  value={totalSelectedEquipment}
                  prefix="⚙️"
                  valueStyle={{ color: '#52c41a' }}
                />
              </Card>
            </Col>
            <Col span={8}>
              <Card size="small">
                <Button
                  type="primary"
                  icon={<EyeOutlined />}
                  onClick={() => setDrawerOpen(true)}
                  block
                >
                  View Details
                </Button>
              </Card>
            </Col>
          </Row>
        </div>
      )}

      {/* 📋 DRAWER - Full Details */}
      <Drawer
        title="Selected Facilities & Equipment"
        placement="right"
        width={500}
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
      >
        {selectedFacilities.length === 0 ? (
          <Empty description="No facilities selected" />
        ) : (
          selectedFacilities.map((facilityId) => {
            const facility = facilityMap[String(facilityId)];
            const selectedEqCodes = selectedEquipment[String(facilityId)] || [];
            const selectedEqList = (facility?.equipment || []).filter(
              (eq: any) => selectedEqCodes.includes(eq.equipmentCode)
            );

            return (
              <Card
                key={facilityId}
                size="small"
                style={{ marginBottom: 12 }}
                title={
                  <Tag color="blue" style={{ margin: 0 }}>
                    {facility?.facilityCode} - {facility?.areaName}
                  </Tag>
                }
              >
                {selectedEqList.length > 0 ? (
                  <List
                    size="small"
                    dataSource={selectedEqList}
                    renderItem={(eq: any) => (
                      <List.Item>
                        <Tag color="green">
                          ⚙️ {eq.equipmentCode} - {eq.equipmentName}
                        </Tag>
                      </List.Item>
                    )}
                  />
                ) : (
                  <Typography.Text type="secondary">
                    No equipment selected
                  </Typography.Text>
                )}
              </Card>
            );
          })
        )}
      </Drawer>

      {/* 📋 TABLE */}
      <Table
        rowKey="_id"
        dataSource={data}
        columns={columns}
        loading={loading}

        rowSelection={{
          selectedRowKeys: selectedFacilities,
          preserveSelectedRowKeys: true,
          onChange: (keys) => setSelectedFacilities(keys)
        }}

        expandable={{
          expandedRowRender: (record) => {
            const fid = record._id;

            return (
              <Checkbox.Group
                options={(record.equipment || []).map((eq: any) => ({
                  label: `${eq.equipmentCode} - ${eq.equipmentName}`,
                  value: eq.equipmentCode
                }))}
                value={selectedEquipment[fid] || []}
                onChange={(vals) => handleEquipmentChange(fid, vals)}
                style={{ display: 'flex', flexDirection: 'column', gap: 6, paddingLeft: 80 }}
              />
            );
          }
        }}

        pagination={{
          ...pagination,
          showSizeChanger: true
        }}

        onChange={handleTableChange}

        locale={{
          emptyText: <Empty description="No data" />
        }}
        size="small"
        scroll={{ y: 300 }}
      />
      <div className="flex justify-end gap-2 pt-4 border-t border-gray-800">
        <Button
          icon={<ArrowLeftOutlined />}
          onClick={handlePrevious}
        >
          Previous
        </Button>
        <Button
          type="primary"
          onClick={handleNext}
        >
         Next <ArrowRightOutlined  />
        </Button>
      </div>
    </Card>
  );
}