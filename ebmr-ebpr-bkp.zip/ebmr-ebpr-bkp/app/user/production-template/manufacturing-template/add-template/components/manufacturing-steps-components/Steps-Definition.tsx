'use client'

import { DataContext } from "@/lib/utils/DataContext"
import {
  ArrowRightOutlined,
  DeleteOutlined,
  PlusOutlined,
  SaveOutlined
} from "@ant-design/icons"
import { Button, Card, Col, Empty, Form, Input, InputNumber, message, Row, Select, Space, Tabs, Tag, Typography } from "antd"
import TextArea from "antd/es/input/TextArea"
import { useContext, useEffect, useMemo, useState } from "react"

const { Text } = Typography

type Material = {
  materialName: string
  uom: string
  splitType: 'split' | 'single'
  lots: number
}

type LotStructure = Record<string, Record<string, Material>>

type MaterialAssignment = {
  materialCode: string
  quantity: number
}

type CppValue = {
  parameterName: string
  value: number
  minValue: number
  maxValue: number
  unit?: string
}

type StepRow = {
  id: string
  stepName: string
  stepDescription: string
  machineCode?: number
  machineName?: string
  materials: MaterialAssignment[]
  cppValues: CppValue[]
}

const createId = () => `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`

const getLotLabel = (lotKey: string) => {
  if (lotKey === 'final-lot') return 'Final Lot'
  return lotKey.replace('-', ' ').replace(/\b\w/g, (letter) => letter.toUpperCase())
}

export default function StepsDefinition({ onPreview, layer }: any) {
  const { templateData, setTemplateData } = useContext(DataContext)
  const [form] = Form.useForm()
  const selectedMachineCode = Form.useWatch('machine', form)
  const selectedMaterialCode = Form.useWatch('materialCode', form)

  const lotConfig = templateData?.['Manufacturing Lot Configuration']?.layers?.[layer]
  const numberOfLots = Number(lotConfig?.numberOfLots || 0)
  const machinesData = templateData?.['Facility Equipment']?.facilitiesWithEquipment || []

  const lotKeys = useMemo(() => {
    if (!numberOfLots) return []

    const keys = Array.from({ length: numberOfLots }, (_, index) => `lot-${index + 1}`)
    const hasFinalLotMaterials = Object.values(lotConfig?.materials || {}).some((material: any) => material.splitType === 'single')
    return numberOfLots > 1 && hasFinalLotMaterials ? [...keys, 'final-lot'] : keys
  }, [lotConfig?.materials, numberOfLots])

  const [activeLotKey, setActiveLotKey] = useState('lot-1')
  const [lotMaterials, setLotMaterials] = useState<LotStructure>({})
  const [lotSteps, setLotSteps] = useState<Record<string, StepRow[]>>({})
  const [draftMaterials, setDraftMaterials] = useState<Record<string, MaterialAssignment[]>>({})
  const [savedLots, setSavedLots] = useState<Record<string, boolean>>({})

  const machineList = useMemo(() => {
    const formattedData: any[] = []

    machinesData.forEach((facility: any) => {
      facility.equipments?.forEach((equipment: any) => {
        formattedData.push({
          machineName: equipment.equipmentName,
          machineCode: equipment.equipmentCode,
          assetTag: equipment.assetTag || 'N/A',
          areaName: facility.areaName || 'N/A',
          facilityCode: facility.facilityCode || 'N/A',
          cppParameters: equipment.cppParameters?.map((param: any) => ({
            parameterName: param.parameterName,
            minValue: param.minValue,
            maxValue: param.maxValue,
            unit: param.unit || 'Not Specified',
            range: `${param.minValue} - ${param.maxValue} ${param.unit || ''}`
          })) || []
        })
      })
    })

    return formattedData
  }, [machinesData])

  const activeMachine = machineList.find((machine) => machine.machineCode === selectedMachineCode)
  const activeDraftMaterials = draftMaterials[activeLotKey] || []
  const activeMaterials = lotMaterials[activeLotKey] || {}

  const getStepConsumedQuantity = (lotKey: string, materialCode: string) => {
    return (lotSteps[lotKey] || []).reduce((total, step) => {
      const stepMaterial = step.materials.find((material) => material.materialCode === materialCode)
      return total + Number(stepMaterial?.quantity || 0)
    }, 0)
  }

  const getConsumedQuantity = (lotKey: string, materialCode: string) => {
    const draftMaterial = (draftMaterials[lotKey] || []).find((material) => material.materialCode === materialCode)

    return getStepConsumedQuantity(lotKey, materialCode) + Number(draftMaterial?.quantity || 0)
  }

  const getRemainingQuantity = (lotKey: string, materialCode: string) => {
    const totalQuantity = Number(lotMaterials[lotKey]?.[materialCode]?.lots || 0)
    return Math.max(totalQuantity - getConsumedQuantity(lotKey, materialCode), 0)
  }

  const getStepRemainingQuantity = (lotKey: string, materialCode: string) => {
    const totalQuantity = Number(lotMaterials[lotKey]?.[materialCode]?.lots || 0)
    return Math.max(totalQuantity - getStepConsumedQuantity(lotKey, materialCode), 0)
  }

  const isLotFullyConsumed = (lotKey: string) => {
    const materials = lotMaterials[lotKey] || {}
    const materialCodes = Object.keys(materials)

    return (
      materialCodes.length > 0 &&
      (lotSteps[lotKey] || []).length > 0 &&
      materialCodes.every((materialCode) => getStepRemainingQuantity(lotKey, materialCode) === 0)
    )
  }

  const isAllLotsReadyForPreview = lotKeys.length > 0 && lotKeys.every((lotKey) => savedLots[lotKey] && isLotFullyConsumed(lotKey))

  useEffect(() => {
    if (!lotConfig) return

    const result: LotStructure = {}
    lotKeys.forEach((lotKey) => {
      result[lotKey] = {}
    })

    Object.entries(lotConfig.materials || {}).forEach(([materialCode, materialData]: [string, any]) => {
      if (materialData.splitType === 'split') {
        materialData.lots?.forEach((lotValue: number, index: number) => {
          const lotKey = `lot-${index + 1}`
          result[lotKey] = {
            ...result[lotKey],
            [materialCode]: {
              ...materialData,
              lots: Number(lotValue || 0)
            }
          }
        })
        return
      }

      const targetLotKey = numberOfLots === 1 ? 'lot-1' : 'final-lot'
      result[targetLotKey] = {
        ...result[targetLotKey],
        [materialCode]: {
          ...materialData,
          lots: Number(materialData.lots?.[0] || 0)
        }
      }
    })

    const savedLayerSteps = templateData?.['Manufacturing Steps']?.layers?.[layer]?.lots || {}
    const nextLotSteps = lotKeys.reduce<Record<string, StepRow[]>>((acc, lotKey) => {
      acc[lotKey] = savedLayerSteps[lotKey]?.steps || []
      return acc
    }, {})

    const nextSavedLots = lotKeys.reduce<Record<string, boolean>>((acc, lotKey) => {
      acc[lotKey] = Boolean(savedLayerSteps[lotKey]?.steps?.length)
      return acc
    }, {})

    setLotMaterials(result)
    setLotSteps(nextLotSteps)
    setDraftMaterials({})
    setSavedLots(nextSavedLots)
    setActiveLotKey(lotKeys[0] || 'lot-1')
    form.resetFields()
  }, [form, layer, lotConfig, lotKeys, numberOfLots, templateData])

  const handleAddMaterialToDraft = () => {
    const materialCode = form.getFieldValue('materialCode')
    const quantity = Number(form.getFieldValue('materialQuantity'))

    if (!materialCode) {
      message.warning('Please select a material first')
      return
    }

    if (!Number.isFinite(quantity) || quantity <= 0) {
      message.warning('Please enter a valid material quantity')
      return
    }

    const selectedMaterial = activeMaterials[materialCode]
    if (!selectedMaterial) {
      message.error('Selected material is not available in this lot')
      return
    }

    const currentDraftMaterials = draftMaterials[activeLotKey] || []
    const existingDraftMaterial = currentDraftMaterials.find((material) => material.materialCode === materialCode)
    const consumedWithoutCurrentDraft = getConsumedQuantity(activeLotKey, materialCode) - Number(existingDraftMaterial?.quantity || 0)
    const availableForDraft = Number(selectedMaterial.lots || 0) - consumedWithoutCurrentDraft

    if (quantity > availableForDraft) {
      message.error(`Quantity cannot exceed remaining ${availableForDraft} ${selectedMaterial.uom}`)
      return
    }

    setDraftMaterials((prev) => {
      const existingIndex = currentDraftMaterials.findIndex((material) => material.materialCode === materialCode)
      const nextMaterials =
        existingIndex >= 0
          ? currentDraftMaterials.map((material, index) =>
            index === existingIndex ? { materialCode, quantity } : material
          )
          : [...currentDraftMaterials, { materialCode, quantity }]

      return {
        ...prev,
        [activeLotKey]: nextMaterials
      }
    })

    form.setFieldsValue({ materialCode: undefined, materialQuantity: undefined })
  }

  const handleRemoveDraftMaterial = (materialCode: string) => {
    setDraftMaterials((prev) => ({
      ...prev,
      [activeLotKey]: (prev[activeLotKey] || []).filter((material) => material.materialCode !== materialCode)
    }))
  }

  const handleAddStep = async () => {
    const values = await form.validateFields()

    if (!activeDraftMaterials.length) {
      message.warning('Please assign at least one material to this step')
      return
    }

    const selectedMachine = machineList.find((machine) => machine.machineCode === values.machine)
    const cppValues = selectedMachine?.cppParameters?.map((param: any) => ({
      parameterName: param.parameterName,
      value: Number(form.getFieldValue(`cpp_${param.parameterName}`) || 0),
      minValue: param.minValue,
      maxValue: param.maxValue,
      unit: param.unit
    })) || []

    const nextStep: StepRow = {
      id: createId(),
      stepName: values.stepName,
      stepDescription: values.stepDescription || '',
      machineCode: values.machine,
      machineName: selectedMachine?.machineName,
      materials: activeDraftMaterials,
      cppValues
    }

    setLotSteps((prev) => ({
      ...prev,
      [activeLotKey]: [...(prev[activeLotKey] || []), nextStep]
    }))

    setDraftMaterials((prev) => ({
      ...prev,
      [activeLotKey]: []
    }))

    setSavedLots((prev) => ({
      ...prev,
      [activeLotKey]: false
    }))

    form.resetFields()
    message.success('Step added')
  }

  const handleRemoveStep = (stepId: string) => {
    setLotSteps((prev) => ({
      ...prev,
      [activeLotKey]: (prev[activeLotKey] || []).filter((step) => step.id !== stepId)
    }))

    setSavedLots((prev) => ({
      ...prev,
      [activeLotKey]: false
    }))
  }

  const saveStepsToTemplate = (nextSavedLots: Record<string, boolean>) => {
    setTemplateData((prev: any) => ({
      ...prev,
      ['Manufacturing Steps']: {
        ...prev?.['Manufacturing Steps'],
        layers: {
          ...prev?.['Manufacturing Steps']?.layers,
          [layer]: {
            numberOfLots,
            lots: lotKeys.reduce<Record<string, { steps: StepRow[] }>>((acc, lotKey) => {
              acc[lotKey] = {
                steps: lotSteps[lotKey] || []
              }
              return acc
            }, {})
          }
        }
      }
    }))

    setSavedLots(nextSavedLots)
  }

  const handleSaveLot = () => {
    if (!isLotFullyConsumed(activeLotKey)) {
      message.error(`${getLotLabel(activeLotKey)} can be saved only after all material quantity is consumed`)
      return
    }

    const nextSavedLots = {
      ...savedLots,
      [activeLotKey]: true
    }

    saveStepsToTemplate(nextSavedLots)
    message.success(`${getLotLabel(activeLotKey)} saved`)
  }

  const handlePreview = () => {
    if (!isAllLotsReadyForPreview) {
      message.error('Please save every lot after fully consuming its materials')
      return
    }

    onPreview()
  }

  if (!layer || !lotConfig) {
    return (
      <Card>
        <Empty description="Please save lot configuration first" image={Empty.PRESENTED_IMAGE_SIMPLE} />
      </Card>
    )
  }

  const items = lotKeys.map((lotKey) => ({
    key: lotKey,
    label: getLotLabel(lotKey),
    children: (
      <Space direction="vertical" size={16} style={{ width: '100%' }}>
        <Card size="small">
          <Space wrap>
            {Object.entries(lotMaterials[lotKey] || {}).map(([materialCode, material]) => {
              const remainingQuantity = getRemainingQuantity(lotKey, materialCode)
              return (
                <Tag key={materialCode} color={remainingQuantity === 0 ? 'green' : 'orange'}>
                  {material.materialName}: {remainingQuantity}/{material.lots} {material.uom} remaining
                </Tag>
              )
            })}
          </Space>
        </Card>

        <Card size="small" title={`Define Step - ${getLotLabel(lotKey)}`}>
          <Form layout="vertical" form={form}>
            <Row gutter={[16, 16]}>
              <Col xs={24} md={12}>
                <Form.Item
                  label="Step Name"
                  name="stepName"
                  rules={[{ required: true, message: 'Please input the step name' }]}
                >
                  <Input placeholder="Enter step name" />
                </Form.Item>
              </Col>

              <Col xs={24} md={12}>
                <Form.Item
                  label="Machine"
                  name="machine"
                  rules={[{ required: true, message: 'Please select a machine' }]}
                >
                  <Select
                    placeholder="Select a machine"
                    options={machineList.map((machine) => ({
                      label: `${machine.machineName} - ${machine.machineCode}`,
                      value: machine.machineCode
                    }))}
                  />
                </Form.Item>
              </Col>

              <Col xs={24}>
                <Form.Item label="Description" name="stepDescription">
                  <TextArea placeholder="Enter step description" rows={3} />
                </Form.Item>
              </Col>

              {activeMachine?.cppParameters?.map((param: any) => (
                <Col xs={24} md={6} key={param.parameterName}>
                  <Form.Item
                    label={`${param.parameterName} (${param.unit})`}
                    name={`cpp_${param.parameterName}`}
                    rules={[{ required: true, message: `Please input value for ${param.parameterName}` }]}
                  >
                    <InputNumber
                      min={param.minValue}
                      max={param.maxValue}
                      placeholder={param.range}
                      style={{ width: '100%' }}
                    />
                  </Form.Item>
                </Col>
              ))}
            </Row>
            <Row gutter={[16,16]}>
              <Col xs={24} md={12}>
                <Form.Item label="Material" name="materialCode">
                  <Select
                    placeholder="Select material for this step"
                    options={Object.entries(activeMaterials).map(([materialCode, material]) => ({
                      label: `${material.materialName} - ${materialCode} (${getRemainingQuantity(lotKey, materialCode)} ${material.uom} remaining)`,
                      value: materialCode,
                      disabled: getRemainingQuantity(lotKey, materialCode) === 0
                    }))}
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={8}>
                <Form.Item label="Quantity" name="materialQuantity">
                  <InputNumber
                    min={1}
                    placeholder="Enter quantity"
                    style={{ width: '100%' }}
                    addonAfter={activeMaterials[selectedMaterialCode]?.uom}
                  />
                </Form.Item>
              </Col>

              <Col xs={24} md={4}>
                <Form.Item label=" ">
                  <Button block icon={<PlusOutlined />} onClick={handleAddMaterialToDraft}>
                    Add
                  </Button>
                </Form.Item>
              </Col>
            </Row>

            {activeDraftMaterials.length > 0 ? (
              <Space wrap style={{ marginBottom: 16 }}>
                {activeDraftMaterials.map((material) => (
                  <Tag
                    key={material.materialCode}
                    color="blue"
                    closable
                    onClose={() => handleRemoveDraftMaterial(material.materialCode)}
                  >
                    {activeMaterials[material.materialCode]?.materialName || material.materialCode}: {material.quantity} {activeMaterials[material.materialCode]?.uom}
                  </Tag>
                ))}
              </Space>
            ) : null}

            <div className="flex justify-end">
              <Button type="primary" icon={<PlusOutlined />} onClick={handleAddStep}>
                Add Step
              </Button>
            </div>
          </Form>
        </Card>

        <Card
          size="small"
          title={`${getLotLabel(lotKey)} Steps`}
          extra={<Tag color={isLotFullyConsumed(lotKey) ? 'green' : 'orange'}>{isLotFullyConsumed(lotKey) ? 'Ready to Save' : 'Pending Consumption'}</Tag>}
        >
          {(lotSteps[lotKey] || []).length ? (
            <Space direction="vertical" size={12} style={{ width: '100%' }}>
              {(lotSteps[lotKey] || []).map((step, index) => (
                <Card
                  key={step.id}
                  size="small"
                  title={
                    <Space wrap>
                      <Tag color="blue">Step {index + 1}</Tag>
                      <Text strong>{step.stepName}</Text>
                      {step.machineName ? <Tag color="purple">{step.machineName}</Tag> : null}
                    </Space>
                  }
                  extra={<Button danger type="text" icon={<DeleteOutlined />} onClick={() => handleRemoveStep(step.id)} />}
                >
                  {step.stepDescription ? <Text type="secondary">{step.stepDescription}</Text> : null}
                  <div style={{ marginTop: 12 }}>
                    <Space wrap>
                      {step.materials.map((material) => (
                        <Tag key={`${step.id}_${material.materialCode}`} color="green">
                          {activeMaterials[material.materialCode]?.materialName || material.materialCode}: {material.quantity} {activeMaterials[material.materialCode]?.uom}
                        </Tag>
                      ))}
                      {step.cppValues.map((cpp) => (
                        <Tag key={`${step.id}_${cpp.parameterName}`} color="geekblue">
                          {cpp.parameterName}: {cpp.value} {cpp.unit}
                        </Tag>
                      ))}
                    </Space>
                  </div>
                </Card>
              ))}
            </Space>
          ) : (
            <Empty description="No steps added for this lot" image={Empty.PRESENTED_IMAGE_SIMPLE} />
          )}
        </Card>

        <div className="flex justify-end gap-2">
          <Button icon={<SaveOutlined />} onClick={handleSaveLot} disabled={!isLotFullyConsumed(lotKey)}>
            Save {getLotLabel(lotKey)}
          </Button>
          <Button type="primary" icon={<ArrowRightOutlined />} onClick={handlePreview} disabled={!isAllLotsReadyForPreview}>
            Proceed to Preview
          </Button>
        </div>
      </Space>
    )
  }))

  return (
    <Card title="Steps Definition" style={{ marginBottom: 20 }}>
      <Tabs
        activeKey={activeLotKey}
        onChange={(key) => {
          setActiveLotKey(key)
          form.resetFields()
        }}
        items={items}
      />
    </Card>
  )
}
