'use client'

import { useContext, useEffect } from 'react'
import { DataContext } from "@/lib/utils/DataContext"
import { Badge, Button, Card, Empty, Space, Tag, Typography } from "antd"
import { AppstoreOutlined, SettingOutlined } from "@ant-design/icons"

const { Text } = Typography

interface MaterialConsumption {
  materialCode: string
  quantity: number
}

interface StepRow {
  id: string
  stepName: string
  stepDescription: string
  machineCode?: string
  machineName?: string
  materials: MaterialConsumption[]
}

interface StepsPreviewProps {
  onBackToConfig?: () => void
  onBackToSteps?: () => void
}

export default function StepsPreview({ onBackToConfig, onBackToSteps }: StepsPreviewProps) {
  const { templateData } = useContext(DataContext)

  const stepLayers = templateData?.["Manufacturing Steps"]?.layers || {}
  const lotLayers = templateData?.["Manufacturing Lot Configuration"]?.layers || {}
  const layerNames = Object.keys(stepLayers)

  useEffect(() => {
    console.log("Step Layers:", stepLayers)
    console.log("Lot Layers:", lotLayers)
    console.log("Template Data:", templateData) 
  }, [])

  if (!layerNames.length) {
    return (
      <Card>
        <Empty description="No steps defined yet" image={Empty.PRESENTED_IMAGE_SIMPLE} />
        <div style={{ marginTop: 16, textAlign: 'center' }}>
          <Space>
            <Button icon={<SettingOutlined />} onClick={onBackToConfig}>
              Go to Lot Configuration
            </Button>
            <Button type="primary" icon={<AppstoreOutlined />} onClick={onBackToSteps}>
              Go to Steps Definition
            </Button>
          </Space>
        </div>
      </Card>
    )
  }

  return (
    <div>
      {layerNames.map((layerName) => {
        const layerData = stepLayers[layerName]
        const lotKeys = Object.keys(layerData?.lots || {})
        const layerMaterials = lotLayers?.[layerName]?.materials || {}

        return (
          <Card key={layerName} title={layerName} size="small" style={{ marginBottom: 16 }}>
            {lotKeys.map((lotKey) => (
              <Card
                key={`${layerName}_${lotKey}`}
                size="small"
                title={
                  <div className="flex items-center gap-2">
                    <Badge count={lotKey.replace('_', ' ').toUpperCase()} />
                    <Text>{layerData?.lots?.[lotKey]?.steps?.length || 0} Steps</Text>
                  </div>
                }
                style={{ marginBottom: 12 }}
              >
                <div className="flex flex-col gap-3">
                  {(layerData?.lots?.[lotKey]?.steps || []).map((step: StepRow, index: number) => (
                    <Card key={step.id} size="small">
                      <div className="flex flex-col gap-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <Tag color="blue">Step {index + 1}</Tag>
                          <Text strong>{step.stepName || "Unnamed Step"}</Text>
                          {step.machineName ? <Tag color="orange">{step.machineName}</Tag> : null}
                        </div>
                        {step.stepDescription ? (
                          <Text type="secondary">{step.stepDescription}</Text>
                        ) : null}
                        <div className="flex flex-wrap gap-2">
                          {step.materials.map((material) => (
                            <Tag key={`${step.id}_${material.materialCode}`} color="green">
                              {material.materialCode} - {layerMaterials?.[material.materialCode]?.materialName || "Material"}: {material.quantity} {layerMaterials?.[material.materialCode]?.uom || ""}
                            </Tag>
                          ))}
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </Card>
            ))}
          </Card>
        )
      })}
    </div>
  )
}
