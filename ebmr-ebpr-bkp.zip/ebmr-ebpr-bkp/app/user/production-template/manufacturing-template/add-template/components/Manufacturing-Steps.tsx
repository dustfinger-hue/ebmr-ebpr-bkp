'use client'

import { Card, Space, Button, Descriptions, InputNumber, Badge, Tag, Radio, Typography, Table, message, Select } from "antd"
import {
  PlusOutlined, DeleteOutlined, ArrowLeftOutlined, ArrowRightOutlined,
  InfoCircleOutlined, FileTextOutlined, SettingOutlined, AppstoreOutlined
} from "@ant-design/icons";
import { use, useContext, useEffect, useState } from "react";
import { DataContext } from "@/lib/utils/DataContext";
import _ from "lodash";
import ConfigPage from "./manufacturing-steps-components/Config-Page";
import StepsDefinition from "./manufacturing-steps-components/Steps-Definition";
import StepsPreview from "./manufacturing-steps-components/Steps-Preview";
const { Text } = Typography;

interface ManufacturingStepsProps {
  onNext: () => void
  onPrevious: () => void
}
export default function ManufacturingSteps({ onNext, onPrevious }: ManufacturingStepsProps) {
  const { templateData, setTemplateData } = useContext(DataContext);
  const [currentPhase, setCurrentPhase] = useState<'config' | 'steps' | 'preview'>('config');
  const [layer, setLayer] = useState<string>('');

  const handleNext = () => {
    // message.success('');
    onNext();
  }
  const handlePrevious = () => {
    if (onPrevious) {
      onPrevious();
    }
  };


  const tabletType = templateData?.['Basic Information']?.tabletType;
  const isBilayer =
    tabletType?.includes('Bilayer') ||
    tabletType?.includes('Tablet in Tablet');
  const dosageForm = templateData?.['Basic Information']?.dosageForm;

  // On mount, restore layer from saved steps data (for edit mode)
  useEffect(() => {
    const savedStepsLayers = templateData?.['Manufacturing Steps']?.layers;
    if (savedStepsLayers && Object.keys(savedStepsLayers).length > 0) {
      // Restore the first saved layer
      const savedLayer = Object.keys(savedStepsLayers)[0];
      setLayer(savedLayer);
    } else {
      // No saved data — start empty so user selects
      setLayer('');
    }
  }, []);

  const options = [
    ...(
      isBilayer ? [
        { value: 'Granulation Layer-1', label: 'Granulation Layer-1' },
        { value: 'Granulation Layer-2', label: 'Granulation Layer-2' },
      ] :
        dosageForm === 'Capsule' ? [
          { value: 'Granulation', label: 'Granulation' },
          { value: 'Pellet Form', label: 'Pellet Form' },
        ] :
          ['Syrup', 'Liquid Suspension', 'Solution', 'Drop', 'Ointment', 'Cream', 'Gel', 'Lotion'].includes(dosageForm) ? [
            { value: 'Formulation', label: 'Formulation' },
          ] :
            ['Dry Powder Suspension', 'Powder'].includes(dosageForm) ? [
              { value: 'Granulation', label: 'Granulation' },
            ] :
              [
                { value: 'Granulation Single Layer', label: 'Granulation Single Layer' },
              ]),
  ];


  return (
    <>
      {/* Phase Navigation */}
      <Card size="small" style={{ marginBottom: 16 }}>
        <div className="flex flex-row justify-between items-center">
          <Space size="small">
            <Button
              type={currentPhase === 'config' ? 'primary' : 'default'}
              onClick={() => setCurrentPhase('config')}
              icon={<SettingOutlined />}
            >
              1. Lot Configuration
            </Button>
            <Button
              type={currentPhase === 'steps' ? 'primary' : 'default'}
              onClick={() => {
                // if (validateLotConfig()) 
                setCurrentPhase('steps');
              }}
              icon={<AppstoreOutlined />}
            >
              2. Steps Definition
            </Button>
            <Button
              type={currentPhase === 'preview' ? 'primary' : 'default'}
              onClick={() => setCurrentPhase('preview')}
              icon={<FileTextOutlined />}
            >
              3. Preview
            </Button>
          </Space>

          <Space size="small">
            {!layer && options.length > 0 && (
              <Tag color="warning" style={{ marginRight: 4 }}>
                ⚠️ Please select a layer to configure
              </Tag>
            )}
            <Select
              style={{ width: 220 }}
              placeholder="-- Select Layer --"
              value={layer || undefined}
              options={options}
              onChange={(value) => setLayer(value)}
            />
          </Space>

        </div>
      </Card>
      {/* Phase Content */}

      {currentPhase === 'config' && (
        <ConfigPage layer={layer} currentPhase={currentPhase} toStepsDefinition={() => setCurrentPhase('steps')} />
      )}
      {currentPhase === 'steps' && (
        <StepsDefinition layer={layer} onPreview={() => setCurrentPhase('preview')} />
      )}
      {currentPhase === 'preview' && (
        <StepsPreview
          onBackToConfig={() => setCurrentPhase('config')}
          onBackToSteps={() => setCurrentPhase('steps')}
        />
      )}
      {currentPhase === 'preview' && (

        <div className="flex justify-end gap-2 pt-4 border-t border-gray-800">
          <Button
            icon={<ArrowLeftOutlined />}
            onClick={handlePrevious}
          >
            Previous
          </Button>
          <Button
            type="primary"
            onClick={handleNext}
          >
            Next <ArrowRightOutlined />
          </Button>
        </div>
      )}
    </>
  )
}
