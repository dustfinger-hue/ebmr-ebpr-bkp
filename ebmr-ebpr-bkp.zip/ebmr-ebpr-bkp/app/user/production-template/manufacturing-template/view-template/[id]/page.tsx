'use client'

import { Spin, message } from "antd"
import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import ViewTemplate from "../components/View-Template"

export default function ViewTemplatePage() {
    const params = useParams()
    const id = params?.id as string
    const [document, setDocument] = useState<any>(null)
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        if (!id) return

        const fetchDocument = async () => {
            setLoading(true)
            try {
                const token = localStorage.getItem('token')
                const res = await fetch(`/api/user/production-template/manufacturing-template?id=${id}`, {
                    method: 'GET',
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                })
                const data = await res.json()

                if (data.success && data.data) {
                    setDocument(data.data)
                } else {
                    message.error(data.message || 'Document not found')
                }
            } catch (error) {
                console.error('Error fetching document:', error)
                message.error('Failed to fetch document')
            } finally {
                setLoading(false)
            }
        }

        fetchDocument()
    }, [id])

    if (loading) {
        return (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 400 }}>
                <Spin size="large" tip="Loading template..." />
            </div>
        )
    }

    if (!document) {
        return (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: 400 }}>
                <p>Document not found</p>
            </div>
        )
    }

    return <ViewTemplate document={document} />
}