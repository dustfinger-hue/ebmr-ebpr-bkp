'use client'
import { Modal, Spin, Typography, Row, Col, Table, Button, message, Tag, Space, Tooltip, Empty } from "antd";
const { Title, Text } = Typography;
import { EyeOutlined, CheckCircleOutlined, InfoCircleOutlined, CloseOutlined, EditTwoTone, EyeTwoTone, DeleteTwoTone } from "@ant-design/icons";
import { useEffect, useState } from "react";
import dayjs from "dayjs";
import { useRouter } from "next/navigation";
import { useAuthorization } from "@/hooks/useAuthorization";
import StatusModal from "../../edit-template/[id]/components/Status-Modal";

interface ProductGroup {
    productCode: string;
    productName: string;
    dosageForm: string;
}

interface TemplateRecord {
    _id: string;
    templateCode: string;
    templateName: string;
    productCode: string;
    productName: string;
    dosageForm: string;
    status: string;
    templateVersion: string;
    createdAt: string;
}

interface ViewProductTemplatesModalProps {
    open: boolean;
    onClose: () => void;
    onSuccess?: () => void;
    productGroup: ProductGroup | null;
}

const statusColorMap: Record<string, string> = {
    'Pending Signatures': 'orange',
    'Active': 'green',
    'Inactive': 'default',
    'Draft': 'default',
    'Superseded': 'red',
    'Rejected': 'red',
    'Reverted': 'orange',
};

export default function ViewProductTemplatesModal({ open, onClose, onSuccess, productGroup }: ViewProductTemplatesModalProps) {
    const [loading, setLoading] = useState(false);
    const [templates, setTemplates] = useState<TemplateRecord[]>([]);
    const [statusModalVisible, setStatusModalVisible] = useState(false);
    const [recordForStatusChange, setRecordForStatusChange] = useState<string | null>(null);
    const router = useRouter();

    const { hasAccess } = useAuthorization();
    const isViewTemplateAuthorized = hasAccess('Batch Manufacturing Template', 'read');
    const isUpdateTemplateAuthorized = hasAccess('Batch Manufacturing Template', 'update');
    const isDeleteTemplateAuthorized = hasAccess('Batch Manufacturing Template', 'delete');

    useEffect(() => {
        if (!open || !productGroup) return;

        fetchTemplatesForProduct(productGroup.productCode);
    }, [open, productGroup]);

    useEffect(() => {
        if (!open) {
            setTemplates([]);
        }
    }, [open]);

    const fetchTemplatesForProduct = async (productCode: string) => {
        const token = localStorage.getItem('token');
        try {
            setLoading(true);
            const res = await fetch(`/api/user/production-template/manufacturing-template?productCode=${productCode}`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                }
            });
            const data = await res.json();
            if (data.success) {
                setTemplates(data.data || []);
            } else {
                message.error(data.message || 'Failed to fetch templates');
            }
        } catch (error) {
            console.error(error);
            message.error("Error fetching templates");
        } finally {
            setLoading(false);
        }
    };

    const formatDate = (date: string) => {
        return date ? dayjs(date).format('DD-MMM-YYYY') : '-';
    };

    const handleView = (id: string) => {
        router.push(`/user/production-template/manufacturing-template/view-template/${id}`);
    };

    const handleEdit = (id: string) => {
        router.push(`/user/production-template/manufacturing-template/edit-template/${id}`);
    };

    const getEditTooltip = (status: string) => {
        if (status === 'Reverted' || status === 'Draft') {
            return "Edit Template";
        }
        return `Editing not available for '${status}' documents. Only Reverted or Draft documents can be edited.`;
    };

    const canEdit = (status: string) => {
        return (status === 'Reverted' || status === 'Draft') && isUpdateTemplateAuthorized;
    };

    const templateColumns = [
        {
            title: 'S.No',
            width: 60,
            render: (_: any, __: any, index: number) => index + 1,
        },
        {
            title: 'Template Code',
            dataIndex: 'templateCode',
            key: 'templateCode',
            width: 130,
            render: (text: string) => (
                <Text copyable style={{ color: '#1677ff', fontWeight: 500 }}>
                    {text}
                </Text>
            ),
        },
        {
            title: 'Template Name',
            dataIndex: 'templateName',
            key: 'templateName',
            width: 200,
            ellipsis: true,
        },
        {
            title: 'Version',
            dataIndex: 'templateVersion',
            key: 'templateVersion',
            width: 80,
            align: 'center' as const,
        },
        {
            title: 'Status',
            dataIndex: 'status',
            key: 'status',
            width: 140,
            render: (text: string) => (
                <Tag color={statusColorMap[text] || 'default'}>{text}</Tag>
            ),
        },
        {
            title: 'Created At',
            dataIndex: 'createdAt',
            key: 'createdAt',
            width: 170,
            render: (text: string) => text ? formatDate(text) : '-',
        },
        {
            title: 'Actions',
            key: 'actions',
            width: 120,
            fixed: 'right' as const,
            render: (_: any, record: TemplateRecord) => (
                <Space size="small">
                    <Tooltip title={isViewTemplateAuthorized ? "View Template" : "Not authorized"}>
                        <Button
                            type="text"
                            size="small"
                            icon={<EyeTwoTone />}
                            onClick={() => handleView(record._id)}
                            disabled={!isViewTemplateAuthorized}
                        />
                    </Tooltip>
                    <Tooltip title={getEditTooltip(record.status)}>
                        <Button
                            type="text"
                            size="small"
                            icon={<EditTwoTone />}
                            onClick={() => handleEdit(record._id)}
                            disabled={!canEdit(record.status)}
                        />
                    </Tooltip>
                    <Tooltip title={isUpdateTemplateAuthorized ? "Edit Status" : "Not authorized"}>
                        <Button
                            type="text"
                            size="small"
                            danger
                            icon={<EditTwoTone twoToneColor="#ff4d4f" />}
                            disabled={!isUpdateTemplateAuthorized}
                            onClick={() => {
                                setStatusModalVisible(true);
                                setRecordForStatusChange(record._id);
                            }}
                        />
                    </Tooltip>
                </Space>
            ),
        },
    ];

    return (
        <>
            <StatusModal
                visible={statusModalVisible}
                onCancel={() => setStatusModalVisible(false)}
                onSuccess={() => {
                    if (productGroup?.productCode) {
                        fetchTemplatesForProduct(productGroup.productCode);
                    }
                    onSuccess?.();
                }}
                documentId={recordForStatusChange} />
            <Modal
                open={open}
                onCancel={onClose}
                footer={null}
                centered
                width={1000}
                destroyOnClose
                closable={false}
                styles={{
                    header: {
                        background: '#001529',
                        padding: '16px 24px',
                    },
                    body: { padding: 0 },
                }}
                title={
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                        <div style={{
                            width: 40,
                            height: 40,
                            borderRadius: 8,
                            background: 'linear-gradient(135deg, #1890ff 0%, #36cfc9 100%)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}>
                            <EyeOutlined style={{ fontSize: 20, color: '#fff' }} />
                        </div>
                        <div>
                            <Title level={5} style={{ marginBottom: 0, color: '#fff' }}>
                                Templates - {productGroup?.productName || 'Loading...'}
                            </Title>
                            <Text style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12 }}>
                                {productGroup?.productCode || ''} | {productGroup?.dosageForm || ''}
                            </Text>
                        </div>
                    </div>
                }
            >
                {loading ? (
                    <div style={{ textAlign: 'center', padding: '60px 0' }}>
                        <Spin size="large" />
                        <div style={{ marginTop: 16 }}>
                            <Text type="secondary">Loading templates...</Text>
                        </div>
                    </div>
                ) : (
                    <div>
                        {/* Product Info Quick Bar */}
                        {productGroup && (
                            <div style={{
                                padding: '12px 24px',
                                // background: '#fafafa',
                                borderBottom: '1px solid #444444',
                                display: 'flex',
                                gap: 24,
                                flexWrap: 'wrap'
                            }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                                    <InfoCircleOutlined style={{ color: '#1890ff' }} />
                                    <Text strong>{productGroup.productCode}</Text>
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                                    <CheckCircleOutlined style={{ color: '#52c41a' }} />
                                    <Text>{productGroup.dosageForm || 'N/A'}</Text>
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                                    <Text type="secondary">{templates.length} template{templates.length !== 1 ? 's' : ''} found</Text>
                                </div>
                            </div>
                        )}

                        {/* Templates Table */}
                        <div style={{ padding: '16px 24px 24px' }}>
                            <div style={{ marginBottom: 16 }}>
                                <Title level={5} style={{ marginBottom: 0 }}>
                                    Template List
                                </Title>
                            </div>

                            {templates.length === 0 ? (
                                <Empty
                                    description="No templates found for this product"
                                    image={Empty.PRESENTED_IMAGE_SIMPLE}
                                />
                            ) : (
                                <Table
                                    dataSource={templates}
                                    columns={templateColumns}
                                    rowKey="_id"
                                    pagination={{ pageSize: 5 }}
                                    size="small"
                                    bordered
                                    scroll={{ x: true }}
                                />
                            )}
                        </div>

                        {/* Footer */}
                        <div style={{
                            padding: '16px 24px',
                            borderTop: '1px solid #444444',
                            display: 'flex',
                            justifyContent: 'flex-end',
                            alignItems: 'center',
                            // background: '#fafafa'
                        }}>
                            <Button
                                onClick={onClose}
                                icon={<CloseOutlined />}
                                type="primary"
                            >
                                Close
                            </Button>
                        </div>
                    </div>
                )}
            </Modal>
        </>
    )
}
