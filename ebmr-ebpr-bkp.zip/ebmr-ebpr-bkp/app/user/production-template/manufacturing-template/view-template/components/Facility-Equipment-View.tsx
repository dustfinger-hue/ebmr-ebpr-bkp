'use client'

import { Card, Space, Tag, Typography } from "antd"
import { SettingOutlined } from "@ant-design/icons"

const { Title, Text } = Typography

interface FacilityEquipmentViewProps {
    data: any
}

export default function FacilityEquipmentView({ data }: FacilityEquipmentViewProps) {
    const facilityEquipment = data?.['Facility Equipment'] || {}

    if (!facilityEquipment?.facilitiesWithEquipment?.length) return null

    return (
        <Card
            title={
                <Space>
                    <SettingOutlined className="text-blue-500" />
                    <Title level={5} style={{ margin: 0 }}>Facility & Equipment</Title>
                </Space>
            }
        >
            {facilityEquipment.facilitiesWithEquipment.map((facility: any, idx: number) => (
                <Card key={idx} size="small" title={facility.areaName || `Facility ${idx + 1}`} style={{ marginBottom: 12 }}>
                    {facility.equipments?.map((eq: any, eqIdx: number) => (
                        <Tag key={eqIdx} color="blue" style={{ marginBottom: 4 }}>{eq.equipmentName} ({eq.equipmentCode})</Tag>
                    ))}
                    {(!facility.equipments || facility.equipments.length === 0) && <Text type="secondary">No equipment</Text>}
                </Card>
            ))}
        </Card>
    )
}