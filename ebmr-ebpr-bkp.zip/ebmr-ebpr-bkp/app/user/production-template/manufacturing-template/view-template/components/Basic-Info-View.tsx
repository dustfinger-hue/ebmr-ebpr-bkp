'use client'

import { Card, Col, Descriptions, Row, Space, Tag, Typography } from "antd"
import { InfoCircleOutlined } from "@ant-design/icons"

const { Title, Text } = Typography

interface BasicInfoViewProps {
    data: any
    document:any
}

export default function BasicInfoView({ data, document }: BasicInfoViewProps) {
    const basicInfo = data?.['Basic Information'] || {}
    const dosageForm = basicInfo.dosageForm
    const coatingRequired = basicInfo.coatingRequired
    const storageConditions = Array.isArray(basicInfo.storageConditions)
        ? basicInfo.storageConditions
        : basicInfo.storageConditions
            ? [basicInfo.storageConditions]
            : []

    return (
        <Card
            title={
                <Space>
                    <InfoCircleOutlined className="text-blue-500" />
                    <Title level={5} style={{ margin: 0 }}>Basic Information</Title>
                </Space>
            }
        >
            <Row gutter={[24, 16]}>
                <Col span={24}>
                    <Descriptions column={3} size="small" bordered>
                        <Descriptions.Item label="Template Code">{document.templateCode || '-'}</Descriptions.Item>
                        <Descriptions.Item label="Version">{basicInfo.templateVersion || '-'}</Descriptions.Item>
                        <Descriptions.Item label="Template Name">{basicInfo.templateName || '-'}</Descriptions.Item>
                        <Descriptions.Item label="Template Type">{basicInfo.templateType || '-'}</Descriptions.Item>
                        <Descriptions.Item label="Product Name">{basicInfo.productName || '-'}</Descriptions.Item>
                        <Descriptions.Item label="Product Code">{basicInfo.productCode || '-'}</Descriptions.Item>
                        <Descriptions.Item label="Dosage Form"><Tag color="blue">{dosageForm || '-'}</Tag></Descriptions.Item>
                        <Descriptions.Item label="Strength">{basicInfo.strength || '-'}</Descriptions.Item>
                        <Descriptions.Item label="Batch Size (Bulk)">{basicInfo.batchSizeBulk ? `${basicInfo.batchSizeBulk} ${basicInfo.uomBulk || ''}` : '-'}</Descriptions.Item>
                        <Descriptions.Item label="Batch Size (Semi)">{basicInfo.batchSizeSemiFinished ? `${basicInfo.batchSizeSemiFinished} ${basicInfo.uomSemiFinished || ''}` : '-'}</Descriptions.Item>
                        <Descriptions.Item label="Storage Conditions">
                            {storageConditions.length > 0
                                ? storageConditions.map((s: string) => <Tag key={s}>{s}</Tag>)
                                : '-'}
                        </Descriptions.Item>
                        <Descriptions.Item label="Shelf Life">{basicInfo.shelfLife ? `${basicInfo.shelfLife} months` : '-'}</Descriptions.Item>
                        <Descriptions.Item label="Drug Reg. No.">{basicInfo.drugRegistrationNumber || '-'}</Descriptions.Item>
                        <Descriptions.Item label="Effective Date">{basicInfo.effectiveDate || '-'}</Descriptions.Item>
                        <Descriptions.Item label="Manufacturing BOM Code">{basicInfo.manufacturingBomCode || '-'}</Descriptions.Item>
                        <Descriptions.Item label="Status"><Tag color={basicInfo.status === 'Active' ? 'green' : 'orange'}>{basicInfo.status || '-'}</Tag></Descriptions.Item>
                    </Descriptions>
                </Col>
            </Row>
            {dosageForm === 'Tablet' && basicInfo.tabletType && (
                <div style={{ marginTop: 12 }}>
                    <Text strong>Tablet Type: </Text><Tag color="purple">{basicInfo.tabletType}</Tag>
                    {coatingRequired && <Tag color="cyan" style={{ marginLeft: 8 }}>Coating Required</Tag>}
                </div>
            )}
        </Card>
    )
}