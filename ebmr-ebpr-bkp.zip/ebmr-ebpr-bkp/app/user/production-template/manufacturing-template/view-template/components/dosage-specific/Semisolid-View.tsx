'use client'

import { Card, Descriptions, Divider, Space, Table, Tag, Typography } from "antd"
import { SettingOutlined, WarningOutlined } from "@ant-design/icons"

const { Title, Text } = Typography

const cppColumns = [
    { title: 'Parameter', dataIndex: 'parameterName', key: 'parameterName', width: 180 },
    { title: 'Value', dataIndex: 'value', key: 'value', width: 80 },
    { title: 'Range', key: 'range', width: 180, render: (_: any, r: any) => `${r.minValue} - ${r.maxValue} ${r.unit}` },
]

const ipqcColumns = [
    { title: 'Parameter', dataIndex: 'parameterName', key: 'parameterName', width: 180 },
    { title: 'Specification', dataIndex: 'specification', key: 'specification', width: 200 },
    { title: 'Frequency', dataIndex: 'frequency', key: 'frequency', width: 120 },
]

interface SemisolidViewProps {
    data: any
}

export default function SemisolidView({ data }: SemisolidViewProps) {
    const params = data?.['Semisolid Parameters'] || {}
    if (!params?.machineSetup) return null

    return (
        <Card
            title={
                <Space>
                    <SettingOutlined className="text-orange-500" />
                    <Title level={5} style={{ margin: 0 }}>Semisolid Parameters</Title>
                </Space>
            }
        >
            <Descriptions column={2} size="small">
                <Descriptions.Item label="Machine">{params.machineSetup.machine}</Descriptions.Item>
                <Descriptions.Item label="Machine ID">{params.machineSetup.machineId || '-'}</Descriptions.Item>
                <Descriptions.Item label="Container Type">{params.containerSpecs.containerType || '-'}</Descriptions.Item>
                <Descriptions.Item label="Container Size">{params.containerSpecs.containerSize ? `${params.containerSpecs.containerSize} g` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Cap Type">{params.containerSpecs.capType || '-'}</Descriptions.Item>
                <Descriptions.Item label="Seal Type">{params.containerSpecs.sealType || '-'}</Descriptions.Item>
                <Descriptions.Item label="Crimp Width">{params.containerSpecs.tubeCrimpWidth ? `${params.containerSpecs.tubeCrimpWidth} mm` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Fill Weight">{params.fillParams?.targetFillWeight ? `${params.fillParams.targetFillWeight} g` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Fill Tolerance">{params.fillParams?.fillWeightTolerance ? `±${params.fillParams.fillWeightTolerance} g` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Production Speed">{params.fillParams?.productionSpeed ? `${params.fillParams.productionSpeed} units/hr` : '-'}</Descriptions.Item>
            </Descriptions>

            {params.machineSetup.cppValues?.length > 0 && (
                <>
                    <Divider><SettingOutlined className="mr-2" /> CPP</Divider>
                    <Table columns={cppColumns} dataSource={params.machineSetup.cppValues} rowKey="parameterName" pagination={false} size="small" />
                </>
            )}
            {params.qualityControls?.ipqcRows?.length > 0 && (
                <>
                    <Divider><WarningOutlined className="mr-2" /> IPQC</Divider>
                    <Table columns={ipqcColumns} dataSource={params.qualityControls.ipqcRows} rowKey="id" pagination={false} size="small" />
                </>
            )}
            {params.qualityControls?.semisolidDefects?.length > 0 && (
                <>
                    <Divider><WarningOutlined className="mr-2 text-red-500" /> Defects</Divider>
                    <Space wrap>{params.qualityControls.semisolidDefects.map((d: string) => <Tag key={d} color="red">{d}</Tag>)}</Space>
                </>
            )}
        </Card>
    )
}