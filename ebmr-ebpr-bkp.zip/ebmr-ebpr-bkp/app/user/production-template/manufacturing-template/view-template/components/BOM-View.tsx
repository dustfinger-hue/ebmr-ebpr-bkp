'use client'

import { Card, Descriptions, Divider, Space, Table, Tag, Typography } from "antd"
import { FileTextOutlined } from "@ant-design/icons"

const { Title, Text } = Typography

const bomMaterialColumns = [
    { title: 'Code', dataIndex: 'materialCode', key: 'materialCode', width: 120 },
    { title: 'Name', dataIndex: 'materialName', key: 'materialName', width: 180 },
    { title: 'Category', dataIndex: 'materialCategory', key: 'materialCategory', width: 120 },
    { title: 'Qty', dataIndex: 'quantity', key: 'quantity', width: 80 },
    { title: 'UOM', dataIndex: 'uom', key: 'uom', width: 60 },
    { title: 'Usage Stage', dataIndex: 'usageStage', key: 'usageStage', width: 120 },
]

interface BOMViewProps {
    data: any
}

export default function BOMView({ data }: BOMViewProps) {
    const bomData = data?.['Manufacturing BOM']?.bomData || {}
    const bomOtherInfo = data?.['Manufacturing BOM']?.otherInfo || ''

    if (!bomData?.materials?.length) return null

    return (
        <Card
            title={
                <Space>
                    <FileTextOutlined className="text-blue-500" />
                    <Title level={5} style={{ margin: 0 }}>Manufacturing BOM</Title>
                </Space>
            }
        >
            <Descriptions column={3} size="small" style={{ marginBottom: 16 }}>
                <Descriptions.Item label="BOM Code">{bomData.bomCode || '-'}</Descriptions.Item>
                <Descriptions.Item label="Version">{bomData.bomVersion || '-'}</Descriptions.Item>
                <Descriptions.Item label="Product">{bomData.productName || '-'}</Descriptions.Item>
            </Descriptions>
            <Table
                columns={bomMaterialColumns}
                dataSource={bomData.materials}
                rowKey="materialCode"
                pagination={false}
                size="small"
                scroll={{ x: 700 }}
            />
            {bomOtherInfo && (
                <div style={{ marginTop: 16 }}>
                    <Divider orientation="horizontal">Additional Notes & Instructions</Divider>
                    <div dangerouslySetInnerHTML={{ __html: bomOtherInfo }} />
                </div>
            )}
        </Card>
    )
}