'use client'

import { Card, Descriptions, Divider, Space, Table, Tag, Typography } from "antd"
import { SettingOutlined, WarningOutlined } from "@ant-design/icons"

const { Title, Text } = Typography

const cppColumns = [
    { title: 'Parameter', dataIndex: 'parameterName', key: 'parameterName', width: 180 },
    { title: 'Value', dataIndex: 'value', key: 'value', width: 80 },
    { title: 'Range', key: 'range', width: 180, render: (_: any, r: any) => `${r.minValue} - ${r.maxValue} ${r.unit}` },
]

const ipqcColumns = [
    { title: 'Parameter', dataIndex: 'parameterName', key: 'parameterName', width: 180 },
    { title: 'Specification', dataIndex: 'specification', key: 'specification', width: 200 },
    { title: 'Frequency', dataIndex: 'frequency', key: 'frequency', width: 120 },
]

interface PowderViewProps {
    data: any
}

export default function PowderView({ data }: PowderViewProps) {
    const rawParams = data?.['Powder Filling Parameters'] || {}
    if (!rawParams?.machineSetup) return null

    const params = {
        ...(rawParams.machineSetup || {}),
        ...(rawParams.containerSpecs || {}),
        ...(rawParams.processParams || {}),
        ...(rawParams.qualityControls || {}),
        cppValues: rawParams.machineSetup?.cppValues || [],
        ipqcRows: rawParams.qualityControls?.ipqcRows || [],
        powderDefects: rawParams.qualityControls?.powderDefects || [],
    }

    return (
        <Card
            title={
                <Space>
                    <SettingOutlined className="text-orange-500" />
                    <Title level={5} style={{ margin: 0 }}>Powder Filling Parameters</Title>
                </Space>
            }
        >
            <Descriptions column={2} size="small">
                <Descriptions.Item label="Machine">{params.machine || '-'}</Descriptions.Item>
                <Descriptions.Item label="Machine ID">{params.machineId || '-'}</Descriptions.Item>
                <Descriptions.Item label="Location">{params.machineLocation || '-'}</Descriptions.Item>
                <Descriptions.Item label="Container Type">{params.containerType || '-'}</Descriptions.Item>
                <Descriptions.Item label="Pack Size">{params.containerSize ? `${params.containerSize} g` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Cap / Closure">{params.capType || '-'}</Descriptions.Item>
                <Descriptions.Item label="Seal Type">{params.sealType || '-'}</Descriptions.Item>
                <Descriptions.Item label="Fill Weight">{params.targetFillWeight ? `${params.targetFillWeight} g` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Tolerance">{params.fillWeightTolerance ? `±${params.fillWeightTolerance} g` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Speed">{params.productionSpeed ? `${params.productionSpeed} packs/hr` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Sieve / Mesh Size">{params.sieveMeshSize || '-'}</Descriptions.Item>
                <Descriptions.Item label="Blending Speed">{params.mixingSpeed ? `${params.mixingSpeed} RPM` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Blending Time">{params.mixingTime ? `${params.mixingTime} min` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Bulk Density">{params.bulkDensity ? `${params.bulkDensity} g/ml` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Tapped Density">{params.tappedDensity ? `${params.tappedDensity} g/ml` : '-'}</Descriptions.Item>
                <Descriptions.Item label="LOD / Moisture Limit">{params.lossOnDryingLimit ? `${params.lossOnDryingLimit}%` : '-'}</Descriptions.Item>
            </Descriptions>

            {params.cppValues?.length > 0 && (
                <>
                    <Divider><SettingOutlined className="mr-2" /> CPP</Divider>
                    <Table columns={cppColumns} dataSource={params.cppValues} rowKey="parameterName" pagination={false} size="small" />
                </>
            )}
            {params.ipqcRows?.length > 0 && (
                <>
                    <Divider><WarningOutlined className="mr-2" /> IPQC</Divider>
                    <Table columns={ipqcColumns} dataSource={params.ipqcRows} rowKey="id" pagination={false} size="small" />
                </>
            )}
            {params.powderDefects?.length > 0 && (
                <>
                    <Divider><WarningOutlined className="mr-2 text-red-500" /> Defects</Divider>
                    <Space wrap>{params.powderDefects.map((d: string) => <Tag key={d} color="red">{d}</Tag>)}</Space>
                </>
            )}
        </Card>
    )
}