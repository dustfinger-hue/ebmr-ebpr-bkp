'use client'

import { Card, Descriptions, Divider, Space, Table, Tag, Typography } from "antd"
import { SettingOutlined, WarningOutlined } from "@ant-design/icons"

const { Title, Text } = Typography

const cppColumns = [
    { title: 'Parameter', dataIndex: 'parameterName', key: 'parameterName', width: 180 },
    { title: 'Value', dataIndex: 'value', key: 'value', width: 80 },
    { title: 'Range', key: 'range', width: 180, render: (_: any, r: any) => `${r.minValue} - ${r.maxValue} ${r.unit}` },
]

interface CompressionViewProps {
    data: any
}

export default function CompressionView({ data }: CompressionViewProps) {
    const params = data?.['Compression Parameters'] || {}
    if (!params?.machineSetup) return null

    return (
        <Card
            title={
                <Space>
                    <SettingOutlined className="text-orange-500" />
                    <Title level={5} style={{ margin: 0 }}>Compression Parameters</Title>
                </Space>
            }
        >
            <Divider orientation="horizontal">Machine Setup</Divider>
            <Descriptions column={2} size="small">
                <Descriptions.Item label="Machine Name">{params.machineSetup?.machineType || '-'}</Descriptions.Item>
                <Descriptions.Item label="Machine ID / Code">{params.machineSetup?.machineId || '-'}</Descriptions.Item>
                <Descriptions.Item label="Location">{params.machineSetup?.machineLocation || '-'}</Descriptions.Item>
                <Descriptions.Item label="Number of Stations">{params.machineSetup?.numberOfStations || '-'}</Descriptions.Item>
                <Descriptions.Item label="Operating Speed">{params.machineSetup?.operatingSpeed ? `${params.machineSetup.operatingSpeed} tabs/hr` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Max Speed">{params.machineSetup?.maxSpeed ? `${params.machineSetup.maxSpeed} tabs/hr` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Pre-Compression Type">{params.machineSetup?.preCompressionType || '-'}</Descriptions.Item>
            </Descriptions>

            {params.machineSetup?.cppParameters?.length > 0 && (
                <>
                    <Divider orientation="horizontal">CPP Parameters (Machine)</Divider>
                    <Table
                        columns={[
                            { title: 'Parameter', dataIndex: 'parameterName', key: 'parameterName', width: 200 },
                            { title: 'Value', dataIndex: 'minValue', key: 'minValue', width: 80, render: (v: any, r: any) => r.minValue === r.maxValue ? r.minValue : `${r.minValue} - ${r.maxValue}` },
                            { title: 'Unit', dataIndex: 'unit', key: 'unit', width: 80 },
                        ]}
                        dataSource={params.machineSetup.cppParameters}
                        rowKey="parameterName"
                        pagination={false}
                        size="small"
                    />
                </>
            )}

            <Divider orientation="horizontal">Tooling Specifications</Divider>
            <Descriptions column={2} size="small">
                <Descriptions.Item label="Tooling Type">{params.toolingSpecs?.toolingType || '-'}</Descriptions.Item>
                <Descriptions.Item label="Tooling Material">{params.toolingSpecs?.toolingMaterial || '-'}</Descriptions.Item>
                <Descriptions.Item label="Tooling Coating">{params.toolingSpecs?.toolingCoating || '-'}</Descriptions.Item>
                <Descriptions.Item label="Die Bore Size">{params.toolingSpecs?.dieBoreSize ? `${params.toolingSpecs.dieBoreSize} mm` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Die Thickness">{params.toolingSpecs?.dieThickness ? `${params.toolingSpecs.dieThickness} mm` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Upper Punch Length">{params.toolingSpecs?.upperPunchLength ? `${params.toolingSpecs.upperPunchLength} mm` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Lower Punch Length">{params.toolingSpecs?.lowerPunchLength ? `${params.toolingSpecs.lowerPunchLength} mm` : '-'}</Descriptions.Item>
            </Descriptions>

            {params.compressionParams && (
                <>
                    <Divider orientation="horizontal">Compression Process Parameters</Divider>
                    {params.compressionParams.tabletDescription && (
                        <div style={{ marginBottom: 12 }}>
                            <Text strong>Tablet Description: </Text>
                            <Text>{params.compressionParams.tabletDescription}</Text>
                        </div>
                    )}
                    <Descriptions column={2} size="small">
                        <Descriptions.Item label="Target Weight">{params.compressionParams.targetTabletWeight ? `${params.compressionParams.targetTabletWeight} mg` : '-'}</Descriptions.Item>
                        <Descriptions.Item label="Weight Tolerance">{params.compressionParams.tabletWeightTolerance ? `±${params.compressionParams.tabletWeightTolerance} mg` : '-'}</Descriptions.Item>
                        <Descriptions.Item label="Target Thickness">{params.compressionParams.targetTabletThickness ? `${params.compressionParams.targetTabletThickness} mm` : '-'}</Descriptions.Item>
                        <Descriptions.Item label="Thickness Tolerance">{params.compressionParams.thicknessTolerance ? `±${params.compressionParams.thicknessTolerance} mm` : '-'}</Descriptions.Item>
                        <Descriptions.Item label="Target Hardness">{params.compressionParams.targetHardness ? `${params.compressionParams.targetHardness} kP` : '-'}</Descriptions.Item>
                        <Descriptions.Item label="Hardness Tolerance">{params.compressionParams.hardnessTolerance ? `±${params.compressionParams.hardnessTolerance} kP` : '-'}</Descriptions.Item>
                        <Descriptions.Item label="Disintegration Time">{params.compressionParams.disintegrationTime ? `${params.compressionParams.disintegrationTime} s` : '-'}</Descriptions.Item>
                        <Descriptions.Item label="Disintegration Temp">{params.compressionParams.disintegrationTemperature ? `${params.compressionParams.disintegrationTemperature} °C` : '-'}</Descriptions.Item>
                        <Descriptions.Item label="Friability Tolerance">{params.compressionParams.friabilityTolerance ? `< ${params.compressionParams.friabilityTolerance}%` : '-'}</Descriptions.Item>
                    </Descriptions>
                </>
            )}

            {params.qualityControls && (
                <>
                    <Divider orientation="horizontal"><WarningOutlined className="mr-2" /> Quality Controls (IPQC)</Divider>
                    <Descriptions column={2} size="small">
                        <Descriptions.Item label="Weight Check Freq">{params.qualityControls.weightCheckFrequency || '-'}</Descriptions.Item>
                        <Descriptions.Item label="Hardness Check Freq">{params.qualityControls.hardnessCheckFrequency || '-'}</Descriptions.Item>
                        <Descriptions.Item label="Thickness Check Freq">{params.qualityControls.thicknessCheckFrequency || '-'}</Descriptions.Item>
                        <Descriptions.Item label="Sample Size (Wt)">{params.qualityControls.sampleSizeWeight || '-'}</Descriptions.Item>
                        <Descriptions.Item label="Sample Size (H/T)">{params.qualityControls.sampleSizeHardnessThickness || '-'}</Descriptions.Item>
                    </Descriptions>
                    {params.qualityControls.defectTypes?.length > 0 && (
                        <>
                            <Divider orientation="horizontal"><WarningOutlined className="mr-2 text-red-500" /> Defects</Divider>
                            <Space wrap>{params.qualityControls.defectTypes.map((d: string) => <Tag key={d} color="red">{d}</Tag>)}</Space>
                        </>
                    )}
                </>
            )}
        </Card>
    )
}