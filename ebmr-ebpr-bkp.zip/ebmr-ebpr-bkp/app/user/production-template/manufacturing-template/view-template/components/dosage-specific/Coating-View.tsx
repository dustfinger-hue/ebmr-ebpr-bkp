'use client'

import { Card, Descriptions, Divider, Space, Table, Tag, Typography } from "antd"
import { CheckCircleOutlined, SettingOutlined, WarningOutlined } from "@ant-design/icons"

const { Title, Text } = Typography

const cppColumns = [
    { title: 'Parameter', dataIndex: 'parameterName', key: 'parameterName', width: 180 },
    { title: 'Value', dataIndex: 'value', key: 'value', width: 80 },
    { title: 'Range', key: 'range', width: 180, render: (_: any, r: any) => `${r.minValue} - ${r.maxValue} ${r.unit}` },
]

const ipqcColumns = [
    { title: 'Parameter', dataIndex: 'parameterName', key: 'parameterName', width: 180 },
    { title: 'Specification', dataIndex: 'specification', key: 'specification', width: 200 },
    { title: 'Frequency', dataIndex: 'frequency', key: 'frequency', width: 120 },
]

interface CoatingViewProps {
    data: any
}

export default function CoatingView({ data }: CoatingViewProps) {
    const coatingSection = data?.['Coating Section'] || {}
    if (!coatingSection) return null

    return (
        <Card
            title={
                <Space>
                    <CheckCircleOutlined className="text-green-500" />
                    <Title level={5} style={{ margin: 0 }}>Coating Section</Title>
                </Space>
            }
        >
            {coatingSection.solutionPrep?.steps?.length > 0 && (
                <>
                    <Divider>Solution Preparation Steps</Divider>
                    {coatingSection.solutionPrep.steps.map((step: any, idx: number) => (
                        <Card key={step.id} size="small" style={{ marginBottom: 8 }}>
                            <Space wrap>
                                <Tag color="blue">Step {idx + 1}</Tag>
                                <Text strong>{step.stepName}</Text>
                                {step.machineName && <Tag color="purple">{step.machineName}</Tag>}
                            </Space>
                            {step.stepDescription && <div><Text type="secondary">{step.stepDescription}</Text></div>}
                            {step.materials?.length > 0 && (
                                <div style={{ marginTop: 4 }}>
                                    {step.materials.map((m: any) => (
                                        <Tag key={m.materialCode} color="green">{m.materialCode}: {m.quantity}</Tag>
                                    ))}
                                </div>
                            )}
                            {step.cppValues?.length > 0 && (
                                <div style={{ marginTop: 4 }}>
                                    {step.cppValues.map((cpp: any) => (
                                        <Tag key={`${step.id}_${cpp.parameterName}`} color="geekblue">
                                            {cpp.parameterName}: {cpp.value} {cpp.unit}
                                        </Tag>
                                    ))}
                                </div>
                            )}
                        </Card>
                    ))}
                </>
            )}

            {coatingSection.coatingParams?.machine && (
                <>
                    <Divider>Coating Parameters</Divider>
                    <Descriptions column={2} size="small">
                        <Descriptions.Item label="Machine">{coatingSection.coatingParams.machine}</Descriptions.Item>
                        <Descriptions.Item label="Machine ID">{coatingSection.coatingParams.machineId || '-'}</Descriptions.Item>
                        <Descriptions.Item label="Location">{coatingSection.coatingParams.machineLocation || '-'}</Descriptions.Item>
                    </Descriptions>
                    {coatingSection.coatingParams.cppValues?.length > 0 && (
                        <>
                            <Divider>CPP</Divider>
                            <Table columns={cppColumns} dataSource={coatingSection.coatingParams.cppValues} rowKey="parameterName" pagination={false} size="small" />
                        </>
                    )}
                    {coatingSection.coatingParams.ipqcRows?.length > 0 && (
                        <>
                            <Divider><WarningOutlined className="mr-2" /> IPQC</Divider>
                            <Table columns={ipqcColumns} dataSource={coatingSection.coatingParams.ipqcRows} rowKey="id" pagination={false} size="small" />
                        </>
                    )}
                    {coatingSection.coatingParams.coatingDefects?.length > 0 && (
                        <>
                            <Divider><WarningOutlined className="mr-2 text-red-500" /> Defects</Divider>
                            <Space wrap>{coatingSection.coatingParams.coatingDefects.map((d: string) => <Tag key={d} color="red">{d}</Tag>)}</Space>
                        </>
                    )}
                </>
            )}
        </Card>
    )
}