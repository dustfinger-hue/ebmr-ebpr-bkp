'use client'

import { Breadcrumb, Button, Card, Space, Tag, Typography, message } from "antd"
import { ArrowLeftOutlined, HomeOutlined } from "@ant-design/icons"
import { useRouter } from "next/navigation"
import SignButton from "@/components/Digital-Signing"

import BasicInfoView from "./Basic-Info-View"
import BOMView from "./BOM-View"
import FacilityEquipmentView from "./Facility-Equipment-View"
import ManufacturingStepsView from "./Manufacturing-Steps-View"
import CompressionView from "./dosage-specific/Compression-View"
import EncapsulationView from "./dosage-specific/Encapsulation-View"
import LiquidView from "./dosage-specific/Liquid-View"
import PowderView from "./dosage-specific/Powder-View"
import SemisolidView from "./dosage-specific/Semisolid-View"
import CoatingView from "./dosage-specific/Coating-View"
import SignaturesView from "./Signatures-View"
import { useAuthorization } from "@/hooks/useAuthorization"

const { Title, Text } = Typography

interface ViewTemplateProps {
    document: any
}

export default function ViewTemplate({ document }: ViewTemplateProps) {
    const router = useRouter()
    const data = document?.fullTemplateData || {}
    const basicInfo = data?.['Basic Information'] || {}
    const dosageForm = basicInfo.dosageForm
    const coatingRequired = basicInfo.coatingRequired
    const { hasAccess } = useAuthorization()
    const isUpdateTemplateAuthorized = hasAccess('Batch Manufacturing Template', 'update')
    const canEdit = (document?.status === 'Reverted' || document?.status === 'Draft') && isUpdateTemplateAuthorized

    return (
        <Space direction="vertical" size="middle" className="w-full">
            {/* Breadcrumb */}
            <Card size="small">
                <Breadcrumb
                    items={[
                        {
                            href: '/user/production-template/manufacturing-template',
                            title: (
                                <Space>
                                    <HomeOutlined />
                                    <span>Manufacturing Templates</span>
                                </Space>
                            ),
                        },
                        {
                            title: `View: ${document.templateCode || ''}`,
                        },
                    ]}
                />
            </Card>

            {/* Header */}
            <Card>
                <Space style={{ width: '100%', justifyContent: 'space-between' }}>
                    <Space size="large">
                        <Button
                            type="text"
                            icon={<ArrowLeftOutlined />}
                            onClick={() => router.push('/user/production-template/manufacturing-template')}
                        />
                        <div>
                            <Title level={3} style={{ margin: 0 }}>
                                {document.templateName || 'Template'}
                            </Title>
                            <Text type="secondary">
                                Code: {document.templateCode} | Version: {document.templateVersion}
                                <Tag color={document.status === 'Active' ? 'green' : document.status === 'Rejected' ? 'red' : 'orange'} style={{ marginLeft: 8 }}>
                                    {document.status}
                                </Tag>
                            </Text>
                        </div>
                    </Space>
                    <Space>
                        {canEdit && (
                            <Button
                                type="primary"
                                onClick={() => router.push(`/user/production-template/manufacturing-template/edit-template/${document._id}`)}
                            >
                                Edit Template
                            </Button>
                        )}
                        {(document.status === 'Pending Signatures' || document.status === 'Draft' || document.status === 'Reverted') && (
                            <SignButton
                                module="Batch Manufacturing Template"
                                label="Sign Document"
                                data={null}
                                documentId={document.templateCode}
                                schemaTitle='BatchManufacturingTemplate'
                                onSignComplete={() => {
                                    message.success("Document signed successfully!")
                                    setTimeout(() => window.location.reload(), 1500)
                                }}
                                apiUrl="/api/user/production-template/manufacturing-template/patch"
                            />
                        )}
                    </Space>
                </Space>
            </Card>

            {/* Common Sections */}
            <BasicInfoView data={data} document={document} />
            <BOMView data={data} />
            <FacilityEquipmentView data={data} />
            <ManufacturingStepsView data={data} />

            {/* Dosage-specific Sections */}
            {dosageForm === 'Tablet' && <CompressionView data={data} />}
            {dosageForm === 'Capsule' && <EncapsulationView data={data} />}
            {['Syrup', 'Liquid Suspension', 'Solution', 'Drop'].includes(dosageForm) && <LiquidView data={data} />}
            {['Dry Powder Suspension', 'Powder'].includes(dosageForm) && <PowderView data={data} />}
            {['Cream', 'Ointment', 'Gel', 'Lotion'].includes(dosageForm) && <SemisolidView data={data} />}
            {dosageForm === 'Tablet' && coatingRequired && <CoatingView data={data} />}

            {/* Signatures & Workflow */}
            <SignaturesView document={document} />
        </Space>
    )
}