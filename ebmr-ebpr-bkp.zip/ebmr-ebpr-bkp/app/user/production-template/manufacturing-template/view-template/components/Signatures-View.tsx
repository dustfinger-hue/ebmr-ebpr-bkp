'use client'

import { Card, Space, Table, Tag, Typography } from "antd"
import { SafetyCertificateOutlined } from "@ant-design/icons"

const { Title, Text } = Typography

const signatureActionColors: Record<string, string> = {
    approved: 'green',
    rejected: 'red',
    reverted: 'orange',
}

const signatureActionLabels: Record<string, string> = {
    approved: '✅ Approved',
    rejected: '❌ Rejected',
    reverted: '🔄 Reverted',
}

interface SignaturesViewProps {
    document: any
}

export default function SignaturesView({ document }: SignaturesViewProps) {
    const signatures = document?.signatures || []
    const signingWorkflow = document?.signingWorkflow || {}

    if (!signatures?.length) return null

    const signatureColumns = [
        { title: 'S.No', width: 60, render: (_: any, __: any, idx: number) => idx + 1 },
        { title: 'Name', dataIndex: ['signatoryInfo', 'name'], key: 'name', width: 150 },
        { title: 'Designation', dataIndex: ['signatoryInfo', 'designation'], key: 'designation', width: 130 },
        { title: 'Department', dataIndex: ['signatoryInfo', 'department'], key: 'department', width: 120 },
        { title: 'Seq', dataIndex: ['signatoryInfo', 'authorizationSequence'], key: 'seq', width: 50, align: 'center' as const },
        {
            title: 'Action',
            dataIndex: 'action',
            key: 'action',
            width: 120,
            render: (action: string) => (
                <Tag color={signatureActionColors[action] || 'default'}>
                    {signatureActionLabels[action] || action}
                </Tag>
            ),
        },
        {
            title: 'Status',
            dataIndex: 'status',
            key: 'status',
            width: 100,
            render: (status: string) => (
                <Tag color={status === 'signed' ? 'green' : status === 'rejected' ? 'red' : 'orange'}>
                    {status}
                </Tag>
            ),
        },
        { title: 'Signed At', dataIndex: 'signedAt', key: 'signedAt', width: 160, render: (d: string) => d ? new Date(d).toLocaleString() : '-' },
    ]

    return (
        <Card
            title={
                <Space>
                    <SafetyCertificateOutlined className="text-blue-500" />
                    <Title level={5} style={{ margin: 0 }}>Signatures & Workflow</Title>
                </Space>
            }
        >
            <Space direction="horizontal" size="large" style={{ marginBottom: 16 }}>
                <Text>Total Required: <Tag color="blue">{signingWorkflow.totalSignaturesRequired || 0}</Tag></Text>
                <Text>Completed: <Tag color="green">{signingWorkflow.completedSignatures || 0}</Tag></Text>
                <Text>Status: <Tag color={signingWorkflow.isSignatureComplete ? 'green' : 'orange'}>
                    {signingWorkflow.isSignatureComplete ? 'Complete' : 'In Progress'}
                </Tag></Text>
            </Space>
            <Table
                columns={signatureColumns}
                dataSource={signatures}
                rowKey={(r: any) => r.signatureRef || r._id}
                pagination={false}
                size="small"
                scroll={{ x: 'max-content' }}
            />
        </Card>
    )
}