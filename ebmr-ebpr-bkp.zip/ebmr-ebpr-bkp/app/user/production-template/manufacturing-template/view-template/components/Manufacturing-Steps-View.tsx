'use client'

import { Card, Space, Tag, Typography } from "antd"
import { CheckCircleOutlined } from "@ant-design/icons"

const { Title, Text } = Typography

interface ManufacturingStepsViewProps {
    data: any
}

export default function ManufacturingStepsView({ data }: ManufacturingStepsViewProps) {
    const manufacturingSteps = data?.['Manufacturing Steps'] || {}

    if (!manufacturingSteps?.layers || Object.keys(manufacturingSteps.layers).length === 0) return null

    return (
        <Card
            title={
                <Space>
                    <CheckCircleOutlined className="text-blue-500" />
                    <Title level={5} style={{ margin: 0 }}>Manufacturing Steps</Title>
                </Space>
            }
        >
            {Object.entries(manufacturingSteps.layers).map(([layerName, layerData]: [string, any]) => (
                <Card key={layerName} size="small" title={layerName} style={{ marginBottom: 12 }}>
                    {layerData.lots && Object.entries(layerData.lots).map(([lotKey, lotData]: [string, any]) => (
                        <div key={lotKey} style={{ marginBottom: 12 }}>
                            <Text strong style={{ fontSize: 13 }}>{lotKey.replace(/-/g, ' ').toUpperCase()}</Text>
                            <div style={{ marginTop: 8 }}>
                                {(lotData.steps || []).map((step: any, idx: number) => (
                                    <Card key={step.id} size="small" style={{ marginBottom: 8 }}>
                                        <Space wrap>
                                            <Tag color="blue">Step {idx + 1}</Tag>
                                            <Text strong>{step.stepName}</Text>
                                            {step.machineName && <Tag color="purple">{step.machineName}</Tag>}
                                        </Space>
                                        {step.stepDescription && <div><Text type="secondary">{step.stepDescription}</Text></div>}
                                        {step.materials?.length > 0 && (
                                            <div style={{ marginTop: 4 }}>
                                                {step.materials.map((m: any) => (
                                                    <Tag key={m.materialCode} color="green">{m.materialCode}: {m.quantity}</Tag>
                                                ))}
                                            </div>
                                        )}
                                        {step.cppValues?.length > 0 && (
                                            <div style={{ marginTop: 4 }}>
                                                {step.cppValues.map((cpp: any) => (
                                                    <Tag key={`${step.id}_${cpp.parameterName}`} color="geekblue">
                                                        {cpp.parameterName}: {cpp.value} {cpp.unit}
                                                    </Tag>
                                                ))}
                                            </div>
                                        )}
                                    </Card>
                                ))}
                            </div>
                        </div>
                    ))}
                </Card>
            ))}
        </Card>
    )
}