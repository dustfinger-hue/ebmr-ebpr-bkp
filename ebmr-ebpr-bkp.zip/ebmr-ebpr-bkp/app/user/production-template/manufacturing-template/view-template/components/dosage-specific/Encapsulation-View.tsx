'use client'

import { Card, Descriptions, Divider, Space, Table, Tag, Typography } from "antd"
import { SettingOutlined, WarningOutlined } from "@ant-design/icons"

const { Title, Text } = Typography

const cppColumns = [
    { title: 'Parameter', dataIndex: 'parameterName', key: 'parameterName', width: 180 },
    { title: 'Value', dataIndex: 'value', key: 'value', width: 80 },
    { title: 'Range', key: 'range', width: 180, render: (_: any, r: any) => `${r.minValue} - ${r.maxValue} ${r.unit}` },
]

const ipqcColumns = [
    { title: 'Parameter', dataIndex: 'parameterName', key: 'parameterName', width: 180 },
    { title: 'Specification', dataIndex: 'specification', key: 'specification', width: 200 },
    { title: 'Frequency', dataIndex: 'frequency', key: 'frequency', width: 120 },
]

interface EncapsulationViewProps {
    data: any
}

export default function EncapsulationView({ data }: EncapsulationViewProps) {
    const params = data?.['Encapsulation Parameters'] || {}
    if (!params?.machine) return null

    return (
        <Card
            title={
                <Space>
                    <SettingOutlined className="text-orange-500" />
                    <Title level={5} style={{ margin: 0 }}>Encapsulation Parameters</Title>
                </Space>
            }
        >
            <Descriptions column={2} size="small">
                <Descriptions.Item label="Machine">{params.machine}</Descriptions.Item>
                <Descriptions.Item label="Machine ID">{params.machineId || '-'}</Descriptions.Item>
                <Descriptions.Item label="Location">{params.machineLocation || '-'}</Descriptions.Item>
                <Descriptions.Item label="Size"><Tag color="blue">{params.capsuleSize || '-'}</Tag></Descriptions.Item>
                <Descriptions.Item label="Type">{params.capsuleType || '-'}</Descriptions.Item>
                <Descriptions.Item label="Color">{params.capsuleColor || '-'}</Descriptions.Item>
                <Descriptions.Item label="Fill Weight">{params.targetFillWeight || '-'} mg</Descriptions.Item>
                <Descriptions.Item label="Tolerance">{params.fillWeightTolerance ? `±${params.fillWeightTolerance} mg` : '-'}</Descriptions.Item>
                <Descriptions.Item label="Speed">{params.productionSpeed || '-'} caps/hr</Descriptions.Item>
                <Descriptions.Item label="Tamping Force">{params.tampingForce || '-'} N</Descriptions.Item>
            </Descriptions>

            {params.cppValues?.length > 0 && (
                <>
                    <Divider><SettingOutlined className="mr-2" /> CPP</Divider>
                    <Table columns={cppColumns} dataSource={params.cppValues} rowKey="parameterName" pagination={false} size="small" />
                </>
            )}
            {params.ipqcRows?.length > 0 && (
                <>
                    <Divider><WarningOutlined className="mr-2" /> IPQC</Divider>
                    <Table columns={ipqcColumns} dataSource={params.ipqcRows} rowKey="id" pagination={false} size="small" />
                </>
            )}
            {params.encapsulationDefects?.length > 0 && (
                <>
                    <Divider><WarningOutlined className="mr-2 text-red-500" /> Defects</Divider>
                    <Space wrap>{params.encapsulationDefects.map((d: string) => <Tag key={d} color="red">{d}</Tag>)}</Space>
                </>
            )}
        </Card>
    )
}