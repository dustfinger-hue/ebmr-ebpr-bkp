'use client';

import { Modal, Descriptions, Tag, Button, message } from 'antd';
import { useState } from 'react';

interface AssignBatchNumberProps {
    open: boolean;
    orderData: any;
    onClose: () => void;
    onSuccess: () => void;
}

export default function AssignBatchNumber({ open, orderData, onClose, onSuccess }: AssignBatchNumberProps) {
    const [loading, setLoading] = useState(false);

    const handleAssign = async () => {
        if (!orderData?._id) return;

        setLoading(true);
        try {
            const token = localStorage.getItem('token');
            const res = await fetch('/api/user/manufacturing-control/batch-number/assign', {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify({ orderId: orderData._id })
            });

            const result = await res.json();
            if (result.success) {
                message.success(result.message);
                onSuccess();
                onClose();
            } else {
                message.error(result.message);
            }
        } catch (error) {
            console.error('Error assigning batch number:', error);
            message.error('Failed to assign batch number');
        } finally {
            setLoading(false);
        }
    };

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'Draft': return 'orange';
            case 'Planned': return 'blue';
            case 'Released': return 'green';
            case 'In-Progress': return 'cyan';
            case 'Completed': return 'purple';
            default: return 'default';
        }
    };

    return (
        <Modal
            title="Assign Batch Number"
            open={open}
            onCancel={onClose}
            footer={[
                <Button key="cancel" onClick={onClose}>Cancel</Button>,
                <Button
                    key="assign"
                    type="primary"
                    loading={loading}
                    onClick={handleAssign}
                >
                    Assign Batch Number
                </Button>
            ]}
            width={600}
            destroyOnClose
        >
            {orderData ? (
                <Descriptions column={2} bordered size="small" style={{ marginTop: 16 }}>
                    <Descriptions.Item label="Process Order Code" span={2}>
                        <strong>{orderData.processOrderCode}</strong>
                    </Descriptions.Item>
                    <Descriptions.Item label="Product Code">{orderData.productCode}</Descriptions.Item>
                    <Descriptions.Item label="Product Name">{orderData.productName}</Descriptions.Item>
                    <Descriptions.Item label="BOM Code">{orderData.bomCode}</Descriptions.Item>
                    <Descriptions.Item label="Status">
                        <Tag color={getStatusColor(orderData.status)}>{orderData.status}</Tag>
                    </Descriptions.Item>
                    <Descriptions.Item label="Batch Size">
                        {orderData.batchSizeSemifinished} {orderData.uom}
                    </Descriptions.Item>
                    <Descriptions.Item label="Bulk Size">
                        {orderData.bulkSize} {orderData.bulkUom}
                    </Descriptions.Item>
                    <Descriptions.Item label="Facilities" span={2}>
                        {orderData.manufacturingFacility && Array.isArray(orderData.manufacturingFacility) && orderData.manufacturingFacility.length > 0
                            ? orderData.manufacturingFacility.map((fac: string, i: number) => (
                                <Tag key={i} color="blue">{fac}</Tag>
                            ))
                            : (typeof orderData.manufacturingFacility === 'string' && orderData.manufacturingFacility
                                ? <Tag color="blue">{orderData.manufacturingFacility}</Tag>
                                : '-')
                        }
                    </Descriptions.Item>
                </Descriptions>
            ) : (
                <div style={{ textAlign: 'center', padding: 40, color: '#999' }}>No order selected</div>
            )}
            <div style={{ marginTop: 16, padding: '12px 16px', background: '#fcdb96', borderRadius: 6, border: '1px solid #fd993c' }}>
                <strong style={{ color: '#d46b08' }}>⚠️ Note:</strong>
                <span style={{ color: '#d46b08', marginLeft: 4 }}>
                    Assigning a batch number will automatically change the order status to <strong>In-Progress</strong>.
                </span>
            </div>
        </Modal>
    );
}