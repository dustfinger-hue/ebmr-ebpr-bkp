'use client';
import { Button, Card, Col, message, Row, Space, Table, Tag, Tooltip, Typography, Select } from "antd";
import { useEffect, useState } from "react";
import { FaClipboardList } from "react-icons/fa";
const { Title, Text } = Typography;
import {
    SearchOutlined,
    ReloadOutlined,
    EyeTwoTone,
    NumberOutlined,
    FilterOutlined,
    ClearOutlined,
} from "@ant-design/icons";
import Search from "antd/es/input/Search";
import { useAuthorization } from "@/hooks/useAuthorization";
import ViewProcessOrder from "@/app/user/manufacturing-control/process-order-creation/components/View-Process-Order";
import AssignBatchNumber from "./components/Assign-Batch-Number";

export default function BatchNumberIssuancePage() {
    const [data, setData] = useState<any[]>([]);
    const [loading, setLoading] = useState(false);
    const [pagination, setPagination] = useState({
        current: 1,
        pageSize: 10,
        total: 0,
    });
    const [searchText, setSearchText] = useState("");
    const [statusFilter, setStatusFilter] = useState<string>('Planned,In-Progress');
    const [productNameFilter, setProductNameFilter] = useState('');
    const [batchNumberFilter, setBatchNumberFilter] = useState('');
    const [viewModalOpen, setViewModalOpen] = useState(false);
    const [assignModalOpen, setAssignModalOpen] = useState(false);
    const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
    const [selectedOrderData, setSelectedOrderData] = useState<any>(null);

    // Auth check
    const { hasAccess } = useAuthorization();
    const isViewAuthorized = hasAccess('Batch Number Issuance', 'read');
    const isCreateAuthorized = hasAccess('Batch Number Issuance', 'create');

    useEffect(() => {
        getPlannedOrders(1, 10, "", statusFilter, productNameFilter, batchNumberFilter);
    }, []);

    const getPlannedOrders = async (page: number, limit: number, search: string, filterStatus?: string, filterProduct?: string, filterBatch?: string) => {
        try {
            setLoading(true);
            let url = `/api/user/manufacturing-control/process-order?page=${page}&limit=${limit}&search=${search}&status=${filterStatus || 'Planned,In-Progress'}`;

            const token = await localStorage.getItem('token');
            const res = await fetch(url, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            const result = await res.json();
            if (result.success) {
                setData(result.data || []);
                setPagination(prev => ({
                    ...prev,
                    current: result.page || page,
                    total: result.total || 0
                }));
            } else {
                message.error(result.message);
            }
        } catch (error) {
            console.error(error);
            message.error("Error fetching planned orders");
        } finally {
            setLoading(false);
        }
    };

    // Get stats
    const totalOrders = pagination.total;
    const assignedOrders = data.filter((item: any) => item.batchNumber).length;
    const pendingOrders = data.filter((item: any) => !item.batchNumber).length;

    // Table Columns
    const columns = [
        {
            title: 'S.No',
            width: 60,
            fixed: 'left' as const,
            render: (_: any, __: any, index: number) =>
                (pagination.current - 1) * pagination.pageSize + index + 1
        },
        {
            title: 'Product',
            key: 'product',
            width: 220,
            render: (_: any, record: any) => (
                <div>
                    <Text type="secondary" style={{ fontSize: 12 }}>{record.productCode}</Text>
                    <br />
                    <Text>{record.productName}</Text>
                </div>
            ),
        },
        {
            title: 'Batch / Bulk Size',
            key: 'batchBulkSize',
            width: 190,
            render: (_: any, record: any) => (
                <div>
                    <Text>Batch: {record.batchSizeSemifinished} {record.uom}</Text>
                    <br />
                    <Text type="secondary">Bulk: {record.bulkSize} {record.bulkUom}</Text>
                </div>
            ),
        },
        {
            title: 'Planned Dates',
            key: 'plannedDates',
            width: 130,
            render: (_: any, record: any) => (
                <Text type="secondary">
                    {record.plannedStartDate ? new Date(record.plannedStartDate).toLocaleDateString() : '-'}
                    {' → '}
                    {record.plannedEndDate ? new Date(record.plannedEndDate).toLocaleDateString() : '-'}
                </Text>
            ),
        },
        {
            title: 'Status',
            dataIndex: 'status',
            key: 'status',
            width: 100,
            render: (text: string) => {
                let color = 'blue';
                return <Tag color={color}>{text}</Tag>;
            },
        },
        {
            title: 'Batch Number',
            dataIndex: 'batchNumber',
            key: 'batchNumber',
            width: 150,
            render: (text: string) => {
                if (text) {
                    return <Tag color="green" style={{ fontWeight: 'bold' }}>{text}</Tag>;
                }
                return <Text type="secondary" italic>Not Assigned</Text>;
            },
        },
        {
            title: 'Action',
            width: 140,
            fixed: "right" as const,
            render: (record: any) => {
                const hasBatch = !!record.batchNumber;
                return (
                    <Space size="small">
                        <Tooltip title={isViewAuthorized ? "View Details" : "Not authorized"}>
                            <Button
                                type="text"
                                size="small"
                                onClick={() => {
                                    setSelectedOrderId(record._id);
                                    setViewModalOpen(true);
                                }}
                                disabled={!isViewAuthorized}
                                icon={<EyeTwoTone />}
                            />
                        </Tooltip>
                        <Tooltip title={!isCreateAuthorized ? "Not authorized" : hasBatch ? "Already assigned" : "Assign Batch Number"}>
                            <Button
                                type="primary"
                                size="small"
                                onClick={() => {
                                    setSelectedOrderData(record);
                                    setAssignModalOpen(true);
                                }}
                                disabled={!isCreateAuthorized || hasBatch}
                                icon={<NumberOutlined />}
                            >
                                Assign Batch
                            </Button>
                        </Tooltip>
                    </Space>
                )
            }
        }
    ];

    return (
        <div>
            <Title level={2}>
                <FaClipboardList size={28} className="inline mb-1 mr-2" />
                Batch Number Issuance
            </Title>

            {/* Stats Cards */}
            <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
                <Col span={6}>
                    <Card size="small">
                        <Text type="secondary">Total Planned Orders</Text>
                        <Title level={3} style={{ margin: 0 }}>{totalOrders}</Title>
                    </Card>
                </Col>
                <Col span={6}>
                    <Card size="small">
                        <Text type="secondary">Assigned</Text>
                        <Title level={3} style={{ margin: 0, color: '#52c41a' }}>{assignedOrders}</Title>
                    </Card>
                </Col>
                <Col span={6}>
                    <Card size="small">
                        <Text type="secondary">Pending</Text>
                        <Title level={3} style={{ margin: 0, color: '#fa8c16' }}>{pendingOrders}</Title>
                    </Card>
                </Col>
                <Col span={6}>
                    <Card size="small">
                        <Text type="secondary">In Progress</Text>
                        <Title level={3} style={{ margin: 0, color: '#1890ff' }}>
                            {assignedOrders}
                        </Title>
                    </Card>
                </Col>
            </Row>

            <Card>
            <Row gutter={[12, 12]} style={{ marginBottom: 16 }} justify="space-between">
                <Col span={6}>
                    <Search
                        placeholder="Search by product, code or order..."
                        allowClear
                        onSearch={(value) => {
                            setPagination(prev => ({ ...prev, current: 1 }));
                            setSearchText(value);
                            getPlannedOrders(1, pagination.pageSize, value, statusFilter, productNameFilter, batchNumberFilter);
                        }}
                        style={{ width: '100%' }}
                        prefix={<SearchOutlined />}
                    />
                </Col>
                <Col>
                    <Space size="small" wrap>
                        <Select
                            value={statusFilter}
                            onChange={(value) => {
                                setPagination(prev => ({ ...prev, current: 1 }));
                                setStatusFilter(value);
                                getPlannedOrders(1, pagination.pageSize, searchText, value, productNameFilter, batchNumberFilter);
                            }}
                            style={{ width: 160 }}
                            options={[
                                { value: 'Planned,In-Progress', label: 'All Statuses' },
                                { value: 'Planned', label: 'Planned' },
                                { value: 'In-Progress', label: 'In-Progress' },
                            ]}
                        />
                        <Search
                            placeholder="Filter by product name"
                            allowClear
                            value={productNameFilter}
                            onChange={(e) => setProductNameFilter(e.target.value)}
                            onSearch={(value) => {
                                setPagination(prev => ({ ...prev, current: 1 }));
                                setProductNameFilter(value);
                                getPlannedOrders(1, pagination.pageSize, searchText, statusFilter, value, batchNumberFilter);
                            }}
                            style={{ width: 200 }}
                            prefix={<FilterOutlined />}
                        />
                        <Search
                            placeholder="Filter by batch number"
                            allowClear
                            value={batchNumberFilter}
                            onChange={(e) => setBatchNumberFilter(e.target.value)}
                            onSearch={(value) => {
                                setPagination(prev => ({ ...prev, current: 1 }));
                                setBatchNumberFilter(value);
                                getPlannedOrders(1, pagination.pageSize, searchText, statusFilter, productNameFilter, value);
                            }}
                            style={{ width: 200 }}
                            prefix={<NumberOutlined />}
                        />
                        <Tooltip title="Refresh">
                            <Button
                                onClick={() => getPlannedOrders(pagination.current, pagination.pageSize, searchText, statusFilter, productNameFilter, batchNumberFilter)}
                                icon={<ReloadOutlined />}
                            />
                        </Tooltip>
                    </Space>
                </Col>
            </Row>

                {/* Table */}
                <Table
                    columns={columns}
                    dataSource={data}
                    loading={loading}
                    scroll={{ x: 'max-content' }}
                    rowKey="_id"
                    pagination={{
                        current: pagination.current,
                        pageSize: pagination.pageSize,
                        total: pagination.total,
                        showSizeChanger: true,
                        pageSizeOptions: ['10', '20', '30', '40', '50'],
                        onChange: (page: number, pageSize: number) => {
                            setPagination(prev => ({
                                ...prev,
                                current: page,
                                pageSize: pageSize,
                            }));
                            getPlannedOrders(page, pageSize, searchText, statusFilter, productNameFilter, batchNumberFilter);
                        },
                    }}
                />
            </Card>

            {/* View Modal (reuse from process-order-creation) */}
            <ViewProcessOrder
                open={viewModalOpen}
                orderId={selectedOrderId}
                onClose={() => {
                    setViewModalOpen(false);
                    setSelectedOrderId(null);
                }}
            />

            {/* Assign Batch Number Modal */}
            <AssignBatchNumber
                open={assignModalOpen}
                orderData={selectedOrderData}
                onClose={() => {
                    setAssignModalOpen(false);
                    setSelectedOrderData(null);
                }}
                onSuccess={() => {
                    getPlannedOrders(pagination.current, pagination.pageSize, searchText, statusFilter, productNameFilter, batchNumberFilter);
                }}
            />
        </div>
    )
}