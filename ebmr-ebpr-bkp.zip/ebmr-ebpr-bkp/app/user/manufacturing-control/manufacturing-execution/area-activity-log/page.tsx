'use client';

import { Badge, Card, message, Space, Tabs } from "antd";
import { useCallback, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { FaBroom, FaFlask, FaThermometerHalf } from "react-icons/fa";
import CreateActivity from "./components/ActivityEntryModal/CreateActivity";
import UpdateActivity from "./components/ActivityEntryModal/UpdateActivity";
import CreateCleaning from "./components/CleaningEntryModal/CreateCleaning";
import UpdateCleaning from "./components/CleaningEntryModal/UpdateCleaning";
import CreateEnvironmental from "./components/EnvironmentalEntryModal/CreateEnvironmental";
import FacilityToolbar from "./components/FacilityToolbar";
import { useFilteredLogs } from "./components/helpers";
import LogDetailsDrawer from "./components/LogDetailsDrawer";
import LogTable from "./components/LogTable";
import {
  getActivityColumns,
  getCleaningColumns,
  getEnvironmentalColumns,
} from "./components/logColumns";
import PageHeader from "./components/PageHeader";
import StatsCards from "./components/StatsCards";
import { useFacilityLogs } from "./hooks/useFacilityLogs";
import { useAuthorization } from "@/hooks/useAuthorization";
import type {
  ActivityLogEntry,
  CleaningLogEntry,
  EnvironmentalLogEntry,
  FacilityOption,
  LogTabKey,
  SignType,
  ViewLogState,
} from "./types";

const API = {
  activity: "/api/user/manufacturing-control/area-activity-log",
  cleaning: "/api/user/manufacturing-control/cleaning-log",
  environmental: "/api/user/manufacturing-control/environmental-log",
};

const initialModalState = {
  activityCreate: false,
  activityUpdate: false,
  cleaningCreate: false,
  cleaningUpdate: false,
  environmentalCreate: false,
  selectedActivity: null as ActivityLogEntry | null,
  selectedCleaning: null as CleaningLogEntry | null,
};

export default function AreaActivityLogPage() {
  const [selectedFacility, setSelectedFacility] = useState<string | undefined>();
  const [facilityOptions, setFacilityOptions] = useState<FacilityOption[]>([]);
  const [facilitiesLoading, setFacilitiesLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<LogTabKey>("activity");
  const [modalState, setModalState] = useState(initialModalState);
  const [viewLog, setViewLog] = useState<ViewLogState>(null);

  const activityLogs = useFacilityLogs<ActivityLogEntry>(API.activity);
  const cleaningLogs = useFacilityLogs<CleaningLogEntry>(API.cleaning);
  const environmentalLogs = useFacilityLogs<EnvironmentalLogEntry>(API.environmental);

  const { hasAccess } = useAuthorization();
  const canAddEntry = hasAccess("Log Book Entry", "create");

  const refreshLogs = useCallback(() => {
    activityLogs.fetchLogs(selectedFacility);
    cleaningLogs.fetchLogs(selectedFacility);
    environmentalLogs.fetchLogs(selectedFacility);
  }, [activityLogs.fetchLogs, cleaningLogs.fetchLogs, environmentalLogs.fetchLogs, selectedFacility]);

  const fetchFacilities = useCallback(async () => {
    try {
      setFacilitiesLoading(true);
      const response = await fetch("/api/user/master-data/facility-master?limit=100", {
        method: "GET",
        headers: { "Content-Type": "application/json" },
      });
      const data = await response.json();

      if (data.success && Array.isArray(data.facilities)) {
        setFacilityOptions(
          data.facilities.map((facility: { facilityCode: string; areaName: string }) => ({
            label: `${facility.facilityCode} - ${facility.areaName}`,
            value: facility.facilityCode,
            areaName: facility.areaName,
            facilityCode: facility.facilityCode,
          }))
        );
      }
    } catch (error) {
      console.error("Error fetching facilities:", error);
      message.error("Failed to load facilities");
    } finally {
      setFacilitiesLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchFacilities();
  }, [fetchFacilities]);

  useEffect(() => {
    if (selectedFacility) {
      refreshLogs();
    }
  }, [refreshLogs, selectedFacility]);

  const handleSign = useCallback(
    async (
      data: any,
      recordId: string,
      type: SignType,
      endpoint: string,
      refetchFn: () => void
    ) => {
      if (!data) return;

      try {
        const token = localStorage.getItem("token");
        const res = await fetch(endpoint, {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            id: recordId,
            type,
            signatureData: {
              name: data.name,
              designation: data.designation,
              department: data.department,
              signatureId: data.signatureId,
            },
          }),
        });
        const result = await res.json();

        if (!res.ok || !result.success) {
          throw new Error(result.message || "Failed to update signature");
        }

        message.success(`${type === "checkedBy" ? "Checked By" : "Verified By"} signature added!`);
        refetchFn();
      } catch (error) {
        console.error("Error updating signature:", error);
        message.error(error instanceof Error ? error.message : "Failed to update signature");
      }
    },
    []
  );

  const filteredActivityLogs = useFilteredLogs(activityLogs, selectedFacility);
  const filteredCleaningLogs = useFilteredLogs(cleaningLogs, selectedFacility);
  const filteredEnvironmentalLogs = useFilteredLogs(environmentalLogs, selectedFacility);

  const selectedFacilityName = useMemo(() => {
    const facility = facilityOptions.find((option) => option.value === selectedFacility);
    return facility?.areaName || selectedFacility || "";
  }, [facilityOptions, selectedFacility]);

  const handleAddEntry = useCallback(() => {
    if (!selectedFacility) {
      message.warning("Please select a facility first");
      return;
    }

    setModalState((prev) => ({
      ...prev,
      activityCreate: activeTab === "activity" || prev.activityCreate,
      cleaningCreate: activeTab === "cleaning" || prev.cleaningCreate,
      environmentalCreate: activeTab === "environmental" || prev.environmentalCreate,
    }));
  }, [activeTab, selectedFacility]);

  const handleActivitySuccess = useCallback(() => {
    activityLogs.fetchLogs(selectedFacility);
    setModalState((prev) => ({
      ...prev,
      activityCreate: false,
      activityUpdate: false,
      selectedActivity: null,
    }));
  }, [activityLogs.fetchLogs, selectedFacility]);

  const handleCleaningSuccess = useCallback(() => {
    cleaningLogs.fetchLogs(selectedFacility);
    setModalState((prev) => ({
      ...prev,
      cleaningCreate: false,
      cleaningUpdate: false,
      selectedCleaning: null,
    }));
  }, [cleaningLogs.fetchLogs, selectedFacility]);

  const handleEnvironmentalSuccess = useCallback(() => {
    environmentalLogs.fetchLogs(selectedFacility);
    setModalState((prev) => ({ ...prev, environmentalCreate: false }));
  }, [environmentalLogs.fetchLogs, selectedFacility]);

  const activityColumns = useMemo(
    () =>
      getActivityColumns({
        handleSign,
        refetch: () => activityLogs.fetchLogs(selectedFacility),
        onUpdate: (record) =>
          setModalState((prev) => ({
            ...prev,
            activityUpdate: true,
            selectedActivity: record,
          })),
      }),
    [activityLogs.fetchLogs, handleSign, selectedFacility]
  );

  const cleaningColumns = useMemo(
    () =>
      getCleaningColumns({
        handleSign,
        refetch: () => cleaningLogs.fetchLogs(selectedFacility),
        onUpdate: (record) =>
          setModalState((prev) => ({
            ...prev,
            cleaningUpdate: true,
            selectedCleaning: record,
          })),
      }),
    [cleaningLogs.fetchLogs, handleSign, selectedFacility]
  );

  const environmentalColumns = useMemo(
    () =>
      getEnvironmentalColumns({
        handleSign,
        refetch: () => environmentalLogs.fetchLogs(selectedFacility),
      }),
    [environmentalLogs.fetchLogs, handleSign, selectedFacility]
  );

  const tabItems = useMemo(
    () => [
      {
        key: "activity",
        label: (
          <TabLabel icon={<FaFlask />} label="Activity Log" count={filteredActivityLogs.length} color="#1677ff" />
        ),
        children: (
          <LogTable
            columns={activityColumns}
            data={filteredActivityLogs}
            emptyText="No activity logs found"
            loading={activityLogs.loading}
            onView={(record) => setViewLog({ type: "activity", record })}
            selectedFacility={selectedFacility}
          />
        ),
      },
      {
        key: "cleaning",
        label: (
          <TabLabel icon={<FaBroom />} label="Cleaning Log" count={filteredCleaningLogs.length} color="#389e0d" />
        ),
        children: (
          <LogTable
            columns={cleaningColumns}
            data={filteredCleaningLogs}
            emptyText="No cleaning logs found"
            loading={cleaningLogs.loading}
            onView={(record) => setViewLog({ type: "cleaning", record })}
            selectedFacility={selectedFacility}
          />
        ),
      },
      {
        key: "environmental",
        label: (
          <TabLabel
            icon={<FaThermometerHalf />}
            label="Environmental Log"
            count={filteredEnvironmentalLogs.length}
            color="#722ed1"
          />
        ),
        children: (
          <LogTable
            columns={environmentalColumns}
            data={filteredEnvironmentalLogs}
            emptyText="No environmental logs found"
            loading={environmentalLogs.loading}
            onView={(record) => setViewLog({ type: "environmental", record })}
            selectedFacility={selectedFacility}
          />
        ),
      },
    ],
    [
      activityColumns,
      activityLogs.loading,
      cleaningColumns,
      cleaningLogs.loading,
      environmentalColumns,
      environmentalLogs.loading,
      filteredActivityLogs,
      filteredCleaningLogs,
      filteredEnvironmentalLogs,
      selectedFacility,
    ]
  );

  return (
    <div style={{ maxWidth: "100%", padding: 24 }}>
      <PageHeader
        selectedFacility={selectedFacility}
        selectedFacilityName={selectedFacilityName}
      />

      <StatsCards
        activityCount={filteredActivityLogs.length}
        cleaningCount={filteredCleaningLogs.length}
        environmentalCount={filteredEnvironmentalLogs.length}
        loading={activityLogs.loading && cleaningLogs.loading && environmentalLogs.loading}
      />

      <Card bordered={false} style={{ borderRadius: 8 }}>
        <Space direction="vertical" size="large" style={{ width: "100%" }}>
          <FacilityToolbar
            activeTab={activeTab}
            canAddEntry={canAddEntry}
            facilitiesLoading={facilitiesLoading}
            facilityOptions={facilityOptions}
            selectedFacility={selectedFacility}
            onAddEntry={handleAddEntry}
            onRefresh={refreshLogs}
            onSelectFacility={setSelectedFacility}
          />

          <Tabs
            activeKey={activeTab}
            items={tabItems}
            onChange={(key) => setActiveTab(key as LogTabKey)}
            size="large"
            tabBarStyle={{ marginBottom: 16 }}
            type="card"
          />
        </Space>
      </Card>

      <CreateActivity
        open={modalState.activityCreate}
        onClose={() => setModalState((prev) => ({ ...prev, activityCreate: false }))}
        onSuccess={handleActivitySuccess}
        facilityCode={selectedFacility}
      />
      <UpdateActivity
        open={modalState.activityUpdate}
        onClose={() =>
          setModalState((prev) => ({
            ...prev,
            activityUpdate: false,
            selectedActivity: null,
          }))
        }
        onSuccess={handleActivitySuccess}
        record={modalState.selectedActivity}
        facilityCode={selectedFacility}
      />
      <CreateCleaning
        open={modalState.cleaningCreate}
        onClose={() => setModalState((prev) => ({ ...prev, cleaningCreate: false }))}
        onSuccess={handleCleaningSuccess}
        facilityCode={selectedFacility}
      />
      <UpdateCleaning
        open={modalState.cleaningUpdate}
        onClose={() =>
          setModalState((prev) => ({
            ...prev,
            cleaningUpdate: false,
            selectedCleaning: null,
          }))
        }
        onSuccess={handleCleaningSuccess}
        record={modalState.selectedCleaning}
        facilityCode={selectedFacility}
      />
      <CreateEnvironmental
        open={modalState.environmentalCreate}
        onClose={() => setModalState((prev) => ({ ...prev, environmentalCreate: false }))}
        onSuccess={handleEnvironmentalSuccess}
        facilityCode={selectedFacility}
      />
      <LogDetailsDrawer viewLog={viewLog} onClose={() => setViewLog(null)} />
    </div>
  );
}

function TabLabel({
  color,
  count,
  icon,
  label,
}: {
  color: string;
  count: number;
  icon: ReactNode;
  label: string;
}) {
  return (
    <Space>
      {icon}
      <span>{label}</span>
      <Badge count={count} overflowCount={999} style={{ backgroundColor: color }} />
    </Space>
  );
}
