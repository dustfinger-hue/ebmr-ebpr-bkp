export interface SignatureEntry {
  name?: string;
  designation?: string;
  department?: string;
  signatureId?: string;
  signatureHash?: string;
}

export interface ActivityLogEntry {
  _id: string;
  date: string;
  productName: string;
  batchNumber: string;
  startDateTime: string;
  endDateTime?: string;
  status: string;
  activityStartedBy?: SignatureEntry;
  activityStoppedBy?: SignatureEntry;
  checkedBy?: SignatureEntry;
  verifiedBy?: SignatureEntry;
  engagedForActivity?: string;
  remarks?: string;
  facilityCode?: string;
}

export interface CleaningLogEntry {
  _id: string;
  date: string;
  productName?: string;
  batchNo?: string;
  cleaningType: string;
  cleaningMethod: string;
  startDateTime: string;
  endDateTime?: string;
  status: string;
  cleaningStartedBy?: SignatureEntry;
  cleaningStoppedBy?: SignatureEntry;
  checkedBy?: SignatureEntry;
  verifiedBy?: SignatureEntry;
  facilityCode?: string;
}

export interface EnvironmentalLogEntry {
  _id: string;
  dateTime: string;
  differentialPressure?: number;
  temperature?: number;
  humidity?: number;
  particulates?: number;
  luxLevel?: number;
  status: string;
  monitoredBy?: SignatureEntry;
  checkedBy?: SignatureEntry;
  verifiedBy?: SignatureEntry;
  facilityCode?: string;
}

export type FacilityOption = {
  label: string;
  value: string;
  areaName: string;
  facilityCode: string;
};

export type LogTabKey = "activity" | "cleaning" | "environmental";

export type SignType = "checkedBy" | "verifiedBy";

export type LogEntry = ActivityLogEntry | CleaningLogEntry | EnvironmentalLogEntry;

export type ViewLogState =
  | { type: "activity"; record: ActivityLogEntry }
  | { type: "cleaning"; record: CleaningLogEntry }
  | { type: "environmental"; record: EnvironmentalLogEntry }
  | null;
