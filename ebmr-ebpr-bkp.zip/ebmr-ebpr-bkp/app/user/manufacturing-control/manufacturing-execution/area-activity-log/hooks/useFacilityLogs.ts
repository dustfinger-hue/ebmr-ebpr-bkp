import { message } from "antd";
import { useCallback, useState } from "react";

export function useFacilityLogs<T>(baseUrl: string) {
  const [logs, setLogs] = useState<T[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchLogs = useCallback(
    async (facilityCode?: string) => {
      try {
        setLoading(true);
        const token = localStorage.getItem("token");
        const url = facilityCode
          ? `${baseUrl}?facilityCode=${encodeURIComponent(facilityCode)}`
          : baseUrl;

        const res = await fetch(url, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();

        if (data.success) {
          setLogs(data.data || []);
        }
      } catch (error) {
        console.error(`Error fetching logs from ${baseUrl}:`, error);
        message.error("Failed to fetch logs");
      } finally {
        setLoading(false);
      }
    },
    [baseUrl]
  );

  return { logs, setLogs, loading, fetchLogs };
}
