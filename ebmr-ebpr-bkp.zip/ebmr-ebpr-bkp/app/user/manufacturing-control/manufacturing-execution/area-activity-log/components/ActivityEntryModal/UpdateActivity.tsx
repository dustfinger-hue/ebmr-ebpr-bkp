'use client';

import {
  Button,
  Card,
  DatePicker,
  Descriptions,
  Form,
  Input,
  message,
  Modal,
  Space,
  Typography,
  Tag,
  Avatar,
  Divider,
  Row,
  Col,
  Spin,
  Alert,
} from "antd";
import { useCallback, useEffect, useState } from "react";
import dayjs from "dayjs";
import SignButton from "@/components/Role-Based-Signing";
import {
  UserOutlined,
  CheckCircleOutlined,
  SafetyCertificateOutlined,
  ClockCircleOutlined,
  FileTextOutlined,
  DeleteOutlined,
  EyeOutlined,
  EditOutlined,
} from "@ant-design/icons";
import { BiFingerprint } from "react-icons/bi";

const { Text, Title } = Typography;

// ✅ Brand colors
const brandColors = {
  primary: "#6366f1",
  success: "#10b981",
  warning: "#f59e0b",
  error: "#ef4444",
  border: "#e2e8f0",
  background: "#1d2846",
  signatureBg: "#1A1325",
  hashBg: "#111A2C",
};

interface SignatureData {
  signatureId: string;
  name: string;
  designation: string;
  department: string;
  module: string;
  status: string;
  expiresAt: string;
  signatureHash: string;
  signingSequence: number;
  levelOfAuthorization: string;
}

interface ActivityLogRecord {
  _id: string;
  date?: string;
  productName?: string;
  batchNumber?: string;
  startDateTime?: string;
  endDateTime?: string;
  status?: string;
  engagedForActivity?: string;
  remarks?: string;
  facilityCode?: string;
  activityStartedBy?: {
    name?: string;
    designation?: string;
    department?: string;
    signatureId?: string;
  };
  activityStoppedBy?: {
    name?: string;
    designation?: string;
    department?: string;
    signatureId?: string;
  };
}

interface Props {
  open: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  record: ActivityLogRecord | null;
  facilityCode?: string;
}

export default function UpdateActivity({
  open,
  onClose,
  onSuccess,
  record,
  facilityCode,
}: Props) {
  const [form] = Form.useForm();
  const [signatureData, setSignatureData] = useState<SignatureData | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (open && record) {
      form.setFieldsValue({
        endDateTime: record.endDateTime ? dayjs(record.endDateTime) : undefined,
        remarks: record.remarks || "",
      });
      if (record.activityStoppedBy?.signatureId) {
        setSignatureData({
          signatureId: record.activityStoppedBy.signatureId,
          name: record.activityStoppedBy.name || "",
          designation: record.activityStoppedBy.designation || "",
          department: record.activityStoppedBy.department || "",
          module: "logBookEntry",
          status: "signed",
          expiresAt: "",
          signatureHash: "",
          signingSequence: 2,
          levelOfAuthorization: "Stopped By",
        });
      } else {
        setSignatureData(null);
      }
    }
  }, [open, record, form]);

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();

      if (!signatureData) {
        message.error("Please complete the electronic signature first!");
        return;
      }

      if (!record?._id) {
        message.error("Record ID not found!");
        return;
      }

      setSubmitting(true);

      const token = localStorage.getItem("token");

      const payload = {
        id: record._id,
        endDateTime: values.endDateTime?.toISOString(),
        remarks: values.remarks || "",
        activityStoppedBy: {
          name: signatureData.name,
          designation: signatureData.designation,
          department: signatureData.department,
          signatureId: signatureData.signatureId,
        },
      };

      console.log("Updating activity log:", payload);

      const res = await fetch("/api/user/manufacturing-control/area-activity-log", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.message || "Failed to update activity log entry");
      }

      message.success("Activity log entry updated successfully!");
      form.resetFields();
      setSignatureData(null);
      onClose();
      onSuccess?.();
    } catch (error) {
      console.error("Error updating activity log:", error);
      message.error(error instanceof Error ? error.message : "Failed to update activity log entry");
    } finally {
      setSubmitting(false);
    }
  };

  const handleSignComplete = (receivedData: any) => {
    setSignatureData(receivedData);
  };

  const handleRemoveSignature = () => {
    Modal.confirm({
      title: "Remove Electronic Signature",
      content: "Are you sure you want to remove this signature? You will need to sign again.",
      okText: "Yes, Remove",
      cancelText: "Cancel",
      okButtonProps: { danger: true },
      onOk: () => {
        setSignatureData(null);
        message.info("Signature removed. Please sign again to continue.");
      },
    });
  };

  return (
    <Modal
      title={
        <Space>
          <EditOutlined style={{ color: brandColors.primary }} />
          <span style={{ fontSize: 18, fontWeight: 600 }}>Update Activity Log Entry</span>
        </Space>
      }
      open={open}
      onCancel={() => {
        form.resetFields();
        setSignatureData(null);
        onClose();
      }}
      width={800}
      footer={[
        <Button key="cancel" onClick={() => {
          form.resetFields();
          setSignatureData(null);
          onClose();
        }}>
          Cancel
        </Button>,
        <Button
          key="submit"
          type="primary"
          onClick={handleSubmit}
          loading={submitting}
          disabled={!signatureData}
          style={{
            background: !signatureData ? undefined : brandColors.primary,
          }}
        >
          Update Activity Log
        </Button>,
      ]}
    >
      <Form
        form={form}
        layout="vertical"
        initialValues={{
          endDateTime: record?.endDateTime ? dayjs(record.endDateTime) : undefined,
          remarks: record?.remarks || "",
        }}
      >
        {/* ─── Card 1: Record Info (Read-only description) ─── */}
        {record && (
          <Card
            size="small"
            style={{
              marginBottom: 16,
              borderTop: `3px solid ${brandColors.primary}`,
            }}
          >
            <Space style={{ marginBottom: 12 }}>
              <FileTextOutlined style={{ color: brandColors.primary }} />
              <Text strong>Record Information</Text>
            </Space>

            <Descriptions
              size="small"
              bordered
              column={{ xs: 1, sm: 2 }}
            >
              <Descriptions.Item label="Date">
                {record.date ? new Date(record.date).toLocaleDateString() : "-"}
              </Descriptions.Item>
              <Descriptions.Item label="Product Name">
                {record.productName || "-"}
              </Descriptions.Item>
              <Descriptions.Item label="Batch Number">
                <Text strong>{record.batchNumber || "-"}</Text>
              </Descriptions.Item>
              <Descriptions.Item label="Status">
                <Tag color={
                  record.status === "Completed" ? "green" :
                  record.status === "In-Progress" ? "blue" :
                  record.status === "Pending Review" ? "orange" :
                  record.status === "Stopped" ? "red" : "default"
                }>
                  {record.status || "-"}
                </Tag>
              </Descriptions.Item>
              <Descriptions.Item label="Start Date & Time">
                {record.startDateTime ? new Date(record.startDateTime).toLocaleString() : "-"}
              </Descriptions.Item>
              <Descriptions.Item label="Started By">
                {record.activityStartedBy?.name ? (
                  <Space>
                    <UserOutlined />
                    <span>{record.activityStartedBy.name}</span>
                    {record.activityStartedBy.designation && (
                      <Text type="secondary" style={{ fontSize: 12 }}>
                        ({record.activityStartedBy.designation})
                      </Text>
                    )}
                  </Space>
                ) : "-"}
              </Descriptions.Item>
            </Descriptions>
          </Card>
        )}

        {/* ─── Card 2: Update Fields ─── */}
        <Card
          size="small"
          style={{
            marginBottom: 16,
            borderTop: `3px solid ${brandColors.warning}`,
          }}
        >
          <Space style={{ marginBottom: 12 }}>
            <ClockCircleOutlined style={{ color: brandColors.warning }} />
            <Text strong>Update Details</Text>
          </Space>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                label="End Date & Time"
                name="endDateTime"
                rules={[{ required: true, message: "Please select end date & time" }]}
              >
                <DatePicker
                  showTime
                  style={{ width: "100%" }}
                  placeholder="Select end date & time"
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item label="Remarks" name="remarks">
                <Input.TextArea
                  rows={3}
                  placeholder="Enter any remarks or comments"
                />
              </Form.Item>
            </Col>
          </Row>
        </Card>

        {/* ─── Card 3: Electronic Signature ─── */}
        <Card
          size="small"
          style={{ borderTop: `3px solid ${brandColors.success}` }}
        >
          <Space style={{ marginBottom: 12 }}>
            <BiFingerprint style={{ color: brandColors.primary }} />
            <Text strong>Electronic Signature - Stopped By (21 CFR Part 11)</Text>
            {!signatureData && <Tag color="orange">Pending</Tag>}
            {signatureData && <Tag color="success" icon={<CheckCircleOutlined />}>Completed</Tag>}
          </Space>

          <Form.Item
            label="Stopped By"
            required
            validateStatus={signatureData ? "success" : "error"}
            help={
              signatureData ? (
                <span style={{ color: brandColors.success }}>
                  ✓ Electronic signature verified and authenticated
                </span>
              ) : (
                "⚠ Electronic signature required for compliance"
              )
            }
          >
            {signatureData ? (
              // Signature Success UI (same style as CreateActivity)
              <div
                style={{
                  padding: "20px",
                  borderRadius: 8,
                  border: `1px solid ${brandColors.success}20`,
                  background: brandColors.signatureBg,
                }}
              >
                <div style={{ display: "flex", alignItems: "flex-start", gap: 16 }}>
                  <Avatar
                    size={48}
                    icon={<UserOutlined />}
                    style={{ background: brandColors.success }}
                  />
                  <div style={{ flex: 1 }}>
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        marginBottom: 12,
                        flexWrap: "wrap",
                        gap: 8,
                      }}
                    >
                      <Space size="middle" wrap>
                        <Text strong style={{ fontSize: 16 }}>
                          {signatureData.name}
                        </Text>
                        <Tag color="success" icon={<CheckCircleOutlined />}>
                          Signed
                        </Tag>
                        <Text type="secondary">
                          Level: {signatureData.levelOfAuthorization}
                        </Text>
                      </Space>
                      <Button
                        type="text"
                        icon={<DeleteOutlined />}
                        danger
                        onClick={handleRemoveSignature}
                        size="small"
                      >
                        Remove
                      </Button>
                    </div>

                    <Row gutter={16} style={{ marginBottom: 12 }}>
                      <Col span={12}>
                        <Text type="secondary" style={{ fontSize: 12 }}>
                          Designation
                        </Text>
                        <div style={{ fontWeight: 500 }}>{signatureData.designation}</div>
                      </Col>
                      <Col span={12}>
                        <Text type="secondary" style={{ fontSize: 12 }}>
                          Department
                        </Text>
                        <div style={{ fontWeight: 500 }}>{signatureData.department}</div>
                      </Col>
                    </Row>

                    <Divider style={{ margin: "12px 0" }} />

                    <Row gutter={16} style={{ marginBottom: 12 }}>
                      <Col span={8}>
                        <Text type="secondary" style={{ fontSize: 12 }}>
                          Signature ID
                        </Text>
                        <div>
                          <Text code style={{ fontSize: 11, color: brandColors.primary }}>
                            {signatureData.signatureId?.slice(0, 16)}...
                          </Text>
                        </div>
                      </Col>
                      <Col span={8}>
                        <Text type="secondary" style={{ fontSize: 12 }}>
                          Sequence
                        </Text>
                        <div>
                          <Tag>#{signatureData.signingSequence}</Tag>
                        </div>
                      </Col>
                      <Col span={8}>
                        <Text type="secondary" style={{ fontSize: 12 }}>
                          Signed
                        </Text>
                        <div>{new Date().toLocaleString()}</div>
                      </Col>
                    </Row>

                    {signatureData.signatureHash && (
                      <div
                        style={{
                          background: brandColors.hashBg,
                          borderRadius: 6,
                          padding: "10px 14px",
                          border: `1px solid ${brandColors.border}`,
                        }}
                      >
                        <Text type="secondary" style={{ fontSize: 12 }}>
                          Signature Hash (SHA-256)
                        </Text>
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            gap: 8,
                            flexWrap: "wrap",
                            marginTop: 4,
                          }}
                        >
                          <Text
                            code
                            style={{
                              fontSize: 11,
                              wordBreak: "break-all",
                              color: brandColors.primary,
                            }}
                          >
                            {signatureData.signatureHash.slice(0, 50)}...
                          </Text>
                          <Button
                            type="link"
                            size="small"
                            icon={<EyeOutlined />}
                            onClick={() => {
                              Modal.info({
                                title: "Full Signature Hash",
                                content: signatureData.signatureHash,
                                width: 600,
                              });
                            }}
                          >
                            View Full
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <SignButton
                  module="logBookEntry"
                  levelOfAuthorization="Stopped By"
                  sequence={2}
                  onSignComplete={handleSignComplete}
                  disableProp={false}
                />
                <div style={{ marginTop: 12, padding: "8px 0", borderRadius: 6 }}>
                  <Tag color="blue" icon={<SafetyCertificateOutlined />} variant="outlined" style={{ fontSize: 12 }}>
                    This electronic signature is legally equivalent to a handwritten signature under 21 CFR Part 11
                  </Tag>
                </div>
              </div>
            )}
          </Form.Item>
        </Card>
      </Form>
    </Modal>
  );
}