'use client';

import {
  AutoComplete,
  Button,
  Card,
  DatePicker,
  Form,
  Input,
  message,
  Modal,
  Select,
  Typography,
  Spin,
  Tag,
  Space,
  Avatar,
  Divider,
  Row,
  Col,
} from "antd";
import { use, useCallback, useEffect, useRef, useState } from "react";
import dayjs from "dayjs";
import SignButton from "@/components/Role-Based-Signing";
import {
  UserOutlined,
  CheckCircleOutlined,
  SafetyCertificateOutlined,
  ClockCircleOutlined,
  FileTextOutlined,
  DeleteOutlined,
  EyeOutlined,

} from "@ant-design/icons";
import { BiFingerprint } from "react-icons/bi";

const { Text } = Typography;

// ✅ Brand colors - theme independent
const brandColors = {
  primary: "#6366f1",     // Indigo
  success: "#10b981",     // Emerald  
  warning: "#f59e0b",     // Amber
  error: "#ef4444",        // Red
  border: "#e2e8f0",      // Slate
  background: "#1d2846",   // Slate light
  signatureBg: "#1A1325",  // Emerald light
  hashBg: "#111A2C",       // Slate light
};

interface IssuedBatch {
  _id: string;
  batchNumber: string;
  productName: string;
}

interface SignatureData {
  signatureId: string;
  name: string;
  designation: string;
  department: string;
  module: string;
  status: string;
  expiresAt: string;
  signatureHash: string;
  signingSequence: number;
  levelOfAuthorization: string;
  userId: string;
}

interface Props {
  open: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  facilityId?: string;
  facilityCode?: string;
  areaName?: string;
  department?: string;
  areaType?: string;
}

export default function CreateActivity({
  open,
  onClose,
  onSuccess,
  facilityId,
  facilityCode,
  areaName,
  department,
  areaType,
}: Props) {
  const [form] = Form.useForm();
  const [batchInputValue, setBatchInputValue] = useState("");
  const [isCheckingBatch, setIsCheckingBatch] = useState(false);
  const [batchNotFound, setBatchNotFound] = useState(false);
  const [foundBatch, setFoundBatch] = useState<IssuedBatch | null>(null);
  const [suggestions, setSuggestions] = useState<IssuedBatch[]>([]);
  const [signatureData, setSignatureData] = useState<SignatureData | null>(null);
  const [buttonDisabled, setButtonDisabled] = useState(true);

  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const searchDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (open) {
      form.setFieldsValue({
        date: dayjs(),
        status: "In-Progress",
      });
      setBatchInputValue("");
      setBatchNotFound(false);
      setFoundBatch(null);
      setSuggestions([]);
      setSignatureData(null);
    }
  }, [open, form]);

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();

      if (!signatureData) {
        message.error("Please complete the electronic signature first!");
        return;
      }

      const token = localStorage.getItem("token");

      const payload = {
        date: values.date.toISOString(),
        productName: values.productName,
        batchNumber: values.batchNumber,
        startDateTime: values.activityStartTimeDate.toISOString(),
        status: values.status,
        activityStartedBy: {
          name: signatureData.name,
          designation: signatureData.designation,
          department: signatureData.department,
          signatureId: signatureData.signatureId,
          userId: signatureData.userId,
        },
        facilityCode: facilityCode || "",
        engagedForActivity: values.productName,
      };
      console.log("Submitting payload:", payload);

      const res = await fetch("/api/user/manufacturing-control/area-activity-log", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.message || "Failed to create activity log entry");
      }

      message.success("Activity log entry added successfully!");
      form.resetFields();
      setSignatureData(null);
      onClose();
      onSuccess?.();
    } catch (error) {
      console.error("Error submitting activity log:", error);
      message.error(error instanceof Error ? error.message : "Failed to create activity log entry");
    }
  };

  const fetchSuggestions = useCallback(async (value: string) => {
    if (value.trim().length < 2) {
      setSuggestions([]);
      return;
    }

    try {
      const token = localStorage.getItem("token");
      const res = await fetch(
        `/api/user/manufacturing-control/area-activity-log?search=${encodeURIComponent(value.trim())}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const data = await res.json();
      if (data.success) {
        setSuggestions(data.data || []);
      }
    } catch {
      // silently fail
    }
  }, []);

  const checkBatchExistence = useCallback(async (value: string) => {
    if (!value.trim()) {
      setBatchNotFound(false);
      setFoundBatch(null);
      form.setFieldsValue({ productName: undefined });
      return;
    }

    setIsCheckingBatch(true);
    setBatchNotFound(false);
    setFoundBatch(null);
    form.setFieldsValue({ productName: undefined });

    try {
      const token = localStorage.getItem("token");
      const res = await fetch(
        `/api/user/manufacturing-control/area-activity-log?batchNumber=${encodeURIComponent(value.trim())}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const data = await res.json();

      if (data.success && data.exists) {
        setFoundBatch(data.data);
        form.setFieldsValue({ productName: data.data.productName });
        setBatchNotFound(false);
      } else {
        setFoundBatch(null);
        form.setFieldsValue({ productName: undefined });
        setBatchNotFound(true);
      }
    } catch {
      setBatchNotFound(false);
      setFoundBatch(null);
    } finally {
      setIsCheckingBatch(false);
    }
  }, [form]);

  const handleBatchSearch = (value: string) => {
    setBatchInputValue(value);

    if (searchDebounceRef.current) {
      clearTimeout(searchDebounceRef.current);
    }
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }

    const debounceMs = value.trim().length < 2 ? 500 : 800;

    searchDebounceRef.current = setTimeout(() => {
      fetchSuggestions(value);
    }, debounceMs);

    debounceRef.current = setTimeout(() => {
      if (value.trim().length >= 2) {
        form.setFieldsValue({ batchNumber: value });
        checkBatchExistence(value);
      }
    }, debounceMs);
  };

  const handleFieldsChange = () => {
    const batchValue = form.getFieldValue('batchNumber');
    const productValue = form.getFieldValue('productName');
    const startTimeValue = form.getFieldValue('activityStartTimeDate');

    if (batchValue && productValue && startTimeValue && batchValue === batchInputValue) {
      setButtonDisabled(false);
    } else {
      setButtonDisabled(true);
    }
  };

  const handleBatchSelect = (value: string) => {
    const selected = suggestions.find((s) => s.batchNumber === value);
    if (selected) {
      setBatchInputValue(selected.batchNumber);
      setFoundBatch(selected);
      form.setFieldsValue({
        batchNumber: selected.batchNumber,
        productName: selected.productName,
      });
      setBatchNotFound(false);
      setSuggestions([]);
    }
  };

  const autoCompleteOptions = suggestions.map((s) => ({
    value: s.batchNumber,
    label: (
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
        <span style={{ fontWeight: 500 }}>{s.batchNumber}</span>
        <span style={{ color: "#64748b" }}>{s.productName}</span>
      </div>
    ),
  }));

  const handleSignComplete = (receivedData: any) => {
    setSignatureData(receivedData);
  };

  const handleRemoveSignature = () => {
    Modal.confirm({
      title: "Remove Electronic Signature",
      content: "Are you sure you want to remove this signature? You will need to sign again.",
      okText: "Yes, Remove",
      cancelText: "Cancel",
      okButtonProps: { danger: true },
      onOk: () => {
        setSignatureData(null);
        message.info("Signature removed. Please sign again to continue.");
      },
    });
  };

  useEffect(() => {
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
      if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
    };
  }, []);

  return (
    <Modal
      title={
        <Space>
          <SafetyCertificateOutlined style={{ color: brandColors.primary }} />
          <span style={{ fontSize: 18, fontWeight: 600 }}>Create Activity Log Entry</span>
        </Space>
      }
      open={open}
      onCancel={() => {
        form.resetFields();
        setSignatureData(null);
        onClose();
      }}
      width={800}
      footer={[
        <Button key="cancel" onClick={() => {
          form.resetFields();
          setSignatureData(null);
          onClose();
        }}>
          Cancel
        </Button>,
        <Button
          key="submit"
          type="primary"
          onClick={handleSubmit}
          disabled={!signatureData}
          style={{
            background: !signatureData ? undefined : brandColors.primary,
          }}
        >
          Submit Activity Log
        </Button>,
      ]}
    >
      <Spin spinning={isCheckingBatch}>
        <Form
          form={form}
          layout="vertical"
          initialValues={{ status: "In-Progress", date: dayjs() }}
          onFieldsChange={handleFieldsChange}
        >
          {/* Batch Information Section */}
          <Card
            size="small"
            style={{ marginBottom: 16, borderTop: `3px solid ${brandColors.primary}` }}
          >
            <Space style={{ marginBottom: 16 }}>
              <FileTextOutlined style={{ color: brandColors.primary }} />
              <Text strong>Batch Information</Text>
              <Tag color="orange">Required</Tag>
            </Space>

            <Row gutter={16}>
              <Col span={12}>
                <Form.Item
                  label="Date"
                  name="date"
                  rules={[{ required: true, message: "Required" }]}
                >
                  <DatePicker style={{ width: "100%" }} disabled />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  label="Batch Number"
                  name="batchNumber"
                  rules={[{ required: true, message: "Please enter or select a batch" }]}
                  validateStatus={batchNotFound ? "error" : undefined}
                  help={
                    batchNotFound ? (
                      "Batch does not exist in issued batches"
                    ) : foundBatch ? (
                      <span style={{ color: brandColors.success }}>
                        ✓ Batch verified — {foundBatch.productName}
                      </span>
                    ) : undefined
                  }
                >
                  <AutoComplete
                    value={batchInputValue}
                    options={autoCompleteOptions}
                    onSearch={handleBatchSearch}
                    onSelect={handleBatchSelect}
                    style={{ width: "100%" }}
                  >
                    <Input
                      placeholder="Type batch number (min 2 chars)"
                      suffix={
                        isCheckingBatch ? (
                          <Spin size="small" />
                        ) : foundBatch ? (
                          <CheckCircleOutlined style={{ color: brandColors.success }} />
                        ) : undefined
                      }
                      status={batchNotFound ? "error" : undefined}
                    />
                  </AutoComplete>
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  label="Product Name"
                  name="productName"
                  rules={[{ required: true, message: "Required" }]}
                >
                  <Input placeholder="Auto-filled from batch" disabled />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  label="Activity Start Time"
                  name="activityStartTimeDate"
                  rules={[{ required: true, message: "Required" }]}
                >
                  <DatePicker
                    showTime
                    style={{ width: "100%" }}
                    placeholder="Select start date & time"
                  />
                </Form.Item>
              </Col>
            </Row>
          </Card>

          {/* Execution Details Section */}
          <Card
            size="small"
            style={{ marginBottom: 16, borderTop: `3px solid ${brandColors.warning}` }}
          >
            <Space style={{ marginBottom: 16 }}>
              <ClockCircleOutlined style={{ color: brandColors.warning }} />
              <Text strong>Execution Details</Text>
            </Space>

            <Row gutter={16}>
              <Col span={12}>
                <Form.Item
                  label="Status"
                  name="status"
                  rules={[{ required: true, message: "Required" }]}
                >
                  <Select
                    options={[
                      { label: "In-Progress", value: "In-Progress" },
                      { label: "Completed", value: "Completed" },
                      { label: "Pending Review", value: "Pending Review" },
                      { label: "Stopped", value: "Stopped" },
                    ]}
                  />
                </Form.Item>
              </Col>
            </Row>
          </Card>

          {/* Electronic Signature Section */}
          <Card
            size="small"
            style={{ borderTop: `3px solid ${brandColors.success}` }}
          >
            <Space style={{ marginBottom: 16 }}>
              <BiFingerprint style={{ color: brandColors.primary }} />
              <Text strong>Electronic Signature (21 CFR Part 11 Compliant)</Text>
              {!signatureData && <Tag color="orange">Pending</Tag>}
              {signatureData && <Tag color="success" icon={<CheckCircleOutlined />}>Completed</Tag>}
            </Space>

            <Form.Item
              label="Performed By"
              required
              validateStatus={signatureData ? "success" : "error"}
              help={
                signatureData ? (
                  <span style={{ color: brandColors.success }}>
                    ✓ Electronic signature verified and authenticated
                  </span>
                ) : (
                  "⚠ Electronic signature required for compliance"
                )
              }
            >
              {signatureData ? (
                // Signature Success UI
                <div
                  style={{
                    padding: "20px",
                    borderRadius: 8,
                    border: `1px solid ${brandColors.success}20`,
                    background: brandColors.signatureBg,
                  }}
                >
                  <div style={{ display: "flex", alignItems: "flex-start", gap: 16 }}>
                    <Avatar
                      size={48}
                      icon={<UserOutlined />}
                      style={{ background: brandColors.success }}
                    />
                    <div style={{ flex: 1 }}>
                      <div
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                          marginBottom: 12,
                          flexWrap: "wrap",
                          gap: 8,
                        }}
                      >
                        <Space size="middle" wrap>
                          <Text strong style={{ fontSize: 16 }}>
                            {signatureData.name}
                          </Text>
                          <Tag color="success" icon={<CheckCircleOutlined />}>
                            Signed
                          </Tag>
                          <Text type="secondary">
                            Level: {signatureData.levelOfAuthorization}
                          </Text>
                        </Space>
                        <Button
                          type="text"
                          icon={<DeleteOutlined />}
                          danger
                          onClick={handleRemoveSignature}
                          size="small"
                        >
                          Remove
                        </Button>
                      </div>

                      <Row gutter={16} style={{ marginBottom: 12 }}>
                        <Col span={12}>
                          <Text type="secondary" style={{ fontSize: 12 }}>
                            Designation
                          </Text>
                          <div style={{ fontWeight: 500 }}>{signatureData.designation}</div>
                        </Col>
                        <Col span={12}>
                          <Text type="secondary" style={{ fontSize: 12 }}>
                            Department
                          </Text>
                          <div style={{ fontWeight: 500 }}>{signatureData.department}</div>
                        </Col>
                      </Row>

                      <Divider style={{ margin: "12px 0" }} />

                      <Row gutter={16} style={{ marginBottom: 12 }}>
                        <Col span={8}>
                          <Text type="secondary" style={{ fontSize: 12 }}>
                            Signature ID
                          </Text>
                          <div>
                            <Text code style={{ fontSize: 11, color: brandColors.primary }}>
                              {signatureData.signatureId.slice(0, 16)}...
                            </Text>
                          </div>
                        </Col>
                        <Col span={8}>
                          <Text type="secondary" style={{ fontSize: 12 }}>
                            Sequence
                          </Text>
                          <div>
                            <Tag>#{signatureData.signingSequence}</Tag>
                          </div>
                        </Col>
                        <Col span={8}>
                          <Text type="secondary" style={{ fontSize: 12 }}>
                            Signed
                          </Text>
                          <div>{new Date().toLocaleString()}</div>
                        </Col>
                      </Row>

                      <div
                        style={{
                          background: brandColors.hashBg,
                          borderRadius: 6,
                          padding: "10px 14px",
                          border: `1px solid ${brandColors.border}`,
                        }}
                      >
                        <Text type="secondary" style={{ fontSize: 12 }}>
                          Signature Hash (SHA-256)
                        </Text>
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            gap: 8,
                            flexWrap: "wrap",
                            marginTop: 4,
                          }}
                        >
                          <Text
                            code
                            style={{
                              fontSize: 11,
                              wordBreak: "break-all",
                              color: brandColors.primary,
                            }}
                          >
                            {signatureData.signatureHash.slice(0, 50)}...
                          </Text>
                          <Button
                            type="link"
                            size="small"
                            icon={<EyeOutlined />}
                            onClick={() => {
                              Modal.info({
                                title: "Full Signature Hash",
                                content: signatureData.signatureHash,
                                width: 600,
                              });
                            }}
                          >
                            View Full
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                // Sign Button UI
                <div>
                  <SignButton
                    module="logBookEntry"
                    levelOfAuthorization="Performed By"
                    sequence={1}
                    onSignComplete={handleSignComplete}
                    disableProp={buttonDisabled}
                  />
                  <div style={{ marginTop: 12, padding: "8px 0x", borderRadius: 6 }}>
                    <Tag color="blue" icon={<SafetyCertificateOutlined />} variant="outlined" style={{ fontSize: 12 }}>
                      This electronic signature is legally equivalent to a handwritten signature under 21 CFR Part 11
                    </Tag>
                  </div>
                </div>
              )}
            </Form.Item>
          </Card>
        </Form>
      </Spin>
    </Modal>
  );
}
