import { Empty, Skeleton, Table } from "antd";
import type { TableProps } from "antd";

type LogTableProps<T extends { _id: string }> = {
  columns: TableProps<T>["columns"];
  data: T[];
  emptyText: string;
  loading: boolean;
  onView?: (record: T) => void;
  selectedFacility?: string;
};

export default function LogTable<T extends { _id: string }>({
  columns,
  data,
  emptyText,
  loading,
  onView,
  selectedFacility,
}: LogTableProps<T>) {
  if (loading) {
    return <Skeleton active paragraph={{ rows: 8 }} />;
  }

  if (!data.length) {
    return (
      <Empty
        description={`${emptyText}${selectedFacility ? " for this facility" : ""}`}
      />
    );
  }

  return (
    <Table<T>
      bordered
      columns={columns}
      dataSource={data}
      loading={loading}
      pagination={{
        pageSize: 10,
        showSizeChanger: true,
        pageSizeOptions: ["10", "20", "50", "100"],
        showTotal: (total, range) => `${range[0]}-${range[1]} of ${total} entries`,
      }}
      rowKey="_id"
      onRow={(record) => ({
        onClick: (event) => {
          const target = event.target as HTMLElement;
          if (target.closest("button,a,input,textarea,.ant-select,.ant-dropdown,.ant-picker")) {
            return;
          }
          onView?.(record);
        },
        style: onView ? { cursor: "pointer" } : undefined,
      })}
      scroll={{ x: "max-content" }}
      size="small"
    />
  );
}
