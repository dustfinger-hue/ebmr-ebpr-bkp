import { Space, Typography } from "antd";

const { Text } = Typography;

export default function TimelineCell({
  start,
  end,
}: {
  start?: string;
  end?: string;
}) {
  return (
    <Space direction="vertical" size={0}>
      <Text strong>
        {start
          ? new Date(start).toLocaleString()
          : "-"}
      </Text>

      <Text type="secondary">
        {end
          ? new Date(end).toLocaleString()
          : "Running"}
      </Text>
    </Space>
  );
}