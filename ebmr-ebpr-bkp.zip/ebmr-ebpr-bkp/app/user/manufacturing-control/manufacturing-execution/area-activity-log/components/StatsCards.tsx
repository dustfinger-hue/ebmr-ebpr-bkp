import { Card, Col, Row, Skeleton, Statistic } from "antd";
import { ExperimentOutlined, ClockCircleOutlined } from "@ant-design/icons";
import { FaBroom } from "react-icons/fa";

type StatsCardsProps = {
  activityCount: number;
  cleaningCount: number;
  environmentalCount: number;
  loading: boolean;
};

export default function StatsCards({
  activityCount,
  cleaningCount,
  environmentalCount,
  loading,
}: StatsCardsProps) {
  if (loading) {
    return (
      <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
        {[1, 2, 3].map((i) => (
          <Col xs={24} md={8} key={i}>
            <Card>
              <Skeleton active paragraph={{ rows: 1 }} />
            </Card>
          </Col>
        ))}
      </Row>
    );
  }

  return (
    <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
      <Col xs={24} md={8}>
        <Card
          styles={{ body: { padding: '20px 24px' } }}
        >
          <Statistic
            title="Activity Logs"
            value={activityCount}
            prefix={<ExperimentOutlined style={{ color: "#1677ff" }} />}
            valueStyle={{ color: "#1677ff" }}
          />
        </Card>
      </Col>
      <Col xs={24} md={8}>
        <Card
          styles={{ body: { padding: '20px 24px' } }}
        >
          <Statistic
            title="Cleaning Logs"
            value={cleaningCount}
            prefix={<FaBroom style={{ color: "#389e0d" }} />}
            valueStyle={{ color: "#389e0d" }}
          />
        </Card>
      </Col>
      <Col xs={24} md={8}>
        <Card
          styles={{ body: { padding: '20px 24px' } }}
        >
          <Statistic
            title="Environmental Logs"
            value={environmentalCount}
            prefix={<ClockCircleOutlined style={{ color: "#722ed1" }} />}
            valueStyle={{ color: "#722ed1" }}
          />
        </Card>
      </Col>
    </Row>
  );
}