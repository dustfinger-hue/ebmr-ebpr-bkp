import { Button, Space, Tooltip, Typography } from "antd";
import { CheckCircleOutlined, SafetyCertificateOutlined } from "@ant-design/icons";
import RoleBasedSigning from "@/components/Role-Based-Signing";
import type { SignatureEntry, SignType } from "../../types";

const { Text } = Typography;

type SignatureCellProps = {
  signature?: SignatureEntry;
  recordId: string;
  status: string;
  type: SignType;
  checkedByName?: string;
  onSign: (data: any, id: string, type: SignType) => Promise<void>;
};

export default function SignatureCell({
  signature,
  recordId,
  status,
  type,
  checkedByName,
  onSign,
}: SignatureCellProps) {
  if (signature?.name) {
    return (
      <Space size={6}>
        <CheckCircleOutlined style={{ color: "#52c41a" }} />
        <span>{signature.name}</span>
      </Space>
    );
  }

  if (!["Completed", "Within Limit"].includes(status)) {
    return <Text type="secondary">-</Text>;
  }

  if (type === "verifiedBy" && !checkedByName) {
    return (
      <Tooltip title="Checked By signature is required first">
        <Button size="small" disabled icon={<SafetyCertificateOutlined />}>
          Wait Checked By
        </Button>
      </Tooltip>
    );
  }

  return (
    <RoleBasedSigning
      module="logBookEntry"
      levelOfAuthorization={type === "checkedBy" ? "Checked By" : "Verified By"}
      sequence={type === "checkedBy" ? 3 : 4}
      onSignComplete={(data) => onSign(data, recordId, type)}
      disableProp={false}
    />
  );
}
