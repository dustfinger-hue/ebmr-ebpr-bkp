'use client';

import {
  Button,
  Card,
  DatePicker,
  Form,
  InputNumber,
  message,
  Modal,
  Select,
  Space,
  Typography,
  Tag,
  Avatar,
  Divider,
  Row,
  Col,
  Tooltip,
} from "antd";
import dayjs from "dayjs";
import { useEffect, useMemo, useState } from "react";
import SignButton from "@/components/Role-Based-Signing";
import {
  DEFAULT_ENVIRONMENTAL_RANGES,
  STATUS_THRESHOLDS,
  ENVIRONMENTAL_STATUS,
} from "@/lib/constants/EnvironmentalRanges";
import {
  UserOutlined,
  CheckCircleOutlined,
  SafetyCertificateOutlined,
  DeleteOutlined,
  EyeOutlined,
  CloudServerOutlined,
  InfoCircleOutlined,
} from "@ant-design/icons";

const { Text } = Typography;

const brandColors = {
  primary: "#6366f1",
  success: "#10b981",
  warning: "#f59e0b",
  error: "#ef4444",
  border: "#e2e8f0",
  signatureBg: "#1A1325",
  hashBg: "#111A2C",
};

interface SignatureData {
  signatureId: string;
  name: string;
  designation: string;
  department: string;
  module: string;
  status: string;
  expiresAt: string;
  signatureHash: string;
  signingSequence: number;
  levelOfAuthorization: string;
}

interface FacilityLimits {
  differentialPressure?: { min?: number; max?: number };
  temperature?: { min?: number; max?: number };
  humidity?: { min?: number; max?: number };
  particulates?: { max?: number };
  luxLevel?: { min?: number; max?: number };
}

interface Props {
  open: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  facilityCode?: string;
}

const statusOptions = [
  { label: "Within Limit", value: "Within Limit" },
  { label: "Warning", value: "Warning" },
  { label: "Alarm", value: "Alarm" },
];

// Get effective range: facility data if available, otherwise default
const getEffectiveRange = (
  field: keyof typeof DEFAULT_ENVIRONMENTAL_RANGES,
  facilityLimits: FacilityLimits
): { min: number; max: number; unit: string } => {
  const defaultRange = DEFAULT_ENVIRONMENTAL_RANGES[field];
  const facilityField = facilityLimits[field] as { min?: number; max?: number } | undefined;

  if (!facilityField) return defaultRange;

  return {
    min: facilityField.min ?? defaultRange.min,
    max: facilityField.max ?? defaultRange.max,
    unit: defaultRange.unit,
  };
};

// Calculate status for a single value against a range
const calculateFieldStatus = (
  value: number | undefined,
  range: { min: number; max: number }
): string | null => {
  if (value === undefined || value === null || isNaN(value)) return null;

  const { min, max } = range;
  const span = max - min;
  if (span <= 0) return ENVIRONMENTAL_STATUS.WITHIN_LIMIT;

  const warningMargin = span * (STATUS_THRESHOLDS.warningDeviationPercent / 100);
  const alarmMargin = span * (STATUS_THRESHOLDS.alarmDeviationPercent / 100);

  const warningMin = min - warningMargin;
  const warningMax = max + warningMargin;
  const alarmMin = min - alarmMargin;
  const alarmMax = max + alarmMargin;

  if (value >= alarmMin && value <= alarmMax) {
    // Within alarm range
    if (value >= min && value <= max) {
      return ENVIRONMENTAL_STATUS.WITHIN_LIMIT;
    }
    return ENVIRONMENTAL_STATUS.WARNING;
  }
  // Outside alarm range
  return ENVIRONMENTAL_STATUS.ALARM;
};

// Get color for status
const getStatusColor = (status: string | null) => {
  switch (status) {
    case ENVIRONMENTAL_STATUS.WITHIN_LIMIT: return brandColors.success;
    case ENVIRONMENTAL_STATUS.WARNING: return brandColors.warning;
    case ENVIRONMENTAL_STATUS.ALARM: return brandColors.error;
    default: return undefined;
  }
};

export default function CreateEnvironmental({ open, onClose, onSuccess, facilityCode }: Props) {
  const [form] = Form.useForm();
  const [signatureData, setSignatureData] = useState<SignatureData | null>(null);
  const [facilityLimits, setFacilityLimits] = useState<FacilityLimits>({});

  // Fetch facility limits when modal opens
  useEffect(() => {
    if (open && facilityCode) {
      fetch(`/api/user/master-data/facility-master?facilityCode=${facilityCode}`)
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            const facility = data.facilities[0];
            setFacilityLimits({
              differentialPressure: {
                min: facility.differentialPressureMin,
                max: facility.differentialPressureMax,
              },
              temperature: {
                min: facility.temperatureMin,
                max: facility.temperatureMax,
              },
              humidity: {
                min: facility.humidityMin,
                max: facility.humidityMax,
              },
              particulates: {
                max: facility.particulatesMax,
              },
              luxLevel: {
                min: facility.luxLevelMin,
                max: facility.luxLevelMax,
              },
            });
          }
        })
        .catch(err => {
          console.error('Error fetching facility limits:', err);
          // Fall back to defaults (empty object)
          setFacilityLimits({});
        });
    }
  }, [open, facilityCode]);


  // Handler for form value changes to auto-calculate status
  const handleValuesChange = (_: any, allValues: any) => {
    const fields: (keyof typeof DEFAULT_ENVIRONMENTAL_RANGES)[] = [
      'differentialPressure',
      'temperature',
      'humidity',
      'particulates',
      'luxLevel',
    ];

    let hasWarning = false;
    let hasAlarm = false;
    let hasAnyValue = false;

    for (const field of fields) {
      const value = allValues[field] as number | undefined;
      if (value === undefined || value === null || isNaN(value)) continue;
      hasAnyValue = true;

      const range = getEffectiveRange(field, facilityLimits);
      const fieldStatus = calculateFieldStatus(value, range);

      if (fieldStatus === ENVIRONMENTAL_STATUS.ALARM) {
        hasAlarm = true;
      } else if (fieldStatus === ENVIRONMENTAL_STATUS.WARNING) {
        hasWarning = true;
      }
    }

    if (!hasAnyValue) {
      form.setFieldsValue({ status: ENVIRONMENTAL_STATUS.WITHIN_LIMIT });
      return;
    }

    if (hasAlarm) {
      form.setFieldsValue({ status: ENVIRONMENTAL_STATUS.ALARM });
    } else if (hasWarning) {
      form.setFieldsValue({ status: ENVIRONMENTAL_STATUS.WARNING });
    } else {
      form.setFieldsValue({ status: ENVIRONMENTAL_STATUS.WITHIN_LIMIT });
    }
  };

  useEffect(() => {
    if (open) {
      form.setFieldsValue({ dateTime: dayjs() });
      setSignatureData(null);
      setFacilityLimits({});
    }
  }, [open, form]);

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();

      if (!signatureData) {
        message.error("Please complete the electronic signature first!");
        return;
      }

      const token = localStorage.getItem("token");

      const payload = {
        dateTime: values.dateTime.toISOString(),
        differentialPressure: values.differentialPressure,
        temperature: values.temperature,
        humidity: values.humidity,
        particulates: values.particulates,
        luxLevel: values.luxLevel,
        status: values.status || "Within Limit",
        facilityCode: facilityCode || "",
        monitoredBy: {
          name: signatureData.name,
          designation: signatureData.designation,
          department: signatureData.department,
          signatureId: signatureData.signatureId,
        },
      };

      console.log("Submitting environmental log:", payload);

      const res = await fetch("/api/user/manufacturing-control/environmental-log", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.message || "Failed to create environmental log entry");
      }

      message.success("Environmental log entry added successfully!");
      form.resetFields();
      setSignatureData(null);
      onClose();
      onSuccess?.();
    } catch (error) {
      console.error("Error submitting environmental log:", error);
      message.error(error instanceof Error ? error.message : "Failed to create environmental log entry");
    }
  };

  const handleSignComplete = (receivedData: any) => {
    setSignatureData(receivedData);
  };

  const handleRemoveSignature = () => {
    Modal.confirm({
      title: "Remove Electronic Signature",
      content: "Are you sure you want to remove this signature? You will need to sign again.",
      okText: "Yes, Remove",
      cancelText: "Cancel",
      okButtonProps: { danger: true },
      onOk: () => {
        setSignatureData(null);
        message.info("Signature removed. Please sign again to continue.");
      },
    });
  };

  // Pre-compute ranges for display
  const ranges = useMemo(() => ({
    differentialPressure: getEffectiveRange('differentialPressure', facilityLimits),
    temperature: getEffectiveRange('temperature', facilityLimits),
    humidity: getEffectiveRange('humidity', facilityLimits),
    particulates: getEffectiveRange('particulates', facilityLimits),
    luxLevel: getEffectiveRange('luxLevel', facilityLimits),
  }), [facilityLimits]);

  // Get status badge color for current status value
  const currentStatus = Form.useWatch('status', form);

  return (
    <Modal
      title={
        <Space>
          <CloudServerOutlined style={{ color: brandColors.primary }} />
          <span style={{ fontSize: 18, fontWeight: 600 }}>Add Environmental Log Entry</span>
        </Space>
      }
      open={open}
      onCancel={() => {
        form.resetFields();
        setSignatureData(null);
        onClose();
      }}
      width={800}
      footer={[
        <Button key="cancel" onClick={() => { form.resetFields(); setSignatureData(null); onClose(); }}>
          Cancel
        </Button>,
        <Button
          key="submit"
          type="primary"
          onClick={handleSubmit}
          disabled={!signatureData}
          style={{ background: !signatureData ? undefined : brandColors.primary }}
        >
          Submit Environmental Log
        </Button>,
      ]}
    >
      <Form
        form={form}
        layout="vertical"
        initialValues={{ dateTime: dayjs(), status: "Within Limit" }}
        onValuesChange={handleValuesChange}
      >
        {/* Card 1: Sensor Readings */}
        <Card
          size="small"
          style={{ marginBottom: 16, borderTop: `3px solid ${brandColors.primary}` }}
        >
          <Space style={{ marginBottom: 16 }}>
            <CloudServerOutlined style={{ color: brandColors.primary }} />
            <Text strong>Sensor Readings</Text>
            <Tag color="orange">Required</Tag>
          </Space>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item label="Date / Time" name="dateTime" rules={[{ required: true, message: "Required" }]}>
                <DatePicker showTime style={{ width: "100%" }} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                label={
                  <span>
                    Differential Pressure (Pa)&nbsp;
                    <Tooltip title={`Range: ${ranges.differentialPressure.min} - ${ranges.differentialPressure.max} Pa`}>
                      <InfoCircleOutlined style={{ color: brandColors.primary }} />
                    </Tooltip>
                  </span>
                }
                name="differentialPressure"
              >
                <InputNumber
                  style={{ width: "100%" }}
                  step={0.1}
                  placeholder={`Range: ${ranges.differentialPressure.min}-${ranges.differentialPressure.max} Pa`}
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                label={
                  <span>
                    Temperature (°C)&nbsp;
                    <Tooltip title={`Range: ${ranges.temperature.min} - ${ranges.temperature.max} °C`}>
                      <InfoCircleOutlined style={{ color: brandColors.primary }} />
                    </Tooltip>
                  </span>
                }
                name="temperature"
              >
                <InputNumber
                  style={{ width: "100%" }}
                  step={0.1}
                  placeholder={`Range: ${ranges.temperature.min}-${ranges.temperature.max} °C`}
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                label={
                  <span>
                    Humidity (%)&nbsp;
                    <Tooltip title={`Range: ${ranges.humidity.min} - ${ranges.humidity.max} %`}>
                      <InfoCircleOutlined style={{ color: brandColors.primary }} />
                    </Tooltip>
                  </span>
                }
                name="humidity"
              >
                <InputNumber
                  style={{ width: "100%" }}
                  step={0.1}
                  placeholder={`Range: ${ranges.humidity.min}-${ranges.humidity.max} %`}
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                label={
                  <span>
                    Airborne Particulates (CFU/m³)&nbsp;
                    <Tooltip title={`Max: ${ranges.particulates.max} CFU/m³`}>
                      <InfoCircleOutlined style={{ color: brandColors.primary }} />
                    </Tooltip>
                  </span>
                }
                name="particulates"
              >
                <InputNumber
                  style={{ width: "100%" }}
                  step={1}
                  placeholder={`Max: ${ranges.particulates.max} CFU/m³`}
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                label={
                  <span>
                    LUX Level&nbsp;
                    <Tooltip title={`Range: ${ranges.luxLevel.min} - ${ranges.luxLevel.max} Lux`}>
                      <InfoCircleOutlined style={{ color: brandColors.primary }} />
                    </Tooltip>
                  </span>
                }
                name="luxLevel"
              >
                <InputNumber
                  style={{ width: "100%" }}
                  step={1}
                  placeholder={`Range: ${ranges.luxLevel.min}-${ranges.luxLevel.max} Lux`}
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item label="Status" name="status" rules={[{ required: true, message: "Required" }]}>
                <Select
                  placeholder="Auto-calculated"
                  options={statusOptions}
                  disabled
                  style={{
                    background: currentStatus ? `${getStatusColor(currentStatus)}15` : undefined,
                  }}
                />
              </Form.Item>
            </Col>
          </Row>
        </Card>

        {/* Card 2: Electronic Signature */}
        <Card
          size="small"
          style={{ borderTop: `3px solid ${brandColors.success}` }}
        >
          <Space style={{ marginBottom: 12 }}>
            <SafetyCertificateOutlined style={{ color: brandColors.primary }} />
            <Text strong>Electronic Signature - Monitored By (21 CFR Part 11)</Text>
            {!signatureData && <Tag color="orange">Pending</Tag>}
            {signatureData && <Tag color="success" icon={<CheckCircleOutlined />}>Completed</Tag>}
          </Space>

          <Form.Item
            label="Monitored By"
            required
            validateStatus={signatureData ? "success" : "error"}
            help={signatureData ? (
              <span style={{ color: brandColors.success }}>✓ Electronic signature verified and authenticated</span>
            ) : "⚠ Electronic signature required for compliance"}
          >
            {signatureData ? (
              <div style={{ padding: "20px", borderRadius: 8, border: `1px solid ${brandColors.success}20`, background: brandColors.signatureBg }}>
                <div style={{ display: "flex", alignItems: "flex-start", gap: 16 }}>
                  <Avatar size={48} icon={<UserOutlined />} style={{ background: brandColors.success }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12, flexWrap: "wrap", gap: 8 }}>
                      <Space size="middle" wrap>
                        <Text strong style={{ fontSize: 16 }}>{signatureData.name}</Text>
                        <Tag color="success" icon={<CheckCircleOutlined />}>Signed</Tag>
                        <Text type="secondary">Level: {signatureData.levelOfAuthorization}</Text>
                      </Space>
                      <Button type="text" icon={<DeleteOutlined />} danger onClick={handleRemoveSignature} size="small">Remove</Button>
                    </div>
                    <Row gutter={16} style={{ marginBottom: 12 }}>
                      <Col span={12}>
                        <Text type="secondary" style={{ fontSize: 12 }}>Designation</Text>
                        <div style={{ fontWeight: 500 }}>{signatureData.designation}</div>
                      </Col>
                      <Col span={12}>
                        <Text type="secondary" style={{ fontSize: 12 }}>Department</Text>
                        <div style={{ fontWeight: 500 }}>{signatureData.department}</div>
                      </Col>
                    </Row>
                    {signatureData.signatureHash && (
                      <div style={{ background: brandColors.hashBg, borderRadius: 6, padding: "10px 14px", border: `1px solid ${brandColors.border}` }}>
                        <Text type="secondary" style={{ fontSize: 12 }}>Signature Hash (SHA-256)</Text>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, flexWrap: "wrap", marginTop: 4 }}>
                          <Text code style={{ fontSize: 11, wordBreak: "break-all", color: brandColors.primary }}>
                            {signatureData.signatureHash.slice(0, 50)}...
                          </Text>
                          <Button type="link" size="small" icon={<EyeOutlined />} onClick={() => {
                            Modal.info({ title: "Full Signature Hash", content: signatureData.signatureHash, width: 600 });
                          }}>View Full</Button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <SignButton
                  module="logBookEntry"
                  levelOfAuthorization="Environmental Monitor"
                  sequence={2}
                  onSignComplete={handleSignComplete}
                  disableProp={false}
                />
                <div style={{ marginTop: 12 }}>
                  <Tag color="blue" icon={<SafetyCertificateOutlined />} variant="outlined" style={{ fontSize: 12 }}>
                    This electronic signature is legally equivalent to a handwritten signature under 21 CFR Part 11
                  </Tag>
                </div>
              </div>
            )}
          </Form.Item>
        </Card>
      </Form>
    </Modal>
  );
}