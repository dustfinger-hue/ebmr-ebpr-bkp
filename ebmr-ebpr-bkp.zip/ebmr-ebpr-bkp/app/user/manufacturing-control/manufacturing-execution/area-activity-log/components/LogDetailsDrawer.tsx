import { Descriptions, Drawer, Space, Tag, Typography } from "antd";
import type { ReactNode } from "react";
import type {
  ActivityLogEntry,
  CleaningLogEntry,
  EnvironmentalLogEntry,
  LogTabKey,
  SignatureEntry,
  ViewLogState,
} from "../types";
import { StatusBadge } from "./table-cells/StatusBadge";

const { Text, Title } = Typography;

const labels: Record<LogTabKey, string> = {
  activity: "Activity Log",
  cleaning: "Cleaning Log",
  environmental: "Environmental Log",
};

const knownKeys = new Set([
  "_id",
  "date",
  "dateTime",
  "productName",
  "batchNumber",
  "batchNo",
  "startDateTime",
  "endDateTime",
  "status",
  "activityStartedBy",
  "activityStoppedBy",
  "cleaningStartedBy",
  "cleaningStoppedBy",
  "checkedBy",
  "verifiedBy",
  "engagedForActivity",
  "remarks",
  "facilityCode",
  "cleaningType",
  "cleaningMethod",
  "differentialPressure",
  "temperature",
  "humidity",
  "particulates",
  "luxLevel",
  "monitoredBy",
]);

type LogDetailsDrawerProps = {
  viewLog: ViewLogState;
  onClose: () => void;
};

export default function LogDetailsDrawer({ viewLog, onClose }: LogDetailsDrawerProps) {
  const record = viewLog?.record;
  const type = viewLog?.type;

  return (
    <Drawer
      destroyOnHidden
      open={Boolean(viewLog)}
      onClose={onClose}
      placement="right"
      title={type ? labels[type] : "Log Details"}
      width={720}
    >
      {record && type && (
        <Space direction="vertical" size="large" style={{ width: "100%" }}>
          <HeaderSummary record={record} type={type} />

          {type === "activity" && <ActivityDetails record={record as ActivityLogEntry} />}
          {type === "cleaning" && <CleaningDetails record={record as CleaningLogEntry} />}
          {type === "environmental" && (
            <EnvironmentalDetails record={record as EnvironmentalLogEntry} />
          )}

          <SignatureDetails
            checkedBy={record.checkedBy}
            monitoredBy={"monitoredBy" in record ? record.monitoredBy : undefined}
            startedBy={
              "activityStartedBy" in record
                ? record.activityStartedBy
                : "cleaningStartedBy" in record
                  ? record.cleaningStartedBy
                  : undefined
            }
            stoppedBy={
              "activityStoppedBy" in record
                ? record.activityStoppedBy
                : "cleaningStoppedBy" in record
                  ? record.cleaningStoppedBy
                  : undefined
            }
            verifiedBy={record.verifiedBy}
          />

          <AdditionalFields record={record} />
        </Space>
      )}
    </Drawer>
  );
}

function HeaderSummary({
  record,
  type,
}: {
  record: ActivityLogEntry | CleaningLogEntry | EnvironmentalLogEntry;
  type: LogTabKey;
}) {
  return (
    <div>
      <Title level={4} style={{ marginBottom: 8 }}>
        {labels[type]} Details
      </Title>
      <Space wrap>
        <StatusBadge status={record.status} type={type} />
        {record.facilityCode && <Tag>{record.facilityCode}</Tag>}
        <Text type="secondary">ID: {record._id}</Text>
      </Space>
    </div>
  );
}

function ActivityDetails({ record }: { record: ActivityLogEntry }) {
  return (
    <DetailBlock title="Activity Information">
      <Descriptions bordered column={1} size="small">
        <Descriptions.Item label="Date">{formatDate(record.date)}</Descriptions.Item>
        <Descriptions.Item label="Product Name">{value(record.productName)}</Descriptions.Item>
        <Descriptions.Item label="Batch Number">{value(record.batchNumber)}</Descriptions.Item>
        <Descriptions.Item label="Start Date / Time">
          {formatDateTime(record.startDateTime)}
        </Descriptions.Item>
        <Descriptions.Item label="End Date / Time">
          {formatDateTime(record.endDateTime)}
        </Descriptions.Item>
        <Descriptions.Item label="Engaged For Activity">
          {value(record.engagedForActivity)}
        </Descriptions.Item>
        <Descriptions.Item label="Remarks">{value(record.remarks)}</Descriptions.Item>
      </Descriptions>
    </DetailBlock>
  );
}

function CleaningDetails({ record }: { record: CleaningLogEntry }) {
  return (
    <DetailBlock title="Cleaning Information">
      <Descriptions bordered column={1} size="small">
        <Descriptions.Item label="Date">{formatDate(record.date)}</Descriptions.Item>
        <Descriptions.Item label="Product Name">{value(record.productName)}</Descriptions.Item>
        <Descriptions.Item label="Batch Number">{value(record.batchNo)}</Descriptions.Item>
        <Descriptions.Item label="Cleaning Type">{value(record.cleaningType)}</Descriptions.Item>
        <Descriptions.Item label="Cleaning Method">{value(record.cleaningMethod)}</Descriptions.Item>
        <Descriptions.Item label="Start Date / Time">
          {formatDateTime(record.startDateTime)}
        </Descriptions.Item>
        <Descriptions.Item label="End Date / Time">
          {formatDateTime(record.endDateTime)}
        </Descriptions.Item>
      </Descriptions>
    </DetailBlock>
  );
}

function EnvironmentalDetails({ record }: { record: EnvironmentalLogEntry }) {
  return (
    <DetailBlock title="Environmental Readings">
      <Descriptions bordered column={1} size="small">
        <Descriptions.Item label="Date / Time">{formatDateTime(record.dateTime)}</Descriptions.Item>
        <Descriptions.Item label="Differential Pressure">
          {measurement(record.differentialPressure, "Pa")}
        </Descriptions.Item>
        <Descriptions.Item label="Temperature">
          {measurement(record.temperature, "°C")}
        </Descriptions.Item>
        <Descriptions.Item label="Humidity">{measurement(record.humidity, "%")}</Descriptions.Item>
        <Descriptions.Item label="Particulates">
          {measurement(record.particulates, "CFU/m³")}
        </Descriptions.Item>
        <Descriptions.Item label="LUX Level">{value(record.luxLevel)}</Descriptions.Item>
      </Descriptions>
    </DetailBlock>
  );
}

function SignatureDetails({
  checkedBy,
  monitoredBy,
  startedBy,
  stoppedBy,
  verifiedBy,
}: {
  checkedBy?: SignatureEntry;
  monitoredBy?: SignatureEntry;
  startedBy?: SignatureEntry;
  stoppedBy?: SignatureEntry;
  verifiedBy?: SignatureEntry;
}) {
  return (
    <DetailBlock title="People & Signatures">
      <Descriptions bordered column={1} size="small">
        {startedBy && (
          <Descriptions.Item label="Started By">{signatureValue(startedBy)}</Descriptions.Item>
        )}
        {stoppedBy && (
          <Descriptions.Item label="Stopped By">{signatureValue(stoppedBy)}</Descriptions.Item>
        )}
        {monitoredBy && (
          <Descriptions.Item label="Monitored By">{signatureValue(monitoredBy)}</Descriptions.Item>
        )}
        <Descriptions.Item label="Checked By">{signatureValue(checkedBy)}</Descriptions.Item>
        <Descriptions.Item label="Verified By">{signatureValue(verifiedBy)}</Descriptions.Item>
      </Descriptions>
    </DetailBlock>
  );
}

function AdditionalFields({
  record,
}: {
  record: ActivityLogEntry | CleaningLogEntry | EnvironmentalLogEntry;
}) {
  const entries = Object.entries(record).filter(([key]) => !knownKeys.has(key));

  if (!entries.length) {
    return null;
  }

  return (
    <DetailBlock title="Additional Fields">
      <Descriptions bordered column={1} size="small">
        {entries.map(([key, fieldValue]) => (
          <Descriptions.Item key={key} label={key}>
            {formatUnknown(fieldValue)}
          </Descriptions.Item>
        ))}
      </Descriptions>
    </DetailBlock>
  );
}

function DetailBlock({
  children,
  title,
}: {
  children: ReactNode;
  title: string;
}) {
  return (
    <div>
      <Text strong style={{ display: "block", marginBottom: 12 }}>
        {title}
      </Text>
      {children}
    </div>
  );
}

function signatureValue(signature?: SignatureEntry) {
  if (!signature?.name) {
    return <Text type="secondary">-</Text>;
  }

  return (
    <Space direction="vertical" size={0}>
      <Text strong>{signature.name}</Text>
      {signature.designation && <Text type="secondary">{signature.designation}</Text>}
      {signature.department && <Text type="secondary">{signature.department}</Text>}
      {signature.signatureId && <Text type="secondary">Signature ID: {signature.signatureId}</Text>}
    </Space>
  );
}

function formatDate(input?: string) {
  return input ? new Date(input).toLocaleDateString("en-US") : "-";
}

function formatDateTime(input?: string) {
  return input ? new Date(input).toLocaleString("en-US") : "-";
}

function measurement(input?: number, unit?: string) {
  return input != null ? `${input} ${unit}` : "-";
}

function value(input?: string | number) {
  return input ?? "-";
}

function formatUnknown(input: unknown) {
  if (input == null || input === "") {
    return "-";
  }

  if (typeof input === "object") {
    return <pre style={{ margin: 0, whiteSpace: "pre-wrap" }}>{JSON.stringify(input, null, 2)}</pre>;
  }

  return String(input);
}
