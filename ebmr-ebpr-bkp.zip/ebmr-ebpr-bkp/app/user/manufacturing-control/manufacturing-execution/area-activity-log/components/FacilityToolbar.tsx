import { Button, Select, Space, Tooltip, Typography } from "antd";
import { ExclamationCircleOutlined, PlusOutlined, ReloadOutlined } from "@ant-design/icons";
import type { FacilityOption, LogTabKey } from "../types";

const { Text } = Typography;

type FacilityToolbarProps = {
  activeTab: LogTabKey;
  canAddEntry: boolean;
  facilitiesLoading: boolean;
  facilityOptions: FacilityOption[];
  selectedFacility?: string;
  onAddEntry: () => void;
  onRefresh: () => void;
  onSelectFacility: (facility?: string) => void;
};

export default function FacilityToolbar({
  activeTab,
  canAddEntry,
  facilitiesLoading,
  facilityOptions,
  selectedFacility,
  onAddEntry,
  onRefresh,
  onSelectFacility,
}: FacilityToolbarProps) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "end",
        flexWrap: "wrap",
        gap: 16,
      }}
    >
      <div style={{ minWidth: 280, flex: "1 1 360px" }}>
        <Text strong style={{ display: "block", marginBottom: 8 }}>
          <ExclamationCircleOutlined style={{ marginRight: 6 }} />
          Select Facility / Area
        </Text>
        <Select
          allowClear
          loading={facilitiesLoading}
          showSearch
          size="large"
          placeholder="Search and select a facility"
          style={{ width: "100%" }}
          value={selectedFacility}
          onChange={onSelectFacility}
          options={facilityOptions}
          filterOption={(input, option) =>
            (option?.label ?? "").toLowerCase().includes(input.toLowerCase())
          }
        />
      </div>

      <Space wrap>
        <Button icon={<ReloadOutlined />} onClick={onRefresh}>
          Refresh
        </Button>
        <Tooltip
          title={
            !selectedFacility
              ? "Please select a facility/area first"
              : !canAddEntry
                ? "You do not have permission to add entries"
                : `Add new ${activeTab} entry`
          }
        >
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={onAddEntry}
            disabled={!canAddEntry || !selectedFacility}
            size="large"
          >
            Add Entry
          </Button>
        </Tooltip>
      </Space>
    </div>
  );
}
