import { Space, Typography } from "antd";
import type { ReactNode } from "react";
import SignatureCell from "./SignatureCell";
import type { SignatureEntry, SignType } from "../../types";

const { Text } = Typography;

type QASignatureCellProps = {
  checkedBy?: SignatureEntry;
  verifiedBy?: SignatureEntry;
  recordId: string;
  status: string;
  onSign: (data: any, id: string, type: SignType) => Promise<void>;
};

function SignatureRow({
  children,
  label,
}: {
  children: ReactNode;
  label: string;
}) {
  return (
    <Space direction="vertical" size={2} style={{ width: "100%" }}>
      <Text type="secondary" style={{ fontSize: 12 }}>
        {label}
      </Text>
      {children}
    </Space>
  );
}

export default function QASignatureCell({
  checkedBy,
  verifiedBy,
  recordId,
  status,
  onSign,
}: QASignatureCellProps) {
  return (
    <Space direction="vertical" size={8} style={{ width: "100%" }}>
      <SignatureRow label="Checked By">
        <SignatureCell
          signature={checkedBy}
          recordId={recordId}
          status={status}
          type="checkedBy"
          onSign={onSign}
        />
      </SignatureRow>

      <SignatureRow label="Verified By">
        <SignatureCell
          signature={verifiedBy}
          recordId={recordId}
          status={status}
          type="verifiedBy"
          checkedByName={checkedBy?.name}
          onSign={onSign}
        />
      </SignatureRow>
    </Space>
  );
}
