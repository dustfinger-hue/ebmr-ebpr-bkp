import { Space, Tag, Typography } from "antd";
import type { SignatureEntry } from "../../types";

const { Text } = Typography;

export default function OperatorCell({
  startLabel = "Start",
  startedBy,
  stopLabel = "Stop",
  stoppedBy,
}: {
  startLabel?: string;
  startedBy?: SignatureEntry;
  stopLabel?: string;
  stoppedBy?: SignatureEntry;
}) {
  if (!startedBy?.name && !stoppedBy?.name) {
    return <Text type="secondary">-</Text>;
  }

  return (
    <Space direction="vertical" size={4}>
      {startedBy?.name && (
        <Tag color="blue">
          {startLabel}: {startedBy.name}
        </Tag>
      )}

      {stoppedBy?.name && (
        <Tag color="volcano">
          {stopLabel}: {stoppedBy.name}
        </Tag>
      )}
    </Space>
  );
}
