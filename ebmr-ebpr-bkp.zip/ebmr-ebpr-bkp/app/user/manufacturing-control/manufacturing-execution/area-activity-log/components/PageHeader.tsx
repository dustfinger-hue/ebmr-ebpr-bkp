import { Space, Tag, Typography } from "antd";
import { FaClipboardList } from "react-icons/fa";
import { SettingOutlined } from "@ant-design/icons";

const { Text, Title } = Typography;

type PageHeaderProps = {
  selectedFacility?: string;
  selectedFacilityName: string;
};

export default function PageHeader({
  selectedFacility,
  selectedFacilityName,
}: PageHeaderProps) {
  return (
    <div
      style={{
        marginBottom: 16,
      }}
    >
      <Space direction="vertical" size={4}>
        <Title level={2} style={{ margin: 0 }}>
          <SettingOutlined
            style={{ marginRight: 12, color: "#1890ff" }}
          />
          Area Activity Log
        </Title>
        {selectedFacility ? (
          <Text type="secondary" style={{ fontSize: 14 }}>
            Facility: <Text strong>{selectedFacilityName}</Text>
            {selectedFacility !== selectedFacilityName && (
              <Tag style={{ marginLeft: 8 }}>{selectedFacility}</Tag>
            )}
          </Text>
        ) : (
          <Text type="secondary">
            Select a facility to load activity, cleaning, and environmental records.
          </Text>
        )}
      </Space>
    </div>
  );
}