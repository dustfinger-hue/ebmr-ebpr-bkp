import { Tag } from "antd";

export const StatusBadge: React.FC<{ status: string; type: 'activity' | 'cleaning' | 'environmental' }> = ({ status, type }) => {
    const colorMap = {
        activity: {
            "Completed": "green",
            "In-Progress": "blue",
            "Pending Review": "orange",
            "Stopped": "red"
        },
        cleaning: {
            "Completed": "green",
            "In-Progress": "blue"
        },
        environmental: {
            "Within Limit": "green",
            "Warning": "orange",
            "Alarm": "red"
        }
    };

    const colors = colorMap[type];
    const color = colors[status as keyof typeof colors] || "default";

    return <Tag color={color}>{status}</Tag>;
};