'use client';

import {
  Button,
  Card,
  DatePicker,
  Form,
  Input,
  message,
  Modal,
  Select,
  Space,
  Typography,
  Tag,
  Avatar,
  Divider,
  Row,
  Col,
  Tooltip,
} from "antd";
import dayjs from "dayjs";
import { useEffect, useState } from "react";
import SignButton from "@/components/Role-Based-Signing";
import {
  UserOutlined,
  CheckCircleOutlined,
  SafetyCertificateOutlined,
  ClockCircleOutlined,
  DeleteOutlined,
  EyeOutlined,
  ToolOutlined,
} from "@ant-design/icons";
import { Cleaning_Type_Options, Cleaning_Method_Options } from "@/lib/constants/Generarl";

const { Text } = Typography;

const brandColors = {
  primary: "#6366f1",
  success: "#10b981",
  warning: "#f59e0b",
  error: "#ef4444",
  border: "#e2e8f0",
  signatureBg: "#1A1325",
  hashBg: "#111A2C",
};

interface SignatureData {
  signatureId: string;
  name: string;
  designation: string;
  department: string;
  module: string;
  status: string;
  expiresAt: string;
  signatureHash: string;
  signingSequence: number;
  levelOfAuthorization: string;
}

interface Props {
  open: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  facilityCode?: string;
}

export default function CreateCleaning({ open, onClose, onSuccess, facilityCode }: Props) {
  const [form] = Form.useForm();
  const [signatureData, setSignatureData] = useState<SignatureData | null>(null);

  useEffect(() => {
    if (open) {
      form.setFieldsValue({ date: dayjs() });
      setSignatureData(null);
    }
  }, [open, form]);

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();

      if (!signatureData) {
        message.error("Please complete the electronic signature first!");
        return;
      }

      const token = localStorage.getItem("token");

      const payload = {
        date: values.date.toISOString(),
        productName: values.productName || "",
        batchNo: values.batchNo || "",
        cleaningType: values.cleaningType,
        cleaningMethod: values.cleaningMethod,
        startDateTime: values.startDateTime.toISOString(),
        facilityCode: facilityCode || "",
        cleaningStartedBy: {
          name: signatureData.name,
          designation: signatureData.designation,
          department: signatureData.department,
          signatureId: signatureData.signatureId,
        },
      };

      console.log("Submitting cleaning log:", payload);

      const res = await fetch("/api/user/manufacturing-control/cleaning-log", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.message || "Failed to create cleaning log entry");
      }

      message.success("Cleaning log entry added successfully!");
      form.resetFields();
      setSignatureData(null);
      onClose();
      onSuccess?.();
    } catch (error) {
      console.error("Error submitting cleaning log:", error);
      message.error(error instanceof Error ? error.message : "Failed to create cleaning log entry");
    }
  };

  const handleSignComplete = (receivedData: any) => {
    setSignatureData(receivedData);
  };

  const handleRemoveSignature = () => {
    Modal.confirm({
      title: "Remove Electronic Signature",
      content: "Are you sure you want to remove this signature? You will need to sign again.",
      okText: "Yes, Remove",
      cancelText: "Cancel",
      okButtonProps: { danger: true },
      onOk: () => {
        setSignatureData(null);
        message.info("Signature removed. Please sign again to continue.");
      },
    });
  };

  return (
    <Modal
      title={
        <Space>
          <ToolOutlined style={{ color: brandColors.primary }} />
          <span style={{ fontSize: 18, fontWeight: 600 }}>Create Cleaning Log Entry</span>
        </Space>
      }
      open={open}
      onCancel={() => {
        form.resetFields();
        setSignatureData(null);
        onClose();
      }}
      width={800}
      footer={[
        <Button key="cancel" onClick={() => { form.resetFields(); setSignatureData(null); onClose(); }}>
          Cancel
        </Button>,
        <Button
          key="submit"
          type="primary"
          onClick={handleSubmit}
          disabled={!signatureData}
          style={{ background: !signatureData ? undefined : brandColors.primary }}
        >
          Submit Cleaning Log
        </Button>,
      ]}
    >
      <Form
        form={form}
        layout="vertical"
        initialValues={{ date: dayjs() }}
      >
        {/* Card 1: Cleaning Details */}
        <Card
          size="small"
          style={{ marginBottom: 16, borderTop: `3px solid ${brandColors.primary}` }}
        >
          <Space style={{ marginBottom: 16 }}>
            <ToolOutlined style={{ color: brandColors.primary }} />
            <Text strong>Cleaning Details</Text>
            <Tag color="orange">Required</Tag>
          </Space>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item label="Date" name="date" rules={[{ required: true, message: "Required" }]}>
                <DatePicker style={{ width: "100%" }} disabled />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item label="Cleaning Type" name="cleaningType" rules={[{ required: true, message: "Required" }]}>
                <Select placeholder="Select cleaning type" options={Cleaning_Type_Options} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item label="Cleaning Method" name="cleaningMethod" rules={[{ required: true, message: "Required" }]}>
                <Select placeholder="Select method" options={Cleaning_Method_Options} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item label="Cleaning Start Time" name="startDateTime" rules={[{ required: true, message: "Required" }]}>
                <DatePicker showTime style={{ width: "100%" }} placeholder="Select start time" />
              </Form.Item>
            </Col>
          </Row>
        </Card>

        {/* Card 2: Optional Batch Info */}
        <Card
          size="small"
          style={{ marginBottom: 16, borderTop: `3px solid ${brandColors.warning}` }}
        >
          <Space style={{ marginBottom: 16 }}>
            <ClockCircleOutlined style={{ color: brandColors.warning }} />
            <Text strong>Batch Information (Optional)</Text>
            <Tag color="default">Optional</Tag>
          </Space>

          <Row gutter={16}>
            <Col span={12}>
              <Form.Item label="Product Name" name="productName">
                <Input placeholder="Enter product name (optional)" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item label="Batch No." name="batchNo">
                <Input placeholder="Enter batch number (optional)" />
              </Form.Item>
            </Col>
          </Row>
        </Card>

        {/* Card 3: Electronic Signature */}
        <Card
          size="small"
          style={{ borderTop: `3px solid ${brandColors.success}` }}
        >
          <Space style={{ marginBottom: 12 }}>
            <SafetyCertificateOutlined style={{ color: brandColors.primary }} />
            <Text strong>Electronic Signature - Started By (21 CFR Part 11)</Text>
            {!signatureData && <Tag color="orange">Pending</Tag>}
            {signatureData && <Tag color="success" icon={<CheckCircleOutlined />}>Completed</Tag>}
          </Space>

          <Form.Item
            label="Started By"
            required
            validateStatus={signatureData ? "success" : "error"}
            help={
              signatureData ? (
                <span style={{ color: brandColors.success }}>
                  ✓ Electronic signature verified and authenticated
                </span>
              ) : (
                "⚠ Electronic signature required for compliance"
              )
            }
          >
            {signatureData ? (
              <div style={{ padding: "20px", borderRadius: 8, border: `1px solid ${brandColors.success}20`, background: brandColors.signatureBg }}>
                <div style={{ display: "flex", alignItems: "flex-start", gap: 16 }}>
                  <Avatar size={48} icon={<UserOutlined />} style={{ background: brandColors.success }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12, flexWrap: "wrap", gap: 8 }}>
                      <Space size="middle" wrap>
                        <Text strong style={{ fontSize: 16 }}>{signatureData.name}</Text>
                        <Tag color="success" icon={<CheckCircleOutlined />}>Signed</Tag>
                        <Text type="secondary">Level: {signatureData.levelOfAuthorization}</Text>
                      </Space>
                      <Button type="text" icon={<DeleteOutlined />} danger onClick={handleRemoveSignature} size="small">Remove</Button>
                    </div>
                    <Row gutter={16} style={{ marginBottom: 12 }}>
                      <Col span={12}>
                        <Text type="secondary" style={{ fontSize: 12 }}>Designation</Text>
                        <div style={{ fontWeight: 500 }}>{signatureData.designation}</div>
                      </Col>
                      <Col span={12}>
                        <Text type="secondary" style={{ fontSize: 12 }}>Department</Text>
                        <div style={{ fontWeight: 500 }}>{signatureData.department}</div>
                      </Col>
                    </Row>
                    {signatureData.signatureHash && (
                      <div style={{ background: brandColors.hashBg, borderRadius: 6, padding: "10px 14px", border: `1px solid ${brandColors.border}` }}>
                        <Text type="secondary" style={{ fontSize: 12 }}>Signature Hash (SHA-256)</Text>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, flexWrap: "wrap", marginTop: 4 }}>
                          <Text code style={{ fontSize: 11, wordBreak: "break-all", color: brandColors.primary }}>
                            {signatureData.signatureHash.slice(0, 50)}...
                          </Text>
                          <Button type="link" size="small" icon={<EyeOutlined />} onClick={() => {
                            Modal.info({ title: "Full Signature Hash", content: signatureData.signatureHash, width: 600 });
                          }}>View Full</Button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <SignButton
                  module="logBookEntry"
                  levelOfAuthorization="Cleaning Started By"
                  sequence={1}
                  onSignComplete={handleSignComplete}
                  disableProp={false}
                />
                <div style={{ marginTop: 12 }}>
                  <Tag color="blue" icon={<SafetyCertificateOutlined />} variant="outlined" style={{ fontSize: 12 }}>
                    This electronic signature is legally equivalent to a handwritten signature under 21 CFR Part 11
                  </Tag>
                </div>
              </div>
            )}
          </Form.Item>
        </Card>
      </Form>
    </Modal>
  );
}