import { useMemo } from "react";

export const useFilteredLogs = <T extends { facilityCode?: string }>(
  logs: { logs: T[] },
  selectedFacility?: string
) => {
  return useMemo(() =>
    selectedFacility
      ? logs.logs.filter(log => log.facilityCode === selectedFacility)
      : logs.logs,
    [logs.logs, selectedFacility]
  );
};
