import { Button, Space, Tooltip, Typography } from "antd";
import type { TableProps } from "antd";
import { EditOutlined } from "@ant-design/icons";
import type { MouseEvent } from "react";
import OperatorCell from "./table-cells/OperatorCell";
import QASignatureCell from "./table-cells/QASignatureCell";
import { StatusBadge } from "./table-cells/StatusBadge";
import TimelineCell from "./table-cells/TimeLineCell";
import type {
  ActivityLogEntry,
  CleaningLogEntry,
  EnvironmentalLogEntry,
  SignatureEntry,
  SignType,
} from "../types";

const { Text } = Typography;

type SignHandler = (
  data: any,
  recordId: string,
  type: SignType,
  endpoint: string,
  refetchFn: () => void
) => Promise<void>;

const dateFormat: Intl.DateTimeFormatOptions = {
  year: "numeric",
  month: "short",
  day: "numeric",
};

const dateTimeFormat: Intl.DateTimeFormatOptions = {
  ...dateFormat,
  hour: "2-digit",
  minute: "2-digit",
};

const indexColumn = {
  title: "#",
  width: 50,
  fixed: "left" as const,
  render: (_: unknown, __: unknown, i: number) => (
    <Text type="secondary">{i + 1}</Text>
  ),
};

const renderDate = (value?: string) =>
  value ? new Date(value).toLocaleDateString("en-US", dateFormat) : "-";

const renderDateTime = (value?: string) =>
  value ? new Date(value).toLocaleString("en-US", dateTimeFormat) : "-";

const renderMeasurement = (value?: number, unit?: string) =>
  value != null ? (
    <Space size={4}>
      <span>{value}</span>
      {unit && <Text type="secondary">{unit}</Text>}
    </Space>
  ) : (
    "-"
  );

const renderUpdateButton = (
  disabled: boolean,
  tooltip: string,
  onClick: (event: MouseEvent<HTMLElement>) => void
) => (
  <Tooltip title={disabled ? "Cannot update completed entries" : tooltip}>
    <Button type="link" icon={<EditOutlined />} onClick={onClick} disabled={disabled}>
      Update
    </Button>
  </Tooltip>
);

export function getActivityColumns({
  handleSign,
  onUpdate,
  refetch,
}: {
  handleSign: SignHandler;
  onUpdate: (record: ActivityLogEntry) => void;
  refetch: () => void;
}): TableProps<ActivityLogEntry>["columns"] {
  return [
    indexColumn,
    {
      title: "Date",
      dataIndex: "date",
      key: "date",
      width: 120,
      sorter: (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime(),
      render: renderDate,
    },
    {
      title: "Product Name",
      dataIndex: "productName",
      key: "productName",
      width: 180,
      ellipsis: true,
    },
    {
      title: "Batch No.",
      dataIndex: "batchNumber",
      key: "batchNumber",
      width: 120,
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: 140,
      filters: [
        { text: "Completed", value: "Completed" },
        { text: "In-Progress", value: "In-Progress" },
        { text: "Pending Review", value: "Pending Review" },
        { text: "Stopped", value: "Stopped" },
      ],
      onFilter: (value, record) => record.status === value,
      render: (status: string) => <StatusBadge status={status} type="activity" />,
    },
    {
      title: "Timeline",
      width: 220,
      render: (_, record) => (
        <TimelineCell start={record.startDateTime} end={record.endDateTime} />
      ),
    },
    {
      title: "Operators",
      width: 180,
      render: (_, record) => (
        <OperatorCell
          startedBy={record.activityStartedBy}
          stoppedBy={record.activityStoppedBy}
        />
      ),
    },
    {
      title: "QA Signatures",
      key: "qaSignatures",
      width: 230,
      render: (_, record) => (
        <QASignatureCell
          checkedBy={record.checkedBy}
          verifiedBy={record.verifiedBy}
          recordId={record._id}
          status={record.status}
          onSign={(data, id, type) =>
            handleSign(data, id, type, "/api/user/manufacturing-control/area-activity-log", refetch)
          }
        />
      ),
    },
    {
      title: "Remarks",
      dataIndex: "remarks",
      key: "remarks",
      width: 160,
      ellipsis: true,
      render: (value: string) => value || "-",
    },
    {
      title: "Action",
      key: "action",
      width: 100,
      fixed: "right",
      render: (_, record) =>
        renderUpdateButton(record.status === "Completed", "Update activity log", (event) => {
          event.stopPropagation();
          onUpdate(record);
        }),
    },
  ];
}

export function getCleaningColumns({
  handleSign,
  onUpdate,
  refetch,
}: {
  handleSign: SignHandler;
  onUpdate: (record: CleaningLogEntry) => void;
  refetch: () => void;
}): TableProps<CleaningLogEntry>["columns"] {
  return [
    indexColumn,
    {
      title: "Date",
      dataIndex: "date",
      key: "date",
      width: 120,
      sorter: (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime(),
      render: renderDate,
    },
    {
      title: "Cleaning Type",
      dataIndex: "cleaningType",
      key: "cleaningType",
      width: 150,
      filters: [
        { text: "Routine", value: "Routine" },
        { text: "Deep Cleaning", value: "Deep Cleaning" },
        { text: "Sterilization", value: "Sterilization" },
      ],
      onFilter: (value, record) => record.cleaningType === value,
    },
    {
      title: "Cleaning Method",
      dataIndex: "cleaningMethod",
      key: "cleaningMethod",
      width: 150,
      ellipsis: true,
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: 130,
      filters: [
        { text: "Completed", value: "Completed" },
        { text: "In-Progress", value: "In-Progress" },
      ],
      onFilter: (value, record) => record.status === value,
      render: (status: string) => <StatusBadge status={status} type="cleaning" />,
    },
    {
      title: "Timeline",
      width: 220,
      render: (_, record) => (
        <TimelineCell start={record.startDateTime} end={record.endDateTime} />
      ),
    },
    {
      title: "Operators",
      width: 180,
      render: (_, record) => (
        <OperatorCell
          startedBy={record.cleaningStartedBy}
          stoppedBy={record.cleaningStoppedBy}
        />
      ),
    },
    {
      title: "QA Signatures",
      key: "qaSignatures",
      width: 230,
      render: (_, record) => (
        <QASignatureCell
          checkedBy={record.checkedBy}
          verifiedBy={record.verifiedBy}
          recordId={record._id}
          status={record.status}
          onSign={(data, id, type) =>
            handleSign(data, id, type, "/api/user/manufacturing-control/cleaning-log", refetch)
          }
        />
      ),
    },
    {
      title: "Action",
      key: "action",
      width: 100,
      fixed: "right",
      render: (_, record) =>
        renderUpdateButton(record.status === "Completed", "Update cleaning log", (event) => {
          event.stopPropagation();
          onUpdate(record);
        }),
    },
  ];
}

export function getEnvironmentalColumns({
  handleSign,
  refetch,
}: {
  handleSign: SignHandler;
  refetch: () => void;
}): TableProps<EnvironmentalLogEntry>["columns"] {
  return [
    indexColumn,
    {
      title: "Date / Time",
      dataIndex: "dateTime",
      key: "dateTime",
      width: 170,
      sorter: (a, b) =>
        new Date(a.dateTime).getTime() - new Date(b.dateTime).getTime(),
      render: renderDateTime,
    },
    {
      title: "Differential Pressure",
      dataIndex: "differentialPressure",
      key: "differentialPressure",
      width: 160,
      render: (value: number) => renderMeasurement(value, "Pa"),
    },
    {
      title: "Temperature",
      dataIndex: "temperature",
      key: "temperature",
      width: 130,
      render: (value: number) => renderMeasurement(value, "°C"),
    },
    {
      title: "Humidity",
      dataIndex: "humidity",
      key: "humidity",
      width: 120,
      render: (value: number) => renderMeasurement(value, "%"),
    },
    {
      title: "Particulates",
      dataIndex: "particulates",
      key: "particulates",
      width: 140,
      render: (value: number) => renderMeasurement(value, "CFU/m³"),
    },
    {
      title: "LUX Level",
      dataIndex: "luxLevel",
      key: "luxLevel",
      width: 120,
      render: (value: number) => value ?? "-",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: 140,
      filters: [
        { text: "Within Limit", value: "Within Limit" },
        { text: "Warning", value: "Warning" },
        { text: "Alarm", value: "Alarm" },
      ],
      onFilter: (value, record) => record.status === value,
      render: (status: string) => <StatusBadge status={status} type="environmental" />,
    },
    {
      title: "Monitored By",
      dataIndex: "monitoredBy",
      key: "monitoredBy",
      width: 150,
      render: (signature: SignatureEntry) => signature?.name || "-",
    },
    {
      title: "QA Signatures",
      key: "qaSignatures",
      width: 230,
      render: (_, record) => (
        <QASignatureCell
          checkedBy={record.checkedBy}
          verifiedBy={record.verifiedBy}
          recordId={record._id}
          status={record.status}
          onSign={(data, id, type) =>
            handleSign(data, id, type, "/api/user/manufacturing-control/environmental-log", refetch)
          }
        />
      ),
    },
  ];
}
