'use client';

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";
import { Button, Card, Spin, Typography } from "antd";
import ManufacturingMaterialRequisition from "../components/ManufacturingMaterialRequisition";
import DispensingExecution from "../components/DispensingExecution";
import { RollbackOutlined } from "@ant-design/icons";


const { Text } = Typography;

function WorkbenchContent() {
    const searchParams = useSearchParams();
    const processOrderId = searchParams.get("processOrderId");
    const mode = searchParams.get("mode") || "allocation";

    const router= useRouter();

    if (!processOrderId) {
        return (
            <Card>
                <div style={{ padding: 40, textAlign: "center" }}>
                    <Text type="danger">No process order selected. Please go back and select a process order.</Text>
                </div>
                <Button
                    className="mt-4"
                    icon={<RollbackOutlined />}
                    onClick={() => router.push("/user/manufacturing-control/manufacturing-execution/dispensing")}
                >
                    Back to Readiness
                </Button>
            </Card>
        );
    }

    if (mode === "dispensing") {
        return <DispensingExecution processOrderId={processOrderId} />;
    }

    return <ManufacturingMaterialRequisition processOrderId={processOrderId} />;
}

export default function WorkbenchPage() {
    return (
        <Suspense
            fallback={
                <Card>
                    <div style={{ padding: 60, textAlign: "center" }}>
                        <Spin size="large" />
                    </div>
                </Card>
            }
        >
            <WorkbenchContent />
        </Suspense>
    );
}
