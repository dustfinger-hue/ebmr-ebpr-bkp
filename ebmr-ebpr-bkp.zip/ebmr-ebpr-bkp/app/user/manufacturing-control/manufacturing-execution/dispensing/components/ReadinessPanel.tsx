'use client';

import {
    Alert,
    Button,
    Card,
    Descriptions,
    Empty,
    List,
    Space,
    Spin,
    Tag,
    Typography,
} from "antd";
import {
    CheckCircleTwoTone,
    CloseCircleTwoTone,
    ExperimentOutlined,
    RightOutlined,
} from "@ant-design/icons";

const { Text, Title } = Typography;

type CheckResult = {
    ok: boolean;
    title: string;
    message: string;
    details?: unknown;
};

type ReadinessData = {
    ready: boolean;
    processOrder: {
        processOrderCode: string;
        productCode: string;
        productName: string;
        batchNumber?: string | null;
        bomCode: string;
        bomVersion: string;
    };
    checks: Record<string, CheckResult>;
};

type ProcessOrderRow = {
    productName: string;
    batchNumber?: string | null;
};

type FacilityItem = {
    ok: boolean;
    facilityCode: string;
    areaName: string;
    status: string;
    qualificationStatus: string;
    message: string;
};

type EquipmentItem = {
    ok: boolean;
    equipmentCode: number;
    equipmentName: string;
    currentStatus: string;
    qualificationStatus: string;
    nextCalibrationDate?: string | Date | null;
    nextMaintenanceDate?: string | Date | null;
    message: string;
};

type ReadinessPanelProps = {
    loading: boolean;
    data: ReadinessData | null;
    selectedOrder: ProcessOrderRow | null;
    canProceed: boolean;
    proceeding: boolean;
    onProceed: () => void;
    allocationExists?: boolean;
};

const getCheckColor = (ok: boolean) => ok ? "success" : "error";

const formatDate = (date?: string | Date | null) => {
    if (!date) return "-";
    return new Date(date).toLocaleDateString();
};

function CheckHeader({ check }: { check: CheckResult }) {
    return (
        <Space align="start">
            {check.ok ? (
                <CheckCircleTwoTone twoToneColor="#52c41a" style={{ fontSize: 20, marginTop: 2 }} />
            ) : (
                <CloseCircleTwoTone twoToneColor="#ff4d4f" style={{ fontSize: 20, marginTop: 2 }} />
            )}
            <div>
                <Space size="small" wrap>
                    <Text strong>{check.title}</Text>
                    <Tag color={getCheckColor(check.ok)}>{check.ok ? "OK" : "Hold"}</Tag>
                </Space>
                <div>
                    <Text type="secondary">{check.message}</Text>
                </div>
            </div>
        </Space>
    );
}

function FacilityDetails({ items }: { items: FacilityItem[] }) {
    if (!items?.length) return null;

    return (
        <List
            size="small"
            dataSource={items}
            renderItem={(item) => (
                <List.Item>
                    <Space direction="vertical" size={0} style={{ width: "100%" }}>
                        <Space wrap>
                            <Text strong>{item.facilityCode}</Text>
                            <Text>{item.areaName}</Text>
                            <Tag color={item.ok ? "green" : "red"}>{item.status}</Tag>
                        </Space>
                        <Text type="secondary">
                            Qualification: {item.qualificationStatus} · {item.message}
                        </Text>
                    </Space>
                </List.Item>
            )}
        />
    );
}

function EquipmentDetails({ items }: { items: EquipmentItem[] }) {
    if (!items?.length) return null;

    return (
        <List
            size="small"
            dataSource={items}
            renderItem={(item) => (
                <List.Item>
                    <Space direction="vertical" size={0} style={{ width: "100%" }}>
                        <Space wrap>
                            <Text strong>{item.equipmentCode}</Text>
                            <Text>{item.equipmentName}</Text>
                            <Tag color={item.ok ? "green" : "red"}>{item.currentStatus}</Tag>
                        </Space>
                        <Text type="secondary">
                            Qualification: {item.qualificationStatus} · Calibration due: {formatDate(item.nextCalibrationDate)} · Maintenance due: {formatDate(item.nextMaintenanceDate)}
                        </Text>
                        <Text type="secondary">{item.message}</Text>
                    </Space>
                </List.Item>
            )}
        />
    );
}

export default function ReadinessPanel({ loading, data, selectedOrder, canProceed, proceeding, onProceed, allocationExists }: ReadinessPanelProps) {
    const allocationStatus = allocationExists === undefined ? null : allocationExists;
    if (!selectedOrder) {
        return (
            <Card>
                <Empty
                    image={Empty.PRESENTED_IMAGE_SIMPLE}
                    description="Select an issued batch to check dispensing readiness"
                />
            </Card>
        );
    }

    return (
        <Card>
            <Space direction="vertical" size={16} style={{ width: "100%" }}>
                <Space style={{ width: "100%", justifyContent: "space-between" }} align="start">
                    <div>
                        <Title level={4} style={{ margin: 0 }}>
                            <ExperimentOutlined /> Dispensing Readiness
                        </Title>
                        <Text type="secondary">
                            {selectedOrder.productName} · Batch {selectedOrder.batchNumber}
                        </Text>
                    </div>
                    <Space wrap>
                        {data && (
                            <Tag color={data.ready ? "green" : "red"} style={{ padding: "4px 10px" }}>
                                {data.ready ? "Green Signal" : "Blocked"}
                            </Tag>
                        )}
                        {allocationStatus !== null && (
                            <Tag
                                color={allocationStatus ? "blue" : "orange"}
                                style={{ padding: "4px 10px" }}
                            >
                                {allocationStatus ? "Lot Allocated ✓" : "Lot Not Allocated"}
                            </Tag>
                        )}
                    </Space>
                </Space>

                {loading ? (
                    <div style={{ padding: 40, textAlign: "center" }}>
                        <Spin />
                    </div>
                ) : data ? (
                    <>
                        {allocationStatus !== null && !allocationStatus && data.ready && (
                            <Alert
                                type="info"
                                showIcon
                                message="Lot allocation pending"
                                description="Lot numbers have not been assigned yet. Click 'Proceed to Lot Allocation' to assign lots."
                            />
                        )}
                        {allocationStatus !== null && allocationStatus && data.ready && (
                            <Alert
                                type="success"
                                showIcon
                                message="Lot allocation completed"
                                description="All materials have been assigned lot numbers. You can proceed to dispensing."
                            />
                        )}
                        <Alert
                            type={data.ready ? "success" : "warning"}
                            showIcon
                            message={data.ready ? "All pre-dispensing checks passed" : "Resolve blocked checks before dispensing"}
                        />

                        <Descriptions size="small" bordered column={1}>
                            <Descriptions.Item label="Process Order">{data.processOrder.processOrderCode}</Descriptions.Item>
                            <Descriptions.Item label="Product">{data.processOrder.productCode} - {data.processOrder.productName}</Descriptions.Item>
                            <Descriptions.Item label="Batch Number">{data.processOrder.batchNumber}</Descriptions.Item>
                            <Descriptions.Item label="BOM">{data.processOrder.bomCode} v{data.processOrder.bomVersion}</Descriptions.Item>
                        </Descriptions>

                        <List
                            itemLayout="vertical"
                            dataSource={Object.entries(data.checks)}
                            renderItem={([key, check]) => (
                                <List.Item>
                                    <Space direction="vertical" size={8} style={{ width: "100%" }}>
                                        <CheckHeader check={check} />
                                        {key === "facilities" && <FacilityDetails items={(check.details || []) as FacilityItem[]} />}
                                        {key === "equipment" && <EquipmentDetails items={(check.details || []) as EquipmentItem[]} />}
                                    </Space>
                                </List.Item>
                            )}
                        />

                        <Button
                            type="primary"
                            size="large"
                            block
                            disabled={!data.ready || !canProceed}
                            loading={proceeding}
                            icon={<RightOutlined />}
                            onClick={onProceed}
                        >
                            {!canProceed
                                ? "Not Authorized"
                                : allocationExists
                                    ? "Proceed to Dispensing"
                                    : "Proceed to Lot Allocation"
                            }
                        </Button>
                    </>
                ) : (
                    <Alert type="info" showIcon message="Readiness check will appear here." />
                )}
            </Space>
        </Card>
    );
}
