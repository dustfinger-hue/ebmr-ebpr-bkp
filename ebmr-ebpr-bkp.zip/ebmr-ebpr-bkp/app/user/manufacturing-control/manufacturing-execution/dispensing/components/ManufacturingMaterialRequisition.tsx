'use client';

import {
    Alert,
    Button,
    Card,
    Col,
    Descriptions,
    Divider,
    Input,
    InputNumber,
    message,
    Modal,
    Row,
    Space,
    Spin,
    Table,
    Tag,
    Tooltip,
    Typography,
} from "antd";
import {
    CheckCircleTwoTone,
    CloseCircleTwoTone,
    DeleteOutlined,
    ExperimentOutlined,
    PlusOutlined,
    RightOutlined,
    RollbackOutlined,
    SaveOutlined,
} from "@ant-design/icons";
import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuthorization } from "@/hooks/useAuthorization";

const { Title, Text } = Typography;

type LotEntry = {
    lotNumber: string;
    quantity: number;
};

type MaterialEntry = {
    materialCode: string;
    materialName: string;
    materialCategory: string;
    uom: string;
    totalRequiredQuantity: number;
    lots: LotEntry[];
};

type ProcessOrderInfo = {
    processOrderId: string;
    processOrderCode: string;
    productName: string;
    batchNumber: string | null;
    bomCode: string;
    bomVersion: string;
    batchSizeSemifinished: number;
    uom: string;
};

type Props = {
    processOrderId: string;
};

export default function ManufacturingMaterialRequisition({ processOrderId }: Props) {
    const router = useRouter();
    const { hasAccess } = useAuthorization();
    const isAuthorized = hasAccess("Dispensing", "create");

    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [orderInfo, setOrderInfo] = useState<ProcessOrderInfo | null>(null);
    const [materials, setMaterials] = useState<MaterialEntry[]>([]);
    const [error, setError] = useState<string | null>(null);
    const [successModalOpen, setSuccessModalOpen] = useState(false);

    const fetchBomMaterials = useCallback(async () => {
        try {
            setLoading(true);
            setError(null);
            const token = localStorage.getItem("token");
            const res = await fetch(
                `/api/user/manufacturing-control/dispensing/bom-materials?processOrderId=${processOrderId}`,
                { headers: { Authorization: `Bearer ${token}` } }
            );
            const result = await res.json();

            if (result.success) {
                setOrderInfo({
                    processOrderId: result.processOrderId,
                    processOrderCode: result.processOrderCode,
                    productName: result.productName,
                    batchNumber: result.batchNumber,
                    bomCode: result.bomCode,
                    bomVersion: result.bomVersion,
                    batchSizeSemifinished: result.batchSizeSemifinished,
                    uom: result.uom,
                });
                const initialMaterials: MaterialEntry[] = (result.materials || []).map(
                    (mat: {
                        materialCode: string;
                        materialName: string;
                        materialCategory: string;
                        uom: string;
                        totalRequiredQuantity: number;
                    }) => ({
                        materialCode: mat.materialCode,
                        materialName: mat.materialName,
                        materialCategory: mat.materialCategory,
                        uom: mat.uom,
                        totalRequiredQuantity: mat.totalRequiredQuantity,
                        lots: [],
                    })
                );
                setMaterials(initialMaterials);
            } else {
                setError(result.message || "Failed to fetch BOM materials");
            }
        } catch (err) {
            console.error("Error fetching BOM materials:", err);
            setError("Error fetching BOM materials");
        } finally {
            setLoading(false);
        }
    }, [processOrderId]);

    useEffect(() => {
        void fetchBomMaterials();
    }, [fetchBomMaterials]);

    const addLot = (materialIndex: number) => {
        setMaterials((prev) => {
            const updated = [...prev];
            updated[materialIndex] = {
                ...updated[materialIndex],
                lots: [
                    ...updated[materialIndex].lots,
                    { lotNumber: "", quantity: 0 },
                ],
            };
            return updated;
        });
    };

    const updateLot = (materialIndex: number, lotIndex: number, field: keyof LotEntry, value: string | number) => {
        setMaterials((prev) => {
            const updated = [...prev];
            const lots = [...updated[materialIndex].lots];
            lots[lotIndex] = { ...lots[lotIndex], [field]: value };
            updated[materialIndex] = { ...updated[materialIndex], lots };
            return updated;
        });
    };

    const removeLot = (materialIndex: number, lotIndex: number) => {
        setMaterials((prev) => {
            const updated = [...prev];
            updated[materialIndex] = {
                ...updated[materialIndex],
                lots: updated[materialIndex].lots.filter((_, i) => i !== lotIndex),
            };
            return updated;
        });
    };

    const getTotalAllocatedQty = (materialIndex: number): number => {
        return materials[materialIndex].lots.reduce((sum, lot) => sum + (lot.quantity || 0), 0);
    };

    const isMaterialComplete = (materialIndex: number): boolean => {
        const mat = materials[materialIndex];
        if (!mat.lots || mat.lots.length === 0) return false;
        const totalQty = getTotalAllocatedQty(materialIndex);
        return totalQty === mat.totalRequiredQuantity;
    };

    const isFormValid = (): boolean => {
        if (!materials || materials.length === 0) return false;
        return materials.every((_, index) => isMaterialComplete(index));
    };

    const handleSubmit = async () => {
        if (!isFormValid()) {
            message.error("Please complete lot allocation for all materials");
            return;
        }

        if (!orderInfo) return;

        try {
            setSubmitting(true);
            const token = localStorage.getItem("token");
            const res = await fetch("/api/user/manufacturing-control/dispensing/allocate-lots", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({
                    processOrderId: orderInfo.processOrderId,
                    processOrderCode: orderInfo.processOrderCode,
                    productName: orderInfo.productName,
                    batchNumber: orderInfo.batchNumber,
                    materials: materials.map((mat) => ({
                        materialCode: mat.materialCode,
                        materialName: mat.materialName,
                        materialCategory: mat.materialCategory,
                        uom: mat.uom,
                        totalRequiredQuantity: mat.totalRequiredQuantity,
                        lots: mat.lots.map((lot) => ({
                            lotNumber: lot.lotNumber,
                            quantity: lot.quantity,
                        })),
                    })),
                }),
            });

            const result = await res.json();

            if (result.success) {
                message.success("Lot allocation saved successfully!");
                setSubmitting(false);
                setSuccessModalOpen(true);
                return;
            } else {
                if (result.errors && Array.isArray(result.errors)) {
                    result.errors.forEach((err: string) => message.error(err));
                } else {
                    message.error(result.message || "Failed to save lot allocation");
                }
            }
        } catch (err) {
            console.error("Error saving lot allocation:", err);
            message.error("Error saving lot allocation");
        } finally {
            setSubmitting(false);
        }
    };

    const materialColumns = [
        {
            title: "Material Code",
            dataIndex: "materialCode",
            key: "materialCode",
            width: 130,
            render: (text: string) => <Text code>{text}</Text>,
        },
        {
            title: "Material Name",
            dataIndex: "materialName",
            key: "materialName",
            width: 200,
        },
        {
            title: "Category",
            dataIndex: "materialCategory",
            key: "materialCategory",
            width: 120,
            render: (text: string) => <Tag>{text}</Tag>,
        },
        {
            title: "Required Qty",
            dataIndex: "totalRequiredQuantity",
            key: "totalRequiredQuantity",
            width: 100,
            render: (qty: number, record: MaterialEntry) => (
                <Text strong>
                    {qty} {record.uom}
                </Text>
            ),
        },
        {
            title: "Allocated Qty",
            key: "allocatedQty",
            width: 100,
            render: (_: unknown, record: MaterialEntry, index: number) => {
                const allocated = getTotalAllocatedQty(index);
                const complete = allocated === record.totalRequiredQuantity;
                const over = allocated > record.totalRequiredQuantity;
                return (
                    <Space>
                        <Text
                            type={complete ? "success" : over ? "danger" : "warning"}
                            strong
                        >
                            {allocated} {record.uom}
                        </Text>
                        {complete && <CheckCircleTwoTone twoToneColor="#52c41a" />}
                        {over && <CloseCircleTwoTone twoToneColor="#ff4d4f" />}
                    </Space>
                );
            },
        },
        {
            title: "Remaining Qty",
            key: "remainingQty",
            width: 100,
            render: (_: unknown, record: MaterialEntry, index: number) => {
                const allocated = getTotalAllocatedQty(index);
                const remaining = record.totalRequiredQuantity - allocated;
                const complete = allocated === record.totalRequiredQuantity;
                const over = allocated > record.totalRequiredQuantity;
                return (
                    <Text
                        type={complete ? "success" : over ? "danger" : "warning"}
                        strong
                    >
                        {over ? 0 : remaining} {record.uom}
                    </Text>
                );
            },
        },
        {
            title: "Status",
            key: "status",
            width: 90,
            render: (_: unknown, __: unknown, index: number) => {
                const complete = isMaterialComplete(index);
                return complete ? (
                    <Tag color="green">Complete</Tag>
                ) : (
                    <Tag color="orange">Pending</Tag>
                );
            },
        },
        {
            title: "Lots",
            key: "lots",
            width: 250,
            render: (_: unknown, __: unknown, materialIndex: number) => {
                const mat = materials[materialIndex];
                return (
                    <Space direction="vertical" size={4} style={{ width: "100%" }}>
                        {mat.lots.map((lot, lotIndex) => (
                            <Row key={lotIndex} gutter={[4, 4]} align="middle" wrap={false}>
                                <Col flex="auto">
                                    <Input
                                        size="small"
                                        placeholder="Lot number"
                                        value={lot.lotNumber}
                                        onChange={(e) =>
                                            updateLot(materialIndex, lotIndex, "lotNumber", e.target.value)
                                        }
                                        style={{ width: 120 }}
                                    />
                                </Col>
                                <Col>
                                    <InputNumber
                                        size="small"
                                        placeholder="Qty"
                                        value={lot.quantity || undefined}
                                        min={0}
                                        max={mat.totalRequiredQuantity}
                                        onChange={(val) =>
                                            updateLot(materialIndex, lotIndex, "quantity", val || 0)
                                        }
                                        style={{ width: 60 }}
                                        addonAfter={mat.uom}
                                    />
                                </Col>
                                <Col>
                                    <Tooltip title="Remove lot">
                                        <Button
                                            type="text"
                                            size="small"
                                            danger
                                            icon={<DeleteOutlined />}
                                            onClick={() => removeLot(materialIndex, lotIndex)}
                                        />
                                    </Tooltip>
                                </Col>
                            </Row>
                        ))}
                        <Tooltip title={isMaterialComplete(materialIndex) ? "Material allocation complete" : "Add lot"}>
                            <Button
                                type="dashed"
                                size="small"
                                icon={<PlusOutlined />}
                                onClick={() => addLot(materialIndex)}
                                disabled={isMaterialComplete(materialIndex)}
                                style={{ width: "100%" }}
                            >
                                Add Lot
                            </Button>
                        </Tooltip>
                    </Space>
                );
            },
        },
    ];

    if (loading) {
        return (
            <Card>
                <div style={{ padding: 60, textAlign: "center" }}>
                    <Spin size="large" />
                    <div style={{ marginTop: 16 }}>
                        <Text type="secondary">Loading BOM materials...</Text>
                    </div>
                </div>
            </Card>
        );
    }

    if (error) {
        return (
            <Card>
                <Alert
                    type="error"
                    showIcon
                    message="Error"
                    description={error}
                    action={
                        <Button onClick={fetchBomMaterials} type="primary" size="small">
                            Retry
                        </Button>
                    }
                />
            </Card>
        );
    }

    if (!orderInfo) {
        return (
            <Card>
                <Alert type="warning" showIcon message="No process order information found" />
            </Card>
        );
    }

    return (
        <Space direction="vertical" size={20} style={{ width: "100%" }}>
            <Modal
                title={
                    <Space>
                        <CheckCircleTwoTone twoToneColor="#52c41a" />
                        <span>Lot Allocation Successful</span>
                    </Space>
                }
                open={successModalOpen}
                onCancel={() => setSuccessModalOpen(false)}
                footer={
                    <Space style={{ width: "100%", justifyContent: "flex-end" }}>
                        <Button
                            icon={<RollbackOutlined />}
                            onClick={() => {
                                setSuccessModalOpen(false);
                                router.push("/user/manufacturing-control/manufacturing-execution/dispensing");
                            }}
                        >
                            Back to Readiness
                        </Button>
                        <Button
                            type="primary"
                            icon={<RightOutlined />}
                            onClick={() => {
                                setSuccessModalOpen(false);
                                router.push(`/user/manufacturing-control/manufacturing-execution/dispensing/workbench?processOrderId=${processOrderId}&mode=dispensing`);
                            }}
                        >
                            Proceed to Dispensing
                        </Button>
                    </Space>
                }
            >
                <Space direction="vertical" size={12} style={{ width: "100%" }}>
                    <Text>Lot allocation has been saved successfully for process order <Text strong>{orderInfo?.processOrderCode}</Text>.</Text>
                    <Text type="secondary">What would you like to do next?</Text>
                </Space>
            </Modal>

            <Card>
                <Space style={{ width: "100%", justifyContent: "space-between" }} align="start">
                    <div>
                        <Title level={4} style={{ margin: 0 }}>
                            <ExperimentOutlined /> Manufacturing Material Requisition
                        </Title>
                        <Text type="secondary">
                            Assign lot numbers to materials before dispensing
                        </Text>
                    </div>
                    <Button
                        type="primary"
                        size="large"
                        icon={<SaveOutlined />}
                        loading={submitting}
                        disabled={!isFormValid() || !isAuthorized}
                        onClick={handleSubmit}
                    >
                        {isAuthorized ? "Save Lot Allocation" : "Not Authorized"}
                    </Button>
                </Space>

                <Divider />

                <Descriptions size="small" bordered column={2} style={{ marginBottom: 16 }}>
                    <Descriptions.Item label="Process Order" span={2}>
                        <Text strong>{orderInfo.processOrderCode}</Text>
                    </Descriptions.Item>
                    <Descriptions.Item label="Product">
                        {orderInfo.productName}
                    </Descriptions.Item>
                    <Descriptions.Item label="Batch Number">
                        {orderInfo.batchNumber || "-"}
                    </Descriptions.Item>
                    <Descriptions.Item label="BOM">
                        {orderInfo.bomCode} v{orderInfo.bomVersion}
                    </Descriptions.Item>
                    <Descriptions.Item label="Batch Size">
                        {orderInfo.batchSizeSemifinished} {orderInfo.uom}
                    </Descriptions.Item>
                </Descriptions>

                <Alert
                    type="info"
                    showIcon
                    message="Lot Allocation Instructions"
                    description="For each material, add one or more lot numbers and specify the quantity allocated from each lot. The total allocated quantity must exactly match the required quantity."
                    style={{ marginBottom: 16 }}
                />

                <Table
                    columns={materialColumns}
                    dataSource={materials}
                    rowKey="materialCode"
                    pagination={false}
                    scroll={{ x: "max-content" }}
                    bordered
                />
            </Card>
        </Space>
    );
}