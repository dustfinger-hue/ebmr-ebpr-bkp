'use client';

import { Alert, Button, Card, Descriptions, Space, Spin, Typography } from "antd";
import { ExperimentOutlined, RollbackOutlined } from "@ant-design/icons";
import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";

const { Title, Text } = Typography;

type Props = {
    processOrderId: string;
};

type DispensingInfo = {
    processOrderCode: string;
    productName: string;
    batchNumber: string | null;
    lotAllocatedBy: {
        fullName: string;
        designation: string;
        department: string;
    };
    allocatedAt: string;
    materials: Array<{
        materialCode: string;
        materialName: string;
        totalRequiredQuantity: number;
        uom: string;
        lots: Array<{
            lotNumber: string;
            quantity: number;
        }>;
    }>;
};

export default function DispensingExecution({ processOrderId }: Props) {
    const router = useRouter();
    const [loading, setLoading] = useState(true);
    const [dispensingInfo, setDispensingInfo] = useState<DispensingInfo | null>(null);
    const [error, setError] = useState<string | null>(null);

    const fetchAllocationData = useCallback(async () => {
        try {
            setLoading(true);
            setError(null);
            const token = localStorage.getItem("token");
            const res = await fetch(
                `/api/user/manufacturing-control/dispensing/allocate-lots?processOrderId=${processOrderId}`,
                { headers: { Authorization: `Bearer ${token}` } }
            );
            const result = await res.json();

            if (result.success) {
                setDispensingInfo(result.data);
            } else {
                setError(result.message || "Failed to fetch allocation data");
            }
        } catch (err) {
            console.error("Error fetching allocation data:", err);
            setError("Error fetching allocation data");
        } finally {
            setLoading(false);
        }
    }, [processOrderId]);

    useEffect(() => {
        void fetchAllocationData();
    }, [fetchAllocationData]);

    if (loading) {
        return (
            <Card>
                <div style={{ padding: 60, textAlign: "center" }}>
                    <Spin size="large" />
                    <div style={{ marginTop: 16 }}>
                        <Text type="secondary">Loading dispensing data...</Text>
                    </div>
                </div>
            </Card>
        );
    }

    if (error) {
        return (
            <Card>
                <Alert
                    type="error"
                    showIcon
                    title="Error"
                    description={error}
                    action={
                        <Button onClick={fetchAllocationData} type="primary" size="small">
                            Retry
                        </Button>
                    }
                />
            </Card>
        );
    }

    if (!dispensingInfo) {
        return (
            <Card>
                <Alert
                    type="warning"
                    showIcon
                    title="No allocation data found"
                    description="Lot allocation has not been completed for this process order yet."
                />
                <Button
                    className="mt-4"
                    icon={<RollbackOutlined />}
                    onClick={() => router.push("/user/manufacturing-control/manufacturing-execution/dispensing")}
                >
                    Back to Readiness
                </Button>
            </Card>
        );
    }

    return (
        <Card>
            <Space orientation="vertical" size={20} style={{ width: "100%" }}>
                <Space style={{ width: "100%", justifyContent: "space-between" }} align="start">
                    <div>
                        <Title level={4} style={{ margin: 0 }}>
                            <ExperimentOutlined /> Dispensing Execution
                        </Title>
                        <Text type="secondary">Perform actual dispensing of allocated materials</Text>
                    </div>
                    <Button
                        icon={<RollbackOutlined />}
                        onClick={() => router.push("/user/manufacturing-control/manufacturing-execution/dispensing")}
                    >
                        Back to Readiness
                    </Button>
                </Space>

                <Descriptions size="small" bordered column={2}>
                    <Descriptions.Item label="Process Order" span={2}>
                        <Text strong>{dispensingInfo.processOrderCode}</Text>
                    </Descriptions.Item>
                    <Descriptions.Item label="Product">
                        {dispensingInfo.productName}
                    </Descriptions.Item>
                    <Descriptions.Item label="Batch Number">
                        {dispensingInfo.batchNumber || "-"}
                    </Descriptions.Item>
                    <Descriptions.Item label="Allocated By">
                        {dispensingInfo.lotAllocatedBy.fullName} ({dispensingInfo.lotAllocatedBy.designation} - {dispensingInfo.lotAllocatedBy.department})
                    </Descriptions.Item>
                    <Descriptions.Item label="Allocated At">
                        {dispensingInfo.allocatedAt ? new Date(dispensingInfo.allocatedAt).toLocaleString() : "-"}
                    </Descriptions.Item>
                </Descriptions>

                <Alert
                    type="info"
                    showIcon
                    title="Dispensing Execution - Coming Soon"
                    description="This page will contain the actual dispensing workflow where materials are weighed, dispensed, and verified against the allocated lots. The functionality is under development."
                />

                {dispensingInfo.materials?.map((material, index) => (
                    <Card key={index} size="small" title={`${material.materialCode} - ${material.materialName}`} extra={<Text strong>{material.totalRequiredQuantity} {material.uom}</Text>}>
                        <Space orientation="vertical" size={8} style={{ width: "100%" }}>
                            {material.lots.map((lot, lotIndex) => (
                                <div key={lotIndex} style={{ display: "flex", justifyContent: "space-between", padding: "4px 8px", background: "#f5f5f5", borderRadius: 4 }}>
                                    <Text strong>Lot: {lot.lotNumber}</Text>
                                    <Text>{lot.quantity} {material.uom}</Text>
                                </div>
                            ))}
                        </Space>
                    </Card>
                ))}
            </Space>
        </Card>
    );
}