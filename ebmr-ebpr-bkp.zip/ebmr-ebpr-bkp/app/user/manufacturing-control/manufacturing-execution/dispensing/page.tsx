'use client';

import {
    Alert,
    Button,
    Card,
    Col,
    Collapse,
    Descriptions,
    List,
    message,
    Modal,
    Row,
    Space,
    Spin,
    Table,
    Tag,
    Tooltip,
    Typography,
} from "antd";
import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { FaClipboardList } from "react-icons/fa";
import {
    CheckCircleTwoTone,
    CloseCircleTwoTone,
    ExperimentOutlined,
    EyeTwoTone,
    ReloadOutlined,
    RightOutlined,
    SearchOutlined,
} from "@ant-design/icons";
import Search from "antd/es/input/Search";
import ViewProcessOrder from "@/app/user/manufacturing-control/process-order-creation/components/View-Process-Order";
import { useAuthorization } from "@/hooks/useAuthorization";

const { Title, Text } = Typography;

type ProcessOrderRow = {
    _id: string;
    processOrderCode: string;
    productCode: string;
    productName: string;
    bomCode: string;
    bomVersion: string;
    status: string;
    batchNumber?: string | null;
    manufacturingFacility?: string[];
};

type CheckResult = {
    ok: boolean;
    title: string;
    message: string;
    details?: unknown;
};

type ReadinessData = {
    ready: boolean;
    processOrder: {
        processOrderCode: string;
        productCode: string;
        productName: string;
        batchNumber?: string | null;
        bomCode: string;
        bomVersion: string;
    };
    checks: Record<string, CheckResult>;
};

type FacilityItem = {
    ok: boolean;
    facilityCode: string;
    areaName: string;
    status: string;
    qualificationStatus: string;
    message: string;
};

type EquipmentItem = {
    ok: boolean;
    equipmentCode: number;
    equipmentName: string;
    currentStatus: string;
    qualificationStatus: string;
    nextCalibrationDate?: string | Date | null;
    nextMaintenanceDate?: string | Date | null;
    message: string;
};

const getCheckColor = (ok: boolean) => ok ? "success" : "error";

const formatDate = (date?: string | Date | null) => {
    if (!date) return "-";
    return new Date(date).toLocaleDateString();
};

function CheckHeader({ check }: { check: CheckResult }) {
    return (
        <Space align="start" >
            {check.ok ? (
                <CheckCircleTwoTone twoToneColor="#52c41a" style={{ fontSize: 20, marginTop: 2 }} />
            ) : (
                <CloseCircleTwoTone twoToneColor="#ff4d4f" style={{ fontSize: 20, marginTop: 2 }} />
            )}
            <div >
                <Space size="small" wrap>
                    <Text strong>{check.title}</Text>
                    <Tag color={getCheckColor(check.ok)}>{check.ok ? "OK" : "Hold"}</Tag>
                </Space>
                <div>
                    <Text type="secondary">{check.message}</Text>
                </div>
            </div>
        </Space>
    );
}

function FacilityDetails({ items }: { items: FacilityItem[] }) {
    if (!items?.length) return null;

    return (
        <Collapse
            size="small"
            ghost
            items={[
                {
                    key: "facilities",
                    label: (
                        <Space>
                            <Text strong>Facilities</Text>
                            <Tag>{items.length} item{items.length > 1 ? 's' : ''}</Tag>
                        </Space>
                    ),
                    children: (
                        <Space direction="vertical" size={4} style={{ width: "100%" }}>
                            {items.map((item) => (
                                <Card key={item.facilityCode} size="small" style={{ borderLeft: item.ok ? "3px solid #52c41a" : "3px solid #ff4d4f" }}>
                                    <Space direction="vertical" size={2} style={{ width: "100%" }}>
                                        <Space wrap>
                                            <Text strong>{item.facilityCode}</Text>
                                            <Text>{item.areaName}</Text>
                                            <Tag color={item.ok ? "green" : "red"}>{item.status}</Tag>
                                        </Space>
                                        <Text type="secondary">
                                            Qualification: {item.qualificationStatus} · {item.message}
                                        </Text>
                                    </Space>
                                </Card>
                            ))}
                        </Space>
                    ),
                },
            ]}
        />
    );
}

function EquipmentDetails({ items }: { items: EquipmentItem[] }) {
    if (!items?.length) return null;

    return (
        <Collapse
            size="small"
            ghost
            items={[
                {
                    key: "equipment",
                    label: (
                        <Space>
                            <Text strong>Equipment</Text>
                            <Tag>{items.length} item{items.length > 1 ? 's' : ''}</Tag>
                        </Space>
                    ),
                    children: (
                        <Space direction="vertical" size={4} style={{ width: "100%" }}>
                            {items.map((item) => (
                                <Card key={item.equipmentCode} size="small" style={{ borderLeft: item.ok ? "3px solid #52c41a" : "3px solid #ff4d4f" }}>
                                    <Space direction="vertical" size={2} style={{ width: "100%" }}>
                                        <Space wrap>
                                            <Text strong>{item.equipmentCode}</Text>
                                            <Text>{item.equipmentName}</Text>
                                            <Tag color={item.ok ? "green" : "red"}>{item.currentStatus}</Tag>
                                        </Space>
                                        <Text type="secondary">
                                            Qualification: {item.qualificationStatus} · Calibration due: {formatDate(item.nextCalibrationDate)} · Maintenance due: {formatDate(item.nextMaintenanceDate)}
                                        </Text>
                                        <Text type="secondary">{item.message}</Text>
                                    </Space>
                                </Card>
                            ))}
                        </Space>
                    ),
                },
            ]}
        />
    );
}

export default function DispensingPage() {
    const router = useRouter();
    const [data, setData] = useState<ProcessOrderRow[]>([]);
    const [loading, setLoading] = useState(false);
    const [readinessLoading, setReadinessLoading] = useState(false);
    const [readinessData, setReadinessData] = useState<ReadinessData | null>(null);
    const [selectedOrder, setSelectedOrder] = useState<ProcessOrderRow | null>(null);
    const [proceeding, setProceeding] = useState(false);
    const [viewModalOpen, setViewModalOpen] = useState(false);
    const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
    const [pagination, setPagination] = useState({
        current: 1,
        pageSize: 10,
        total: 0,
    });
    const [searchText, setSearchText] = useState("");
    const [allocationExists, setAllocationExists] = useState<Record<string, boolean>>({});

    // Modal state for readiness
    const [readinessModalOpen, setReadinessModalOpen] = useState(false);

    const { hasAccess } = useAuthorization();
    const isViewAuthorized = hasAccess("Process Order", "read");
    const isProceedAuthorized = hasAccess("Dispensing", "create");

    const getIssuedBatches = useCallback(async (page: number, limit: number, search: string) => {
        try {
            setLoading(true);
            const token = localStorage.getItem("token");
            const url = `/api/user/manufacturing-control/process-order?page=${page}&limit=${limit}&search=${search}&status=In-Progress`;
            const res = await fetch(url, {
                headers: { Authorization: `Bearer ${token}` },
            });
            const result = await res.json();

            if (result.success) {
                const rows = (result.data || []) as ProcessOrderRow[];
                setData(rows);
                setPagination((prev) => ({
                    ...prev,
                    current: result.page || page,
                    total: result.total || 0,
                }));
            } else {
                message.error(result.message || "Failed to fetch process orders");
            }
        } catch (error) {
            console.error("Error fetching process orders:", error);
            message.error("Error fetching process orders");
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        void Promise.resolve().then(() => getIssuedBatches(1, 10, ""));
    }, [getIssuedBatches]);

    const checkReadiness = async (record: ProcessOrderRow) => {
        try {
            setSelectedOrder(record);
            setReadinessData(null);
            setReadinessLoading(true);
            setReadinessModalOpen(true);

            const token = localStorage.getItem("token");
            const res = await fetch(`/api/user/manufacturing-control/dispensing/readiness?processOrderId=${record._id}`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            const result = await res.json();

            if (result.success) {
                setReadinessData(result as ReadinessData);

                // Also check if allocation exists for this order
                const exists = await checkAllocationStatus(record._id);
                setAllocationExists((prev) => ({ ...prev, [record._id]: exists }));
            } else {
                message.error(result.message || "Failed to check readiness");
                setReadinessModalOpen(false);
            }
        } catch (error) {
            console.error("Error checking readiness:", error);
            message.error("Error checking readiness");
            setReadinessModalOpen(false);
        } finally {
            setReadinessLoading(false);
        }
    };

    const checkAllocationStatus = async (processOrderId: string): Promise<boolean> => {
        try {
            const token = localStorage.getItem("token");
            const res = await fetch(`/api/user/manufacturing-control/dispensing/allocate-lots?processOrderId=${processOrderId}`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            const result = await res.json();
            return result.success && result.exists;
        } catch {
            return false;
        }
    };

    const handleProceedToDispensing = async () => {
        if (!selectedOrder) {
            message.warning("No process order selected");
            return;
        }
        setProceeding(true);

        // Check if allocation already exists
        const allocationCheck = allocationExists[selectedOrder._id];

        if (allocationCheck) {
            router.push(`/user/manufacturing-control/manufacturing-execution/dispensing/workbench?processOrderId=${selectedOrder._id}&mode=dispensing`);
        } else {
            router.push(`/user/manufacturing-control/manufacturing-execution/dispensing/workbench?processOrderId=${selectedOrder._id}&mode=allocation`);
        }
    };

    const columns = [
        {
            title: "S.No",
            width: 70,
            render: (_: unknown, __: unknown, index: number) =>
                (pagination.current - 1) * pagination.pageSize + index + 1,
        },
        {
            title: "Product",
            key: "product",
            width: 240,
            render: (_: unknown, record: ProcessOrderRow) => (
                <div>
                    <Text type="secondary" style={{ fontSize: 12 }}>{record.productCode}</Text>
                    <br />
                    <Text>{record.productName}</Text>
                </div>
            ),
        },
        {
            title: "Batch Number",
            dataIndex: "batchNumber",
            key: "batchNumber",
            width: 150,
            render: (text: string) => <Tag color="green" style={{ fontWeight: 600 }}>{text || "-"}</Tag>,
        },
        {
            title: "Process Order",
            dataIndex: "processOrderCode",
            key: "processOrderCode",
            width: 150,
            render: (text: string) => <Text strong>{text}</Text>,
        },
        {
            title: "BOM",
            key: "bom",
            width: 150,
            render: (_: unknown, record: ProcessOrderRow) => (
                <Text type="secondary">{record.bomCode} v{record.bomVersion}</Text>
            ),
        },
        {
            title: "Status",
            dataIndex: "status",
            key: "status",
            width: 120,
            render: (text: string) => <Tag color={text === "In-Progress" ? "blue" : "default"}>{text}</Tag>,
        },
        {
            title: "Facilities",
            dataIndex: "manufacturingFacility",
            key: "manufacturingFacility",
            width: 220,
            render: (facilities: unknown) => {
                const facilityList = Array.isArray(facilities) ? facilities : [];
                return (
                    <Space size={[0, 4]} wrap>
                        {facilityList.map((facility, index) => (
                            <Tag key={`${facility}-${index}`} color="blue">{facility}</Tag>
                        ))}
                        {facilityList.length === 0 && <Text type="secondary">-</Text>}
                    </Space>
                );
            },
        },
        {
            title: "Action",
            width: 150,
            fixed: "right" as const,
            render: (record: ProcessOrderRow) => (
                <Space size="small">
                    <Tooltip title={isViewAuthorized ? "View details" : "Not authorized"}>
                        <Button
                            type="text"
                            size="small"
                            disabled={!isViewAuthorized}
                            icon={<EyeTwoTone />}
                            onClick={(e) => {
                                e.stopPropagation();
                                setSelectedOrderId(record._id);
                                setViewModalOpen(true);
                            }}
                        />
                    </Tooltip>
                    <Tooltip title="Run readiness checks">
                        <Button
                            type="primary"
                            size="small"
                            icon={<CheckCircleTwoTone twoToneColor="#52c41a" />}
                            loading={readinessLoading && selectedOrder?._id === record._id}
                            onClick={(e) => {
                                e.stopPropagation();
                                checkReadiness(record);
                            }}
                        >
                            Check
                        </Button>
                    </Tooltip>
                </Space>
            ),
        },
    ];

    const allocationStatus = selectedOrder ? (allocationExists[selectedOrder._id] === undefined ? null : allocationExists[selectedOrder._id]) : null;

    return (
        <div>
            <Title level={2}>
                <FaClipboardList size={28} className="inline mb-1 mr-2" />
                Dispensing - Readiness Check
            </Title>

            <Card>
                <Row gutter={[12, 12]} style={{ marginBottom: 16 }} justify="space-between">
                    <Col xs={24} md={12}>
                        <Search
                            placeholder="Search product or process order..."
                            allowClear
                            prefix={<SearchOutlined />}
                            onSearch={(value) => {
                                setSearchText(value);
                                getIssuedBatches(1, pagination.pageSize, value);
                            }}
                        />
                    </Col>
                    <Col>
                        <Tooltip title="Refresh">
                            <Button
                                icon={<ReloadOutlined />}
                                onClick={() => getIssuedBatches(pagination.current, pagination.pageSize, searchText)}
                            />
                        </Tooltip>
                    </Col>
                </Row>

                <Table
                    columns={columns}
                    dataSource={data}
                    loading={loading}
                    rowKey="_id"
                    scroll={{ x: "max-content" }}
                    onRow={(record) => ({
                        onClick: () => checkReadiness(record),
                        style: {
                            cursor: "pointer",
                        },
                    })}
                    pagination={{
                        current: pagination.current,
                        pageSize: pagination.pageSize,
                        total: pagination.total,
                        showSizeChanger: true,
                        pageSizeOptions: ["10", "20", "30", "40", "50"],
                        onChange: (page: number, pageSize: number) => {
                            setPagination((prev) => ({ ...prev, current: page, pageSize }));
                            getIssuedBatches(page, pageSize, searchText);
                        },
                    }}
                />
            </Card>

            {/* Readiness Check Modal */}
            <Modal
                title={
                    <Space>
                        <ExperimentOutlined style={{ color: "#1890ff" }} />
                        <span>Dispensing Readiness</span>
                        {selectedOrder && (
                            <Text type="secondary" style={{ fontSize: 13 }}>
                                {selectedOrder.productName} · Batch {selectedOrder.batchNumber}
                            </Text>
                        )}
                    </Space>
                }
                open={readinessModalOpen}
                onCancel={() => {
                    setReadinessModalOpen(false);
                    setSelectedOrder(null);
                    setReadinessData(null);
                }}
                width={900}
                footer={
                    readinessData ? (
                        <Space style={{ width: "100%", justifyContent: "flex-end" }}>
                            <Button
                                onClick={() => {
                                    setReadinessModalOpen(false);
                                    setSelectedOrder(null);
                                    setReadinessData(null);
                                }}
                            >
                                Close
                            </Button>
                            <Button
                                type="primary"
                                // size="large"
                                disabled={!readinessData.ready || !isProceedAuthorized}
                                loading={proceeding}
                                icon={<RightOutlined />}
                                onClick={handleProceedToDispensing}
                            >
                                {!isProceedAuthorized
                                    ? "Not Authorized"
                                    : allocationExists[selectedOrder?._id || ""]
                                        ? "Proceed to Dispensing"
                                        : "Proceed to Lot Allocation"
                                }
                            </Button>
                        </Space>
                    ) : null
                }
            >
                <Space direction="vertical" size={16} style={{ width: "100%" }}>
                    {readinessLoading ? (
                        <div style={{ padding: 60, textAlign: "center" }}>
                            <Spin size="large" />
                            <div style={{ marginTop: 16 }}>
                                <Text type="secondary">Running readiness checks...</Text>
                            </div>
                        </div>
                    ) : readinessData ? (
                        <>
                            <Space style={{ width: "100%", justifyContent: "space-between" }} align="start">
                                <Space wrap>
                                    {readinessData && (
                                        <Tag color={readinessData.ready ? "green" : "red"} style={{ padding: "4px 10px" }}>
                                            {readinessData.ready ? "Green Signal" : "Blocked"}
                                        </Tag>
                                    )}
                                    {allocationStatus !== null && (
                                        <Tag
                                            color={allocationStatus ? "blue" : "orange"}
                                            style={{ padding: "4px 10px" }}
                                        >
                                            {allocationStatus ? "Lot Allocated ✓" : "Lot Not Allocated"}
                                        </Tag>
                                    )}
                                </Space>
                            </Space>

                            {allocationStatus !== null && !allocationStatus && readinessData.ready && (
                                <Alert
                                    type="info"
                                    showIcon
                                    message="Lot allocation pending"
                                    description="Lot numbers have not been assigned yet. Click 'Proceed to Lot Allocation' to assign lots."
                                />
                            )}
                            {allocationStatus !== null && allocationStatus && readinessData.ready && (
                                <Alert
                                    type="success"
                                    showIcon
                                    message="Lot allocation completed"
                                    description="All materials have been assigned lot numbers. You can proceed to dispensing."
                                />
                            )}
                            <Alert
                                type={readinessData.ready ? "success" : "warning"}
                                showIcon
                                message={readinessData.ready ? "All pre-dispensing checks passed" : "Resolve blocked checks before dispensing"}
                            />
                            <div>
                                <Descriptions size="small" bordered column={1}>
                                    <Descriptions.Item label="Process Order">{readinessData.processOrder.processOrderCode}</Descriptions.Item>
                                    <Descriptions.Item label="Product">{readinessData.processOrder.productCode} - {readinessData.processOrder.productName}</Descriptions.Item>
                                    <Descriptions.Item label="Batch Number">{readinessData.processOrder.batchNumber || "-"}</Descriptions.Item>
                                    <Descriptions.Item label="BOM">{readinessData.processOrder.bomCode} v{readinessData.processOrder.bomVersion}</Descriptions.Item>
                                </Descriptions>

                                <List
                                    itemLayout="vertical"
                                    dataSource={Object.entries(readinessData.checks)}
                                    renderItem={([key, check]) => (
                                        <List.Item>
                                            <Space direction="vertical" size={8} style={{ width: "100%" }}>
                                                <CheckHeader check={check} />
                                                {key === "facilities" && <FacilityDetails items={(check.details || []) as FacilityItem[]} />}
                                                {key === "equipment" && <EquipmentDetails items={(check.details || []) as EquipmentItem[]} />}
                                            </Space>
                                        </List.Item>
                                    )}
                                />
                            </div>
                        </>
                    ) : (
                        <Alert type="info" showIcon message="Running readiness checks..." />
                    )}
                </Space>
            </Modal>

            <ViewProcessOrder
                open={viewModalOpen}
                orderId={selectedOrderId}
                onClose={() => {
                    setViewModalOpen(false);
                    setSelectedOrderId(null);
                }}
            />
        </div>
    );
}