'use client';
import { Button, Card, Col, message, Row, Space, Table, Tag, Tooltip, Typography, Modal } from "antd";
import { useEffect, useState } from "react";
import { FaClipboardList } from "react-icons/fa";
const { Title, Text } = Typography;
import {
    SearchOutlined,
    ReloadOutlined,
    PlusOutlined,
    EyeTwoTone,
    EditTwoTone,
    DeleteTwoTone,
} from "@ant-design/icons";
import Search from "antd/es/input/Search";
import { useAuthorization } from "@/hooks/useAuthorization";
import AddProcessOrder from "./components/Add-Process-Order";
import ViewProcessOrder from "./components/View-Process-Order";
import EditProcessOrder from "./components/Edit-Process-Order";

export default function ProcessOrderCreationPage() {
    const [data, setData] = useState<any[]>([]);
    const [loading, setLoading] = useState(false);
    const [pagination, setPagination] = useState({
        current: 1,
        pageSize: 10,
        total: 0,
    });
    const [searchText, setSearchText] = useState("");
    const [addModalOpen, setAddModalOpen] = useState(false);
    const [viewModalOpen, setViewModalOpen] = useState(false);
    const [editModalOpen, setEditModalOpen] = useState(false);
    const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

    // Auth check
    const { hasAccess } = useAuthorization();
    const isCreateAuthorized = hasAccess('Process Order', 'create');
    const isViewAuthorized = hasAccess('Process Order', 'read');
    const isUpdateAuthorized = hasAccess('Process Order', 'update');
    const isDeleteAuthorized = hasAccess('Process Order', 'delete');

    useEffect(() => {
        getProcessOrders(1, 10, "");
    }, []);

    const getProcessOrders = async (page: number, limit: number, search: string) => {
        try {
            setLoading(true);
            let url = `/api/user/manufacturing-control/process-order?page=${page}&limit=${limit}&search=${search}`;

            const token = await localStorage.getItem('token');
            const res = await fetch(url, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            const result = await res.json();
            if (result.success) {
                setData(result.data || []);
                setPagination(prev => ({
                    ...prev,
                    current: result.page || page,
                    total: result.total || 0
                }));
            } else {
                message.error(result.message);
            }
        } catch (error) {
            console.error(error);
            message.error("Error fetching process orders");
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = (record: any) => {
        if (record.status !== 'Draft') {
            message.warning('Only Draft orders can be deleted');
            return;
        }
        Modal.confirm({
            title: 'Delete Process Order',
            content: `Are you sure you want to delete ${record.processOrderCode}?`,
            okText: 'Delete',
            okType: 'danger',
            cancelText: 'Cancel',
            onOk: async () => {
                try {
                    const token = localStorage.getItem('token');
                    const res = await fetch(`/api/user/manufacturing-control/process-order?id=${record._id}`, {
                        method: 'DELETE',
                        headers: { Authorization: `Bearer ${token}` }
                    });
                    const result = await res.json();
                    if (result.success) {
                        message.success(result.message);
                        getProcessOrders(pagination.current, pagination.pageSize, searchText);
                    } else {
                        message.error(result.message);
                    }
                } catch (error) {
                    console.error('Error deleting process order:', error);
                    message.error('Failed to delete process order');
                }
            }
        });
    };

    // Get stats from data
    const totalOrders = pagination.total;
    const draftOrders = data.filter((item: any) => item.status === 'Draft').length;
    const releasedOrders = data.filter((item: any) => item.status === 'Released').length;

    // Table Columns
    const columns = [
        {
            title: 'S.No',
            width: 70,
            fixed: 'left' as const,
            render: (_: any, __: any, index: number) =>
                (pagination.current - 1) * pagination.pageSize + index + 1
        },
        {
            title: 'Process Order Code',
            dataIndex: 'processOrderCode',
            key: 'processOrderCode',
            width: 150,
            render: (text: string) => <Text strong>{text}</Text>,
        },
        {
            title: 'Product',
            key: 'product',
            width: 220,
            render: (_: any, record: any) => (
                <div>
                    <Text type="secondary" style={{ fontSize: 12 }}>{record.productCode}</Text>
                    <br />
                    <Text>{record.productName}</Text>
                </div>
            ),
        },
        {
            title: 'Batch / Bulk Size',
            key: 'batchBulkSize',
            width: 190,
            render: (_: any, record: any) => (
                <div>
                    <Text>Batch: {record.batchSizeSemifinished} {record.uom}</Text>
                    <br />
                    <Text type="secondary">Bulk: {record.bulkSize} {record.bulkUom}</Text>
                </div>
            ),
        },
        {
            title: 'BOM Code',
            dataIndex: 'bomCode',
            key: 'bomCode',
            width: 140,
            render: (text: string) => <Text type="secondary">{text}</Text>,
        },
        {
            title: 'Planned Dates',
            key: 'plannedDates',
            width: 200,
            render: (_: any, record: any) => (
                <Text type="secondary">
                    {record.plannedStartDate ? new Date(record.plannedStartDate).toLocaleDateString() : '-'}
                    {' → '}
                    {record.plannedEndDate ? new Date(record.plannedEndDate).toLocaleDateString() : '-'}
                </Text>
            ),
        },
        {
            title: 'Status',
            dataIndex: 'status',
            key: 'status',
            width: 120,
            render: (text: string) => {
                let color = 'default';
                switch (text) {
                    case 'Draft': color = 'orange'; break;
                    case 'Planned': color = 'blue'; break;
                    case 'Released': color = 'green'; break;
                    case 'In-Progress': color = 'cyan'; break;
                    case 'Completed': color = 'purple'; break;
                    case 'On-Hold': color = 'red'; break;
                    case 'Cancelled': color = 'red'; break;
                }
                return <Tag color={color}>{text}</Tag>;
            },
        },
        {
            title: 'Facilities',
            dataIndex: 'manufacturingFacility',
            key: 'manufacturingFacility',
            width: 180,
            render: (facilities: any) => {
                if (!facilities || (Array.isArray(facilities) && facilities.length === 0)) return '-';
                if (Array.isArray(facilities)) {
                    return (
                        <Space size={[0, 2]} wrap>
                            {facilities.map((fac: string, i: number) => (
                                <Tag key={i} color="blue" style={{ fontSize: 11 }}>{fac}</Tag>
                            ))}
                        </Space>
                    );
                }
                return <Text type="secondary">{facilities}</Text>;
            },
        },
        {
            title: 'Action',
            width: 140,
            fixed: "right" as const,
            render: (record: any) => {
                const isDraft = record.status === 'Draft';
                return (
                    <Space size="small">
                        <Tooltip title={isViewAuthorized ? "View Details" : "Not authorized"}>
                            <Button
                                type="text"
                                size="small"
                                onClick={() => {
                                    setSelectedOrderId(record._id);
                                    setViewModalOpen(true);
                                }}
                                disabled={!isViewAuthorized}
                                icon={<EyeTwoTone />}
                            />
                        </Tooltip>
                        <Tooltip title={isUpdateAuthorized && isDraft ? "Edit" : isUpdateAuthorized ? "Only Draft orders can be edited" : "Not authorized"}>
                            <Button
                                type="text"
                                size="small"
                                onClick={() => {
                                    setSelectedOrderId(record._id);
                                    setEditModalOpen(true);
                                }}
                                disabled={!isUpdateAuthorized || !isDraft}
                                icon={<EditTwoTone />}
                            />
                        </Tooltip>
                        <Tooltip title={isDeleteAuthorized && isDraft ? "Delete" : isDeleteAuthorized ? "Only Draft orders can be deleted" : "Not authorized"}>
                            <Button
                                type="text"
                                danger
                                size="small"
                                onClick={() => handleDelete(record)}
                                disabled={!isDeleteAuthorized || !isDraft}
                                icon={<DeleteTwoTone />}
                            />
                        </Tooltip>
                    </Space>
                )
            }
        }
    ];

    return (
        <div>
            <Title level={2}>
                <FaClipboardList size={28} className="inline mb-1 mr-2" />
                Process Order Creation
            </Title>

            {/* Stats Cards */}
            <Row gutter={[16, 16]} style={{ marginBottom: 16 }}>
                <Col span={6}>
                    <Card size="small">
                        <Text type="secondary">Total Orders</Text>
                        <Title level={3} style={{ margin: 0 }}>{totalOrders}</Title>
                    </Card>
                </Col>
                <Col span={6}>
                    <Card size="small">
                        <Text type="secondary">Draft</Text>
                        <Title level={3} style={{ margin: 0, color: '#fa8c16' }}>{draftOrders}</Title>
                    </Card>
                </Col>
                <Col span={6}>
                    <Card size="small">
                        <Text type="secondary">Released</Text>
                        <Title level={3} style={{ margin: 0, color: '#52c41a' }}>{releasedOrders}</Title>
                    </Card>
                </Col>
                <Col span={6}>
                    <Card size="small">
                        <Text type="secondary">In Progress</Text>
                        <Title level={3} style={{ margin: 0, color: '#1890ff' }}>
                            {data.filter((item: any) => item.status === 'In-Progress' || item.status === 'Planned').length}
                        </Title>
                    </Card>
                </Col>
            </Row>

            <Card>
                {/* Filters */}
                <Row gutter={[16, 16]} style={{ marginBottom: 16 }} justify="space-between">
                    <Col span={8}>
                        <Search
                            placeholder="Search by product code, name or order code..."
                            allowClear
                            onSearch={(value) => {
                                setPagination(prev => ({ ...prev, current: 1 }));
                                setSearchText(value);
                                getProcessOrders(1, pagination.pageSize, value);
                            }}
                            style={{ width: '100%' }}
                            prefix={<SearchOutlined />}
                        />
                    </Col>
                    <Col span={12} style={{ display: 'flex', justifyContent: 'flex-end' }}>
                        <div className="flex flex-row gap-1">
                            <Tooltip title="Refresh">
                                <Button
                                    onClick={() => getProcessOrders(pagination.current, pagination.pageSize, searchText)}
                                    icon={<ReloadOutlined />}
                                />
                            </Tooltip>
                            <Tooltip title={isCreateAuthorized ? "" : "You are not authorized to create process orders"}>
                                <Button
                                    type="primary"
                                    icon={<PlusOutlined />}
                                    onClick={() => setAddModalOpen(true)}
                                    disabled={!isCreateAuthorized}
                                >
                                    Create Process Order
                                </Button>
                            </Tooltip>
                        </div>
                    </Col>
                </Row>

                {/* Table */}
                <Table
                    columns={columns}
                    dataSource={data}
                    loading={loading}
                    scroll={{ x: 'max-content', y: 250 }}
                    rowKey="_id"
                    pagination={{
                        current: pagination.current,
                        pageSize: pagination.pageSize,
                        total: pagination.total,
                        showSizeChanger: true,
                        pageSizeOptions: ['10', '20', '30', '40', '50'],
                        onChange: (page: number, pageSize: number) => {
                            setPagination(prev => ({
                                ...prev,
                                current: page,
                                pageSize: pageSize,
                            }));
                            getProcessOrders(page, pageSize, searchText);
                        },
                    }}
                />
            </Card>

            {/* Modals */}
            <AddProcessOrder
                open={addModalOpen}
                onClose={() => setAddModalOpen(false)}
                onSuccess={() => {
                    getProcessOrders(pagination.current, pagination.pageSize, searchText);
                }}
            />
            <ViewProcessOrder
                open={viewModalOpen}
                orderId={selectedOrderId}
                onClose={() => {
                    setViewModalOpen(false);
                    setSelectedOrderId(null);
                }}
            />
            <EditProcessOrder
                open={editModalOpen}
                orderId={selectedOrderId}
                onClose={() => {
                    setEditModalOpen(false);
                    setSelectedOrderId(null);
                }}
                onSuccess={() => {
                    getProcessOrders(pagination.current, pagination.pageSize, searchText);
                }}
            />
        </div>
    )
}