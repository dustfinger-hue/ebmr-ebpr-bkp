'use client';

import { Modal, Form, Select, Input, DatePicker, InputNumber, Button, message } from 'antd';
import { useEffect, useState } from 'react';
import { useAuthorization } from '@/hooks/useAuthorization';

interface AddProcessOrderProps {
    open: boolean;
    onClose: () => void;
    onSuccess: () => void;
}

interface Product {
    productCode: string;
    productName: string;
}

interface BOM {
    bomCode: string;
    bomVersion: string;
    batchSizeSemifinished: number;
    bulkSize: number;
    uom: string;
    bulkUom: string;
    status: string;
    createdAt: string;
}

interface Facility {
    facilityCode: string;
    areaName: string;
}

export default function AddProcessOrder({ open, onClose, onSuccess }: AddProcessOrderProps) {
    const [form] = Form.useForm();
    const [loading, setLoading] = useState(false);
    const [products, setProducts] = useState<Product[]>([]);
    const [productLoading, setProductLoading] = useState(false);
    const [facilities, setFacilities] = useState<Facility[]>([]);
    const [facilityLoading, setFacilityLoading] = useState(false);
    const { hasAccess } = useAuthorization();
    const isCreateAuthorized = hasAccess('Process Order', 'create');

    // Fetch products for searchable dropdown
    const fetchProducts = async (search: string = '') => {
        setProductLoading(true);
        try {
            const token = localStorage.getItem('token');
            const res = await fetch(`/api/user/master-data/product-master?page=1&limit=50&search=${search}`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) {
                setProducts(data.products || []);
            }
        } catch (error) {
            console.error('Error fetching products:', error);
        } finally {
            setProductLoading(false);
        }
    };

    // Fetch facilities for searchable dropdown
    const fetchFacilities = async (search: string = '') => {
        setFacilityLoading(true);
        try {
            const token = localStorage.getItem('token');
            const res = await fetch(`/api/user/master-data/facility-master?page=1&limit=50&search=${search}`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) {
                setFacilities(data.facilities || []);
            }
        } catch (error) {
            console.error('Error fetching facilities:', error);
        } finally {
            setFacilityLoading(false);
        }
    };

    useEffect(() => {
        if (open) {
            fetchProducts();
            fetchFacilities();
            form.resetFields();
        }
    }, [open]);

    // When product is selected, fetch latest Active BOM
    const handleProductSelect = async (productCode: string) => {
        if (!productCode) return;

        // Find the selected product name
        const selectedProduct = products.find(p => p.productCode === productCode);
        if (selectedProduct) {
            form.setFieldsValue({ productName: selectedProduct.productName });
        }

        try {
            const token = localStorage.getItem('token');
            const res = await fetch(`/api/user/bill-of-material/manufacturing?fetchAll=true&productCode=${productCode}&limit=50`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success && data.data && data.data.length > 0) {
                // Filter Active BOMs and sort by createdAt desc
                const activeBoms: BOM[] = data.data
                    .filter((bom: BOM) => bom.status === 'Active')
                    .sort((a: BOM, b: BOM) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

                if (activeBoms.length > 0) {
                    const latestBom = activeBoms[0];
                    form.setFieldsValue({
                        bomCode: latestBom.bomCode,
                        bomVersion: latestBom.bomVersion,
                        batchSizeSemifinished: latestBom.batchSizeSemifinished,
                        bulkSize: latestBom.bulkSize,
                        uom: latestBom.uom,
                        bulkUom: latestBom.bulkUom,
                    });
                } else {
                    // If no Active BOM, try to get latest any status
                    const sortedBoms = data.data.sort((a: BOM, b: BOM) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
                    if (sortedBoms.length > 0) {
                        const bom = sortedBoms[0];
                        form.setFieldsValue({
                            bomCode: bom.bomCode,
                            bomVersion: bom.bomVersion,
                            batchSizeSemifinished: bom.batchSizeSemifinished,
                            bulkSize: bom.bulkSize,
                            uom: bom.uom,
                            bulkUom: bom.bulkUom,
                        });
                    }
                }
            }
        } catch (error) {
            console.error('Error fetching BOM:', error);
        }
    };

    const handleSubmit = async () => {
        try {
            const values = await form.validateFields();
            setLoading(true);

            const token = localStorage.getItem('token');
            const res = await fetch('/api/user/manufacturing-control/process-order', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify(values)
            });

            const data = await res.json();
            if (data.success) {
                message.success(data.message);
                form.resetFields();
                onSuccess();
                onClose();
            } else {
                message.error(data.message);
            }
        } catch (error) {
            console.error('Error creating process order:', error);
            message.error('Failed to create process order');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Modal
            title="Create Process Order"
            open={open}
            onCancel={onClose}
            footer={null}
            width={800}
            destroyOnHidden
        >
            <Form
                form={form}
                layout="vertical"
                style={{ marginTop: 16 }}
                initialValues={{ status: 'Draft' }}
            >
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 16px' }}>
                    {/* Product Selection */}
                    <Form.Item
                        name="productCode"
                        label="Product Name"
                        rules={[{ required: true, message: 'Please select a product' }]}
                    >
                        <Select
                            showSearch
                            placeholder="Search and select a product"
                            loading={productLoading}
                            filterOption={(input, option) =>
                                (option?.label as string || '').toLowerCase().includes(input.toLowerCase())
                            }
                            onSelect={handleProductSelect}
                            onSearch={fetchProducts}
                            options={products.map(p => ({
                                value: p.productCode,
                                label: `${p.productCode} - ${p.productName}`
                            }))}
                        />
                    </Form.Item>

                    {/* Product Name (hidden field to store value) */}
                    <Form.Item name="productName" hidden>
                        <Input />
                    </Form.Item>

                    {/* Manufacturing BOM */}
                    <Form.Item
                        name="bomCode"
                        label="Manufacturing BOM"
                        rules={[{ required: true, message: 'BOM will auto-fill' }]}
                    >
                        <Input readOnly placeholder="Auto-fills from product" />
                    </Form.Item>

                    {/* BOM Version (hidden) */}
                    <Form.Item name="bomVersion" hidden>
                        <Input />
                    </Form.Item>

                    {/* Batch Size (Semi-Finished) */}
                    <Form.Item
                        name="batchSizeSemifinished"
                        label="Batch Size (Semi-Finished)"
                    >
                        <InputNumber
                            readOnly
                            style={{ width: '100%' }}
                            placeholder="Auto-fills from BOM"
                        />
                    </Form.Item>

                    {/* Bulk Size */}
                    <Form.Item
                        name="bulkSize"
                        label="Bulk Size"
                    >
                        <InputNumber
                            readOnly
                            style={{ width: '100%' }}
                            placeholder="Auto-fills from BOM"
                        />
                    </Form.Item>

                    {/* UOM (hidden) */}
                    <Form.Item name="uom" hidden>
                        <Input />
                    </Form.Item>

                    {/* Bulk UOM (hidden) */}
                    <Form.Item name="bulkUom" hidden>
                        <Input />
                    </Form.Item>

                    {/* Planned Start Date */}
                    <Form.Item
                        name="plannedStartDate"
                        label="Planned Start Date"
                        rules={[{ required: true, message: 'Please select start date' }]}
                    >
                        <DatePicker style={{ width: '100%' }} />
                    </Form.Item>

                    {/* Planned End Date */}
                    <Form.Item
                        name="plannedEndDate"
                        label="Planned End Date"
                        rules={[{ required: true, message: 'Please select end date' }]}
                    >
                        <DatePicker style={{ width: '100%' }} />
                    </Form.Item>

                    {/* Status */}
                    <Form.Item
                        name="status"
                        label="Status"
                        rules={[{ required: true, message: 'Please select status' }]}
                    >
                        <Select
                            options={[
                                { value: 'Draft', label: 'Draft' },
                                { value: 'Planned', label: 'Planned' },
                                // { value: 'Released', label: 'Released' },
                            ]}
                        />
                    </Form.Item>

                    {/* Manufacturing Facility (Optional - Multiple) */}
                    <Form.Item
                        name="manufacturingFacility"
                        label="Manufacturing Facilities (Optional)"
                    >
                        <Select
                            mode="multiple"
                            showSearch
                            allowClear
                            placeholder="Search and select facilities"
                            loading={facilityLoading}
                            filterOption={(input, option) =>
                                (option?.label as string || '').toLowerCase().includes(input.toLowerCase())
                            }
                            onSearch={fetchFacilities}
                            options={facilities.map(f => ({
                                value: `${f.facilityCode} - ${f.areaName}`,
                                label: `${f.facilityCode} - ${f.areaName}`
                            }))}
                        />
                    </Form.Item>
                </div>

                {/* Remarks */}
                <Form.Item
                    name="remarks"
                    label="Remarks"
                >
                    <Input.TextArea rows={3} placeholder="Optional remarks" />
                </Form.Item>

                {/* Buttons */}
                <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 16 }}>
                    <Button onClick={onClose}>Cancel</Button>
                    <Button
                        type="primary"
                        loading={loading}
                        onClick={handleSubmit}
                        disabled={!isCreateAuthorized}
                    >
                        Create Process Order
                    </Button>
                </div>
            </Form>
        </Modal>
    );
}