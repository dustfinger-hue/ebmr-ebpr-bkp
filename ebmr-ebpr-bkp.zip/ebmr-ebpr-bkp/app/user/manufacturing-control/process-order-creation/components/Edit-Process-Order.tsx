'use client';

import { Modal, Form, Select, Input, DatePicker, InputNumber, Button, message, Spin } from 'antd';
import { useEffect, useState } from 'react';
import { useAuthorization } from '@/hooks/useAuthorization';
import dayjs from 'dayjs';

interface EditProcessOrderProps {
    open: boolean;
    orderId: string | null;
    onClose: () => void;
    onSuccess: () => void;
}

export default function EditProcessOrder({ open, orderId, onClose, onSuccess }: EditProcessOrderProps) {
    const [form] = Form.useForm();
    const [loading, setLoading] = useState(false);
    const [fetching, setFetching] = useState(false);
    const [facilities, setFacilities] = useState<{ facilityCode: string; areaName: string }[]>([]);
    const [facilityLoading, setFacilityLoading] = useState(false);
    const { hasAccess } = useAuthorization();
    const isUpdateAuthorized = hasAccess('Process Order', 'update');

    // Fetch order data when modal opens
    useEffect(() => {
        if (open && orderId) {
            fetchOrderData(orderId);
            fetchFacilities();
        } else {
            form.resetFields();
        }
    }, [open, orderId]);

    const fetchOrderData = async (id: string) => {
        setFetching(true);
        try {
            const token = localStorage.getItem('token');
            const res = await fetch(`/api/user/manufacturing-control/process-order?id=${id}&limit=1`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            const result = await res.json();
            if (result.success && result.data) {
                const data = Array.isArray(result.data) ? result.data[0] : result.data;
                form.setFieldsValue({
                    ...data,
                    plannedStartDate: data.plannedStartDate ? dayjs(data.plannedStartDate) : null,
                    plannedEndDate: data.plannedEndDate ? dayjs(data.plannedEndDate) : null,
                });
            } else {
                message.error('Failed to fetch order data');
                onClose();
            }
        } catch (error) {
            console.error('Error fetching order:', error);
            message.error('Error fetching order data');
        } finally {
            setFetching(false);
        }
    };

    // Fetch facilities
    const fetchFacilities = async (search: string = '') => {
        setFacilityLoading(true);
        try {
            const token = localStorage.getItem('token');
            const res = await fetch(`/api/user/master-data/facility-master?page=1&limit=50&search=${search}`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) {
                setFacilities(data.facilities || []);
            }
        } catch (error) {
            console.error('Error fetching facilities:', error);
        } finally {
            setFacilityLoading(false);
        }
    };

    const handleSubmit = async () => {
        try {
            const values = await form.validateFields();
            setLoading(true);

            const token = localStorage.getItem('token');
            const res = await fetch(`/api/user/manufacturing-control/process-order?id=${orderId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify(values)
            });

            const data = await res.json();
            if (data.success) {
                message.success(data.message);
                form.resetFields();
                onSuccess();
                onClose();
            } else {
                message.error(data.message);
            }
        } catch (error) {
            console.error('Error updating process order:', error);
            message.error('Failed to update process order');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Modal
            title="Edit Process Order"
            open={open}
            onCancel={onClose}
            footer={null}
            width={800}
            destroyOnClose
        >
            {fetching ? (
                <div style={{ textAlign: 'center', padding: 60 }}>
                    <Spin size="large" />
                </div>
            ) : (
                <Form
                    form={form}
                    layout="vertical"
                    style={{ marginTop: 16 }}
                >
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 16px' }}>
                        {/* Product Code (readonly) */}
                        <Form.Item
                            name="productCode"
                            label="Product Code"
                        >
                            <Input readOnly />
                        </Form.Item>

                        {/* Product Name (readonly) */}
                        <Form.Item
                            name="productName"
                            label="Product Name"
                        >
                            <Input readOnly />
                        </Form.Item>

                        {/* BOM Code (readonly) */}
                        <Form.Item
                            name="bomCode"
                            label="Manufacturing BOM"
                        >
                            <Input readOnly />
                        </Form.Item>

                        {/* BOM Version (hidden) */}
                        <Form.Item name="bomVersion" hidden>
                            <Input />
                        </Form.Item>

                        {/* Batch Size (readonly) */}
                        <Form.Item
                            name="batchSizeSemifinished"
                            label="Batch Size (Semi-Finished)"
                        >
                            <InputNumber readOnly style={{ width: '100%' }} />
                        </Form.Item>

                        {/* Bulk Size (readonly) */}
                        <Form.Item
                            name="bulkSize"
                            label="Bulk Size"
                        >
                            <InputNumber readOnly style={{ width: '100%' }} />
                        </Form.Item>

                        {/* UOM (hidden) */}
                        <Form.Item name="uom" hidden>
                            <Input />
                        </Form.Item>

                        {/* Bulk UOM (hidden) */}
                        <Form.Item name="bulkUom" hidden>
                            <Input />
                        </Form.Item>

                        {/* Planned Start Date */}
                        <Form.Item
                            name="plannedStartDate"
                            label="Planned Start Date"
                            rules={[{ required: true, message: 'Please select start date' }]}
                        >
                            <DatePicker style={{ width: '100%' }} />
                        </Form.Item>

                        {/* Planned End Date */}
                        <Form.Item
                            name="plannedEndDate"
                            label="Planned End Date"
                            rules={[{ required: true, message: 'Please select end date' }]}
                        >
                            <DatePicker style={{ width: '100%' }} />
                        </Form.Item>

                        {/* Status */}
                        <Form.Item
                            name="status"
                            label="Status"
                            rules={[{ required: true, message: 'Please select status' }]}
                        >
                            <Select
                                options={[
                                    { value: 'Draft', label: 'Draft' },
                                    { value: 'Planned', label: 'Planned' },
                                    { value: 'Released', label: 'Released' },
                                ]}
                            />
                        </Form.Item>

                    {/* Manufacturing Facility (Optional - Multiple) */}
                    <Form.Item
                        name="manufacturingFacility"
                        label="Manufacturing Facilities (Optional)"
                    >
                        <Select
                            mode="multiple"
                            showSearch
                            allowClear
                            placeholder="Search and select facilities"
                            loading={facilityLoading}
                            filterOption={(input, option) =>
                                (option?.label as string || '').toLowerCase().includes(input.toLowerCase())
                            }
                            onSearch={fetchFacilities}
                            options={facilities.map(f => ({
                                value: `${f.facilityCode} - ${f.areaName}`,
                                label: `${f.facilityCode} - ${f.areaName}`
                            }))}
                        />
                    </Form.Item>
                    </div>

                    {/* Remarks */}
                    <Form.Item
                        name="remarks"
                        label="Remarks"
                    >
                        <Input.TextArea rows={3} placeholder="Optional remarks" />
                    </Form.Item>

                    {/* Buttons */}
                    <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 16 }}>
                        <Button onClick={onClose}>Cancel</Button>
                        <Button
                            type="primary"
                            loading={loading}
                            onClick={handleSubmit}
                            disabled={!isUpdateAuthorized}
                        >
                            Update Process Order
                        </Button>
                    </div>
                </Form>
            )}
        </Modal>
    );
}