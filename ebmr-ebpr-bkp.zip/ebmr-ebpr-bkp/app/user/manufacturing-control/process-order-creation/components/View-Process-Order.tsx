'use client';

import { Modal, Descriptions, Tag, Button } from 'antd';
import { useEffect, useState } from 'react';

interface ViewProcessOrderProps {
    open: boolean;
    orderId: string | null;
    onClose: () => void;
}

export default function ViewProcessOrder({ open, orderId, onClose }: ViewProcessOrderProps) {
    const [orderData, setOrderData] = useState<any>(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (open && orderId) {
            fetchOrderDetail(orderId);
        } else {
            setOrderData(null);
        }
    }, [open, orderId]);

    const fetchOrderDetail = async (id: string) => {
        setLoading(true);
        try {
            const token = localStorage.getItem('token');
            const res = await fetch(`/api/user/manufacturing-control/process-order?id=${id}&limit=1`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            const result = await res.json();
            if (result.success && result.data) {
                // If GET returns array, take first item
                const data = Array.isArray(result.data) ? result.data[0] : result.data;
                setOrderData(data);
            }
        } catch (error) {
            console.error('Error fetching order detail:', error);
        } finally {
            setLoading(false);
        }
    };

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'Draft': return 'orange';
            case 'Planned': return 'blue';
            case 'Released': return 'green';
            case 'In-Progress': return 'cyan';
            case 'Completed': return 'purple';
            case 'On-Hold': return 'red';
            case 'Cancelled': return 'red';
            default: return 'default';
        }
    };

    return (
        <Modal
            title="Process Order Details"
            open={open}
            onCancel={onClose}
            footer={[
                <Button key="close" onClick={onClose}>Close</Button>
            ]}
            width={800}
            destroyOnClose
        >
            {loading ? (
                <div style={{ textAlign: 'center', padding: 40 }}>Loading...</div>
            ) : orderData ? (
                <Descriptions
                    column={2}
                    bordered
                    size="small"
                    style={{ marginTop: 16 }}
                >
                    <Descriptions.Item label="Process Order Code" span={2}>
                        <strong>{orderData.processOrderCode}</strong>
                    </Descriptions.Item>
                    <Descriptions.Item label="Product Code">{orderData.productCode}</Descriptions.Item>
                    <Descriptions.Item label="Product Name">{orderData.productName}</Descriptions.Item>
                    <Descriptions.Item label="Manufacturing BOM">{orderData.bomCode}</Descriptions.Item>
                    <Descriptions.Item label="BOM Version">{orderData.bomVersion || '-'}</Descriptions.Item>
                    <Descriptions.Item label="Batch Size (Semi-Finished)">
                        {orderData.batchSizeSemifinished} {orderData.uom}
                    </Descriptions.Item>
                    <Descriptions.Item label="Bulk Size">
                        {orderData.bulkSize} {orderData.bulkUom}
                    </Descriptions.Item>
                    <Descriptions.Item label="Planned Start Date">
                        {orderData.plannedStartDate ? new Date(orderData.plannedStartDate).toLocaleDateString() : '-'}
                    </Descriptions.Item>
                    <Descriptions.Item label="Planned End Date">
                        {orderData.plannedEndDate ? new Date(orderData.plannedEndDate).toLocaleDateString() : '-'}
                    </Descriptions.Item>
                    <Descriptions.Item label="Status">
                        <Tag color={getStatusColor(orderData.status)}>{orderData.status}</Tag>
                    </Descriptions.Item>
                    <Descriptions.Item label="Manufacturing Facilities" span={2}>
                        {orderData.manufacturingFacility && Array.isArray(orderData.manufacturingFacility) && orderData.manufacturingFacility.length > 0
                            ? orderData.manufacturingFacility.map((fac: string, i: number) => (
                                <Tag key={i} color="blue" style={{ marginBottom: 2 }}>{fac}</Tag>
                            ))
                            : (typeof orderData.manufacturingFacility === 'string' && orderData.manufacturingFacility
                                ? <Tag color="blue">{orderData.manufacturingFacility}</Tag>
                                : '-')
                        }
                    </Descriptions.Item>
                    <Descriptions.Item label="Remarks" span={2}>
                        {orderData.remarks || '-'}
                    </Descriptions.Item>
                    <Descriptions.Item label="Created At">
                        {orderData.createdAt ? new Date(orderData.createdAt).toLocaleString() : '-'}
                    </Descriptions.Item>
                    <Descriptions.Item label="Updated At">
                        {orderData.updatedAt ? new Date(orderData.updatedAt).toLocaleString() : '-'}
                    </Descriptions.Item>
                </Descriptions>
            ) : (
                <div style={{ textAlign: 'center', padding: 40, color: '#999' }}>
                    {orderId ? 'No data found' : 'Select an order to view'}
                </div>
            )}
        </Modal>
    );
}