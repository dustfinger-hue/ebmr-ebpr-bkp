"use client";

import { Card, Typography, Table, Input, Select, Button, Space, Tag, message, Modal, Avatar, Tooltip } from "antd";
import {
    UserOutlined,
    SearchOutlined,
    PlusOutlined,
    EditOutlined,
    DeleteOutlined,
    EyeOutlined,
    CheckCircleOutlined,
    CloseCircleOutlined,
    ClockCircleOutlined,
    ReloadOutlined,
} from "@ant-design/icons";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Adduser from "./components/Adduser";
import ViewUser from "./components/ViewUser";
import EditUser from "./components/EditUser";
import { User } from "./Interface";

const { Title, Text } = Typography;
const { Option } = Select;

// interface User {
//     id: string;
//     firstName: string;
//     lastName: string;
//     fullName: string;
//     username: string;
//     email: string;
//     phoneNumber: string;
//     profileImage?: string;
//     employeeId: string;
//     gender: 'male' | 'female' | 'other';
//     dateOfBirth: string;
//     role: string;
//     permissionsOverride: string[];
//     department: string;
//     designation: string;
//     reportingManagerId: string;
//     approvalLimit: number;
//     accessLevel: string;
//     companyId: string;
//     branchId: string;
//     warehouseIds: string[];
//     costCenterId: string;
//     employmentType: 'permanent' | 'contract';
//     joiningDate: string;
//     employmentStatus: string;
//     language: string;
//     timezone: string;
//     dateFormat: string;
//     currencyFormat: string;
//     themePreference: string;
//     dashboardLayout: string;
//     notificationPreferences: any;
//     status: 'active' | 'inactive' | 'pending';
//     lastLogin?: string;
//     createdAt: string;
// }

export default function UsersPage() {
    const [users, setUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(false);
    const [searchText, setSearchText] = useState('');
    const [roleFilter, setRoleFilter] = useState<string>('all');
    const [statusFilter, setStatusFilter] = useState<string>('all');
    const [deleteModalVisible, setDeleteModalVisible] = useState(false);
    const [userToDelete, setUserToDelete] = useState<User | null>(null);
    const [addUserModalOpen, setAddUserModalOpen] = useState(false);
    const [viewModalOpen, setViewModalOpen] = useState(false);
    const [userEditModalOpen, setUserEditModalOpen] = useState(false);
    const [userData, setUserData] = useState<User | null>(null);
    const router = useRouter();

    useEffect(() => {
        fetchUsers()
    }, []);
    const fetchUsers = async () => {
        try {
            setLoading(true);
            const res = await fetch('/api/admin/user-management', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            }
            )
            const data = await res.json()
            setUsers(data.users)
        } catch {
            console.log('error')
            setUsers([])
        } finally {
            setLoading(false)
        }
    }

    const handleSearch = (value: string) => {
        setSearchText(value);
    };

    const handleRoleFilter = (value: string) => {
        setRoleFilter(value);
    };

    const handleStatusFilter = (value: string) => {
        setStatusFilter(value);
    };

    const handleEdit = (user: User) => {
        console.log(user)
        setUserEditModalOpen(true);
        setUserData(user);
    };

    const handleView = (user: User) => {
        setViewModalOpen(true);
        setUserData(user);
    };

    const handleDelete = (user: User) => {
        setUserToDelete(user);
        setDeleteModalVisible(true);
    };

    const confirmDelete = () => {
        if (userToDelete) {
            setUsers(users.filter(u => u._id !== userToDelete._id));
            message.success(`User ${userToDelete.fullName} has been deleted`);
            setDeleteModalVisible(false);
            setUserToDelete(null);
        }
    };

    const getStatusTag = (status: string) => {
        switch (status) {
            case 'active':
                return <Tag color="green" icon={<CheckCircleOutlined />}>Active</Tag>;
            case 'inactive':
                return <Tag color="red" icon={<CloseCircleOutlined />}>Inactive</Tag>;
            case 'pending':
                return <Tag color="orange" icon={<ClockCircleOutlined />}>Pending</Tag>;
            default:
                return <Tag>{status}</Tag>;
        }
    };

    const getRoleColor = (role: string) => {
        switch (role) {
            case 'Operator':
                return 'default';
            case 'Supervisor':
                return 'orange';
            case 'Officer/Executive':
                return 'green';
            case 'Manager':
                return 'blue';
            case 'Head of Department':
                return 'purple';
            case 'Director':
                return 'red';
            default:
                return 'default';
        }
    };


    const filteredUsers = users.filter(user => {
        const matchesSearch = user?.fullName?.toLowerCase().includes(searchText.toLowerCase()) ||
            user.email.toLowerCase().includes(searchText.toLowerCase()) ||
            user.department.toLowerCase().includes(searchText.toLowerCase());

        const matchesRole = roleFilter === 'all' || user.role === roleFilter;
        const matchesStatus = statusFilter === 'all' || user.status === statusFilter;

        return matchesSearch && matchesRole && matchesStatus;
    });

    const columns = [
        {
            title: 'User',
            dataIndex: 'fullName',
            key: 'fullName',
            render: (text: string, record: User) => (
                <Space>
                    <Avatar size="small" style={{ backgroundColor: getRoleColor(record.role) }}>
                        {text ? text.charAt(0).toUpperCase() : 'U'}
                    </Avatar>
                    <div>
                        <div style={{ fontWeight: 500 }}>{text || 'Unknown User'}</div>
                        <div style={{ fontSize: 12, color: '#666' }}>{record.email}</div>
                    </div>
                </Space>
            ),
        },
        {
            title: 'Role',
            dataIndex: 'role',
            key: 'role',
            render: (role: string) => (
                <Tag color={getRoleColor(role)}>{role.replace('-', ' ').toUpperCase()}</Tag>
            ),
        },
        {
            title: 'Department',
            dataIndex: 'department',
            key: 'department',
        },
        {
            title: 'Designation',
            dataIndex: 'designation',
            key: 'designation',
        },
        {
            title: 'Status',
            dataIndex: 'status',
            key: 'status',
            render: (status: string) => getStatusTag(status),
        },
        {
            title: 'Last Login',
            dataIndex: 'lastLogin',
            key: 'lastLogin',
            render: (text: string) => {
                if (!text) return <Text type="secondary">-</Text>;
                const date = new Date(text).toLocaleString();
                return <Text type="secondary">{date}</Text>;
            }
        },
        {
            title: 'Actions',
            key: 'actions',
            render: (_: any, record: User) => (
                <Space size="middle">
                    <Button
                        type="text"
                        icon={<EyeOutlined />}
                        onClick={() => handleView(record)}
                        title="View Details"
                    />
                    <Button
                        type="text"
                        icon={<EditOutlined />}
                        onClick={() => handleEdit(record)}
                        title="Edit User"
                    />
                    <Button
                        type="text"
                        danger
                        icon={<DeleteOutlined />}
                        onClick={() => handleDelete(record)}
                        title="Delete User"
                    />
                </Space>
            ),
        },
    ];

    return (
        <div>
            <div style={{ marginBottom: 24 }}>
                <Title level={2} style={{ margin: 0, color: "#1890ff" }}>
                    User Management
                </Title>
                <Text type="secondary">
                    Manage users, roles, and permissions for the EBMR & BPR System
                </Text>
            </div>

            {/* Filters and Actions */}
            <Card style={{ marginBottom: 16 }}>
                <Space orientation="vertical" style={{ width: '100%' }}>
                    <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', alignItems: 'center' }}>
                        <Input
                            placeholder="Search users by name, email, or department..."
                            prefix={<SearchOutlined />}
                            style={{ width: 300 }}
                            onChange={(e) => handleSearch(e.target.value)}
                            allowClear
                        />
                        <Select
                            placeholder="Filter by role"
                            style={{ width: 200 }}
                            onChange={handleRoleFilter}
                            defaultValue="all"
                        >
                            <Option value="all">All Roles</Option>
                            <Option value="admin">Admin</Option>
                            <Option value="qc-manager">QC Manager</Option>
                            <Option value="qc-officer">QC Officer</Option>
                            <Option value="qa-manager">QA Manager</Option>
                            <Option value="qa-officer">QA Officer</Option>
                            <Option value="production-manager">Production Manager</Option>
                            <Option value="production-officer">Production Officer</Option>
                        </Select>
                        <Select
                            placeholder="Filter by status"
                            style={{ width: 150 }}
                            onChange={handleStatusFilter}
                            defaultValue="all"
                        >
                            <Option value="all">All Status</Option>
                            <Option value="active">Active</Option>
                            <Option value="inactive">Inactive</Option>
                            <Option value="pending">Pending</Option>
                        </Select>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Text strong>
                            Total Users: {filteredUsers.length} |
                            Active: {filteredUsers.filter(u => u.status === 'active').length} |
                            Pending: {filteredUsers.filter(u => u.status === 'pending').length} |
                            Inactive: {filteredUsers.filter(u => u.status === 'inactive').length}
                        </Text>
                        <div className="flex flex-row gap-2">
                            <Button
                                // type="primary"
                                icon={<PlusOutlined />}
                                onClick={() => setAddUserModalOpen(true)}
                            >
                                Add New User
                            </Button>
                            <Button
                                // type="primary"
                                icon={<ReloadOutlined />}
                                onClick={() => fetchUsers()}
                            >
                                Refresh
                            </Button>
                        </div>
                    </div>
                </Space>
            </Card>

            {/* Users Table */}
            <Card>
                <Table
                    columns={columns}
                    dataSource={filteredUsers}
                    rowKey="id"
                    loading={loading}
                    pagination={{
                        pageSize: 10,
                        showSizeChanger: true,
                        showQuickJumper: true,
                        showTotal: (total, range) => `Showing ${range[0]}-${range[1]} of ${total} users`,
                        pageSizeOptions: ['5', '10', '20', '50']
                    }}
                    scroll={{ x: 1000 }}
                />
            </Card>

            {/* Add User Modal */}
            <Adduser
                modalOpen={addUserModalOpen}
                onCancel={() => setAddUserModalOpen(false)}
            />
            {/* View User Modal */}
            <ViewUser
                open={viewModalOpen}
                onClose={() => setViewModalOpen(false)}
                userData={userData}
            />
            {/* Edit User Modal */}
            <EditUser
                open={userEditModalOpen}
                onClose={() => setUserEditModalOpen(false)}
                userData={userData}
            // onSave={handleEditUser}
            />

            {/* Delete Confirmation Modal */}
            <Modal
                title="Delete User"
                open={deleteModalVisible}
                onOk={confirmDelete}
                onCancel={() => setDeleteModalVisible(false)}
                okText="Delete"
                cancelText="Cancel"
                okButtonProps={{ danger: true }}
            >
                {userToDelete && (
                    <div>
                        <p>Are you sure you want to delete the following user?</p>
                        <div style={{ background: '#f5f5f5', padding: 12, borderRadius: 6 }}>
                            <Text strong>{userToDelete.fullName}</Text>
                            <br />
                            <Text type="secondary">{userToDelete.email}</Text>
                            <br />
                            <Text type="secondary">Role: {userToDelete.role.replace('-', ' ').toUpperCase()}</Text>
                        </div>
                        <p style={{ marginTop: 12, color: '#ff4d4f' }}>
                            <strong>Warning:</strong> This action cannot be undone.
                        </p>
                    </div>
                )}
            </Modal>
        </div>
    );
}