'use client';

import {
    Modal,
    Card,
    Descriptions,
    Avatar,
    Tag,
    Tabs,
    Table,
    Typography,
    Space,
    Button,
    Divider,
    Skeleton,
} from 'antd';

import {
    UserOutlined,
    MailOutlined,
    PhoneOutlined,
    IdcardOutlined,
    CalendarOutlined,
    TeamOutlined,
    SafetyOutlined,
    BankOutlined,
    ClockCircleOutlined,
    CheckCircleOutlined,
    CloseCircleOutlined,
    CloseOutlined,
} from '@ant-design/icons';

import { useState, useEffect, useMemo } from 'react';
import dayjs from 'dayjs';
import { User } from '../Interface';

interface ViewUserProps {
    open: boolean;
    onClose: () => void;
    userData?: User | null;
}

export default function ViewUser({ open, onClose, userData }: ViewUserProps) {
    const [loading, setLoading] = useState(false);
    const [user, setUser] = useState<User | null>(null);
    const [error, setError] = useState<string | null>(null);

    /* -------------------- Effects -------------------- */

    useEffect(() => {
        if (!open || !userData?._id) return;
        fetchUserDetails();
    }, [open, userData]);

    useEffect(() => {
        if (!open) {
            setUser(null);
            setError(null);
        }
    }, [open]);

    /* -------------------- Fetch -------------------- */

    const fetchUserDetails = async () => {
        try {
            setLoading(true);
            setError(null);

            const token =
                typeof window !== 'undefined'
                    ? localStorage.getItem('token')
                    : null;

            const res = await fetch(
                `/api/admin/user-management?type=detailed&id=${userData?._id}`,
                {
                    method: 'GET',
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );

            const data = await res.json();

            if (data.success) {
                setUser(data.users);
            } else {
                setError(data.message || 'Failed to fetch user details');
            }
        } catch (err) {
            console.error(err);
            setError('An error occurred while fetching user details');
        } finally {
            setLoading(false);
        }
    };

    /* -------------------- Helpers -------------------- */

    const formatRole = (role?: string) =>
        role
            ?.replace(/-/g, ' ')
            .replace(/\b\w/g, (l) => l.toUpperCase());

    const getRoleColor = (role: string) => {
        const colors: Record<string, string> = {
            Operator: 'default',
            Supervisor: 'orange',
            'Officer/Executive': 'green',
            Manager: 'blue',
            'Head of Department': 'purple',
            Director: 'red',
            admin: 'blue',
        };
        return colors[role] || 'default';
    };

    const getStatusColor = (status: string) => {
        const colors: Record<string, string> = {
            active: 'success',
            inactive: 'error',
            pending: 'warning',
            resigned: 'default',
        };
        return colors[status] || 'default';
    };

    const getStatusIcon = (status: string) => {
        switch (status) {
            case 'active':
                return <CheckCircleOutlined />;
            case 'inactive':
                return <CloseCircleOutlined />;
            case 'pending':
                return <ClockCircleOutlined />;
            default:
                return null;
        }
    };

    const getGenderIcon = (gender?: string) => {
        switch (gender) {
            case 'male':
                return '👨';
            case 'female':
                return '👩';
            default:
                return '🧑';
        }
    };

    /* -------------------- Memoized Table Columns -------------------- */

    const authorizationColumns = useMemo(
        () => [
            {
                title: 'Module',
                dataIndex: 'module',
                key: 'module',
                render: (text: string) => (
                    <Tag color="blue">{text || 'N/A'}</Tag>
                ),
            },
            {
                title: 'Access Level',
                dataIndex: 'accessLevel',
                key: 'accessLevel',
                render: (levels: string[]) => (
                    <Space wrap>
                        {levels?.length
                            ? levels.map((lvl, i) => (
                                  <Tag key={i} color="green">
                                      {lvl}
                                  </Tag>
                              ))
                            : 'No Access'}
                    </Space>
                ),
            },
        ],
        []
    );

    const displayUser = user ?? userData ?? null;
    if (!displayUser && !loading) return null;

    /* -------------------- Tabs -------------------- */

    const tabItems = [
        {
            key: 'personal',
            label: (
                <>
                    <UserOutlined /> Personal Info
                </>
            ),
            children: (
                <Card size="small">
                    <Descriptions bordered column={{ xs: 1, sm: 2, md: 3 }}>
                        <Descriptions.Item label="Full Name" span={3}>
                            <Space>
                                <strong>{displayUser?.fullName}</strong>
                                {getGenderIcon(displayUser?.gender)}
                            </Space>
                        </Descriptions.Item>
                        <Descriptions.Item label="Email" span={2}>
                            {displayUser?.email}
                        </Descriptions.Item>
                        <Descriptions.Item label="Employee ID">
                            {displayUser?.employeeId || 'N/A'}
                        </Descriptions.Item>
                        <Descriptions.Item label="Phone Number">
                            {displayUser?.phoneNumber || 'N/A'}
                        </Descriptions.Item>
                        <Descriptions.Item label="DOB">
                            {displayUser?.dateOfBirth
                                ? dayjs(displayUser.dateOfBirth).format(
                                      'MMMM D, YYYY'
                                  )
                                : 'N/A'}
                        </Descriptions.Item>
                        <Descriptions.Item label="Gender">
                            {displayUser?.gender ? (
                                <Tag>
                                    {displayUser.gender.charAt(0).toUpperCase() +
                                        displayUser.gender.slice(1)}
                                </Tag>
                            ) : (
                                'N/A'
                            )}
                        </Descriptions.Item>
                    </Descriptions>
                </Card>
            ),
        },
        {
            key: 'employment',
            label: (
                <>
                    <BankOutlined /> Employment
                </>
            ),
            children: (
                <Card size="small">
                    <Descriptions bordered column={{ xs: 1, sm: 2, md: 3 }}>
                        <Descriptions.Item label="Department" span={1}>
                            {displayUser?.department}
                        </Descriptions.Item>
                        <Descriptions.Item label="Designation" span={1}>
                            {displayUser?.designation}
                        </Descriptions.Item>
                </Descriptions>
                <Descriptions bordered column={{ xs: 1, sm: 2, md: 3 }}>
                        <Descriptions.Item label="Role">
                            <Tag
                                color={getRoleColor(
                                    displayUser?.role || ''
                                )}
                            >
                                {formatRole(displayUser?.role) || 'User'}
                            </Tag>
                        </Descriptions.Item>
                        <Descriptions.Item label="Joining Date">
                            {displayUser?.joiningDate
                                ? dayjs(displayUser.joiningDate).format(
                                      'MMMM D, YYYY'
                                  )
                                : 'N/A'}
                        </Descriptions.Item>
                        <Descriptions.Item label="Status">
                            <Tag
                                icon={getStatusIcon(
                                    displayUser?.employmentStatus ||
                                        ''
                                )}
                                color={getStatusColor(
                                    displayUser?.employmentStatus ||
                                        ''
                                )}
                            >
                                {displayUser?.employmentStatus?.toUpperCase()}
                            </Tag>
                        </Descriptions.Item>
                    </Descriptions>
                </Card>
            ),
        },
        {
            key: 'authorization',
            label: (
                <>
                    <SafetyOutlined /> Authorization
                </>
            ),
            children: (
                <Card size="small">
                    {displayUser?.authorization?.length ? (
                        <Table
                            columns={authorizationColumns}
                            dataSource={displayUser.authorization}
                            rowKey={(r) => r.module}
                            pagination={false}
                            bordered
                            size="small"
                        />
                    ) : (
                        <div style={{ textAlign: 'center', padding: 40 }}>
                            No Authorization Assigned
                        </div>
                    )}
                </Card>
            ),
        },
    ];

    /* -------------------- UI -------------------- */

    return (
        <Modal
            open={open}
            onCancel={onClose}
            width={900}
            centered
            destroyOnClose
            footer={[
                <Button
                    key="close"
                    icon={<CloseOutlined />}
                    onClick={onClose}
                >
                    Close
                </Button>,
            ]}
            title={null}
        >
            {loading ? (
                <Skeleton active avatar paragraph={{ rows: 6 }} />
            ) : error ? (
                <Typography.Text type="danger">
                    {error}
                </Typography.Text>
            ) : (
                <>
                    {/* Header */}
                    <Card
                        bordered={false}
                        style={{
                            marginBottom: 16,
                            background:
                                'linear-gradient(135deg, #1d39c4 0%, #722ed1 100%)',
                            borderRadius: 8,
                            color: 'white',
                        }}
                    >
                        <Space size="large">
                            <Avatar
                                size={80}
                                src={displayUser?.profileImage}
                            >
                                {!displayUser?.profileImage &&
                                    displayUser?.fullName?.charAt(0)}
                            </Avatar>
                            <div>
                                <Typography.Title
                                    level={3}
                                    style={{ color: 'white', margin: 0 }}
                                >
                                    {displayUser?.fullName}
                                </Typography.Title>
                                <Typography.Text
                                    style={{
                                        color:
                                            'rgba(255,255,255,0.85)',
                                    }}
                                >
                                    {displayUser?.designation}
                                </Typography.Text>
                            </div>
                        </Space>
                    </Card>

                    <Divider />

                    <Tabs defaultActiveKey="personal" items={tabItems} />
                </>
            )}
        </Modal>
    );
}