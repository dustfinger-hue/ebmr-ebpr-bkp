'use client';
import { Button, Card, Col, Form, Input, message, Modal, Row, Select, Space } from "antd";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { UserAddOutlined, SaveOutlined, ClearOutlined } from "@ant-design/icons";

import { Typography } from "antd";
import { DEPARTMENTS } from "@/lib/constants/Department";
import { ROLES } from "@/lib/constants/Roles";


interface AddUserModalProps {
    modalOpen: boolean;
    onCancel: () => void;
}

export default function Adduser({ modalOpen, onCancel }: AddUserModalProps) {
    const [loading, setLoading] = useState(false);
    const [form] = Form.useForm();
    const router = useRouter();
    const { Title } = Typography;

    const validatePassword = (_: any, value: string) => {
        if (!value) {
            return Promise.resolve();
        }
        if (value.length < 8) {
            return Promise.reject(new Error("Password must be at least 8 characters long"));
        }
        if (!/(?=.*[a-z])/.test(value)) {
            return Promise.reject(new Error("Password must contain at least one lowercase letter"));
        }
        if (!/(?=.*[A-Z])/.test(value)) {
            return Promise.reject(new Error("Password must contain at least one uppercase letter"));
        }
        if (!/(?=.*\d)/.test(value)) {
            return Promise.reject(new Error("Password must contain at least one number"));
        }
        return Promise.resolve();
    };
    const handleFinish = async (values: FormData) => {
        try {
            setLoading(true);
            console.log(values)

            // API call to create user
            const response = await fetch("/api/admin/user-management", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${localStorage.getItem("token")}`,
                },
                body: JSON.stringify(values),
            });

            const result = await response.json();

            if (response.ok) {
                message.success("User created successfully!");
                form.resetFields();
                onCancel();
            } else {
                message.error(result.message || "Failed to create user");
            }
        } catch (error) {
            console.error("Error creating user:", error);
            message.error("An error occurred while creating the user");
        } finally {
            setLoading(false);
        }
    };
    const handleReset = () => {
        form.resetFields();
    };

    return (
        <>
            <Modal
                title={
                    <Title
                        level={4}
                        style={{
                            margin: 0,
                            display: "flex",
                            alignItems: "center",
                            gap: 8,
                            color: "#1890ff"
                        }}
                    >
                        <UserAddOutlined />
                        Add New User
                    </Title>
                }

                open={modalOpen}
                onCancel={onCancel}
                width={800}
                centered
                footer={null}
                destroyOnHidden
            >
                <Card>
                    <Form
                        form={form}
                        name="addUser"
                        onFinish={handleFinish}
                        layout="vertical"
                        initialValues={{
                            role: "user",
                            status: "active"
                        }}
                    >
                        <Row gutter={[16, 0]}>
                            <Col xs={24} sm={12}>
                                <Form.Item
                                    label="Full Name"
                                    name="fullName"
                                    rules={[
                                        { required: true, message: "Please enter the user's full name" },
                                        { min: 2, message: "Name must be at least 2 characters long" },
                                    ]}
                                >
                                    <Input
                                        placeholder="Enter full name"
                                        size="large"

                                    />
                                </Form.Item>
                            </Col>

                            <Col xs={24} sm={12}>
                                <Form.Item
                                    label="Email Address"
                                    name="email"
                                    rules={[
                                        { required: true, message: "Please enter email address" },
                                        { type: "email", message: "Please enter a valid email address" },
                                    ]}
                                >
                                    <Input
                                        type="email"
                                        placeholder="user@hiltonpharma.com"
                                        size="large"
                                    />
                                </Form.Item>
                            </Col>
                        </Row>

                        <Row gutter={[16, 0]}>
                            <Col xs={24} sm={12}>
                                <Form.Item
                                    label="Password"
                                    name="password"
                                    rules={[
                                        { required: true, message: "Please enter a password" },
                                        { validator: validatePassword },
                                    ]}
                                >
                                    <Input.Password
                                        placeholder="Enter password"
                                        size="large"
                                    />
                                </Form.Item>
                            </Col>

                            <Col xs={24} sm={12}>
                                <Form.Item
                                    label="Confirm Password"
                                    name="confirmPassword"
                                    dependencies={["password"]}
                                    rules={[
                                        { required: true, message: "Please confirm your password" },
                                        ({ getFieldValue }) => ({
                                            validator(_, value) {
                                                if (!value || getFieldValue("password") === value) {
                                                    return Promise.resolve();
                                                }
                                                return Promise.reject(new Error("The two passwords that you entered do not match!"));
                                            },
                                        }),
                                    ]}
                                >
                                    <Input.Password
                                        placeholder="Confirm password"
                                        size="large"
                                    />
                                </Form.Item>
                            </Col>
                        </Row>

                        <Row gutter={[16, 0]}>
                            <Col xs={24} sm={12}>
                                <Form.Item
                                    label="Role"
                                    name="role"
                                    rules={[{ required: true, message: "Please select a role" }]}
                                >
                                    <Select
                                        placeholder="Select user role"
                                        size="large"
                                        showSearch
                                        options={ROLES}
                                    >
                                    </Select>
                                </Form.Item>
                            </Col>

                            <Col xs={24} sm={12}>
                                <Form.Item
                                    label="Department"
                                    name="department"
                                    rules={[{ required: true, message: "Please enter department" }]}
                                >
                                    <Select
                                        placeholder="Select department"
                                        size="large"
                                        showSearch
                                        options={DEPARTMENTS}
                                    />
                                </Form.Item>
                            </Col>
                        </Row>

                        <Row gutter={[16, 0]}>
                            <Col xs={24} sm={12}>
                                <Form.Item
                                    label="Designation"
                                    name="designation"
                                    rules={[{ required: true, message: "Please enter designation" }]}
                                >
                                    <Input
                                        placeholder="e.g., Officer, Manager, Supervisor"
                                        size="large"
                                    />
                                </Form.Item>
                            </Col>
                            <Col xs={24} sm={12}>
                                <Form.Item
                                    label="Status"
                                    name="status"
                                    rules={[{ required: true, message: "Please select a status" }]}
                                >
                                    <Select
                                        placeholder="Select status"
                                        size="large"
                                        showSearch
                                        options={[
                                            { value: 'active', label: 'Active' },
                                            { value: 'inactive', label: 'Inactive' },
                                            { value: 'pending', label: 'Pending' },
                                        ]}
                                    >
                                    </Select>
                                </Form.Item>
                            </Col>
                        </Row>

                        <Form.Item style={{ marginTop: 24 }}>
                            <Space>
                                <Button
                                    type="primary"
                                    htmlType="submit"
                                    loading={loading}
                                    icon={<SaveOutlined />}
                                    size="large"
                                >
                                    Create User
                                </Button>
                                <Button
                                    onClick={handleReset}
                                    icon={<ClearOutlined />}
                                    size="large"
                                >
                                    Reset Form
                                </Button>
                                <Button
                                    onClick={() => router.push("/admin/users")}
                                    size="large"
                                >
                                    Cancel
                                </Button>
                            </Space>
                        </Form.Item>
                    </Form>
                </Card>
            </Modal >


        </>
    )
}