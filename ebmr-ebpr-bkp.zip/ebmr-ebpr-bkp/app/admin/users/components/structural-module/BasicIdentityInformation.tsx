import { Col, DatePicker, Form, Input, message, Row, Select, Upload } from "antd";
import { UserOutlined, MailOutlined, PhoneOutlined, IdcardOutlined, UploadOutlined } from '@ant-design/icons';
import { useState } from "react";

interface BasicIdentityInformationProps {
    form?: any;
}

export default function BasicIdentityInformation() {
    return (
        <div>
            <Row gutter={16}>
                <Col span={8}>
                    <Form.Item
                        label="First Name"
                        name="firstName"
                        rules={[{ required: true, message: 'Please enter first name' }]}
                    >
                        <Input prefix={<UserOutlined />} placeholder="Enter first name" />
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item
                        label="Last Name"
                        name="lastName"
                        rules={[{ required: true, message: 'Please enter last name' }]}
                    >
                        <Input prefix={<UserOutlined />} placeholder="Enter last name" />
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item
                        label="Full Name"
                        name="fullName"
                        rules={[{ required: true, message: 'Please enter full name' }]}
                    >
                        <Input prefix={<UserOutlined />} placeholder="Enter full name" />
                    </Form.Item>
                </Col>
            </Row>

            <Row gutter={16}>
                <Col span={8}>
                    <Form.Item
                        label="Email Address"
                        name="email"
                        rules={[
                            { required: true, message: 'Please enter email address' },
                            { type: 'email', message: 'Please enter a valid email address' }
                        ]}
                    >
                        <Input prefix={<MailOutlined />} placeholder="Enter email address" />
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item
                        label="Phone Number"
                        name="phoneNumber"
                        rules={[
                            { required: true, message: 'Please enter phone number' },
                            { pattern: /^\+\d{2}-\d{3}-\d{7}$/, message: 'Please enter a valid phone number' }
                        ]}
                    >
                        <Input prefix={<PhoneOutlined />} placeholder="Enter phone number as +92-XXX-XXXXXXX" />
                    </Form.Item>
                </Col>
            </Row>

            <Row gutter={16}>
                <Col span={8}>
                    <Form.Item
                        label="Employee ID"
                        name="employeeId"
                        rules={[{ required: true, message: 'Please enter employee ID' }]}
                    >
                        <Input prefix={<IdcardOutlined />} placeholder="Enter employee ID" disabled />
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item
                        label="Gender"
                        name="gender"
                        rules={[{ required: true, message: 'Please select gender' }]}
                    >
                        <Select placeholder="Select gender"
                            options={[
                                { value: 'male', label: 'Male' },
                                { value: 'female', label: 'Female' },
                                { value: 'other', label: 'Other' }

                            ]}
                        />
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item
                        label="Date of Birth"
                        name="dateOfBirth"
                    >
                        <DatePicker
                            style={{ width: '100%' }}
                            placeholder="Select date of birth"
                            format="YYYY-MM-DD"
                        />
                    </Form.Item>
                </Col>
            </Row>
        </div>
    );
}
