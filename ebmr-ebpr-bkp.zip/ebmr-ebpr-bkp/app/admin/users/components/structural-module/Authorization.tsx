import { DEPARTMENTS } from "@/lib/constants/Department";
import { AUTHORIZATION_MODULES, AUTHORIZATION_TYPES } from "@/lib/constants/PermissionConstants";
import { ROLES } from "@/lib/constants/Roles";
import { Row, Col, Form, Select, Input, Button, Table, Tag, Popconfirm } from "antd";
import { PlusOutlined, DeleteOutlined } from '@ant-design/icons';
import { useEffect, useState } from "react";


export default function Authorization({ form, initialAuthorization }: { form: any, initialAuthorization?: Array<{ module: string; accessLevel: string[] }> }) {
    const [module, setModule] = useState<string>('');
    const [accessLevel, setAccessLevel] = useState<string[]>([]);
    const [authorizationList, setAuthorizationList] = useState<Array<{ module: string; accessLevel: string[] }>>([]);
    
    useEffect(() => {
    if (initialAuthorization && initialAuthorization.length > 0) {

        // Remove Mongo _id from each object
        const cleanedAuth = initialAuthorization.map(({ module, accessLevel }) => ({
            module,
            accessLevel
        }));

        setAuthorizationList(cleanedAuth);

        // also sync with form
        form.setFieldsValue({
            authorization: cleanedAuth
        });
    }
}, [initialAuthorization]);

    const handleAddAuthorization = () => {
        if (module && accessLevel.length > 0) {
            const moduleLabel = AUTHORIZATION_MODULES.find(m => m.value === module)?.label || module;

            setAuthorizationList(prev => [...prev, { module: moduleLabel, accessLevel: accessLevel }]);
            setModule('');
            setAccessLevel([]);
        }
    };

    const handleRemoveAuthorization = (index: number) => {
        setAuthorizationList(prev => prev.filter((_, i) => i !== index));
    };

    useEffect(() => {
        form.setFieldsValue({ authorization: authorizationList })
    }, [authorizationList])

    return (
        <div>
            <Row gutter={16}>
                <Col span={8}>
                    <Form.Item
                        label="Department"
                        name="department"
                        rules={[{ required: true, message: 'Please select department' }]}
                    >
                        <Select placeholder="Select department" options={DEPARTMENTS} />
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item
                        label="Role"
                        name="role"
                        rules={[{ required: true, message: 'Please select roles' }]}
                    >
                        <Select
                            placeholder="Select user role"
                            options={ROLES}
                        />
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item
                        label="Designation"
                        name="designation"
                        rules={[{ required: true, message: 'Please enter designation' }]}
                    >
                        <Input placeholder="Enter designation" />
                    </Form.Item>
                </Col>
            </Row>

            <Row gutter={16}>
                <Col span={8}>
                    <Form.Item
                        label="Reporting to"
                        name="reportingToId"
                    >
                        <Input placeholder="Enter reporting to ID" />
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item
                        label="Subordinate"
                        name="subordinateId"
                    >
                        <Input placeholder="Enter reporting Subordinate ID" />
                    </Form.Item>
                </Col>
            </Row>

            <Row gutter={16}>
                <Col span={8}>
                    <Form.Item label="Authorization Module">
                        <Select
                            placeholder="Select authorization module"
                            options={AUTHORIZATION_MODULES}
                            value={module}
                            onChange={setModule}
                        />
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item label="Access Level">
                        <Select
                            mode="multiple"
                            placeholder="Select permissions"
                            options={AUTHORIZATION_TYPES}
                            value={accessLevel}
                            onChange={setAccessLevel}
                        />
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item label=" ">
                        <Button
                            type="primary"
                            icon={<PlusOutlined />}
                            onClick={handleAddAuthorization}
                            disabled={!module || accessLevel.length === 0}
                        >
                            Add Authorization
                        </Button>
                    </Form.Item>
                    <Form.Item name="authorization">
                        <Input type='hidden' />
                    </Form.Item>
                </Col>

            </Row>

            {/* Authorization List Table */}
            {authorizationList.length > 0 && (
                <Row gutter={16} style={{ marginTop: '-60px' }}>
                    <Col span={24}>
                        <Table
                            dataSource={authorizationList.map((auth, index) => ({ ...auth, key: index }))}
                            pagination={false}
                            scroll={{ y: 200 }}
                            size="small"
                            title={() => (
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                    <span style={{ fontWeight: 'bold', fontSize: '16px' }}>Authorization List</span>
                                    <span style={{ color: '#666', fontSize: '12px' }}>
                                        Total: {authorizationList.length} authorization(s)
                                    </span>
                                </div>
                            )}
                        >
                            <Table.Column
                                title="Module"
                                dataIndex="module"
                                key="module"
                                render={(text) => (
                                    <Tag color="blue" style={{ fontSize: '12px', padding: '2px 6px' }}>
                                        {text}
                                    </Tag>
                                )}
                            />
                            <Table.Column
                                title="Access Level"
                                dataIndex="accessLevel"
                                key="accessLevel"
                                render={(accessLevels: string[]) => (
                                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                                        {accessLevels.map((level: string, index: number) => {
                                            const accessType = AUTHORIZATION_TYPES.find(a => a.value === level);
                                            const label = accessType?.label || level;
                                            return (
                                                <Tag key={index} color="green" style={{ fontSize: '12px', padding: '2px 6px' }}>
                                                    {label}
                                                </Tag>
                                            );
                                        })}
                                    </div>
                                )}
                            />
                            <Table.Column
                                title="Actions"
                                key="actions"
                                render={(_, __, index) => (
                                    <Popconfirm
                                        title="Are you sure you want to remove this authorization?"
                                        onConfirm={() => handleRemoveAuthorization(index)}
                                        okText="Yes"
                                        cancelText="No"
                                    >
                                        <Button
                                            type="text"
                                            danger
                                            icon={<DeleteOutlined />}
                                            style={{ border: 'none', boxShadow: 'none' }}
                                        />
                                    </Popconfirm>
                                )}
                            />
                        </Table>
                    </Col>
                </Row>
            )}
        </div>
    )
}
