import { Row, Col, Form, Select, Input, DatePicker } from "antd";

interface OrganizationalInfoProps {
    form?: any;
}

export default function OrganizationalInfo() {
    return (
        <div>
            

            <Row gutter={16}>
                <Col span={8}>
                    <Form.Item
                        label="Employment Type"
                        name="employmentType"
                        rules={[{ required: true, message: 'Please select employment type' }]}
                    >
                        <Select placeholder="Select employment type"
                            options={[
                                { value: 'permanent', label: 'Permanent' },
                                { value: 'contract', label: 'Contract' }
                            ]} />
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item
                        label="Joining Date"
                        name="joiningDate"
                        rules={[{ required: true, message: 'Please select joining date' }]}
                    >
                        <DatePicker
                            style={{ width: '100%' }}
                            placeholder="Select joining date"
                            format="YYYY-MM-DD"
                        />
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item
                        label="Employment Status"
                        name="employmentStatus"
                        rules={[{ required: true, message: 'Please enter employment status' }]}
                    >
                        <Select placeholder="Select employment status"
                            options={[
                                { value: 'active', label: 'Active' },
                                { value: 'inactive', label: 'Inactive' },
                                {value:'resigned', label:'Resigned'}
                            ]} />
                    </Form.Item>
                </Col>
            </Row>
            <Row gutter={16}>
                <Col span={8}>
                    <Form.Item
                        label="Company"
                        name="companyId"
                        rules={[{ required: true, message: 'Please select company' }]}
                    >
                        <Select placeholder="Select company"
                            options={[
                                { value: 'company1', label: 'Company 1' },
                                { value: 'company2', label: 'Company 2' },
                                { value: 'company3', label: 'Company 3' }
                            ]}
                        />
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item
                        label="Branch"
                        name="branchId"
                        rules={[{ required: true, message: 'Please select branch' }]}
                    >
                        <Select placeholder="Select branch"
                            options={[
                                { value: 'branch1', label: 'Branch 1' },
                                { value: 'branch2', label: 'Branch 2' },
                                { value: 'branch3', label: 'Branch 3' }
                            ]} />
                    </Form.Item>
                </Col>
                {/* <Col span={8}>
                    <Form.Item
                        label="Cost Center"
                        name="costCenterId"
                    >
                        <Input placeholder="Enter cost center ID" />
                    </Form.Item>
                </Col> */}
            </Row>
        </div>
    )
}
