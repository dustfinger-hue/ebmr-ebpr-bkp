'use client';

import { Modal, Form, Button, Space, Avatar, message, Tabs } from 'antd';
import { UserOutlined } from '@ant-design/icons';
import { useState, useEffect } from 'react';
import dayjs from 'dayjs';
import BasicIdentityInformation from './structural-module/BasicIdentityInformation';
import Authorization from './structural-module/Authorization';
import OrganizationalInfo from './structural-module/OrganizationalInfo';
import { User } from '../Interface';



interface EditUserProps {
    open: boolean;
    onClose: () => void;
    userData?: User | null;
}

export default function EditUser({ open, onClose, userData }: EditUserProps) {
    const [form] = Form.useForm<any>();
    const [loading, setLoading] = useState(false);
    const [activeTab, setActiveTab] = useState('basic');
    const [fetchedUserData, setFetchedUserData] = useState<User | null>(null);

    useEffect(() => {
    if (open && userData?._id) {
        fetchUser();
    }
}, [open, userData?._id]);

useEffect(() => {
    if (fetchedUserData) {
        form.setFieldsValue({
            firstName: fetchedUserData.firstName,
            lastName: fetchedUserData.lastName,
            fullName: fetchedUserData.fullName,
            username: fetchedUserData.username,
            email: fetchedUserData.email,
            phoneNumber: fetchedUserData.phoneNumber || '+92',
            employeeId: fetchedUserData.employeeId,
            gender: fetchedUserData.gender,
            dateOfBirth: fetchedUserData.dateOfBirth ? dayjs(fetchedUserData.dateOfBirth) : null,
            profileImage: fetchedUserData.profileImage,
            role: fetchedUserData.role,
            department: fetchedUserData.department,
            designation: fetchedUserData.designation,
            reportingToId: fetchedUserData.reportingToId,
            subordinateId: fetchedUserData.subordinateId,
            accessLevel: fetchedUserData.accessLevel,
            companyId: fetchedUserData.companyId,
            branchId: fetchedUserData.branchId,
            employmentType: fetchedUserData.employmentType,
            joiningDate: fetchedUserData.joiningDate ? dayjs(fetchedUserData.joiningDate) : null,
            employmentStatus: fetchedUserData.employmentStatus
        });
    }
}, [fetchedUserData]);

    const fetchUser = async () => {
        try {
            setLoading(true);
            const res = await fetch('/api/admin/user-management?type=detailed&id=' + userData?._id, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            }
            )
            const data = await res.json()
            console.log(data.users)
            setFetchedUserData(data.users)
        } catch {
            console.log('error')
            setFetchedUserData(null)
        } finally {
            setLoading(false)
        }
    }


    const TAB_FIELDS: Record<string, string[]> = {
        basic: [
            'firstName',
            'lastName',
            'fullName',
            'email',
            'phoneNumber',
            'employeeId',
            'gender',
            'dateOfBirth'
        ],
        authorization: [
            'role',
            'department',
            'designation',
            'reportingToId',
            'subordinateId',
            'authorization'
        ],
        organization: [
            'companyId',
            'branchId',
            'employmentType',
            'joiningDate',
            'employmentStatus'
        ]
    };

    const handleStepSave = async () => {
        try {
            setLoading(true);

            // 🔥 get fields based on active tab
            const fieldsToValidate = TAB_FIELDS[activeTab];

            // 🔥 validate only those fields
            const validatedValues = await form.validateFields(fieldsToValidate);

            const res = await fetch('/api/admin/user-management', {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    ...validatedValues,
                    id: userData?._id
                })
            });

            const data = await res.json();

            if (data.success) {
                message.success(`${activeTab} updated successfully`);
            } else {
                message.error(data.message);
            }

        } catch (error) {
            message.error('Please fix validation errors');
        } finally {
            setLoading(false);
        }
    };
    const tabItems = [
        { key: 'basic', label: 'Basic Identity Information', children: <BasicIdentityInformation /> },
        { key: 'authorization', label: 'Authorization (Access Control)', children: <Authorization form={form} initialAuthorization={fetchedUserData?.authorization||[]} /> },
        { key: 'organization', label: 'Organizational Info', children: <OrganizationalInfo /> },
    ]

    return (
        <Modal
            open={open}
            onCancel={() => {
                form.resetFields();
                setFetchedUserData(null)
                onClose();
            }}
            title={
                <Space>
                    <Avatar
                        size="large"
                        icon={<UserOutlined />}
                        src={fetchedUserData?.profileImage}
                        style={{ backgroundColor: '#1890ff' }}
                    />
                    <span style={{ fontSize: '18px', fontWeight: 'bold' }}>
                        Edit User: {fetchedUserData?.fullName || fetchedUserData?.firstName + ' ' + fetchedUserData?.lastName}
                    </span>
                </Space>
            }
            footer={null}
            centered
            width={900}
            destroyOnHidden
        >
            {/* <Form.Provider> */}
            <Form form={form} layout="vertical"
            >
                <Tabs
                    activeKey={activeTab}
                    onChange={(key) => setActiveTab(key)}
                    items={tabItems} />
                <div className="flex justify-end mt-5">
                    <Button
                        type="primary"
                        loading={loading}
                        onClick={handleStepSave}
                    >
                        Save Changes
                    </Button>
                </div>
            </Form>
            {/* </Form.Provider> */}
        </Modal>
    );
}