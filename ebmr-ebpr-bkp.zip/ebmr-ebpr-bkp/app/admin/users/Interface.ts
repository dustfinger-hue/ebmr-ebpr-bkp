export interface User {
    _id: string;
    firstName: string;
    lastName: string;
    fullName: string;
    username: string;
    email: string;
    phoneNumber: string;
    profileImage?: string;
    employeeId: string;
    gender: 'male' | 'female' | 'other';
    dateOfBirth: string;
    role: string;
    department: string;
    designation: string;
    reportingToId: string;
    authorization: any[];
    subordinateId: string;
    accessLevel: string;
    companyId: string;
    branchId: string;
    employmentType: 'permanent' | 'contract';
    joiningDate: string;
    employmentStatus: string;
    status: 'active' | 'inactive' | 'pending';
    lastLogin?: string;
    createdAt: string;
}
