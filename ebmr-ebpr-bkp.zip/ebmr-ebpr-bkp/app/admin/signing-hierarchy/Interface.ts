export interface AuthorizedPerson {
    id: string;
    name: string;
    designation: string;
    department: string;
    authorizationLevel: string;
    authorizationSequence?: number;
}

export interface SigningHierarchyModule {
    _id?: string;
    key: string;
    module: string;
    signRequired: number;
    authorizedPersons: AuthorizedPerson[];
    status: 'active' | 'inactive';
    lastModified?: string;
    lastModifiedBy?: string;
    createdAt?: string;
    updatedAt?: string;
}

export interface SelectableUser {
    _id: string;
    fullName: string;
    email: string;
    role: string;
    department: string;
    designation: string;
}
