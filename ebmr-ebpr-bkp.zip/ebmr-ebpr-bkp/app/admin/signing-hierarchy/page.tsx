"use client";

import { Avatar, Badge, Button, Card, Col, Input, message, Row, Select, Space, Statistic, Table, Tag, Tooltip, Typography } from "antd";
import {
    SearchOutlined,
    PlusOutlined,
    EditOutlined,
    DeleteOutlined,
    ReloadOutlined,
    CheckCircleOutlined,
    CloseCircleOutlined,
    UserOutlined,
    TeamOutlined,
    BlockOutlined,
    EyeOutlined,
    SafetyCertificateOutlined,
} from "@ant-design/icons";
import { useState, useEffect } from "react";
import { SigningHierarchyModule, AuthorizedPerson } from "./Interface";
import AddModuleModal from "./components/AddModuleModal";
import DeleteModuleModal from "./components/DeleteModuleModal";
import EditModuleModal from "./components/EditModuleModal";
import ViewModuleModal from "./components/ViewModuleModal";

const { Title, Text } = Typography;
const { Option } = Select;

// Department color mapping
const departmentColors: Record<string, string> = {
    "Quality Assurance": "green",
    "Quality Control": "orange",
    "Production": "blue",
    "Engineering": "purple",
    "Warehouse": "cyan",
    "Research & Development": "magenta",
    "Regulatory Affairs": "red",
    "Validation": "geekblue",
};

const getDepartmentColor = (dept: string) => {
    return departmentColors[dept] || "default";
};

interface SigningHierarchyApiPerson {
    _id?: string;
    userId?: string;
    name: string;
    designation: string;
    department: string;
    authorizationLevel?: string;
    authorizationSequence?: number;
}

interface SigningHierarchyApiModule extends Omit<SigningHierarchyModule, "key" | "authorizedPersons"> {
    authorizedPersons: SigningHierarchyApiPerson[];
}

export default function SigningHierarchyPage() {
    const [modules, setModules] = useState<SigningHierarchyModule[]>([]);
    const [loading, setLoading] = useState(false);
    const [searchText, setSearchText] = useState("");
    const [departmentFilter, setDepartmentFilter] = useState<string>("all");
    const [statusFilter, setStatusFilter] = useState<string>("all");
    const [deleteModalVisible, setDeleteModalVisible] = useState(false);
    const [moduleToDelete, setModuleToDelete] = useState<SigningHierarchyModule | null>(null);
    const [addModalOpen, setAddModalOpen] = useState(false);
    const [editModalOpen, setEditModalOpen] = useState(false);
    const [selectedModule, setSelectedModule] = useState<SigningHierarchyModule | null>(null);
    const [viewModalOpen, setViewModalOpen] = useState(false);
    const [moduleToView, setModuleToView] = useState<SigningHierarchyModule | null>(null);

    // Fetch signing hierarchy modules
    const fetchModules = async () => {
        try {
            setLoading(true);
            const res = await fetch("/api/admin/signing-hierarchy", {
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
            });
            const data = await res.json();
            if (data.success) {
                const mapped = data.modules.map((m: SigningHierarchyApiModule, idx: number) => ({
                    ...m,
                    key: m._id || String(idx),
                    authorizedPersons: m.authorizedPersons.map((p) => ({
                        id: p.userId || p._id,
                        name: p.name,
                        designation: p.designation,
                        department: p.department,
                        authorizationLevel: p.authorizationLevel || "",
                        authorizationSequence: p.authorizationSequence,
                    })),
                }));
                setModules(mapped);
            } else {
                message.error(data.message);
            }
        } catch {
            message.error("Failed to fetch signing modules");
            setModules([]);
        } finally {
            setLoading(false);
        }
    };

    // Initial load
    useEffect(() => {
        void Promise.resolve().then(fetchModules);
    }, []);

    // Get unique departments from modules
    const allDepartments = Array.from(
        new Set(modules.flatMap((m) => m.authorizedPersons.map((p) => p.department)))
    ).sort();

    // Filter logic
    const filteredModules = modules.filter((mod) => {
        const matchesSearch = mod.module.toLowerCase().includes(searchText.toLowerCase());
        const matchesStatus = statusFilter === "all" || mod.status === statusFilter;
        const matchesDepartment =
            departmentFilter === "all" ||
            mod.authorizedPersons.some((p) => p.department === departmentFilter);
        return matchesSearch && matchesStatus && matchesDepartment;
    });

    // Stats
    const totalModules = modules.length;
    const activeModules = modules.filter((m) => m.status === "active").length;
    const inactiveModules = modules.filter((m) => m.status === "inactive").length;
    const totalSignatories = modules.reduce((acc, m) => acc + m.authorizedPersons.length, 0);

    // --- Add Module Handlers ---
    const openAddModal = () => {
        setAddModalOpen(true);
    };

    // --- Edit Module Handlers ---
    const handleEdit = (mod: SigningHierarchyModule) => {
        setSelectedModule(mod);
        setEditModalOpen(true);
    };

    const handleView = (mod: SigningHierarchyModule) => {
        setModuleToView(mod);
        setViewModalOpen(true);
    };

    // --- Delete Handlers ---
    const handleDelete = (mod: SigningHierarchyModule) => {
        setModuleToDelete(mod);
        setDeleteModalVisible(true);
    };

    const getStatusTag = (status: string) => {
        switch (status) {
            case "active":
                return <Tag color="green" icon={<CheckCircleOutlined />}>Active</Tag>;
            case "inactive":
                return <Tag color="red" icon={<CloseCircleOutlined />}>Inactive</Tag>;
            default:
                return <Tag>{status}</Tag>;
        }
    };

    // Expanded row render
    const expandedRowRender = (record: SigningHierarchyModule) => {
        return (
            <div style={{ padding: "12px 8px" }}>
                <Text strong style={{ marginBottom: 8, display: "block" }}>
                    Authorized Signatories Details
                </Text>
                <Table
                    dataSource={record.authorizedPersons}
                    rowKey="id"
                    pagination={false}
                    showHeader={false}
                    columns={[
                        {
                            dataIndex: "authorizationSequence",
                            key: "authorizationSequence",
                            width: 40,
                            render: (seq: number | undefined) => (
                                <Text strong style={{ fontSize: 13 }}>{seq ?? "-"}</Text>
                            ),
                        },
                        {
                            dataIndex: "name",
                            key: "name",
                            width: 200,
                            render: (name: string) => (
                                <Space>
                                    <Avatar size="small" icon={<UserOutlined />} />
                                    <Text strong>{name}</Text>
                                </Space>
                            ),
                        },
                        {
                            dataIndex: "designation",
                            key: "designation",
                            width: 200,
                            render: (designation: string) => (
                                <Text type="secondary">{designation}</Text>
                            ),
                        },
                        {
                            dataIndex: "authorizationLevel",
                            key: "authorizationLevel",
                            width: 160,
                            render: (authorizationLevel: string) => (
                                <Tag color="blue">{authorizationLevel || "Not Set"}</Tag>
                            ),
                        },
                        {
                            dataIndex: "department",
                            key: "department",
                            render: (dept: string) => (
                                <Tag color={getDepartmentColor(dept)}>{dept}</Tag>
                            ),
                        },
                    ]}
                    size="small"
                />
            </div>
        );
    };

    const columns = [
        {
            title: "Module",
            dataIndex: "module",
            key: "module",
            render: (text: string, record: SigningHierarchyModule) => (
                <Space align="start">
                    <Avatar
                        shape="square"
                        icon={<SafetyCertificateOutlined />}
                        style={{ background: "#e6f4ff", color: "#1677ff" }}
                    />
                    <div>
                        <Text strong style={{ fontSize: 14 }}>{text}</Text>
                        {record.updatedAt && (
                            <div style={{ fontSize: 11, color: "#999", marginTop: 2 }}>
                                Modified: {new Date(record.updatedAt).toLocaleDateString()}
                                {record.lastModifiedBy && ` by ${record.lastModifiedBy}`}
                            </div>
                        )}
                    </div>
                </Space>
            ),
        },
        {
            title: "Sign Required",
            dataIndex: "signRequired",
            key: "signRequired",
            width: 130,
            render: (count: number) => (
                <Badge
                    count={count}
                    style={{
                        backgroundColor: count > 3 ? "#ff4d4f" : count > 1 ? "#faad14" : "#52c41a",
                        fontSize: 13,
                        fontWeight: 600,
                        minWidth: 28,
                        height: 24,
                        lineHeight: "24px",
                    }}
                    overflowCount={99}
                />
            ),
        },
        {
            title: "Authorized Signatories",
            dataIndex: "authorizedPersons",
            key: "authorizedPersons",
            render: (persons: AuthorizedPerson[]) => (
                <Space direction="vertical" size={4} style={{ width: "100%" }}>
                    {persons.slice(0, 3).map((person) => (
                        <Tooltip
                            key={person.id}
                            title={`${person.name} — ${person.authorizationLevel || person.designation} — ${person.department}`}
                        >
                            <Space size={4} style={{ cursor: "pointer", padding: "2px 0" }}>
                                <UserOutlined style={{ color: "#1890ff", fontSize: 12 }} />
                                <Text style={{ fontSize: 13 }}>{person.name}</Text>
                                <Text type="secondary" style={{ fontSize: 12 }}>
                                    ({person.authorizationLevel || person.designation})
                                </Text>
                                <Tag
                                    color={getDepartmentColor(person.department)}
                                    style={{ fontSize: 11, lineHeight: "18px", padding: "0 6px" }}
                                >
                                    {person.department}
                                </Tag>
                            </Space>
                        </Tooltip>
                    ))}
                    {persons.length > 3 && (
                        <Text type="secondary" style={{ fontSize: 12 }}>
                            +{persons.length - 3} more
                        </Text>
                    )}
                </Space>
            ),
        },
        {
            title: "Status",
            dataIndex: "status",
            key: "status",
            width: 110,
            render: (status: string) => getStatusTag(status),
        },
        {
            title: "Actions",
            key: "actions",
            width: 150,
            render: (_: unknown, record: SigningHierarchyModule) => (
                <Space size="small">
                    <Tooltip title="View Module">
                        <Button
                            type="text"
                            icon={<EyeOutlined />}
                            onClick={() => handleView(record)}
                        />
                    </Tooltip>
                    <Tooltip title="Edit Module">
                        <Button
                            type="text"
                            icon={<EditOutlined />}
                            onClick={() => handleEdit(record)}
                        />
                    </Tooltip>
                    <Tooltip title="Delete Module">
                        <Button
                            type="text"
                            danger
                            icon={<DeleteOutlined />}
                            onClick={() => handleDelete(record)}
                        />
                    </Tooltip>
                </Space>
            ),
        },
    ];

    return (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <Card
                styles={{ body: { padding: 20 } }}
                style={{ border: "1px solid #e6f4ff" }}
            >
                <div style={{ display: "flex", justifyContent: "space-between", gap: 16, flexWrap: "wrap", alignItems: "center" }}>
                    <Space align="center">
                        <Avatar
                            size={52}
                            shape="square"
                            icon={<SafetyCertificateOutlined />}
                            style={{ background: "#1677ff" }}
                        />
                        <div>
                            <Title level={2} style={{ margin: 0 }}>
                                Signing Hierarchy
                            </Title>
                            <Text type="secondary">
                                Manage module-wise signatories and approval levels
                            </Text>
                        </div>
                    </Space>
                    <Space wrap>
                        <Button icon={<ReloadOutlined />} onClick={fetchModules}>
                            Refresh
                        </Button>
                        <Button type="primary" icon={<PlusOutlined />} onClick={openAddModal}>
                            Add New Module
                        </Button>
                    </Space>
                </div>
            </Card>

            {/* Summary Stats Cards */}
            <Row gutter={[16, 16]}>
                <Col xs={24} sm={12} lg={6}>
                    <Card hoverable styles={{ body: { padding: 18 } }}>
                        <Statistic
                            title="Total Modules"
                            value={totalModules}
                            prefix={<BlockOutlined style={{ color: "#1890ff" }} />}
                            valueStyle={{ color: "#1890ff" }}
                        />
                    </Card>
                </Col>
                <Col xs={24} sm={12} lg={6}>
                    <Card hoverable styles={{ body: { padding: 18 } }}>
                        <Statistic
                            title="Authorized Signatories"
                            value={totalSignatories}
                            prefix={<TeamOutlined style={{ color: "#52c41a" }} />}
                            valueStyle={{ color: "#52c41a" }}
                        />
                    </Card>
                </Col>
                <Col xs={24} sm={12} lg={6}>
                    <Card hoverable styles={{ body: { padding: 18 } }}>
                        <Statistic
                            title="Active Modules"
                            value={activeModules}
                            prefix={<CheckCircleOutlined style={{ color: "#52c41a" }} />}
                            valueStyle={{ color: "#52c41a" }}
                            suffix={
                                <Text type="secondary" style={{ fontSize: 14 }}>
                                    / {totalModules}
                                </Text>
                            }
                        />
                    </Card>
                </Col>
                <Col xs={24} sm={12} lg={6}>
                    <Card hoverable styles={{ body: { padding: 18 } }}>
                        <Statistic
                            title="Inactive Modules"
                            value={inactiveModules}
                            prefix={<CloseCircleOutlined style={{ color: "#ff4d4f" }} />}
                            valueStyle={{ color: "#ff4d4f" }}
                            suffix={
                                <Text type="secondary" style={{ fontSize: 14 }}>
                                    / {totalModules}
                                </Text>
                            }
                        />
                    </Card>
                </Col>
            </Row>

            {/* Filters and Actions */}
            <Card>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 16, flexWrap: "wrap", alignItems: "center" }}>
                    <Space wrap>
                        <Input
                            placeholder="Search by module name..."
                            prefix={<SearchOutlined />}
                            style={{ width: 280 }}
                            onChange={(e) => setSearchText(e.target.value)}
                            allowClear
                        />
                        <Select
                            placeholder="Filter by department"
                            style={{ width: 220 }}
                            onChange={(value) => setDepartmentFilter(value)}
                            defaultValue="all"
                            allowClear
                        >
                            <Option value="all">All Departments</Option>
                            {allDepartments.map((dept) => (
                                <Option key={dept} value={dept}>
                                    {dept}
                                </Option>
                            ))}
                        </Select>
                        <Select
                            placeholder="Filter by status"
                            style={{ width: 160 }}
                            onChange={(value) => setStatusFilter(value)}
                            defaultValue="all"
                            allowClear
                        >
                            <Option value="all">All Status</Option>
                            <Option value="active">Active</Option>
                            <Option value="inactive">Inactive</Option>
                        </Select>
                    </Space>
                    <Text strong>
                        Showing {filteredModules.length} of {totalModules} modules
                    </Text>
                </div>
            </Card>

            {/* Modules Table */}
            <Card styles={{ body: { padding: 0 } }}>
                <Table
                    columns={columns}
                    dataSource={filteredModules}
                    rowKey="key"
                    loading={loading}
                    expandable={{
                        expandedRowRender,
                        rowExpandable: (record) => record.authorizedPersons.length > 0,
                    }}
                    pagination={{
                        pageSize: 10,
                        showSizeChanger: true,
                        showQuickJumper: true,
                        showTotal: (total, range) =>
                            `Showing ${range[0]}-${range[1]} of ${total} modules`,
                        pageSizeOptions: ["5", "10", "20", "50"],
                    }}
                    scroll={{ x: 900 }}
                />
            </Card>

            <AddModuleModal
                open={addModalOpen}
                onCancel={() => setAddModalOpen(false)}
                onSuccess={fetchModules}
            />

            <EditModuleModal
                open={editModalOpen}
                module={selectedModule}
                onCancel={() => {
                    setEditModalOpen(false);
                    setSelectedModule(null);
                }}
                onSuccess={fetchModules}
            />

            <DeleteModuleModal
                open={deleteModalVisible}
                moduleToDelete={moduleToDelete}
                onCancel={() => {
                    setDeleteModalVisible(false);
                    setModuleToDelete(null);
                }}
                onSuccess={fetchModules}
            />

            <ViewModuleModal
                open={viewModalOpen}
                module={moduleToView}
                onCancel={() => {
                    setViewModalOpen(false);
                    setModuleToView(null);
                }}
            />
        </div>
    );
}
