"use client";

import { message, Modal, Typography } from "antd";
import { useState } from "react";
import { SigningHierarchyModule } from "../Interface";

const { Text } = Typography;

interface DeleteModuleModalProps {
    open: boolean;
    moduleToDelete: SigningHierarchyModule | null;
    onCancel: () => void;
    onSuccess: () => void;
}

export default function DeleteModuleModal({
    open,
    moduleToDelete,
    onCancel,
    onSuccess,
}: DeleteModuleModalProps) {
    const [submitting, setSubmitting] = useState(false);

    const confirmDelete = async () => {
        if (!moduleToDelete) return;

        try {
            setSubmitting(true);
            const res = await fetch(`/api/admin/signing-hierarchy?id=${moduleToDelete._id}`, {
                method: "DELETE",
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
            });
            const data = await res.json();
            if (data.success) {
                message.success(`Module "${moduleToDelete.module}" has been deleted`);
                onCancel();
                onSuccess();
            } else {
                message.error(data.message || "Failed to delete module");
            }
        } catch {
            message.error("An error occurred while deleting the module");
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <Modal
            title="Delete Signing Module"
            open={open}
            onOk={confirmDelete}
            onCancel={onCancel}
            okText="Delete"
            cancelText="Cancel"
            confirmLoading={submitting}
            okButtonProps={{ danger: true }}
        >
            {moduleToDelete && (
                <div>
                    <p>Are you sure you want to delete the following module?</p>
                    <div
                        style={{
                            background: "#f5f5f5",
                            padding: 12,
                            borderRadius: 6,
                        }}
                    >
                        <Text strong style={{ fontSize: 16 }}>
                            {moduleToDelete.module}
                        </Text>
                        <br />
                        <Text type="secondary">
                            Sign Required: {moduleToDelete.signRequired}
                        </Text>
                        <br />
                        <Text type="secondary">
                            Authorized Persons: {moduleToDelete.authorizedPersons.length}
                        </Text>
                    </div>
                    <p style={{ marginTop: 12, color: "#ff4d4f" }}>
                        <strong>Warning:</strong> This action cannot be undone.
                    </p>
                </div>
            )}
        </Modal>
    );
}
