"use client";

import { CheckCircleOutlined, CloseCircleOutlined, UserOutlined } from "@ant-design/icons";
import { Avatar, Descriptions, Empty, Modal, Space, Table, Tag, Typography } from "antd";
import { AuthorizedPerson, SigningHierarchyModule } from "../Interface";

const { Text, Title } = Typography;

const departmentColors: Record<string, string> = {
    "Quality Assurance": "green",
    "Quality Control": "orange",
    "Production": "blue",
    "Engineering": "purple",
    "Warehouse": "cyan",
    "Research & Development": "magenta",
    "Regulatory Affairs": "red",
    "Validation": "geekblue",
};

const getDepartmentColor = (dept: string) => departmentColors[dept] || "default";

interface ViewModuleModalProps {
    open: boolean;
    module: SigningHierarchyModule | null;
    onCancel: () => void;
}

export default function ViewModuleModal({ open, module, onCancel }: ViewModuleModalProps) {
    const statusTag = module?.status === "active" ? (
        <Tag color="green" icon={<CheckCircleOutlined />}>Active</Tag>
    ) : (
        <Tag color="red" icon={<CloseCircleOutlined />}>Inactive</Tag>
    );

    return (
        <Modal
            title="Signing Module Details"
            open={open}
            onCancel={onCancel}
            footer={null}
            width={820}
        >
            {!module ? (
                <Empty description="No module selected" />
            ) : (
                <Space direction="vertical" size="large" style={{ width: "100%" }}>
                    <div>
                        <Title level={4} style={{ marginBottom: 4 }}>
                            {module.module}
                        </Title>
                        <Text type="secondary">
                            {module.authorizedPersons.length} authorized person(s), {module.signRequired} signature(s) required
                        </Text>
                    </div>

                    <Descriptions bordered size="small" column={{ xs: 1, sm: 2 }}>
                        <Descriptions.Item label="Status">{statusTag}</Descriptions.Item>
                        <Descriptions.Item label="Sign Required">
                            <Tag color="blue">{module.signRequired}</Tag>
                        </Descriptions.Item>
                        <Descriptions.Item label="Last Modified By">
                            {module.lastModifiedBy || "Not available"}
                        </Descriptions.Item>
                        <Descriptions.Item label="Last Modified">
                            {module.updatedAt ? new Date(module.updatedAt).toLocaleString() : "Not available"}
                        </Descriptions.Item>
                    </Descriptions>

                    <Table
                        rowKey="id"
                        dataSource={module.authorizedPersons}
                        pagination={false}
                        size="small"
                        columns={[
                            {
                                title: "#",
                                dataIndex: "authorizationSequence",
                                key: "authorizationSequence",
                                width: 50,
                                render: (seq: number | undefined) => (
                                    <Text strong style={{ fontSize: 13 }}>{seq ?? "-"}</Text>
                                ),
                            },
                            {
                                title: "Person",
                                dataIndex: "name",
                                key: "name",
                                render: (name: string) => (
                                    <Space>
                                        <Avatar size="small" icon={<UserOutlined />} />
                                        <Text strong>{name}</Text>
                                    </Space>
                                ),
                            },
                            {
                                title: "Authorization Level",
                                dataIndex: "authorizationLevel",
                                key: "authorizationLevel",
                                render: (level: string) => (
                                    <Tag color="blue">{level || "Not Set"}</Tag>
                                ),
                            },
                            {
                                title: "Designation",
                                dataIndex: "designation",
                                key: "designation",
                                render: (designation: string) => <Text type="secondary">{designation}</Text>,
                            },
                            {
                                title: "Department",
                                dataIndex: "department",
                                key: "department",
                                render: (department: AuthorizedPerson["department"]) => (
                                    <Tag color={getDepartmentColor(department)}>{department}</Tag>
                                ),
                            },
                        ]}
                    />
                </Space>
            )}
        </Modal>
    );
}
