"use client";

import { SearchOutlined } from "@ant-design/icons";
import { Avatar, Card, Checkbox, Input, message, Modal, Select, Space, Tag, Typography } from "antd";
import { useEffect, useState } from "react";
import { SelectableUser, SigningHierarchyModule } from "../Interface";

const { Text } = Typography;
const { Option } = Select;

const departmentColors: Record<string, string> = {
    "Quality Assurance": "green",
    "Quality Control": "orange",
    "Production": "blue",
    "Engineering": "purple",
    "Warehouse": "cyan",
    "Research & Development": "magenta",
    "Regulatory Affairs": "red",
    "Validation": "geekblue",
};

const getDepartmentColor = (dept: string) => departmentColors[dept] || "default";

type SelectedSigningUser = SelectableUser & {
    authorizationLevel: string;
    authorizationSequence?: number;
};

const toTitleCase = (value: string) => {
    return value
        .toLowerCase()
        .replace(/\b\w/g, (char) => char.toUpperCase());
};

interface EditModuleModalProps {
    open: boolean;
    module: SigningHierarchyModule | null;
    onCancel: () => void;
    onSuccess: () => void;
}

export default function EditModuleModal({
    open,
    module,
    onCancel,
    onSuccess,
}: EditModuleModalProps) {
    const [moduleName, setModuleName] = useState("");
    const [signRequired, setSignRequired] = useState<number>(1);
    const [status, setStatus] = useState<string>("active");
    const [selectedUsers, setSelectedUsers] = useState<SelectedSigningUser[]>([]);
    const [usersList, setUsersList] = useState<SelectableUser[]>([]);
    const [usersLoading, setUsersLoading] = useState(false);
    const [userSearchText, setUserSearchText] = useState("");
    const [submitting, setSubmitting] = useState(false);

    const fetchUsers = async () => {
        try {
            setUsersLoading(true);
            const res = await fetch("/api/admin/user-management", {
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
            });
            const data = await res.json();
            setUsersList(data.success && Array.isArray(data.users) ? data.users : []);
        } catch {
            console.log("Error fetching users");
            setUsersList([]);
        } finally {
            setUsersLoading(false);
        }
    };

    useEffect(() => {
        if (!open || !module) return;

        void Promise.resolve().then(() => {
            setModuleName(module.module);
            setSignRequired(module.signRequired);
            setStatus(module.status);
            setUserSearchText("");
            setSelectedUsers(
                module.authorizedPersons.map((p, idx) => ({
                    _id: p.id,
                    fullName: p.name,
                    email: "",
                    role: "",
                    department: p.department,
                    designation: p.designation,
                    authorizationLevel: p.authorizationLevel || "",
                    authorizationSequence: p.authorizationSequence ?? (idx + 1),
                }))
            );
            void fetchUsers();
        });
    }, [open, module]);

    const filteredUsers = usersList.filter((u) => {
        const search = userSearchText.toLowerCase();
        return (
            u.fullName?.toLowerCase().includes(search) ||
            u.email?.toLowerCase().includes(search) ||
            u.department?.toLowerCase().includes(search)
        );
    });

    const toggleUserSelection = (user: SelectableUser) => {
        setSelectedUsers((prev) => {
            const exists = prev.find((u) => u._id === user._id);
            if (exists) {
                return prev.filter((u) => u._id !== user._id);
            }
            const nextSeq = prev.length > 0 ? Math.max(...prev.map((u) => u.authorizationSequence ?? 0)) + 1 : 1;
            return [...prev, { ...user, authorizationLevel: "", authorizationSequence: nextSeq }];
        });
    };

    const updateAuthorizationLevel = (userId: string, value: string) => {
        setSelectedUsers((prev) =>
            prev.map((user) =>
                user._id === userId
                    ? { ...user, authorizationLevel: toTitleCase(value) }
                    : user
            )
        );
    };

    const handleEditModule = async () => {
        if (!module) return;

        if (!moduleName.trim()) {
            message.error("Please enter a module name");
            return;
        }
        if (!signRequired || signRequired < 1) {
            message.error("Sign required must be at least 1");
            return;
        }
        if (selectedUsers.length === 0) {
            message.error("Please select at least one authorized person");
            return;
        }
        if (selectedUsers.some((u) => !u.authorizationLevel.trim())) {
            message.error("Please enter authorization level for each selected person");
            return;
        }

        try {
            setSubmitting(true);
            const res = await fetch("/api/admin/signing-hierarchy", {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
                body: JSON.stringify({
                    id: module._id,
                    module: moduleName.trim(),
                    signRequired,
                    status,
                    authorizedPersons: selectedUsers.map((u) => ({
                        userId: u._id,
                        name: u.fullName,
                        designation: u.designation,
                        department: u.department,
                        authorizationLevel: u.authorizationLevel.trim(),
                        authorizationSequence: u.authorizationSequence,
                    })),
                }),
            });

            const data = await res.json();
            if (data.success) {
                message.success("Module updated successfully!");
                onCancel();
                onSuccess();
            } else {
                message.error(data.message || "Failed to update module");
            }
        } catch {
            message.error("An error occurred while updating the module");
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <Modal
            title="Edit Signing Module"
            open={open}
            onCancel={onCancel}
            onOk={handleEditModule}
            okText="Save Changes"
            confirmLoading={submitting}
            width={700}
        >
            <Space direction="vertical" style={{ width: "100%" }} size="middle">
                <div>
                    <Text strong>Module Name</Text>
                    <Input
                        placeholder="Enter module name"
                        value={moduleName}
                        onChange={(e) => setModuleName(e.target.value)}
                    />
                </div>
                <div style={{ display: "flex", gap: 16 }}>
                    <div style={{ flex: 1 }}>
                        <Text strong>Sign Required</Text>
                        <Input
                            type="number"
                            min={1}
                            placeholder="Number of signatures required"
                            value={signRequired}
                            onChange={(e) => setSignRequired(Number(e.target.value))}
                        />
                    </div>
                    <div style={{ flex: 1 }}>
                        <Text strong>Status</Text>
                        <Select
                            style={{ width: "100%" }}
                            value={status}
                            onChange={setStatus}
                        >
                            <Option value="active">Active</Option>
                            <Option value="inactive">Inactive</Option>
                        </Select>
                    </div>
                </div>
                <div>
                    <Text strong>
                        Authorized Persons ({selectedUsers.length} selected)
                    </Text>
                    <Input
                        placeholder="Search users by name, email, or department..."
                        prefix={<SearchOutlined />}
                        value={userSearchText}
                        onChange={(e) => setUserSearchText(e.target.value)}
                        style={{ marginBottom: 8, marginTop: 4 }}
                        allowClear
                    />
                    <Card
                        size="small"
                        style={{
                            maxHeight: 250,
                            overflow: "auto",
                            // background: "#fafafa",
                        }}
                    >
                        {usersLoading ? (
                            <Text type="secondary">Loading users...</Text>
                        ) : filteredUsers.length === 0 ? (
                            <Text type="secondary">No users found</Text>
                        ) : (
                            filteredUsers.map((user) => {
                                const isSelected = selectedUsers.some(
                                    (u) => u._id === user._id
                                );
                                return (
                                    <div
                                        key={user._id}
                                        onClick={() => toggleUserSelection(user)}
                                        style={{
                                            padding: "8px 12px",
                                            cursor: "pointer",
                                            borderRadius: 4,
                                            // background: isSelected ? "#e6f7ff" : "transparent",
                                            border: isSelected
                                                ? "1px solid #1890ff"
                                                : "1px solid transparent",
                                            marginBottom: 4,
                                            display: "flex",
                                            alignItems: "center",
                                            gap: 8,
                                            transition: "all 0.2s",
                                        }}
                                    >
                                        <Checkbox checked={isSelected} />
                                        <Avatar size="small" style={{ backgroundColor: "#1890ff" }}>
                                            {user.fullName?.charAt(0).toUpperCase()}
                                        </Avatar>
                                        <div style={{ flex: 1 }}>
                                            <Text strong style={{ fontSize: 13 }}>
                                                {user.fullName}
                                            </Text>
                                            <Text
                                                type="secondary"
                                                style={{ fontSize: 12, marginLeft: 8 }}
                                            >
                                                {user.designation}
                                            </Text>
                                        </div>
                                        <Tag color={getDepartmentColor(user.department)}>
                                            {user.department}
                                        </Tag>
                                    </div>
                                );
                            })
                        )}
                    </Card>
                </div>
                {selectedUsers.length > 0 && (
                    <div>
                        <Text strong>Selected Persons:</Text>
                        <Space direction="vertical" style={{ width: "100%", marginTop: 8 }} size="small">
                            {selectedUsers.map((u) => (
                                    <div
                                        key={u._id}
                                        style={{
                                            display: "grid",
                                            gridTemplateColumns: "40px minmax(180px, 1fr) minmax(160px, 180px)",
                                            gap: 8,
                                            alignItems: "center",
                                        }}
                                    >
                                        <Input
                                            // type="number"
                                            disabled
                                            min={1}
                                            style={{ width: 40, textAlign: "center" }}
                                            value={u.authorizationSequence ?? (selectedUsers.indexOf(u) + 1)}
                                            onChange={(e) => {
                                                const seq = Number(e.target.value);
                                                setSelectedUsers((prev) =>
                                                    prev.map((x) =>
                                                        x._id === u._id ? { ...x, authorizationSequence: seq } : x
                                                    )
                                                );
                                            }}
                                        />
                                        <Tag
                                            closable
                                            onClose={() => toggleUserSelection(u)}
                                            color="blue"
                                            style={{ marginBottom: 0, width: "fit-content" }}
                                        >
                                            {u.fullName} ({u.department})
                                        </Tag>
                                        <Input
                                            placeholder="Checked By / Approved By"
                                            value={u.authorizationLevel}
                                            onChange={(e) => updateAuthorizationLevel(u._id, e.target.value)}
                                        />
                                    </div>
                            ))}
                        </Space>
                    </div>
                )}
            </Space>
        </Modal>
    );
}
