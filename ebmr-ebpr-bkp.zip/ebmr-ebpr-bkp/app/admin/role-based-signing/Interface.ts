export interface RoleEntry {
    userRole: string;
    levelOfAuthorization: string;
    sequence: number;
}

export interface RoleBasedSigningModule {
    _id?: string;
    key: string;
    moduleName: string;
    signRequired: number;
    roles: RoleEntry[];
    status: 'active' | 'inactive';
    lastModified?: string;
    lastModifiedBy?: string;
    createdAt?: string;
    updatedAt?: string;
}