"use client";

import { message, Modal, Typography } from "antd";
import { useState } from "react";
import { RoleBasedSigningModule } from "../Interface";

const { Text } = Typography;

interface DeleteRoleBasedModalProps {
    open: boolean;
    moduleToDelete: RoleBasedSigningModule | null;
    onCancel: () => void;
    onSuccess: () => void;
}

export default function DeleteRoleBasedModal({ open, moduleToDelete, onCancel, onSuccess }: DeleteRoleBasedModalProps) {
    const [submitting, setSubmitting] = useState(false);

    const handleDelete = async () => {
        if (!moduleToDelete) return;

        try {
            setSubmitting(true);
            const res = await fetch("/api/admin/role-based-signing", {
                method: "DELETE",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
                body: JSON.stringify({ id: moduleToDelete._id }),
            });

            const data = await res.json();
            if (data.success) {
                message.success("Module deleted successfully!");
                onCancel();
                onSuccess();
            } else {
                message.error(data.message || "Failed to delete module");
            }
        } catch {
            message.error("An error occurred while deleting the module");
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <Modal
            title="Delete Role Based Signing Module"
            open={open}
            onCancel={onCancel}
            onOk={handleDelete}
            okText="Delete"
            okButtonProps={{ danger: true }}
            confirmLoading={submitting}
            width={500}
        >
            <Text>
                Are you sure you want to delete Module{' '}
                <Text strong>"{moduleToDelete?.moduleName}"</Text>? This action cannot be undone.
                All role entries associated with this module will be permanently removed.
            </Text>
        </Modal>
    );
}