"use client";

import { DeleteOutlined, PlusOutlined } from "@ant-design/icons";
import { Input, message, Modal, Select, Space, Tag, Typography, Button } from "antd";
import { ROLES } from "@/lib/constants/Roles";
import { useEffect, useState } from "react";
import { RoleBasedSigningModule } from "../Interface";

const { Text } = Typography;
const { Option } = Select;

interface RoleEntryInput {
    userRole: string;
    levelOfAuthorization: string;
    sequence: number;
}

interface EditRoleBasedModalProps {
    open: boolean;
    module: RoleBasedSigningModule | null;
    onCancel: () => void;
    onSuccess: () => void;
}

export default function EditRoleBasedModal({ open, module, onCancel, onSuccess }: EditRoleBasedModalProps) {
    const [moduleName, setModuleName] = useState("");
    const [signRequired, setSignRequired] = useState<number>(1);
    const [status, setStatus] = useState<string>("active");
    const [roles, setRoles] = useState<RoleEntryInput[]>([]);
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        if (!open || !module) return;
        setModuleName(module.moduleName);
        setSignRequired(module.signRequired);
        setStatus(module.status);
        setRoles(
            module.roles.map((r) => ({
                userRole: r.userRole || "",
                levelOfAuthorization: r.levelOfAuthorization,
                sequence: r.sequence,
            }))
        );
    }, [open, module]);

    const addRole = () => {
        const nextSeq = roles.length > 0
            ? Math.max(...roles.map((d) => d.sequence)) + 1
            : 1;
        setRoles([...roles, { userRole: "", levelOfAuthorization: "", sequence: nextSeq }]);
    };

    const removeRole = (seq: number) => {
        const resequenced = roles
            .filter((d) => d.sequence !== seq)
            .map((d, idx) => ({ ...d, sequence: idx + 1 }));
        setRoles(resequenced);
    };

    const updateRole = (seq: number, field: 'userRole' | 'levelOfAuthorization', value: string) => {
        setRoles((prev) =>
            prev.map((d) => (d.sequence === seq ? { ...d, [field]: value } : d))
        );
    };

    const handleSubmit = async () => {
        if (!module) return;
        if (!moduleName.trim()) {
            message.error("Please enter a module name");
            return;
        }
        if (!signRequired || signRequired < 1) {
            message.error("Sign required must be at least 1");
            return;
        }
        if (roles.length === 0) {
            message.error("Please add at least one role");
            return;
        }
        for (const role of roles) {
            if (!role.userRole.trim()) {
                message.error("Please select a role for each entry");
                return;
            }
            if (!role.levelOfAuthorization.trim()) {
                message.error("Please enter level of authorization for each role");
                return;
            }
        }

        try {
            setSubmitting(true);
            const res = await fetch("/api/admin/role-based-signing", {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
                body: JSON.stringify({
                    id: module._id,
                    moduleName: moduleName.trim(),
                    signRequired,
                    status,
                    roles: roles.map((r) => ({
                        userRole: r.userRole.trim(),
                        levelOfAuthorization: r.levelOfAuthorization.trim(),
                        sequence: r.sequence,
                    })),
                }),
            });

            const data = await res.json();
            if (data.success) {
                message.success("Module updated successfully!");
                onCancel();
                onSuccess();
            } else {
                message.error(data.message || "Failed to update module");
            }
        } catch {
            message.error("An error occurred while updating the module");
        } finally {
            setSubmitting(false);
        }
    };

    return (
        <Modal
            title="Edit Role Based Signing Module"
            open={open}
            onCancel={onCancel}
            onOk={handleSubmit}
            okText="Save Changes"
            confirmLoading={submitting}
            width={750}
        >
            <Space direction="vertical" style={{ width: "100%" }} size="middle">
                <div>
                    <Text strong>Module Name</Text>
                    <Input
                        placeholder="Enter module name"
                        value={moduleName}
                        onChange={(e) => setModuleName(e.target.value)}
                    />
                </div>
                <div style={{ display: "flex", gap: 16 }}>
                    <div style={{ flex: 1 }}>
                        <Text strong>Sign Required</Text>
                        <Input
                            type="number"
                            min={1}
                            placeholder="Number of signatures required"
                            value={signRequired}
                            onChange={(e) => setSignRequired(Number(e.target.value))}
                        />
                    </div>
                    <div style={{ flex: 1 }}>
                        <Text strong>Status</Text>
                        <Select
                            style={{ width: "100%" }}
                            value={status}
                            onChange={setStatus}
                        >
                            <Option value="active">Active</Option>
                            <Option value="inactive">Inactive</Option>
                        </Select>
                    </div>
                </div>

                <div>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                        <Text strong>Roles ({roles.length} added)</Text>
                        <Button type="dashed" icon={<PlusOutlined />} size="small" onClick={addRole}>
                            Add Role
                        </Button>
                    </div>
                    <Space direction="vertical" style={{ width: "100%" }} size="small">
                        {roles.map((role) => (
                            <div
                                key={role.sequence}
                                style={{
                                    display: "flex",
                                    gap: 8,
                                    alignItems: "center",
                                    padding: "8px 12px",
                                    border: "1px solid rgba(255,255,255,0.1)",
                                    borderRadius: 6,
                                    background: "rgba(0,0,0,0.02)",
                                    flexWrap: "wrap",
                                }}
                            >
                                <Tag color="blue" style={{ fontWeight: 600, minWidth: 30, textAlign: "center" }}>
                                    #{role.sequence}
                                </Tag>
                                <Select
                                    showSearch
                                    placeholder="Select role"
                                    style={{ minWidth: 180, flex: 1 }}
                                    value={role.userRole || undefined}
                                    onChange={(val) => updateRole(role.sequence, "userRole", val)}
                                >
                                    {ROLES.map((r) => (
                                        <Option key={r.value} value={r.value}>{r.label}</Option>
                                    ))}
                                </Select>
                                <Input
                                    placeholder="e.g. Checked By, Approved By"
                                    style={{ minWidth: 180, flex: 1 }}
                                    value={role.levelOfAuthorization}
                                    onChange={(e) => updateRole(role.sequence, "levelOfAuthorization", e.target.value)}
                                />
                                <Button
                                    type="text"
                                    danger
                                    icon={<DeleteOutlined />}
                                    onClick={() => removeRole(role.sequence)}
                                />
                            </div>
                        ))}
                    </Space>
                </div>
            </Space>
        </Modal>
    );
}