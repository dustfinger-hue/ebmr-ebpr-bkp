"use client";

import { Avatar, Descriptions, Modal, Space, Table, Tag, Typography } from "antd";
import { SafetyCertificateOutlined, UserOutlined } from "@ant-design/icons";
import { RoleBasedSigningModule } from "../Interface";

const { Text } = Typography;

interface ViewRoleBasedModalProps {
    open: boolean;
    module: RoleBasedSigningModule | null;
    onCancel: () => void;
}

export default function ViewRoleBasedModal({ open, module, onCancel }: ViewRoleBasedModalProps) {
    if (!module) return null;

    const sortedRoles = [...module.roles].sort((a, b) => a.sequence - b.sequence);

    const roleColumns = [
        {
            title: "Seq #",
            dataIndex: "sequence",
            key: "sequence",
            width: 80,
            render: (seq: number) => <Tag color="blue" style={{ fontWeight: 600 }}>#{seq}</Tag>,
        },
        {
            title: "Role",
            dataIndex: "userRole",
            key: "userRole",
            render: (role: string) => (
                <Space>
                    <UserOutlined style={{ color: "#722ed1" }} />
                    <Text strong>{role}</Text>
                </Space>
            ),
        },
        {
            title: "Level of Authorization",
            dataIndex: "levelOfAuthorization",
            key: "levelOfAuthorization",
            render: (level: string) => (
                <Tag color="geekblue" style={{ fontWeight: 500 }}>{level}</Tag>
            ),
        },
    ];

    return (
        <Modal
            title="View Role Based Signing Module"
            open={open}
            onCancel={onCancel}
            footer={null}
            width={650}
        >
            <Space direction="vertical" style={{ width: "100%" }} size="middle">
                <Descriptions column={2} bordered size="small">
                    <Descriptions.Item label="Module" span={2}>
                        <Space>
                            <Avatar
                                shape="square"
                                icon={<SafetyCertificateOutlined />}
                                style={{ background: "#fff7e6", color: "#fa8c16" }}
                            />
                            <Text strong>{module.moduleName}</Text>
                        </Space>
                    </Descriptions.Item>
                    <Descriptions.Item label="Sign Required">
                        <Tag color="blue" style={{ fontWeight: 600 }}>{module.signRequired}</Tag>
                    </Descriptions.Item>
                    <Descriptions.Item label="Status">
                        <Tag color={module.status === "active" ? "green" : "red"}>
                            {module.status === "active" ? "Active" : "Inactive"}
                        </Tag>
                    </Descriptions.Item>
                    {module.lastModifiedBy && (
                        <Descriptions.Item label="Last Modified By" span={2}>
                            {module.lastModifiedBy}
                        </Descriptions.Item>
                    )}
                    {module.createdAt && (
                        <Descriptions.Item label="Created">
                            {new Date(module.createdAt).toLocaleString()}
                        </Descriptions.Item>
                    )}
                    {module.updatedAt && (
                        <Descriptions.Item label="Updated">
                            {new Date(module.updatedAt).toLocaleString()}
                        </Descriptions.Item>
                    )}
                </Descriptions>

                <div>
                    <Text strong style={{ fontSize: 15, display: "block", marginBottom: 12 }}>
                        Role Based Signing Sequence ({sortedRoles.length} roles)
                    </Text>
                    <Table
                        dataSource={sortedRoles}
                        columns={roleColumns}
                        rowKey="sequence"
                        pagination={false}
                        size="small"
                    />
                </div>
            </Space>
        </Modal>
    );
}