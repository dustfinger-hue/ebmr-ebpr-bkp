"use client";

import { Avatar, Badge, Button, Card, Col, Input, message, Row, Select, Space, Statistic, Table, Tag, Tooltip, Typography } from "antd";
import {
    SearchOutlined,
    PlusOutlined,
    EditOutlined,
    DeleteOutlined,
    ReloadOutlined,
    CheckCircleOutlined,
    CloseCircleOutlined,
    TeamOutlined,
    BlockOutlined,
    EyeOutlined,
    SafetyCertificateOutlined,
    UserOutlined,
} from "@ant-design/icons";
import { useState, useEffect } from "react";
import { RoleBasedSigningModule, RoleEntry } from "./Interface";
import AddRoleBasedModal from "./components/AddRoleBasedModal";
import DeleteRoleBasedModal from "./components/DeleteRoleBasedModal";
import EditRoleBasedModal from "./components/EditRoleBasedModal";
import ViewRoleBasedModal from "./components/ViewRoleBasedModal";

const { Title, Text } = Typography;
const { Option } = Select;

interface ApiModule {
    _id?: string;
    moduleName: string;
    signRequired: number;
    roles: RoleEntry[];
    status: 'active' | 'inactive';
    lastModifiedBy?: string;
    createdAt?: string;
    updatedAt?: string;
}

export default function RoleBasedSigningPage() {
    const [modules, setModules] = useState<RoleBasedSigningModule[]>([]);
    const [loading, setLoading] = useState(false);
    const [searchText, setSearchText] = useState("");
    const [statusFilter, setStatusFilter] = useState<string>("all");
    const [addModalOpen, setAddModalOpen] = useState(false);
    const [editModalOpen, setEditModalOpen] = useState(false);
    const [selectedModule, setSelectedModule] = useState<RoleBasedSigningModule | null>(null);
    const [viewModalOpen, setViewModalOpen] = useState(false);
    const [moduleToView, setModuleToView] = useState<RoleBasedSigningModule | null>(null);
    const [deleteModalVisible, setDeleteModalVisible] = useState(false);
    const [moduleToDelete, setModuleToDelete] = useState<RoleBasedSigningModule | null>(null);

    const fetchModules = async () => {
        try {
            setLoading(true);
            const res = await fetch("/api/admin/role-based-signing", {
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
            });
            const data = await res.json();
            if (data.success) {
                const mapped = data.modules.map((m: ApiModule, idx: number) => ({
                    _id: m._id,
                    moduleName: m.moduleName,
                    signRequired: m.signRequired,
                    roles: (m.roles || []).map((r: any) => ({
                        userRole: r.userRole || "",
                        levelOfAuthorization: r.levelOfAuthorization || r.action || "",
                        sequence: r.sequence,
                    })),
                    status: m.status,
                    lastModifiedBy: m.lastModifiedBy,
                    createdAt: m.createdAt,
                    updatedAt: m.updatedAt,
                    key: m._id || String(idx),
                }));
                setModules(mapped);
            } else {
                message.error(data.message);
            }
        } catch {
            message.error("Failed to fetch role based signing modules");
            setModules([]);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        void Promise.resolve().then(fetchModules);
    }, []);

    const filteredModules = modules.filter((mod) => {
        const matchesSearch = mod.moduleName.toLowerCase().includes(searchText.toLowerCase());
        const matchesStatus = statusFilter === "all" || mod.status === statusFilter;
        return matchesSearch && matchesStatus;
    });

    const totalModules = modules.length;
    const activeModules = modules.filter((m) => m.status === "active").length;
    const inactiveModules = modules.filter((m) => m.status === "inactive").length;
    const totalRoles = modules.reduce((acc, m) => acc + m.roles.length, 0);

    const handleEdit = (mod: RoleBasedSigningModule) => {
        setSelectedModule(mod);
        setEditModalOpen(true);
    };

    const handleView = (mod: RoleBasedSigningModule) => {
        setModuleToView(mod);
        setViewModalOpen(true);
    };

    const handleDelete = (mod: RoleBasedSigningModule) => {
        setModuleToDelete(mod);
        setDeleteModalVisible(true);
    };

    const getStatusTag = (status: string) => {
        switch (status) {
            case "active":
                return <Tag color="green" icon={<CheckCircleOutlined />}>Active</Tag>;
            case "inactive":
                return <Tag color="red" icon={<CloseCircleOutlined />}>Inactive</Tag>;
            default:
                return <Tag>{status}</Tag>;
        }
    };

    const columns = [
        {
            title: "Module",
            dataIndex: "moduleName",
            key: "moduleName",
            render: (text: string, record: RoleBasedSigningModule) => (
                <Space align="start">
                    <Avatar
                        shape="square"
                        icon={<SafetyCertificateOutlined />}
                        style={{ background: "#fff7e6", color: "#fa8c16" }}
                    />
                    <div>
                        <Text strong style={{ fontSize: 14 }}>{text}</Text>
                        {record.updatedAt && (
                            <div style={{ fontSize: 11, color: "#999", marginTop: 2 }}>
                                Modified: {new Date(record.updatedAt).toLocaleDateString()}
                                {record.lastModifiedBy && ` by ${record.lastModifiedBy}`}
                            </div>
                        )}
                    </div>
                </Space>
            ),
        },
        {
            title: "Sign Required",
            dataIndex: "signRequired",
            key: "signRequired",
            width: 130,
            render: (count: number) => (
                <Badge
                    count={count}
                    style={{
                        backgroundColor: count > 3 ? "#ff4d4f" : count > 1 ? "#faad14" : "#52c41a",
                        fontSize: 13,
                        fontWeight: 600,
                        minWidth: 28,
                        height: 24,
                        lineHeight: "24px",
                    }}
                    overflowCount={99}
                />
            ),
        },
        {
            title: "Roles",
            dataIndex: "roles",
            key: "roles",
            render: (roles: RoleEntry[]) => (
                <Space direction="vertical" size={4} style={{ width: "100%" }}>
                    {roles.slice(0, 3).map((role) => (
                        <Space key={role.sequence} size={4} style={{ padding: "2px 0" }}>
                            <Tag color="blue" style={{ fontSize: 11, lineHeight: "18px", padding: "0 6px" }}>
                                #{role.sequence}
                            </Tag>
                            <Tag color="purple" style={{ fontSize: 11, lineHeight: "18px", padding: "0 6px" }}>
                                {role.userRole}
                            </Tag>
                            <Text type="secondary" style={{ fontSize: 12 }}>
                                ({role.levelOfAuthorization})
                            </Text>
                        </Space>
                    ))}
                    {roles.length > 3 && (
                        <Text type="secondary" style={{ fontSize: 12 }}>
                            +{roles.length - 3} more
                        </Text>
                    )}
                </Space>
            ),
        },
        {
            title: "Status",
            dataIndex: "status",
            key: "status",
            width: 110,
            render: (status: string) => getStatusTag(status),
        },
        {
            title: "Actions",
            key: "actions",
            width: 150,
            render: (_: unknown, record: RoleBasedSigningModule) => (
                <Space size="small">
                    <Tooltip title="View Module">
                        <Button
                            type="text"
                            icon={<EyeOutlined />}
                            onClick={() => handleView(record)}
                        />
                    </Tooltip>
                    <Tooltip title="Edit Module">
                        <Button
                            type="text"
                            icon={<EditOutlined />}
                            onClick={() => handleEdit(record)}
                        />
                    </Tooltip>
                    <Tooltip title="Delete Module">
                        <Button
                            type="text"
                            danger
                            icon={<DeleteOutlined />}
                            onClick={() => handleDelete(record)}
                        />
                    </Tooltip>
                </Space>
            ),
        },
    ];

    const expandedRowRender = (record: RoleBasedSigningModule) => {
        return (
            <div style={{ padding: "12px 8px" }}>
                <Text strong style={{ marginBottom: 8, display: "block" }}>
                    Role Based Signing Sequence
                </Text>
                <Table
                    dataSource={record.roles}
                    rowKey="sequence"
                    pagination={false}
                    showHeader={false}
                    columns={[
                        {
                            dataIndex: "sequence",
                            key: "sequence",
                            width: 60,
                            render: (seq: number) => (
                                <Tag color="blue" style={{ fontWeight: 600 }}>#{seq}</Tag>
                            ),
                        },
                        {
                            dataIndex: "userRole",
                            key: "userRole",
                            width: 200,
                            render: (role: string) => (
                                <Space>
                                    <UserOutlined style={{ color: "#722ed1" }} />
                                    <Text strong>{role}</Text>
                                </Space>
                            ),
                        },
                        {
                            dataIndex: "levelOfAuthorization",
                            key: "levelOfAuthorization",
                            render: (level: string) => (
                                <Tag color="geekblue" style={{ fontWeight: 500 }}>{level}</Tag>
                            ),
                        },
                    ]}
                    size="small"
                />
            </div>
        );
    };

    return (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {/* Header */}
            <Card styles={{ body: { padding: 20 } }} style={{ border: "1px solid #fff7e6" }}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 16, flexWrap: "wrap", alignItems: "center" }}>
                    <Space align="center">
                        <Avatar
                            size={52}
                            shape="square"
                            icon={<UserOutlined />}
                            style={{ background: "#722ed1" }}
                        />
                        <div>
                            <Title level={2} style={{ margin: 0 }}>
                                Role Based Signing
                            </Title>
                            <Text type="secondary">
                                Manage role-wise signing hierarchy and approval sequence
                            </Text>
                        </div>
                    </Space>
                    <Space wrap>
                        <Button icon={<ReloadOutlined />} onClick={fetchModules}>
                            Refresh
                        </Button>
                        <Button type="primary" icon={<PlusOutlined />} onClick={() => setAddModalOpen(true)}>
                            Add New Module
                        </Button>
                    </Space>
                </div>
            </Card>

            {/* Stats */}
            <Row gutter={[16, 16]}>
                <Col xs={24} sm={12} lg={6}>
                    <Card hoverable styles={{ body: { padding: 18 } }}>
                        <Statistic
                            title="Total Modules"
                            value={totalModules}
                            prefix={<BlockOutlined style={{ color: "#722ed1" }} />}
                            valueStyle={{ color: "#722ed1" }}
                        />
                    </Card>
                </Col>
                <Col xs={24} sm={12} lg={6}>
                    <Card hoverable styles={{ body: { padding: 18 } }}>
                        <Statistic
                            title="Role Entries"
                            value={totalRoles}
                            prefix={<TeamOutlined style={{ color: "#52c41a" }} />}
                            valueStyle={{ color: "#52c41a" }}
                        />
                    </Card>
                </Col>
                <Col xs={24} sm={12} lg={6}>
                    <Card hoverable styles={{ body: { padding: 18 } }}>
                        <Statistic
                            title="Active Modules"
                            value={activeModules}
                            prefix={<CheckCircleOutlined style={{ color: "#52c41a" }} />}
                            valueStyle={{ color: "#52c41a" }}
                            suffix={
                                <Text type="secondary" style={{ fontSize: 14 }}>/ {totalModules}</Text>
                            }
                        />
                    </Card>
                </Col>
                <Col xs={24} sm={12} lg={6}>
                    <Card hoverable styles={{ body: { padding: 18 } }}>
                        <Statistic
                            title="Inactive Modules"
                            value={inactiveModules}
                            prefix={<CloseCircleOutlined style={{ color: "#ff4d4f" }} />}
                            valueStyle={{ color: "#ff4d4f" }}
                            suffix={
                                <Text type="secondary" style={{ fontSize: 14 }}>/ {totalModules}</Text>
                            }
                        />
                    </Card>
                </Col>
            </Row>

            {/* Filters */}
            <Card>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 16, flexWrap: "wrap", alignItems: "center" }}>
                    <Space wrap>
                        <Input
                            placeholder="Search by module name..."
                            prefix={<SearchOutlined />}
                            style={{ width: 280 }}
                            onChange={(e) => setSearchText(e.target.value)}
                            allowClear
                        />
                        <Select
                            placeholder="Filter by status"
                            style={{ width: 160 }}
                            onChange={(value) => setStatusFilter(value)}
                            defaultValue="all"
                            allowClear
                        >
                            <Option value="all">All Status</Option>
                            <Option value="active">Active</Option>
                            <Option value="inactive">Inactive</Option>
                        </Select>
                    </Space>
                    <Text strong>
                        Showing {filteredModules.length} of {totalModules} modules
                    </Text>
                </div>
            </Card>

            {/* Table */}
            <Card styles={{ body: { padding: 0 } }}>
                <Table
                    columns={columns}
                    dataSource={filteredModules}
                    rowKey="key"
                    loading={loading}
                    expandable={{
                        expandedRowRender,
                        rowExpandable: (record) => record.roles.length > 0,
                    }}
                    pagination={{
                        pageSize: 10,
                        showSizeChanger: true,
                        showQuickJumper: true,
                        showTotal: (total, range) =>
                            `Showing ${range[0]}-${range[1]} of ${total} modules`,
                        pageSizeOptions: ["5", "10", "20", "50"],
                    }}
                    scroll={{ x: 900 }}
                />
            </Card>

            <AddRoleBasedModal
                open={addModalOpen}
                onCancel={() => setAddModalOpen(false)}
                onSuccess={fetchModules}
            />
            <EditRoleBasedModal
                open={editModalOpen}
                module={selectedModule}
                onCancel={() => { setEditModalOpen(false); setSelectedModule(null); }}
                onSuccess={fetchModules}
            />
            <DeleteRoleBasedModal
                open={deleteModalVisible}
                moduleToDelete={moduleToDelete}
                onCancel={() => { setDeleteModalVisible(false); setModuleToDelete(null); }}
                onSuccess={fetchModules}
            />
            <ViewRoleBasedModal
                open={viewModalOpen}
                module={moduleToView}
                onCancel={() => { setViewModalOpen(false); setModuleToView(null); }}
            />
        </div>
    );
}