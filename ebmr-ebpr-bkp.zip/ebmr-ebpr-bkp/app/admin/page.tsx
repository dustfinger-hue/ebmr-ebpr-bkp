"use client";

import { Card, Typography, Row, Col, Statistic, Progress, Button, Space } from "antd";
import {
  UserOutlined,
  MedicineBoxOutlined,
  FileTextOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined,
  ExclamationCircleOutlined,
} from "@ant-design/icons";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

const { Title, Text } = Typography;

interface DashboardStats {
  totalUsers: number;
  activeUsers: number;
  totalQCRecords: number;
  pendingReviews: number;
  complianceRate: number;
}

export default function AdminPage() {
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    activeUsers: 0,
    totalQCRecords: 0,
    pendingReviews: 0,
    complianceRate: 0,
  });
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    // Fetch dashboard statistics
    const fetchStats = async () => {
      try {
        setLoading(true);
        // This would typically fetch from your API
        // For now, using mock data
        setStats({
          totalUsers: 24,
          activeUsers: 18,
          totalQCRecords: 156,
          pendingReviews: 12,
          complianceRate: 94.5,
        });
      } catch (error) {
        console.error("Error fetching stats:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  // const quickActions = [
  //   {
  //     title: "Add New User",
  //     icon: <UserOutlined />,
  //     color: "#1890ff",
  //     onClick: () => router.push("/admin/add-user"),
  //   },
  //   {
  //     title: "Manage Users",
  //     icon: <UserOutlined />,
  //     color: "#52c41a",
  //     onClick: () => router.push("/admin/users"),
  //   },
  //   {
  //     title: "Quality Control",
  //     icon: <MedicineBoxOutlined />,
  //     color: "#722ed1",
  //     onClick: () => router.push("/admin/qc"),
  //   },
  //   {
  //     title: "Reports",
  //     icon: <FileTextOutlined />,
  //     color: "#fa8c16",
  //     onClick: () => router.push("/admin/reports"),
  //   },
  // ];

  const recentActivities = [
    { action: "User created", details: "New user 'ahmed.khan' added", time: "2 min ago" },
    { action: "QC Review", details: "Batch #BPR-2024-001 approved", time: "15 min ago" },
    { action: "System update", details: "Database backup completed", time: "1 hour ago" },
    { action: "Compliance check", details: "Monthly audit scheduled", time: "3 hours ago" },
  ];

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <Title level={2} style={{ margin: 0, color: "#1890ff" }}>
          Admin Dashboard
        </Title>
        <Text type="secondary">
          Welcome to the EBMR & BPR Quality Control System
        </Text>
      </div>

      {/* Statistics Cards */}
      <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
        <Col xs={24} sm={12} md={6}>
          <Card loading={loading}>
            <Statistic
              title="Total Users"
              value={stats.totalUsers}
              prefix={<UserOutlined />}
              valueStyle={{ color: "#1890ff" }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card loading={loading}>
            <Statistic
              title="Active Users"
              value={stats.activeUsers}
              prefix={<UserOutlined />}
              valueStyle={{ color: "#52c41a" }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card loading={loading}>
            <Statistic
              title="QC Records"
              value={stats.totalQCRecords}
              prefix={<MedicineBoxOutlined />}
              valueStyle={{ color: "#722ed1" }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6}>
          <Card loading={loading}>
            <Statistic
              title="Pending Reviews"
              value={stats.pendingReviews}
              prefix={<ClockCircleOutlined />}
              valueStyle={{ color: "#fa8c16" }}
            />
          </Card>
        </Col>
      </Row>

      {/* Compliance Rate */}
      <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
        <Col xs={24} md={16}>
          <Card title="Compliance Rate" loading={loading}>
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <Progress
                type="dashboard"
                percent={stats.complianceRate}
                format={(percent) => `${percent}%`}
                strokeColor="#52c41a"
                trailColor="#f0f0f0"
                size={120}
              />
              <div>
                <Title level={4} style={{ margin: 0 }}>{stats.complianceRate}%</Title>
                <Text type="secondary">Overall system compliance</Text>
                <div style={{ marginTop: 8 }}>
                  <Space>
                    <CheckCircleOutlined style={{ color: "#52c41a" }} />
                    <Text>Within acceptable limits</Text>
                  </Space>
                </div>
              </div>
            </div>
          </Card>
        </Col>
        {/* <Col xs={24} md={8}>
          <Card title="Quick Actions" loading={loading}>
            <Space direction="vertical" size="middle" style={{ width: "100%" }}>
              {quickActions.map((action, index) => (
                <Button
                  key={index}
                  type="primary"
                  icon={action.icon}
                  onClick={action.onClick}
                  style={{
                    width: "100%",
                    justifyContent: "flex-start",
                    backgroundColor: action.color,
                    border: "none",
                  }}
                >
                  {action.title}
                </Button>
              ))}
            </Space>
          </Card>
        </Col> */}
      </Row>

      {/* Recent Activities */}
      <Row>
        <Col xs={24}>
          <Card title="Recent Activities" loading={loading}>
            {recentActivities.map((activity, index) => (
              <div key={index} style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "12px 0",
                borderBottom: index < recentActivities.length - 1 ? "1px solid #f0f0f0" : "none",
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <ExclamationCircleOutlined style={{ color: "#1890ff" }} />
                  <div>
                    <div style={{ fontWeight: 500 }}>{activity.action}</div>
                    <div style={{ fontSize: 12, color: "#666" }}>{activity.details}</div>
                  </div>
                </div>
                <Text type="secondary" style={{ fontSize: 12 }}>{activity.time}</Text>
              </div>
            ))}
          </Card>
        </Col>
      </Row>
    </div>
  );
}