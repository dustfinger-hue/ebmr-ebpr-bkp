"use client";

import {
  Card,
  Typography,
  Button,
  Table,
  Tag,
  message,
  Spin,
  Row,
  Col,
  Space,
  Modal,
  Popconfirm,
} from "antd";
import {
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  EyeOutlined,
  ClockCircleOutlined,
  ReloadOutlined,
} from "@ant-design/icons";
import { useEffect, useState } from "react";
import { useTheme } from "@/lib/utils/ThemeContext";
import AddShiftModal from "./components/AddShiftModal";
import EditShiftModal from "./components/EditShiftModal";
import ViewShiftModal from "./components/ViewShiftModal";

const { Title, Text } = Typography;

interface ShiftConfigData {
  _id: string;
  name: string;
  numberOfShifts: number;
  hoursPerShift: number;
  shiftNames: string[];
  startTime: string;
  lastModifiedBy?: string;
  createdAt?: string;
  updatedAt?: string;
}

export default function ShiftManagementPage() {
  const [configs, setConfigs] = useState<ShiftConfigData[]>([]);
  const [loading, setLoading] = useState(true);
  const { theme } = useTheme();
  const isDark = theme === "dark";

  // Modal states
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [viewModalOpen, setViewModalOpen] = useState(false);
  const [selectedConfig, setSelectedConfig] = useState<ShiftConfigData | null>(null);

  const fetchConfigs = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem("token");
      const res = await fetch("/api/admin/shifts", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.success) {
        setConfigs(data.configs || []);
      } else {
        message.error(data.message || "Failed to load");
      }
    } catch {
      message.error("Failed to load shift configurations");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchConfigs();
  }, []);

  const handleDelete = async (id: string) => {
    try {
      const token = localStorage.getItem("token");
      const res = await fetch(`/api/admin/shifts?id=${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.success) {
        message.success("Shift configuration deleted");
        fetchConfigs();
      } else {
        message.error(data.message || "Failed to delete");
      }
    } catch {
      message.error("Failed to delete shift configuration");
    }
  };

  const handleEdit = (config: ShiftConfigData) => {
    setSelectedConfig(config);
    setEditModalOpen(true);
  };

  const handleView = (config: ShiftConfigData) => {
    setSelectedConfig(config);
    setViewModalOpen(true);
  };

  const columns = [
    {
      title: "Name",
      dataIndex: "name",
      key: "name",
      render: (name: string, record: ShiftConfigData) => (
        <div>
          <Text strong style={{ fontSize: 14 }}>{name}</Text>
          <div style={{ fontSize: 11, color: isDark ? "#a6a6a6" : "#999", marginTop: 2 }}>
            {record.numberOfShifts} shifts × {record.hoursPerShift}h
            {record.startTime && ` · Starts ${record.startTime}`}
          </div>
        </div>
      ),
    },
    {
      title: "Shifts",
      dataIndex: "numberOfShifts",
      key: "numberOfShifts",
      width: 80,
      align: "center" as const,
      render: (val: number) => <Tag color="blue">{val}</Tag>,
    },
    {
      title: "Hours/Shift",
      dataIndex: "hoursPerShift",
      key: "hoursPerShift",
      width: 100,
      align: "center" as const,
      render: (val: number) => <Tag>{val}h</Tag>,
    },
    {
      title: "Total Hours",
      key: "totalHours",
      width: 100,
      align: "center" as const,
      render: (_: any, record: ShiftConfigData) => {
        const total = record.numberOfShifts * record.hoursPerShift;
        const isValid = total <= 24;
        return (
          <Tag color={isValid ? "green" : "red"}>
            {total}h / 24h
          </Tag>
        );
      },
    },
    {
      title: "Shift Names",
      dataIndex: "shiftNames",
      key: "shiftNames",
      render: (names: string[]) => (
        <Space size={4} wrap>
          {names?.map((name, i) => (
            <Tag key={i} color={["#1890ff", "#52c41a", "#fa8c16", "#722ed1"][i % 4]}>
              {name}
            </Tag>
          ))}
        </Space>
      ),
    },
    {
      title: "Modified",
      dataIndex: "updatedAt",
      key: "updatedAt",
      width: 140,
      render: (date: string) =>
        date ? new Date(date).toLocaleDateString() : "N/A",
    },
    {
      title: "Actions",
      key: "actions",
      width: 140,
      render: (_: any, record: ShiftConfigData) => (
        <Space>
          <Button
            type="text"
            icon={<EyeOutlined />}
            onClick={() => handleView(record)}
            title="View"
          />
          <Button
            type="text"
            icon={<EditOutlined />}
            onClick={() => handleEdit(record)}
            title="Edit"
          />
          <Popconfirm
            title="Delete this shift configuration?"
            description="This action cannot be undone."
            onConfirm={() => handleDelete(record._id)}
            okText="Delete"
            cancelText="Cancel"
            okButtonProps={{ danger: true }}
          >
            <Button type="text" danger icon={<DeleteOutlined />} title="Delete" />
          </Popconfirm>
        </Space>
      ),
    },
  ];

  // Add the key property for the table
  const dataSource = configs.map((c) => ({ ...c, key: c._id }));

  return (
    <div>
      {/* Header */}
      <div
        style={{
          marginBottom: 24,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <div>
          <Title level={2} style={{ margin: 0, color: "#1890ff" }}>
            <ClockCircleOutlined style={{ marginRight: 12 }} />
            Shift Management
          </Title>
          <Text type="secondary">
            Manage multiple shift configurations for 24-hour operations
          </Text>
        </div>
        <Space>
          <Button icon={<ReloadOutlined />} onClick={fetchConfigs}>
            Refresh
          </Button>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => setAddModalOpen(true)}
          >
            Add Shift
          </Button>
        </Space>
      </div>

      {/* Main Table */}
      <Card>
        <Table
          dataSource={dataSource}
          columns={columns}
          loading={loading}
          pagination={{ pageSize: 10 }}
          size="middle"
          bordered
          locale={{ emptyText: "No shift configurations yet. Click 'Add Shift' to create one." }}
        />
      </Card>

      {/* Modals */}
      <AddShiftModal
        open={addModalOpen}
        onCancel={() => setAddModalOpen(false)}
        onSuccess={fetchConfigs}
      />
      <EditShiftModal
        open={editModalOpen}
        config={selectedConfig}
        onCancel={() => {
          setEditModalOpen(false);
          setSelectedConfig(null);
        }}
        onSuccess={fetchConfigs}
      />
      <ViewShiftModal
        open={viewModalOpen}
        config={selectedConfig}
        onCancel={() => {
          setViewModalOpen(false);
          setSelectedConfig(null);
        }}
      />
    </div>
  );
}