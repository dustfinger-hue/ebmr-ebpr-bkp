"use client";

import {
  Modal,
  Form,
  Input,
  InputNumber,
  Select,
  TimePicker,
  Row,
  Col,
  message,
  Typography,
  Tag,
  Alert,
} from "antd";
import { useState, useEffect } from "react";
import dayjs from "dayjs";
import customParseFormat from "dayjs/plugin/customParseFormat";
import { useTheme } from "@/lib/utils/ThemeContext";
import { SHIFT_PRESET_NAMES } from "@/lib/constants/Generarl";

dayjs.extend(customParseFormat);

const { Text } = Typography;
const DEFAULT_NAMES = SHIFT_PRESET_NAMES.map(s => s.value);

interface ShiftConfigData {
  _id: string;
  name: string;
  numberOfShifts: number;
  hoursPerShift: number;
  shiftNames: string[];
  startTime: string;
}

interface EditShiftModalProps {
  open: boolean;
  config: ShiftConfigData | null;
  onCancel: () => void;
  onSuccess: () => void;
}

export default function EditShiftModal({
  open,
  config,
  onCancel,
  onSuccess,
}: EditShiftModalProps) {
  const [form] = Form.useForm();
  const [submitting, setSubmitting] = useState(false);
  const { theme } = useTheme();
  const isDark = theme === "dark";

  useEffect(() => {
    if (!open || !config) return;
    form.setFieldsValue({
      name: config.name,
      numberOfShifts: config.numberOfShifts,
      hoursPerShift: config.hoursPerShift,
      shiftNames: config.shiftNames,
      startTime: config.startTime
        ? dayjs(config.startTime, "HH:mm")
        : dayjs("06:00", "HH:mm"),
    });
  }, [open, config, form]);

  const numberOfShifts = Form.useWatch("numberOfShifts", form) || 3;
  const hoursPerShift = Form.useWatch("hoursPerShift", form) || 8;
  const totalHours = numberOfShifts * hoursPerShift;
  const isValid = totalHours <= 24;

  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      if (totalHours > 24) {
        message.error(`Total hours (${totalHours}) exceeds 24.`);
        return;
      }

      setSubmitting(true);
      const shiftNames: string[] = [];
      for (let i = 0; i < values.numberOfShifts; i++) {
        shiftNames.push(values.shiftNames?.[i] || DEFAULT_NAMES[i]);
      }

      const res = await fetch("/api/admin/shifts", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: JSON.stringify({
          id: config?._id,
          name: values.name,
          numberOfShifts: values.numberOfShifts,
          hoursPerShift: values.hoursPerShift,
          shiftNames,
          startTime: values.startTime.format("HH:mm"),
        }),
      });

      const data = await res.json();
      if (data.success) {
        message.success("Shift configuration updated successfully!");
        onCancel();
        onSuccess();
      } else {
        message.error(data.message || "Failed to update");
      }
    } catch {
      // validation failed
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      title="Edit Shift Configuration"
      open={open}
      onCancel={onCancel}
      onOk={handleSubmit}
      okText="Update Shift"
      confirmLoading={submitting}
      okButtonProps={{ disabled: !isValid }}
      width={600}
    >
      <Form
        form={form}
        layout="vertical"
      >
        <Form.Item
          name="name"
          label="Configuration Name"
          rules={[{ required: true, message: "Please enter a name" }]}
        >
          <Input placeholder="e.g., Default Shifts, Summer Schedule" />
        </Form.Item>

        <Row gutter={16}>
          <Col span={12}>
            <Form.Item
              name="numberOfShifts"
              label="Number of Shifts"
              rules={[{ required: true, message: "Required" }]}
            >
              <InputNumber min={1} max={4} style={{ width: "100%" }} />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name="hoursPerShift"
              label="Hours per Shift"
              rules={[{ required: true, message: "Required" }]}
            >
              <InputNumber min={1} max={24} style={{ width: "100%" }} />
            </Form.Item>
          </Col>
        </Row>

        <Form.Item
          name="startTime"
          label="First Shift Start Time"
          rules={[{ required: true, message: "Required" }]}
        >
          <TimePicker format="HH:mm" style={{ width: "100%" }} minuteStep={30} />
        </Form.Item>

        {Array.from({ length: numberOfShifts }, (_, i) => (
          <Form.Item
            key={i}
            name={["shiftNames", i]}
            label={`Shift ${i + 1} Name`}
            rules={[{ required: true, message: "Required" }]}
          >
            <Select
              placeholder="Select shift name"
              options={SHIFT_PRESET_NAMES}
              showSearch
              optionFilterProp="label"
            />
          </Form.Item>
        ))}

        <div
          style={{
            padding: "12px 16px",
            background: isValid ? (isDark ? "#162312" : "#f6ffed") : (isDark ? "#2a1215" : "#fff2f0"),
            borderRadius: 8,
            border: `1px solid ${isValid ? (isDark ? "#274916" : "#b7eb8f") : (isDark ? "#58181c" : "#ffccc7")}`,
          }}
        >
          <Row align="middle" justify="space-between">
            <Col>
              <Text
                strong
                style={{
                  color: isDark
                    ? isValid
                      ? "#b7eb8f"
                      : "#ffa39e"
                    : undefined,
                }}
              >
                Total: {numberOfShifts} × {hoursPerShift}h = {totalHours}h
              </Text>
            </Col>
            <Col>
              {isValid ? (
                <Tag color="green">Within 24h ✓</Tag>
              ) : (
                <Tag color="red">Exceeds 24h ✗</Tag>
              )}
            </Col>
          </Row>
          {!isValid && (
            <Alert
              type="error"
              showIcon
              message={`Total (${totalHours}) exceeds 24. Adjust shifts/hours.`}
              style={{ marginTop: 8, padding: "4px 12px", background: "transparent", border: "none" }}
            />
          )}
        </div>
      </Form>
    </Modal>
  );
}