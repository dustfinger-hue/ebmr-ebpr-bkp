"use client";

import {
  Modal,
  Typography,
  Tag,
  Table,
  Row,
  Col,
  Card,
  Statistic,
  Divider,
  Descriptions,
  Empty,
} from "antd";
import { useMemo } from "react";
import { ClockCircleOutlined } from "@ant-design/icons";

const { Title, Text } = Typography;

const DEFAULT_NAMES = ["Morning", "Afternoon", "Evening", "Night"];
const TIMELINE_COLORS = ["#1890ff", "#52c41a", "#fa8c16", "#722ed1"];

interface ShiftConfigData {
  _id: string;
  name: string;
  numberOfShifts: number;
  hoursPerShift: number;
  shiftNames: string[];
  startTime: string;
  createdAt?: string;
  updatedAt?: string;
  lastModifiedBy?: string;
}

interface ViewShiftModalProps {
  open: boolean;
  config: ShiftConfigData | null;
  onCancel: () => void;
}

function timeToMinutes(time: string): number {
  const [h, m] = time.split(":").map(Number);
  return h * 60 + m;
}

function minutesToTime(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

export default function ViewShiftModal({
  open,
  config,
  onCancel,
}: ViewShiftModalProps) {
  const shiftRows = useMemo(() => {
    if (!config) return [];
    const { numberOfShifts, hoursPerShift, shiftNames, startTime } = config;
    const rows: {
      key: number;
      name: string;
      startTime: string;
      endTime: string;
      duration: string;
    }[] = [];
    const startMinutes = timeToMinutes(startTime || "06:00");

    for (let i = 0; i < numberOfShifts; i++) {
      const shiftStart = (startMinutes + i * hoursPerShift * 60) % 1440;
      const shiftEnd = (shiftStart + hoursPerShift * 60) % 1440;
      const name = shiftNames?.[i] || DEFAULT_NAMES[i] || `Shift ${i + 1}`;

      rows.push({
        key: i,
        name,
        startTime: minutesToTime(shiftStart),
        endTime: minutesToTime(shiftEnd),
        duration: `${hoursPerShift} hours`,
      });
    }

    return rows;
  }, [config]);

  const totalHours =
    config
      ? config.numberOfShifts * config.hoursPerShift
      : 0;

  return (
    <Modal
      title="Shift Configuration Details"
      open={open}
      onCancel={onCancel}
      footer={null}
      width={700}
    >
      {!config ? (
        <Empty description="No shift configuration selected" />
      ) : (
        <>
          <Title level={4} style={{ marginBottom: 4 }}>
            {config.name}
          </Title>
          <Text type="secondary">
            Created:{" "}
            {config.createdAt
              ? new Date(config.createdAt).toLocaleString()
              : "N/A"}
          </Text>

          <Divider />

          {/* Stats */}
          <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
            <Col span={6}>
              <Card size="small">
                <Statistic
                  title="Shifts"
                  value={config.numberOfShifts}
                  suffix={`× ${config.hoursPerShift}h`}
                />
              </Card>
            </Col>
            <Col span={6}>
              <Card size="small">
                <Statistic
                  title="Total Hours"
                  value={totalHours}
                  suffix="/ 24"
                  valueStyle={{
                    color: totalHours <= 24 ? "#52c41a" : "#ff4d4f",
                  }}
                />
              </Card>
            </Col>
            <Col span={6}>
              <Card size="small">
                <Statistic
                  title="Start Time"
                  value={config.startTime || "06:00"}
                />
              </Card>
            </Col>
            <Col span={6}>
              <Card size="small">
                <Statistic
                  title="Modified By"
                  value={config.lastModifiedBy || "Admin"}
                />
              </Card>
            </Col>
          </Row>

          {/* Timeline Visual */}
          {shiftRows.length > 0 && (
            <div style={{ marginBottom: 24 }}>
              <Text strong style={{ display: "block", marginBottom: 8 }}>
                24-Hour Timeline
              </Text>
              <div
                style={{
                  position: "relative",
                  width: "100%",
                  height: "48px",
                  borderRadius: "8px",
                  overflow: "hidden",
                  border: "1px solid #e8e8e8",
                }}
              >
                {shiftRows.flatMap((shift, index) => {
                  const startMin = timeToMinutes(shift.startTime);
                  const endMin = timeToMinutes(shift.endTime);
                  const colorIndex = index % TIMELINE_COLORS.length;
                  const color = TIMELINE_COLORS[colorIndex];
                  const midnight = 1440;

                  let segments: {
                    left: number;
                    width: number;
                    label: string;
                  }[];

                  if (endMin > startMin) {
                    segments = [
                      {
                        left: (startMin / midnight) * 100,
                        width: ((endMin - startMin) / midnight) * 100,
                        label: `${shift.name}`,
                      },
                    ];
                  } else {
                    segments = [
                      {
                        left: (startMin / midnight) * 100,
                        width: ((midnight - startMin) / midnight) * 100,
                        label: `${shift.name} cont.`,
                      },
                      {
                        left: 0,
                        width: (endMin / midnight) * 100,
                        label: `${shift.name}`,
                      },
                    ];
                  }

                  return segments.map((seg, segIndex) => (
                    <div
                      key={`${shift.key}-${segIndex}`}
                      style={{
                        position: "absolute",
                        left: `${seg.left}%`,
                        width: `${seg.width}%`,
                        height: "100%",
                        backgroundColor: color,
                        opacity: 0.85,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                      title={`${shift.name}: ${shift.startTime} - ${shift.endTime}`}
                    >
                      <Text
                        style={{
                          color: "#fff",
                          fontSize: 11,
                          fontWeight: 600,
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          padding: "0 4px",
                        }}
                      >
                        {seg.label}
                      </Text>
                    </div>
                  ));
                })}
              </div>
              {/* Time labels */}
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  marginTop: 4,
                }}
              >
                <Text type="secondary" style={{ fontSize: 11 }}>
                  00:00
                </Text>
                <Text type="secondary" style={{ fontSize: 11 }}>
                  06:00
                </Text>
                <Text type="secondary" style={{ fontSize: 11 }}>
                  12:00
                </Text>
                <Text type="secondary" style={{ fontSize: 11 }}>
                  18:00
                </Text>
                <Text type="secondary" style={{ fontSize: 11 }}>
                  24:00
                </Text>
              </div>
            </div>
          )}

          <Divider />

          {/* Shift Table */}
          <Table
            dataSource={shiftRows}
            columns={[
              {
                title: "Shift",
                dataIndex: "name",
                key: "name",
                render: (name: string, _: any) => (
                  <Tag
                    color={
                      TIMELINE_COLORS[_.key % TIMELINE_COLORS.length]
                    }
                  >
                    {name}
                  </Tag>
                ),
              },
              {
                title: "Start Time",
                dataIndex: "startTime",
                key: "startTime",
              },
              {
                title: "End Time",
                dataIndex: "endTime",
                key: "endTime",
              },
              {
                title: "Duration",
                dataIndex: "duration",
                key: "duration",
              },
            ]}
            pagination={false}
            size="small"
            bordered
          />

          <Divider />

          <Descriptions bordered size="small" column={{ xs: 1, sm: 2 }}>
            <Descriptions.Item label="Configuration Name">
              {config.name}
            </Descriptions.Item>
            <Descriptions.Item label="Number of Shifts">
              {config.numberOfShifts}
            </Descriptions.Item>
            <Descriptions.Item label="Hours per Shift">
              {config.hoursPerShift}
            </Descriptions.Item>
            <Descriptions.Item label="Total Hours">
              {totalHours}h / 24h
            </Descriptions.Item>
            <Descriptions.Item label="Start Time">
              {config.startTime || "06:00"}
            </Descriptions.Item>
            <Descriptions.Item label="Last Modified By">
              {config.lastModifiedBy || "Admin"}
            </Descriptions.Item>
            <Descriptions.Item label="Created">
              {config.createdAt
                ? new Date(config.createdAt).toLocaleString()
                : "N/A"}
            </Descriptions.Item>
            <Descriptions.Item label="Last Updated">
              {config.updatedAt
                ? new Date(config.updatedAt).toLocaleString()
                : "N/A"}
            </Descriptions.Item>
          </Descriptions>
        </>
      )}
    </Modal>
  );
}