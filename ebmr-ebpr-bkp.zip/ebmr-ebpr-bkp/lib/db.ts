import mongoose from 'mongoose';

const MONGODB_URI = process.env.MONGODB_URI || 

// 'mongodb://abdulcodeat29:Alohomora1234@ac-zbmipfn-shard-00-00.g7gbhd9.mongodb.net:27017,ac-zbmipfn-shard-00-01.g7gbhd9.mongodb.net:27017,ac-zbmipfn-shard-00-02.g7gbhd9.mongodb.net:27017/ebmpr?ssl=true&replicaSet=atlas-5kxa1d-shard-0&authSource=admin&appName=bmr-bpr'

'mongodb+srv://abdulcodeat29:Alohomora1234@bmr-bpr.g7gbhd9.mongodb.net/ebmpr?retryWrites=true&w=majority&appName=bmr-bpr';

if (!MONGODB_URI) {
  throw new Error('Please define the MONGODB_URI environment variable inside .env.local');
}

interface MongooseGlobal {
  conn: typeof mongoose | null;
  promise: Promise<typeof mongoose> | null;
}

const globalWithMongoose = global as typeof global & {
  mongoose: MongooseGlobal;
};

let cached = globalWithMongoose.mongoose;

if (!cached) {
  cached = globalWithMongoose.mongoose = { conn: null, promise: null };
}

async function connectToDatabase() {
  if (cached.conn) {
    return cached.conn;
  }

  if (!cached.promise) {
    const opts = {
      bufferCommands: false,

      // ✅ YE ADD KARO
      serverSelectionTimeoutMS: 30000, // 30 sec
      socketTimeoutMS: 45000,
    };

    cached.promise = mongoose.connect(MONGODB_URI, opts).then((mongoose) => {
      console.log("Connected DB:", mongoose.connection.name);
      return mongoose;
    });
  }

  try {
    cached.conn = await cached.promise;
  } catch (e) {
    cached.promise = null;
    console.error('❌ MongoDB connection error:', e);
    throw e;
  }

  return cached.conn;
}

export default connectToDatabase;
