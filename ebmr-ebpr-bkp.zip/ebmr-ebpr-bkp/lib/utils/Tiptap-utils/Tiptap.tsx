'use client'
import { useEditor, EditorContent, Editor, useEditorState } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import Placeholder from '@tiptap/extension-placeholder'
import Highlight from '@tiptap/extension-highlight'
import { Button } from 'antd'
import { 
  BoldOutlined, 
  CodeOutlined, 
  ItalicOutlined, 
  OrderedListOutlined, 
  StrikethroughOutlined, 
  UnorderedListOutlined,
  FontSizeOutlined,
  LineOutlined,
  HighlightOutlined
} from "@ant-design/icons";
import { BiParagraph } from 'react-icons/bi';
import { GrBlockQuote } from 'react-icons/gr';
import './TiptapEditor.css';

interface TiptapProps {
  value?: string;
  onChange?: (value: string) => void;
  placeholder?: string;
}

const Tiptap = ({ value, onChange, placeholder = 'Start typing...' }: TiptapProps) => {
  const editor = useEditor({
    extensions: [
      StarterKit,
      Placeholder.configure({
        placeholder: placeholder,
      }),
      Highlight,
    ],
    content: value || '',
    immediatelyRender: false,
    onUpdate: ({ editor }) => {
      onChange?.(editor.getHTML());
    },
  })

  return (
    <div className="tiptap-editor">
      {editor && <Toolbar editor={editor} />}
      <EditorContent editor={editor} className="tiptap-content" />
    </div>
  )
}

export default Tiptap

const Toolbar = ({ editor }: { editor: Editor }) => {
  const editorState = useEditorState({
    editor,
    selector: (ctx) => {
      return {
        isBold: ctx.editor.isActive('bold') ?? false,
        canBold: ctx.editor.can().chain().focus().toggleBold().run() ?? false,
        isItalic: ctx.editor.isActive('italic') ?? false,
        canItalic: ctx.editor.can().chain().focus().toggleItalic().run() ?? false,
        isStrike: ctx.editor.isActive('strike') ?? false,
        canStrike: ctx.editor.can().chain().focus().toggleStrike().run() ?? false,
        isCode: ctx.editor.isActive('code') ?? false,
        canCode: ctx.editor.can().chain().focus().toggleCode().run() ?? false,
        isBlockquote: ctx.editor.isActive('blockquote') ?? false,
        canBlockquote: ctx.editor.can().chain().focus().toggleBlockquote().run() ?? false,
        isBulletList: ctx.editor.isActive('bulletList') ?? false,
        canBulletList: ctx.editor.can().chain().focus().toggleBulletList().run() ?? false,
        isParagraph: ctx.editor.isActive('paragraph') ?? false,
        canParagraph: ctx.editor.can().chain().focus().setParagraph().run() ?? false,
        isOrderedList: ctx.editor.isActive('orderedList') ?? false,
        canOrderedList: ctx.editor.can().chain().focus().toggleOrderedList().run() ?? false,
        isHeading: ctx.editor.isActive('heading') ?? false,
        canHeading: ctx.editor.can().chain().focus().toggleHeading({ level: 2 }).run() ?? false,
        isHr: ctx.editor.isActive('horizontalRule') ?? false,
        canHr: ctx.editor.can().chain().focus().setHorizontalRule().run() ?? false,
        isHighlight: ctx.editor.isActive('highlight') ?? false,
        canHighlight: ctx.editor.can().chain().focus().toggleHighlight().run() ?? false,
      }
    }
  })

  return (
    <div className="editor-toolbar">
      <div className="toolbar-group">
        {/* Text Formatting */}
        <Button
          onClick={() => editor.chain().focus().toggleBold().run()}
          disabled={!editorState.canBold}
          type={editorState.isBold ? 'primary' : 'default'}
          icon={<BoldOutlined />}
          title="Bold"
        />
        <Button
          onClick={() => editor.chain().focus().toggleItalic().run()}
          disabled={!editorState.canItalic}
          type={editorState.isItalic ? 'primary' : 'default'}
          icon={<ItalicOutlined />}
          title="Italic"
        />
        <Button
          onClick={() => editor.chain().focus().toggleStrike().run()}
          disabled={!editorState.canStrike}
          type={editorState.isStrike ? 'primary' : 'default'}
          icon={<StrikethroughOutlined />}
          title="Strikethrough"
        />
        <Button
          onClick={() => editor.chain().focus().toggleCode().run()}
          disabled={!editorState.canCode}
          type={editorState.isCode ? 'primary' : 'default'}
          icon={<CodeOutlined />}
          title="Inline Code"
        />
        <Button
          onClick={() => editor.chain().focus().toggleHighlight().run()}
          disabled={!editorState.canHighlight}
          type={editorState.isHighlight ? 'primary' : 'default'}
          icon={<HighlightOutlined />}
          title="Highlight"
        />
      </div>

      <div className="toolbar-group">
        {/* Headings & Paragraph */}
        <Button
          onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
          disabled={!editorState.canHeading}
          type={editorState.isHeading ? 'primary' : 'default'}
          icon={<FontSizeOutlined />}
          title="Heading"
        />
        <Button
          onClick={() => editor.chain().focus().setParagraph().run()}
          disabled={!editorState.canParagraph}
          type={editorState.isParagraph ? 'primary' : 'default'}
          icon={<BiParagraph />}
          title="Paragraph"
        />
        <Button
          onClick={() => editor.chain().focus().setHorizontalRule().run()}
          disabled={!editorState.canHr}
          type={editorState.isHr ? 'primary' : 'default'}
          icon={<LineOutlined />}
          title="Horizontal Line"
        />
      </div>

      <div className="toolbar-group">
        {/* Lists */}
        <Button
          onClick={() => editor.chain().focus().toggleBulletList().run()}
          disabled={!editorState.canBulletList}
          type={editorState.isBulletList ? 'primary' : 'default'}
          icon={<UnorderedListOutlined />}
          title="Bullet List"
        />
        <Button
          onClick={() => editor.chain().focus().toggleOrderedList().run()}
          disabled={!editorState.canOrderedList}
          type={editorState.isOrderedList ? 'primary' : 'default'}
          icon={<OrderedListOutlined />}
          title="Numbered List"
        />
      </div>

      <div className="toolbar-group">
        {/* Block Elements */}
        <Button
          onClick={() => editor.chain().focus().toggleBlockquote().run()}
          disabled={!editorState.canBlockquote}
          type={editorState.isBlockquote ? 'primary' : 'default'}
          icon={<GrBlockQuote />}
          title="Blockquote"
        />
      </div>
    </div>
  )
}
