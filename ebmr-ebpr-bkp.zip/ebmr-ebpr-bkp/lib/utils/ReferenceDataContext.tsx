'use client'

import { createContext, useContext, useState, ReactNode } from "react";

export interface TemplateRecord {
    _id: string;
    templateCode: string;
    templateName: string;
    productCode: string;
    productName: string;
    status: string;
    templateVersion: string;
    dosageForm: string;
}

interface ReferenceDataContextType {
    templates: TemplateRecord[];
    setTemplates: (templates: TemplateRecord[]) => void;
    selectedTemplate: TemplateRecord | null;
    setSelectedTemplate: (tpl: TemplateRecord | null) => void;
    fullTemplateData: any;
    setFullTemplateData: (data: any) => void;
    view: 'list' | 'detail';
    setView: (view: 'list' | 'detail') => void;
    searchText: string;
    setSearchText: (text: string) => void;
    isDetailLoaded: boolean;
    setIsDetailLoaded: (loaded: boolean) => void;
    resetReferenceData: () => void;
}

const ReferenceDataContext = createContext<ReferenceDataContextType>({
    templates: [],
    setTemplates: () => {},
    selectedTemplate: null,
    setSelectedTemplate: () => {},
    fullTemplateData: null,
    setFullTemplateData: () => {},
    view: 'list',
    setView: () => {},
    searchText: '',
    setSearchText: () => {},
    isDetailLoaded: false,
    setIsDetailLoaded: () => {},
    resetReferenceData: () => {},
});

export function ReferenceDataProvider({ children }: { children: ReactNode }) {
    const [templates, setTemplates] = useState<TemplateRecord[]>([]);
    const [selectedTemplate, setSelectedTemplate] = useState<TemplateRecord | null>(null);
    const [fullTemplateData, setFullTemplateData] = useState<any>(null);
    const [view, setView] = useState<'list' | 'detail'>('list');
    const [searchText, setSearchText] = useState('');
    const [isDetailLoaded, setIsDetailLoaded] = useState(false);

    const resetReferenceData = () => {
        setTemplates([]);
        setSelectedTemplate(null);
        setFullTemplateData(null);
        setView('list');
        setSearchText('');
        setIsDetailLoaded(false);
    };

    return (
        <ReferenceDataContext.Provider
            value={{
                templates,
                setTemplates,
                selectedTemplate,
                setSelectedTemplate,
                fullTemplateData,
                setFullTemplateData,
                view,
                setView,
                searchText,
                setSearchText,
                isDetailLoaded,
                setIsDetailLoaded,
                resetReferenceData,
            }}
        >
            {children}
        </ReferenceDataContext.Provider>
    );
}

export function useReferenceData() {
    const context = useContext(ReferenceDataContext);
    if (!context) {
        throw new Error('useReferenceData must be used within a ReferenceDataProvider');
    }
    return context;
}

export { ReferenceDataContext };