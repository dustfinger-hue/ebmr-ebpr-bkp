import { createContext } from "react";

interface DataContextType {
  templateData: any;
  setTemplateData: (data: any) => void;
}

export const DataContext = createContext<DataContextType>({
  templateData: null,
  setTemplateData: () => {}
});
