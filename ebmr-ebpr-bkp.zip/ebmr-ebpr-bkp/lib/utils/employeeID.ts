import Counter from "@/lib/models/CounterSchema"

export async function getNextEmployeeId() {
    const counter = await Counter.findOneAndUpdate(
        { name: "employeeId" },
        { $inc: { seq: 1 } },
        { upsert: true, new: true }
    )
     return `EMP-${String(counter.seq).padStart(4, "0")}`;
}