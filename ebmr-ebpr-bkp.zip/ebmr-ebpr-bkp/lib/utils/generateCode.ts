import {
  BatchCounter,
  BatchManufacturingTemplateCounter,
  EquipmentCounter,
  FacilityCounter,
  ManufacturingBOMCounter,
  MaterialCounter,
  PackagingBOMCounter,
  PharmaceuticalProductCounter,
  ProcessOrderCounter,
} from "../models/CounterSchema";

export async function generateMaterialCode(category: string) {
  const prefix = getPrefix(category);

  const counter = await MaterialCounter.findOneAndUpdate(
    { name: "Material Master", prefix },
    { $inc: { seq: 1 } },
    {
      new: true,
      upsert: true,
    },
  );

  const paddedNumber = String(counter.seq).padStart(6, "0");
  return `${prefix}-${paddedNumber}`;
}

export async function generatePharmaceuticalProductCode(prefix: string) {
  const productPrefix = getPrefix(prefix);
  const counter = await PharmaceuticalProductCounter.findOneAndUpdate(
    { name: "Product Master" },
    { $inc: { seq: 1 } },
    {
      new: true,
      upsert: true,
    },
  );

  const paddedNUmber = String(counter.seq).padStart(6, "0");
  return `${productPrefix}${paddedNUmber}`;
}

export async function generateEquipmentCode(prefix: string) {
  const equipmentPrefix = getPrefix(prefix);
  const counter = await EquipmentCounter.findOneAndUpdate(
    { name: "Equipment Master" },
    { $inc: { seq: 1 } },
    {
      new: true,
      upsert: true,
    },
  );

  const paddedNumber = String(counter.seq).padStart(6, "0");
  return `${equipmentPrefix}${paddedNumber}`;
}

export async function generateFacilityCode(prefix: string) {
  const facilityPrefix = getPrefix(prefix);
  const counter = await FacilityCounter.findOneAndUpdate(
    { name: "Facility Master" },
    { $inc: { seq: 1 } },
    {
      new: true,
      upsert: true,
    },
  );

  const paddedNumber = String(counter.seq).padStart(6, "0");
  return `${facilityPrefix}${paddedNumber}`;
}

export async function generateManufacturingBomCode(prefix: string) {
  const bomPrefix = getPrefix(prefix);
  const counter = await ManufacturingBOMCounter.findOneAndUpdate(
    { name: "Manufacturing BOM" },
    { $inc: { seq: 1 } },
    {
      new: true,
      upsert: true,
    },
  );

  const paddedNumber = String(counter.seq).padStart(5, "0");
  return `${bomPrefix}${paddedNumber}`;
}

export async function generatePackagingBomCode(prefix: string) {
  const bomPrefix = getPrefix(prefix);
  const counter = await PackagingBOMCounter.findOneAndUpdate(
    { name: "Packaging BOM" },
    { $inc: { seq: 1 } },
    {
      new: true,
      upsert: true,
    },
  );

  const paddedNumber = String(counter.seq).padStart(5, "0");
  return `${bomPrefix}${paddedNumber}`;
}

export async function generateManufacturingTemplateCode(prefix: string) {
  const manufacturingTemplatePrefix = getPrefix(prefix);
  const counter = await BatchManufacturingTemplateCounter.findOneAndUpdate(
    { name: "Batch Manufacturing Template" },
    { $inc: { seq: 1 } },
    {
      new: true,
      upsert: true,
    },
  );

  const paddedNumber = String(counter.seq).padStart(5, "0");
  return `${manufacturingTemplatePrefix}${paddedNumber}`;
}

export async function generateProcessOrderCode(prefix: string) {
  const processOrderPrefix = getPrefix(prefix);
  const counter = await ProcessOrderCounter.findOneAndUpdate(
    { name: "Process Order" },
    { $inc: { seq: 1 } },
    {
      new: true,
      upsert: true,
    },
  );

  const paddedNumber = String(counter.seq).padStart(5, "0");
  return `${processOrderPrefix}${paddedNumber}`;
}

export async function generateBatchNumber(shortName: string) {
  const year = new Date().getFullYear().toString().slice(-2);
  const counter = await BatchCounter.findOneAndUpdate(
    { shortName: shortName.toUpperCase() },
    { $inc: { seq: 1 } },
    {
      new: true,
      upsert: true,
    },
  );

  const paddedNumber = String(counter.seq).padStart(4, "0");
  return `${shortName.toUpperCase()}-${year}-${paddedNumber}`;
}

function getPrefix(category: string) {
  switch (category) {
    case "Raw Material":
      return "RM";
    case "Packaging Material":
      return "PM";
    case "Material Subgroup":
      return "MS";
    case "Material Category":
      return "MC";
    case "Pharmaceutical Product":
      return "21";
    case "Equipment Master":
      return "81";
    case "FAC":
      return "71";
    case "MBOM":
      return "201";
    case "PBOM":
      return "202";
    case "BMT":
      return "242";
    case "BPT":
      return "272";
    case "POM":
      return "764";
    case "POP":
      return "767";
    default:
      return "M";
  }
}