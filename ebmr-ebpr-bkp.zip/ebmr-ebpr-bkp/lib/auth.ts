import { message } from 'antd';
import jwt from 'jsonwebtoken';
import { NextRequest, NextResponse } from 'next/server';
export const JWT_SECRET: string = process.env.JWT_SECRET || 'secret-sdfkjfhk3jlkj-vbsdbdjhf43jkh38cxvbddksdbshf342457982345jbfhjf';

// Create token and set HTTP-only cookie
export function createTokenCookie(user: { id: string, role: string }) {
    const token = jwt.sign(user, JWT_SECRET, {
        expiresIn: '1h',
    });
    const res = NextResponse.json({
        token,
        message: 'Login successful!',
        role: user.role
    });

    res.cookies.set('token', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        path: '/',
        maxAge: 60 * 60 * 24 * 30,
    });
    return res;
}

// Verify token and return user
export async function verifyTokenCookie(req: NextRequest) {
    const token = req.cookies.get('token')?.value;
    if (!token) {
        return null;
    }
    try {
        const decoded = jwt.verify(token, JWT_SECRET) as { id: string; role: string };
        return decoded;
    } catch (error) {
        message.error('Invalid token');
        return null;
    }
}