export const Dosage_Forms = [
  { label: "Tablet", value: "Tablet" },
  { label: "Capsule", value: "Capsule" },
  { label: "Syrup", value: "Syrup" },
  { label: "Injection", value: "Injection" },
  { label: "Cream", value: "Cream" },
  { label: "Ointment", value: "Ointment" },
  { label: "Drop", value: "Drop" },
  { label: "Liquid Suspension", value: "Liquid Suspension" },
  { label: "Dry Powder Suspension", value: "Dry Powder Suspension" },
  { label: "Gel", value: "Gel" },
  { label: "Powder", value: "Powder" },
  { label: "Solution", value: "Solution" },
  { label: "Lotion", value: "Lotion" },
];

export const Pack_Presentation = [
  { label: "Strip", value: "Strip" },
  { label: "Box", value: "Box" },
  { label: "Tube", value: "Tube" },
  { label: "Vial", value: "Vial" },
  { label: "Bottle", value: "Bottle" },
];

export const Therapeutic_Classes = [
  { label: "Analgesic", value: "Analgesic" },
  { label: "Antibiotic", value: "Antibiotic" },
  { label: "Antidiabetic", value: "Antidiabetic" },
  { label: "Antihypertensive", value: "Antihypertensive" },
  { label: "Anti-inflammatory", value: "Anti-inflammatory" },
  { label: "Antihistamine", value: "Antihistamine" },
  { label: "Anti-malarial", value: "Anti-malarial" },
  { label: "Antimicrobial", value: "Antimicrobial" },
  { label: "Antineoplastic", value: "Antineoplastic" },
  { label: "Antiparasitic", value: "Antiparasitic" },
  { label: "Antipsychotic", value: "Antipsychotic" },
  { label: "Antiretroviral", value: "Antiretroviral" },
  { label: "Antithrombotic", value: "Antithrombotic" },
  { label: "Antitumor", value: "Antitumor" },
  { label: "Antiviral", value: "Antiviral" },
  { label: "Anti-ulcerant", value: "An    ti-ulcerant" },
  { label: "Cardiovascular", value: "Cardiovascular" },
  { label: "Dermatological", value: "Dermatological" },
  { label: "Endocrine", value: "Endocrine" },
  { label: "Gastrointestinal", value: "Gastrointestinal" },
  { label: "Immune", value: "Immune" },
  { label: "Infectious", value: "Infectious" },
  { label: "Neurological", value: "Neurological" },
  { label: "Ophthalmic", value: "Ophthalmic" },
  { label: "Otorhinolaryngological", value: "Otorhinolaryngological" },
  { label: "Respiratory", value: "Respiratory" },
  { label: "Rheumatological", value: "Rheumatological" },
  { label: "Urological", value: "Urological" },
  { label: "Other", value: "Other" },
];

export const Drug_Categories = [
  { label: "OTC", value: "OTC" },
  { label: "Prescription", value: "Prescription" },
  { label: "Controlled", value: "Controlled" },
];

export const Storage_Conditions = [
  { value: "Ambient (15-25°C)", label: "Ambient (15-25°C)" },
  {
    value: "Controlled Room Temp (20-25°C)",
    label: "Controlled Room Temp (20-25°C)",
  },
  { value: "Refrigerated (2-8°C)", label: "Refrigerated (2-8°C)" },
  { value: "Frozen (-20°C)", label: "Frozen (-20°C)" },
  {
    value: "Deep Frozen (-40°C or below)",
    label: "Deep Frozen (-40°C or below)",
  },
  {
    value: "Cold Chain (2–8°C with monitoring)",
    label: "Cold Chain (2–8°C with monitoring)",
  },
  { value: "Desiccated", label: "Desiccated" },
  { value: "Protect From Light", label: "Protect From Light" },
  { value: "Protect From Moisture", label: "Protect From Moisture" },
  { value: "Nitrogen Flushed", label: "Nitrogen Flushed" },
  { value: "Flammable  Cabinet Required", label: "Flammable Cabinet Required" },
  {
    value: "Hazardous / Controlled Storage",
    label: "Hazardous / Controlled Storage",
  },
  { value: "Quarantine Storage", label: "Quarantine Storage" },
  { value: "Controlled Substance Vault", label: "Controlled Substance Vault" },
];

export const Manufacturers = "Hilton Pharma";
export const Drug_License_Number = "DR/2022/12348";

export const SIGNING_HIERARCHY_MODULES = [
  {
    label: "Batch Manufacturing Template",
    value: "Batch Manufacturing Template",
  },
  { label: "Dispensing Line Clearance", value: "Dispensing Line Clearance" },
];

// After adding new Hierarchy module and also add the new document model in lib/models and import it in app/api/user/digital-signing/sign/route.ts for dynamic document validation during signing process.

export const Departmental_Signing_Hierarchy_Module = [
  { label: "Log Book Entry", value: "logBookEntry" },
  { label: "Line Clearance Activity", value: "lineClearanceActivity" },
];

// Equipment Master Constants
export const Equipment_Types = [
  { label: "Machine", value: "Machine" },
  { label: "Instrument", value: "Instrument" },
  { label: "Utility", value: "Utility" },
  { label: "Tool", value: "Tool" },
];

export const Equipment_Categories = [
  { label: "Production Equipment", value: "Production Equipment" },
  { label: "Quality Control Equipment", value: "Quality Control Equipment" },
  { label: "Warehouse Equipment", value: "Warehouse Equipment" },
  { label: "Utility Equipment", value: "Utility Equipment" },
  { label: "HVAC Equipment", value: "HVAC Equipment" },
  { label: "Laboratory Equipment", value: "Laboratory Equipment" },
  { label: "Packaging Equipment", value: "Packaging Equipment" },
  { label: "Sterilization Equipment", value: "Sterilization Equipment" },
  { label: "IT Equipment", value: "IT Equipment" },
  { label: "Safety Equipment", value: "Safety Equipment" },
  { label: "Other", value: "Other" },
];

export const Equipment_Status = [
  { label: "Active", value: "Active" },
  { label: "Under Maintenance", value: "Under Maintenance" },
  { label: "Breakdown", value: "Breakdown" },
  { label: "Retired", value: "Retired" },
  { label: "Decommissioned", value: "Decommissioned" },
];

export const Qualification_Status = [
  { label: "Not Qualified", value: "Not Qualified" },
  { label: "IQ", value: "IQ" },
  { label: "OQ", value: "OQ" },
  { label: "PQ", value: "PQ" },
  { label: "Qualified", value: "Qualified" },
];

export const Calibration_Status = [
  { label: "Calibrated", value: "Calibrated" },
  { label: "Due", value: "Due" },
  { label: "Overdue", value: "Overdue" },
];

export const Maintenance_Type = [
  { label: "Preventive", value: "Preventive" },
  { label: "Breakdown", value: "Breakdown" },
  { label: "Routine", value: "Routine" },
];

export const Criticality = [
  { label: "Critical", value: "Critical" },
  { label: "Major", value: "Major" },
  { label: "Minor", value: "Minor" },
];

export const Usage_Type = [
  { label: "Production", value: "Production" },
  { label: "QC", value: "QC" },
  { label: "Warehouse", value: "Warehouse" },
  { label: "Utility", value: "Utility" },
];

export const Cleaning_Status = [
  { value: "Cleaned", label: "Cleaned" },
  { value: "Not Cleaned", label: "Not Cleaned" },
  { value: "Pending", label: "Pending" },
  { value: "In Progress", label: "In Progress" },
];

// Facility Master Constants
export const Area_Types = [
  { label: "Production", value: "Production" },
  { label: "Warehouse", value: "Warehouse" },
  { label: "Utility", value: "Utility" },
  { label: "QC Lab", value: "QC Lab" },
  { label: "Admin", value: "Admin" },
  { label: "R&D", value: "R&D" },
];

export const Status_Options = [
  { label: "Active", value: "Active" },
  { label: "Inactive", value: "Inactive" },
  { label: "Under Maintenance", value: "Under Maintenance" },
  { label: "Decommissioned", value: "Decommissioned" },
];

export const Block_Options = [
  { label: "Production Block A", value: "Production Block A" },
  { label: "Production Block B", value: "Production Block B" },
  { label: "Production Block C", value: "Production Block C" },
  { label: "Production Block D", value: "Production Block D" },
  { label: "Warehouse Block", value: "Warehouse Block" },
  { label: "QC Lab Block", value: "QC Lab Block" },
  { label: "Admin Block", value: "Admin Block" },
];

export const CleanRoom_Grades = [
  { label: "A", value: "A" },
  { label: "B", value: "B" },
  { label: "C", value: "C" },
  { label: "D", value: "D" },
  { label: "Non Classified", value: "Non Classified" },
];

export const Qualification_Statuses = [
  { label: "Not Qualified", value: "Not Qualified" },
  { label: "Pending", value: "Pending" },
  { label: "Qualified", value: "Qualified" },
];

export const Sanitization_Options = [
  { label: "Daily", value: "Daily" },
  { label: "Weekly", value: "Weekly" },
  { label: "Monthly", value: "Monthly" },
];

export const SHIFT_PRESET_NAMES = [
  { label: "Production Shift", value: "Production Shift" },
  { label: "Morning", value: "Morning" },
  { label: "Afternoon", value: "Afternoon" },
  { label: "Evening", value: "Evening" },
  { label: "Night", value: "Night" },
];

export const PRODUCTION_SHIFT_NAME = "Production Shift";

export const Flow_Directions = [
  { label: "Inward", value: "Inward" },
  { label: "Outward", value: "Outward" },
  { label: "Both", value: "Both" },
];

export const Floor_Options = [
  { label: "Ground Floor", value: "Ground Floor" },
  { label: "First Floor", value: "First Floor" },
  { label: "Second Floor", value: "Second Floor" },
  { label: "Third Floor", value: "Third Floor" },
];

// BOM Constants
export const UOM_OPTIONS = [
  { value: "Tablets", label: "Tablets" },
  { value: "Capsules", label: "Capsules" },
  { value: "Sachets", label: "Sachets" },
  { value: "Bottles", label: "Bottles" },
  { value: "Boxes", label: "Boxes" },
  { value: "Liters", label: "Liters" },
  { value: "kg", label: "kg" },
  { value: "Grams", label: "Grams" },
  { value: "ml", label: "ml" },
];

export const STATUS_OPTIONS = [
  { value: "Draft", label: "Draft" },
  { value: "Active", label: "Active" },
  { value: "Inactive", label: "Inactive" },
  { value: "Under Review", label: "Under Review" },
];
export const UOM_OPTIONS_BULK = [
  { value: "kg", label: "kg" },
  { value: "Grams", label: "Grams" },
  { value: "Milligrams", label: "Milligrams" },
  { value: "Liters", label: "Liters" },
  { value: "Mililiters", label: "Mililiters" },
  // { value: 'ML', label: 'ML' },
];
export const UOM_OPTION_PACKAGIGN_MATERIAL = [
  { value: "Each", label: "Each" },
  { value: "kg", label: "kg" },
  { value: "Grams", label: "Grams" },
];

export const CONVERSION_RATES: Record<string, number> = {
  kg: 1,
  Grams: 0.001,
  Milligrams: 0.000001,
  Liters: 1,
  Milliliters: 0.001,
};

// Manufacturing Template Constants

export const Tabalet_Types = [
  { value: "Immediate Release", label: "Immediate Release" },
  { value: "Extended Release", label: "Extended Release" },
  { value: "Enteric Coated", label: "Enteric Coated" },
  { value: "Sublingual", label: "Sublingual" },
  { value: "Orally Disintegrating", label: "Orally Disintegrating" },
  { value: "Chewable", label: "Chewable" },
  { value: "Effervescent", label: "Effervescent" },
  { value: "Bilayer", label: "Bilayer" },
  { value: "Tablet in Tablet", label: "Tablet in Tablet" },
];

export const Template_types = [
  {
    value: "Batch Manufacturing Template",
    label: "Batch Manufacturing Template",
  },
  { value: "Batch Packing Template", label: "Batch Packing Template" },
];

// compression parameters

// Tooling Types
export const TOOLING_TYPES = [
  { value: "B", label: "B Type (19mm)" },
  { value: "D", label: "D Type (25mm)" },
  { value: "BB", label: "BB Type (19mm Double)" },
  { value: "DD", label: "DD Type (25mm Double)" },
  { value: "Custom", label: "Custom" },
];

//Tooling Materials
export const TOOLING_MATERIALS = [
  { value: "Steel", label: "Steel" },
  { value: "Stainless Steel", label: "Stainless Steel" },
  { value: "HCHC Steel", label: "HCHC Steel" },
  { value: "Tungsten Carbide", label: "Tungsten Carbide" },
];

//Tooling Coatings
export const TOOLING_COATINGS = [
  { value: "None", label: "None (Polished)" },
  { value: "Chrome Plating", label: "Chrome Plating" },
  { value: "TiN (Titanium Nitride)", label: "TiN (Titanium Nitride)" },
  { value: "CrN (Chromium Nitride)", label: "CrN (Chromium Nitride)" },
  { value: "DLC (Diamond-Like Carbon)", label: "DLC (Diamond-Like Carbon)" },
];

// Punch Shapes
export const PUNCH_SHAPES = [
  { value: "Round", label: "Round" },
  { value: "Oval", label: "Oval" },
  { value: "Capsule", label: "Capsule" },
  { value: "Rectangle", label: "Rectangle" },
  { value: "Square", label: "Square" },
  { value: "Triangle", label: "Triangle" },
  { value: "Diamond", label: "Diamond" },
  { value: "Custom", label: "Custom" },
];

// Embossing Types
export const EMBOSSING_TYPES = [
  { value: "Debossed", label: "Debossed (Indented)" },
  { value: "Embossed", label: "Embossed (Raised)" },
  { value: "Breakline", label: "Breakline (Scored)" },
  { value: "None", label: "None" },
];

// IPQC Frequency
export const IPQC_FREQUENCY = [
  { value: "Every 5 minutes", label: "Every 5 minutes" },
  { value: "Every 10 minutes", label: "Every 10 minutes" },
  { value: "Every 15 minutes", label: "Every 15 minutes" },
  { value: "Every 30 minutes", label: "Every 30 minutes" },
  { value: "Every 60 minutes", label: "Every 60 minutes" },
  { value: "Every 120 minutes", label: "Every 120 minutes" },
];

// Coating defect types
export const COATING_DEFECT_TYPES = [
  { value: "Peeling", label: "Peeling" },
  { value: "Bridging", label: "Bridging" },
  { value: "Sticking", label: "Sticking" },
  { value: "Chipping", label: "Chipping" },
  { value: "Color Variation", label: "Color Variation" },
  { value: "Orange Peel Effect", label: "Orange Peel Effect" },
  { value: "Logo Bridging", label: "Logo Bridging" },
];

// Encapsulation Constants
export const CAPSULE_SIZES = [
  { value: "000", label: "000 (Largest)" },
  { value: "00", label: "00" },
  { value: "0", label: "0" },
  { value: "1", label: "1" },
  { value: "2", label: "2" },
  { value: "3", label: "3" },
  { value: "4", label: "4" },
  { value: "5", label: "5 (Smallest)" },
];

export const CAPSULE_TYPES = [
  { value: "Hard Gelatin", label: "Hard Gelatin" },
  { value: "Vegetarian (HPMC)", label: "Vegetarian (HPMC)" },
  { value: "Soft Gelatin", label: "Soft Gelatin" },
];

export const ENCAPSULATION_DEFECT_TYPES = [
  { value: "Denting", label: "Denting" },
  { value: "Splitting", label: "Splitting" },
  { value: "Misalignment", label: "Misalignment" },
  { value: "Powder Leakage", label: "Powder Leakage" },
  { value: "Sticking", label: "Sticking" },
  { value: "Incomplete Fill", label: "Incomplete Fill" },
  { value: "Empty Capsule", label: "Empty Capsule" },
];

// Liquid & Suspension Constants
export const LIQUID_DEFECT_TYPES = [
  { value: "Precipitation", label: "Precipitation" },
  { value: "Cloudiness", label: "Cloudiness" },
  { value: "Color Change", label: "Color Change" },
  { value: "Sedimentation", label: "Sedimentation" },
  { value: "Crystallization", label: "Crystallization" },
  { value: "Foaming", label: "Foaming" },
  { value: "Microbial Growth", label: "Microbial Growth" },
];

export const BOTTLE_TYPES = [
  { value: "PET", label: "PET (Polyethylene Terephthalate)" },
  { value: "Glass", label: "Glass" },
  { value: "HDPE", label: "HDPE (High Density Polyethylene)" },
  { value: "LDPE", label: "LDPE (Low Density Polyethylene)" },
  { value: "Polypropylene", label: "Polypropylene" },
];

export const CAP_TYPES = [
  { value: "Screw Cap", label: "Screw Cap" },
  { value: "RCCI", label: "RCCI (Ratchet Child Resistant)" },
  { value: "CRC", label: "CRC (Child Resistant Cap)" },
  { value: "Snap Cap", label: "Snap Cap" },
  { value: "Pilfer Proof", label: "Pilfer Proof" },
];

export const SEAL_TYPES = [
  { value: "Induction Seal", label: "Induction Seal" },
  { value: "Heat Seal", label: "Heat Seal" },
  { value: "Pressure Sensitive", label: "Pressure Sensitive" },
  { value: "No Seal", label: "No Seal" },
];

export const POWDER_CONTAINER_TYPES = [
  { value: "Bottle", label: "Bottle" },
  { value: "Sachet", label: "Sachet" },
  { value: "Pouch", label: "Pouch" },
  { value: "Jar", label: "Jar" },
  { value: "HDPE Container", label: "HDPE Container" },
];

export const POWDER_DEFECT_TYPES = [
  { value: "Under Fill", label: "Under Fill" },
  { value: "Over Fill", label: "Over Fill" },
  { value: "Poor Flow", label: "Poor Flow" },
  { value: "Lumps", label: "Lumps" },
  { value: "Segregation", label: "Segregation" },
  { value: "Moisture Pickup", label: "Moisture Pickup" },
  { value: "Seal Leak", label: "Seal Leak" },
  { value: "Powder Leakage", label: "Powder Leakage" },
];

// Semisolid Constants (Cream, Ointment, Gel, Lotion)
export const SEMISOLID_CONTAINER_TYPES = [
  { value: "Tube", label: "Tube (Aluminum/Laminate)" },
  { value: "Jar", label: "Jar" },
  { value: "Bottle", label: "Bottle (Pump/Flip-top)" },
  { value: "Sachet", label: "Sachet" },
  { value: "Stick", label: "Stick (Push-up)" },
];

export const SEMISOLID_DEFECT_TYPES = [
  { value: "Grittiness", label: "Grittiness" },
  { value: "Separation", label: "Separation / Cracking" },
  { value: "Color Variation", label: "Color Variation" },
  { value: "Graininess", label: "Graininess" },
  { value: "Air Bubbles", label: "Air Bubbles / Pinholes" },
  { value: "Syneresis", label: "Syneresis (Liquid oozing)" },
  { value: "Phase Separation", label: "Phase Separation" },
];

//Compressed tablet defect types
export const COMPRESSED_TABLET_DEFECT_TYPES = [
  { value: "Capping", label: "Capping" },
  { value: "Lamination", label: "Lamination" },
  { value: "Sticking", label: "Sticking" },
  { value: "Picking", label: "Picking" },
  { value: "Chipping", label: "Chipping" },
  { value: "Cracking", label: "Cracking" },
  { value: "Mottling", label: "Mottling" },
  { value: "Double Impression", label: "Double Impression" },
];
// Log book entry constants
export const Cleaning_Type_Options = [
  { label: "Routine", value: "Routine" },
  { label: "Deep Clean", value: "Deep Clean" },
  { label: "Between Batch", value: "Between Batch" },
  { label: "After Batch", value: "After Batch" },
  { label: "Campaign Close", value: "Campaign Close" },
  { label: "Pre-Operation", value: "Pre-Operation" },
  { label: "Other", value: "Other" },
];

export const Cleaning_Method_Options = [
  { label: "Wet", value: "Wet" },
  { label: "Dry", value: "Dry" },
  { label: "Wipe", value: "Wipe" },
  { label: "Vacuum", value: "Vacuum" },
  { label: "Foam", value: "Foam" },
  { label: "CIP", value: "CIP" },
  { label: "Other", value: "Other" },
];