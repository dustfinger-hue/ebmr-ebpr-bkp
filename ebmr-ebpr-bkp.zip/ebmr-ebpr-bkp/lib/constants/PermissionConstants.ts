export const AUTHORIZATION_TYPES=[
    {label:'Create',value:'create'},
    {label:'Read',value:'read'},
    {label:'Update',value:'update'},
    {label:'Delete',value:'delete'},
]
export const AUTHORIZATION_MODULES=[
    {label:'Please Select',value:''},
    {label:'Material Master',value:'material-master'},
    {label:'Product Master',value:'product-master'},
    {label:'Equipment Master',value:'equipment-master'},
    {label:'Facility Master',value:'facility-master'},
    {label:'Manufacturing BOM',value:'manufacturing-bom'},
    {label:'Packaging BOM',value:'packaging-bom'},
    {label:'Batch Manufacturing Template',value:'batch-manufacturing-template'},
    {label:'Batch Packing Template',value:'batch-packing-template'},
    {label:'Process Order',value:'process-order'},
    {label:'Batch Number Issuance',value:'batch-number-issuance'},
    {label:'Dispensing',value:'dispensing'},
    // {label:'Area Activity Log',value:'area-activity-log'},
    {label:'Log Book Entry',value:'log-book-entry'},
]
