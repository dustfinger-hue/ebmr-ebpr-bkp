// src/constants/departments.ts

export const DEPARTMENTS = [
    { label: "Production", value: "Production" },
    { label: "Quality Control", value: "Quality Control" },
    { label: "Quality Assurance", value: "Quality Assurance" },
    { label: "Warehouse", value: "Warehouse" },
    { label: "Engineering", value: "Engineering" },
    { label: "Human Resources", value: "Human Resources" },
    { label: "Accounts", value: "Accounts" },
    { label: "IT", value: "IT" },
];
