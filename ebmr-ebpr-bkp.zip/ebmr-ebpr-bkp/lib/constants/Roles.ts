// src/constants/departments.ts

export const ROLES = [
    { label: "Operator", value: "Operator" },
    {label:"Supervisor",value:"Supervisor"},
    {label:'Officer/Executive',value:'Officer/Executive'},
    {label:'Manager',value:'Manager'},
    {label:'Head of Department',value:'Head of Department'},
    {label:'Director',value:'Director'},
];
