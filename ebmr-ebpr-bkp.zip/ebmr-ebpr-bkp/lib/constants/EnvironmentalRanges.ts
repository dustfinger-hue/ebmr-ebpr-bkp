// Default environmental monitoring ranges (used when facility has no specific data)
export const DEFAULT_ENVIRONMENTAL_RANGES = {
  differentialPressure: { min: 0, max: 50, unit: 'Pa' },
  temperature: { min: 15, max: 30, unit: '°C' },
  humidity: { min: 30, max: 65, unit: '%' },
  particulates: { min: 0, max: 1000, unit: 'CFU/m³' },
  luxLevel: { min: 200, max: 1500, unit: 'Lux' },
} as const;

// Warning & Alarm thresholds (percentage deviation from range span)
// Example: range = 10-20 Pa (span = 10)
//   Warning: value ±15% of span outside range (1.5) => 8.5 to 21.5
//   Alarm:   value ±30% of span outside range (3)   => 7 to 23
export const STATUS_THRESHOLDS = {
  warningDeviationPercent: 15,
  alarmDeviationPercent: 30,
} as const;

// Status options for environmental monitoring
export const ENVIRONMENTAL_STATUS = {
  WITHIN_LIMIT: 'Within Limit',
  WARNING: 'Warning',
  ALARM: 'Alarm',
} as const;

export type EnvironmentalStatus = typeof ENVIRONMENTAL_STATUS[keyof typeof ENVIRONMENTAL_STATUS];