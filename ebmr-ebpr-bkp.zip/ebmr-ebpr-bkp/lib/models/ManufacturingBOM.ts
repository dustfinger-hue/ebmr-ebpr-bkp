import mongoose, { Schema } from "mongoose";

const MaterialSubSchema = new Schema({
    materialCode: { type: String, required: true },
    materialName: { type: String, required: true },
    materialCategory: { type: String, required: true },
    quantity: { type: Number, required: true, min: 0 },
    uom: { type: String, required: true }
}, { _id: false });

const ManufacturingBOMSchema = new Schema({
    productCode: { type: String, required: true, index: true },
    productName: { type: String, required: true },
    bomCode: { type: String, required: true, unique: true, index: true },
    bomVersion: { type: String, required: true, default: "1.0" },
    batchSizeSemifinished: { type: Number, required: true, min: 0 },
    uom: { type: String, required: true },
    bulkSize: { type: Number, required: true, min: 0 },
    bulkUom: { type: String, required: true },
    status: { type: String, required: true, enum: ["Draft", "Active", "Inactive", "Under Review"], default: "Draft" },
    effectiveDate: { type: Date, required: true },
    validTill: { type: Date },
    materials: { type: [MaterialSubSchema], required: true },
    createdBy: { type: Schema.Types.ObjectId, ref: "User", required: true },
    updatedBy: { type: Schema.Types.ObjectId, ref: "User" }
}, { timestamps: true });

ManufacturingBOMSchema.index({ productCode: 1, bomVersion: 1 });
ManufacturingBOMSchema.index({ status: 1 });

export default mongoose.models.ManufacturingBOM || mongoose.model("ManufacturingBOM", ManufacturingBOMSchema);
