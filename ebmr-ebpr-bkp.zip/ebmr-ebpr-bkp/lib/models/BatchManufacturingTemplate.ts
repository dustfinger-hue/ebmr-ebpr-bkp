import mongoose, { Schema } from "mongoose";

// Sub-schema for individual signature
const SignatureDetailSchema = new Schema(
  {
    signatureRef: { type: Schema.Types.ObjectId, ref: "Signature" }, // Reference to main Signature collection
    signatureHash: { type: String, required: true },
    action: {
      type: String,
      enum: ["approved", "rejected", "reverted"],
      default: "approved",
    },
    signatoryInfo: {
      id: { type: String, required: true },
      name: { type: String, required: true },
      designation: { type: String },
      department: { type: String },
      authorizationLevel: { type: String },
      authorizationSequence: { type: Number }, // For sequential signing
    },
    status: {
      type: String,
      enum: ["pending", "signed", "rejected", "reverted", "expired"],
      default: "pending",
    },
    signedAt: { type: Date },
  },
  { timestamps: true },
);

const BatchManufacturingTemplate = new Schema(
  {
    // Basic fields
    templateCode: { type: String, required: true, unique: true },
    templateName: { type: String, required: true },
    productCode: { type: String, required: true },
    productName: { type: String, required: true },
    dosageForm: { type: String, required: true },
    status: {
      type: String,
      enum: [
        "Draft",
        "Pending Signatures",
        "Active",
        "Inactive",
        "Superseded",
        "Rejected",
        "Reverted",
      ],
      default: "Draft",
    },

    // Complete nested data
    fullTemplateData: { type: Schema.Types.Mixed, required: true },

    // Version tracking
    templateVersion: { type: String, required: true },

    // Points to the version that supersedes this one, if applicable
    supersededBy: {
      type: Schema.Types.ObjectId,
      ref: "BatchManufacturingTemplate",
    },
    supersededTemplateVersion: { type: String },

    // Points to the version that this document supersedes, if applicable (for easy backward reference)
    supersedes: {
      type: Schema.Types.ObjectId,
      ref: "BatchManufacturingTemplate",
    },

    // 👇 Signatures array with detailed info
    signatures: [SignatureDetailSchema],

    // Workflow tracking
    signingWorkflow: {
      isSignatureComplete: { type: Boolean, default: false },
      totalSignaturesRequired: { type: Number, default: 0 },
      completedSignatures: { type: Number, default: 0 },
      lastSignedAt: { type: Date },
    },

    // Status history for audit trail
    statusHistory: [
      {
        status: {
          type: String,
          enum: [
            "Draft",
            "Pending Signatures",
            "Active",
            "Inactive",
            "Superseded",
            "Rejected",
            "Reverted",
          ],
          required: true,
        },
        changedAt: { type: Date, default: Date.now },
        changedBy: {
          id: { type: String, required: true },
          name: { type: String, required: true },
          signatureRef: { type: Schema.Types.ObjectId, ref: "Signature" }, // Reference to main Signature collection
          signatureHash: { type: String, required: true },
        },
      },
    ],
  },
  { timestamps: true },
);

// Indexes
BatchManufacturingTemplate.index({ "signatures.status": 1 });
BatchManufacturingTemplate.index({ "signatures.signatoryInfo.id": 1 });
BatchManufacturingTemplate.index({
  status: 1,
  "signingWorkflow.isSignatureComplete": 1,
});

export default mongoose.models.BatchManufacturingTemplate ||
  mongoose.model("BatchManufacturingTemplate", BatchManufacturingTemplate);
