import mongoose from "mongoose";

const CounterSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  seq: {
    type: Number,
    default: 0,
  },
});

const MaterialCounterSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    seq: { type: Number, default: 0 },
    prefix: { type: String, required: true },
  },
  { timestamps: true },
);
MaterialCounterSchema.index({ name: 1, prefix: 1 }, { unique: true });

const PharmaceuticalProductCounterSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    seq: { type: Number, default: 0 },
  },
  { timestamps: true },
);
PharmaceuticalProductCounterSchema.index({ name: 1 }, { unique: true });

const EquipmentCounterSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    seq: { type: Number, default: 0 },
  },
  { timestamps: true },
);
EquipmentCounterSchema.index({ name: 1 }, { unique: true });

const FacilityCounterSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    seq: { type: Number, default: 0 },
  },
  { timestamps: true },
);
FacilityCounterSchema.index({ name: 1 }, { unique: true });

const ManufacturingBOMCounterSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    seq: { type: Number, default: 0 },
  },
  { timestamps: true },
);
ManufacturingBOMCounterSchema.index({ name: 1 }, { unique: true });

const PackagingBOMCounterSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    seq: { type: Number, default: 0 },
  },
  { timestamps: true },
);
PackagingBOMCounterSchema.index({ name: 1 }, { unique: true });

const BatchManufacturingTemplate = new mongoose.Schema(
  {
    name: { type: String, required: true },
    seq: { type: Number, default: 0 },
  },
  { timestamps: true },
);
BatchManufacturingTemplate.index({ name: 1 }, { unique: true });

const ProcessOrderCounterSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    seq: { type: Number, default: 0 },
  },
  { timestamps: true },
);
ProcessOrderCounterSchema.index({ name: 1 }, { unique: true });

const BatchCounterSchema = new mongoose.Schema(
  {
    shortName: { type: String, required: true, unique: true },
    seq: { type: Number, default: 0 },
  },
  { timestamps: true },
);
BatchCounterSchema.index({ shortName: 1 }, { unique: true });

export const PackagingBOMCounter =
  mongoose.models.PackagingBOMCounter ||
  mongoose.model("PackagingBOMCounter", PackagingBOMCounterSchema);
export const ManufacturingBOMCounter =
  mongoose.models.ManufacturingBOMCounter ||
  mongoose.model("ManufacturingBOMCounter", ManufacturingBOMCounterSchema);
export const FacilityCounter =
  mongoose.models.FacilityCounter ||
  mongoose.model("FacilityCounter", FacilityCounterSchema);
export const MaterialCounter =
  mongoose.models.MaterialCounter ||
  mongoose.model("MaterialCounter", MaterialCounterSchema);
export const PharmaceuticalProductCounter =
  mongoose.models.PharmaceuticalProductCounter ||
  mongoose.model(
    "PharmaceuticalProductCounter",
    PharmaceuticalProductCounterSchema,
  );
export const EquipmentCounter =
  mongoose.models.EquipmentCounter ||
  mongoose.model("EquipmentCounter", EquipmentCounterSchema);
export const BatchManufacturingTemplateCounter =
  mongoose.models.BatchManufacturingTemplateCounter ||
  mongoose.model(
    "BatchManufacturingTemplateCounter",
    BatchManufacturingTemplate,
  );
export const ProcessOrderCounter =
  mongoose.models.ProcessOrderCounter ||
  mongoose.model("ProcessOrderCounter", ProcessOrderCounterSchema);
export const BatchCounter =
  mongoose.models.BatchCounter ||
  mongoose.model("BatchCounter", BatchCounterSchema);
export default mongoose.models.Counter ||
  mongoose.model("Counter", CounterSchema);
