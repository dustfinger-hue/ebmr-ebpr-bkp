import { Schema } from "mongoose";

const LineClearanceSchema = new Schema({
  previousProductName: { tpe: String, required: true },
  previousProductBatchNumber: { type: String, required: true },
  currentProductName: { type: String, required: true },
  currentProductBatchNumber: { type: String, required: true },

  lineClearanceStage:{type: String, required: true},
  lineClearanceStatus:{type: String, required: true},

  
});
