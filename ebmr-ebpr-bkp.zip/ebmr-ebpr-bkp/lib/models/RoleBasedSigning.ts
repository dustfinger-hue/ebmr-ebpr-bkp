import mongoose from "mongoose";

const RoleEntrySchema = new mongoose.Schema({
  userRole: { type: String, required: true }, // e.g. "Manager", "Director"
  levelOfAuthorization: { type: String, required: true }, // e.g. "Checked By", "Approved By"
  sequence: { type: Number, required: true }, // signing order (1, 2, 3...)
});

const RoleBasedSigningSchema = new mongoose.Schema(
  {
    moduleName: {
      type: String,
      required: true,
      unique: true,
    },
    signRequired: {
      type: Number,
      required: true,
      min: 1,
    },
    roles: [RoleEntrySchema],
    status: {
      type: String,
      enum: ["active", "inactive"],
      default: "active",
    },
    lastModifiedBy: {
      type: String,
    },
  },
  { timestamps: true },
);

export default mongoose.models.RoleBasedSigning ||
  mongoose.model("RoleBasedSigning", RoleBasedSigningSchema);