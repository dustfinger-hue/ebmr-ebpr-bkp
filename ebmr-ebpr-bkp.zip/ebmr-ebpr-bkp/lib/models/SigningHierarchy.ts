import mongoose from "mongoose";

const AuthorizedPersonSchema = new mongoose.Schema({
    userId: { type: String, required: true },
    name: { type: String, required: true },
    designation: { type: String, required: true },
    department: { type: String, required: true },
    authorizationLevel: { type: String, required: true },
    authorizationSequence: { type: Number, required: true }, // For sequential signing
});

const SigningHierarchySchema = new mongoose.Schema(
    {
        module: {
            type: String,
            required: true,
            unique: true,
        },
        signRequired: {
            type: Number,
            required: true,
            min: 1,
        },
        authorizedPersons: [AuthorizedPersonSchema],
        status: {
            type: String,
            enum: ["active", "inactive"],
            default: "active",
        },
        lastModifiedBy: {
            type: String,
        },
    },
    { timestamps: true }
);

const existingModel = mongoose.models.SigningHierarchy;
if (existingModel && !existingModel.schema.path("authorizedPersons.authorizationLevel")) {
    delete mongoose.models.SigningHierarchy;
}

export default mongoose.models.SigningHierarchy ||
    mongoose.model("SigningHierarchy", SigningHierarchySchema);
