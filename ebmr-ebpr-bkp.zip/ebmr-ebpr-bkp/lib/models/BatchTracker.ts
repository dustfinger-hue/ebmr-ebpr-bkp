import mongoose, { Schema } from "mongoose";

const DispensingRecordSchema = new Schema({
  MaterialAllocationRecordId: {
    type: Schema.Types.ObjectId,
    ref: "MatetrialAllocationRecord",
    unique: true,
  },
  lineClearanceRecordId: [
    {
      type: Schema.Types.ObjectId,
      ref: "LineClearanceRecord",
      default: null,
    },
  ],
});

const BatchTracker = new Schema({
  processOrderId: {
    type: Schema.Types.ObjectId,
    ref: "ProcessOrder",
    required: true,
  },
  batchNumber: {
    type: String,
    unique: true,
  },
  dispensingRecords: { type: DispensingRecordSchema, default: null },
});
export default mongoose.models.BatchTracker ||
  mongoose.model("BatchTracker", BatchTracker);
