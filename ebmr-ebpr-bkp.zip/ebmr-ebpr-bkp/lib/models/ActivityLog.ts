import mongoose from "mongoose";

// ─── Sub-schema for signature entries (performedBy, checkedBy, verifiedBy) ──
const SignatureEntrySchema = new mongoose.Schema(
  {
    name: { type: String },
    designation: { type: String },
    department: { type: String },
    signatureId: { type: mongoose.Schema.Types.ObjectId, ref: "Signature" },
    signatureHash: { type: String },
  },
  { _id: false }
);

const userInfoSchema = new mongoose.Schema(
  {
    name: { type: String },
    designation: { type: String },
    department: { type: String },
    signatureId: { type: mongoose.Schema.Types.ObjectId, ref: "Signature" },
  },
  { _id: false }
);

// ─── Activity Log Schema ───────────────────────────────────────────────
const ActivityLogSchema = new mongoose.Schema(
  {
    facilityCode: { type: String },
    date: { type: Date, required: true },
    productName: { type: String, required: true },
    batchNumber: { type: String, required: true },
    startDateTime: { type: Date, required: true },
    activityStartedBy: { type: userInfoSchema, required: true },
    endDateTime: { type: Date },
    activityStoppedBy: { type: userInfoSchema },
    status: {
      type: String,
      enum: ["Completed", "In-Progress", "Stopped"],
      default: "In-Progress",
    },
    engagedForActivity: { type: String },
    remarks: { type: String },
    checkedBy: { type: SignatureEntrySchema },
    verifiedBy: { type: SignatureEntrySchema },
  },
  { timestamps: true }
);

export default mongoose.models.ActivityLog ||
  mongoose.model("ActivityLog", ActivityLogSchema);