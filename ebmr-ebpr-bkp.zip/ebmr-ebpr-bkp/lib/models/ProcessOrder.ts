import mongoose, { Schema } from "mongoose";

const ProcessOrderSchema = new Schema({
    processOrderCode: { type: String, required: true, unique: true, index: true },
    productCode: { type: String, required: true, index: true },
    productName: { type: String, required: true },
    bomCode: { type: String, required: true },
    bomVersion: { type: String, default: "1.0" },
    batchSizeSemifinished: { type: Number, required: true, min: 0 },
    bulkSize: { type: Number, required: true, min: 0 },
    uom: { type: String, required: true },
    bulkUom: { type: String, required: true },
    plannedStartDate: { type: Date, required: true },
    plannedEndDate: { type: Date, required: true },
    status: {
        type: String,
        required: true,
        enum: ["Draft", "Planned", "Released", "In-Progress", "Completed", "On-Hold", "Cancelled"],
        default: "Draft"
    },
    remarks: { type: String, default: "" },
    manufacturingFacility: { type: [String], default: [] },
    batchNumber: { type: String, default: null, index: true },
    createdBy: { type: Schema.Types.ObjectId, ref: "User", required: true },
    updatedBy: { type: Schema.Types.ObjectId, ref: "User" },
}, { timestamps: true });

ProcessOrderSchema.index({ status: 1 });
ProcessOrderSchema.index({ productCode: 1, status: 1 });

export default mongoose.models.ProcessOrder || mongoose.model("ProcessOrder", ProcessOrderSchema);