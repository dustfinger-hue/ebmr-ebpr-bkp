import mongoose from "mongoose";
import { ROLES } from "../constants/Roles";

const authorizationSchema = new mongoose.Schema({
    module: {
        type: String,
        // required: true
    },
    accessLevel: {
        type: [String],
        // required: true
    }
})

const UserSchema = new mongoose.Schema({
    firstName: {
        type: String,
        // required: true
    },
    lastName: {
        type: String,
        // required: true
    },
    fullName: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    phoneNumber: {
        type: String,
        // required: true
    },
    employeeId: {
        type: String,
        required: true,
        unique: true
    },
    gender: {
        type: String,
        // required: true,
        enum: ['male', 'female', 'other']
    },
    dateOfBirth: {
        type: Date,
        // required: true
    },
    department: {
        type: String,
        required: true
    },
    role: {
        type: String,
        required: true,
        enum: ROLES.map(role => role.value)
    },
    designation: {
        type: String,
        required: true
    },
    reportingToId: {
        type: String,
        // required: true
    },
    subordinateId: {
        type: String,
        // required: true
    },
    authorization: [authorizationSchema],
    employmentType: {
        type: String,
        // required: true,
        enum: ['permanent', 'contract']
    },  
    joiningDate: {
        type: Date,
        // required: true
    },
    employmentStatus: {
        type: String,
        // required: true,
        enum: ['active', 'inactive', 'resigned']
    },
    companyId: {
        type: String,
        // required: true
    },
    branchId: {
        type: String,
        // required: true
    },
    lastLogin: {
        type: Date,
        // default:Date.now()
    }
},
    { timestamps: true }
);
export default mongoose.models.User ||
    mongoose.model('User', UserSchema);