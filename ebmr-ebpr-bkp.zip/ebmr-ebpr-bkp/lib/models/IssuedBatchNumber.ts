import mongoose from "mongoose";

const IssuedBatchNumber = new mongoose.Schema({
  batchNumber: { type: String, required: true, unique: true },
  productName: { type: String, required: true },
  status: {
    type: String,
    enum: ["Batch Under Processing", "Batch Closed"],
    default: "Batch Under Processing",
  },
});
export default mongoose.models.IssuedBatchNumber || 
  mongoose.model("IssuedBatchNumber", IssuedBatchNumber);