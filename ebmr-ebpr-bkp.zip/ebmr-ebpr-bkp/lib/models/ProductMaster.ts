import mongoose, { Schema, Document } from "mongoose";

export interface IProduct extends Document {
    productCode: number;
    productName: string;
    genericName: string;
    shortName: string;
    description: string;

    productType: string;
    dosageForm: string;
    strength: string;
    packSize: string;
    unit: string;
    therapeuticClass: string[];
    drugCategory: string;
    manufacturer: string;

    shelfLife: number;
    storageCondition: string[];

    status: string;

    gtinNumber: string;
    registrationNumber: string;
    drugLicenseNumber: string;

    createdBy: mongoose.Types.ObjectId;
    updatedBy?: mongoose.Types.ObjectId;
    updateReason?: string;

    isDeleted: boolean;
    deletedBy?: mongoose.Types.ObjectId;
    deletedAt?: Date;
    deleteReason?: string;

    createdAt: Date;
    updatedAt: Date;
}
const ProductMasterSchema: Schema = new Schema(
    {
        /* =======================================================
           BASIC PRODUCT INFORMATION
        ======================================================= */

        productCode: {
            type: Number,
            required: true,
            unique: true,
            trim: true,
            index: true, // Fast searching
        },

        productName: {
            type: String,
            required: true,
            unique: true,
            index: true, // Fast searching
            trim: true,
        },

        genericName: {
            type: String,
            required: true,
            trim: true,
        },

        shortName: {
            type: String,
            required: true,
            uppercase: true, // Always store in capital
            trim: true,
            unique: true,
            index: true, // Fast searching
            minlength: 3,
            maxlength: 8,
        },

        description: {
            type: String,
            trim: true,
        },

        /* =======================================================
           PRODUCT SPECIFICATIONS
        ======================================================= */

        productType: {
            type: String,
        },

        dosageForm: {
            type: String,
            required: true,
        },

        strength: {
            type: String,
            required: true,
        },

        packSize: {
            type: String,
        },

        unit: {
            type: String,
        },

        therapeuticClass: [String],

        drugCategory: {
            type: String, // OTC / Prescription / Controlled
        },

        manufacturer: {
            type: String,
        },

        /* =======================================================
           STORAGE & SHELF INFORMATION
        ======================================================= */

        shelfLife: {
            type: Number, // In months
            required: true,
            min: 1,
            max: 120,
        },

        storageCondition: {
            type: [String],
            required: true,
        },

        status: {
            type: String,
            required: true, // Active / Inactive
            default: "Active",
            enum: ["Active", "Inactive"],
        },

        /* =======================================================
           REGULATORY INFORMATION
        ======================================================= */

        gtinNumber: {
            type: String,
            unique: true,
            sparse: true,
        },

        registrationNumber: {
            type: String,
        },

        drugLicenseNumber: {
            type: String,
        },

        /* =======================================================
           AUDIT INFORMATION
        ======================================================= */

        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            required: true,
        },

        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
        },
        updateReason: {
            type: String,
        },

        /* =======================================================
           SOFT DELETE INFORMATION
        ======================================================= */

        isDeleted: {
            type: Boolean,
            default: false,
            index: true, // Faster filtering
        },

        deletedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
        },

        deletedAt: {
            type: Date,
        },

        deleteReason: {
            type: String,
        },
    },
    {
        timestamps: true, // Auto adds createdAt & updatedAt
    }
);

export default mongoose.models.ProductMaster ||
    mongoose.model<IProduct>("ProductMaster", ProductMasterSchema);
