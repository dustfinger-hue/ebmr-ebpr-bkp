import mongoose, { Schema, Document } from "mongoose";

export interface IFacility extends Document {
  facilityCode: string;
  areaName: string;

  // Basic Information
  blockBuilding: string;
  floor: string;
  department: string;
  areaType: string;
  status: string;
  description: string;

  // Classification / GMP Info
  cleanRoomGrade: string;
  hvacZone: string;
  differentialPressure: number;
  differentialPressureMin: number;
  differentialPressureMax: number;
  temperatureMin: number;
  temperatureMax: number;
  humidityMin: number;
  humidityMax: number;
  particulatesMax: number;
  luxLevelMin: number;
  luxLevelMax: number;
  airChangesPerHour: number;

    // Area Capacity / Operational Info
    areaSize: number;
    areaSizeUnit: string;
    equipment: string[];
    maxEquipmentAllowed: number;
  maxOperatorsAllowed: number;
  materialFlowDirection: string;
  personnelFlow: string;

  // Qualification Information
  qualificationRequired: boolean;
  qualificationStatus: string;
  qualificationDate: Date;
  requalificationFrequency: number;

  // Monitoring & Compliance
  environmentalMonitoringRequired: boolean;
  environmentalReference: string;
  environmentalReferenceVersion: string;
  cleaningSopNumber: string;
  sanitizationFrequency: string;
  pestControlRequired: boolean;

  // Documentation
  layoutDocument: string;
  riskAssessmentId: string;
  validationProtocol: string;
  remarks: string;

  // Audit
  createdBy: mongoose.Types.ObjectId;
  updatedBy?: mongoose.Types.ObjectId;
  updateReason?: string;

  // Soft Delete
  isDeleted: boolean;
  deletedBy?: mongoose.Types.ObjectId;
  deletedAt?: Date;
  deleteReason?: string;

  createdAt: Date;
  updatedAt: Date;
}

const FacilityMasterSchema: Schema = new Schema(
  {
    // Basic Information
    facilityCode: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    areaName: {
      type: String,
      required: true,
      index: true,
      trim: true,
    },
    blockBuilding: {
      type: String,
      required: true,
    },
    floor: {
      type: String,
      required: true,
    },
    department: {
      type: String,
      required: true,
    },
    areaType: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      required: true,
      default: "Active",
      enum: ["Active", "Inactive", "Under Maintenance", "Decommissioned"],
    },
    description: {
      type: String,
      trim: true,
    },

    // Classification / GMP Info
    cleanRoomGrade: {
      type: String,
      enum: ["A", "B", "C", "D", "Non Classified", ""],
    },
    hvacZone: {
      type: String,
      trim: true,
    },
    differentialPressure: {
      type: Number,
    },
    differentialPressureMin: {
      type: Number,
    },
    differentialPressureMax: {
      type: Number,
    },
    temperatureMin: {
      type: Number,
    },
    temperatureMax: {
      type: Number,
    },
    humidityMin: {
      type: Number,
    },
    humidityMax: {
      type: Number,
    },
    particulatesMax: {
      type: Number,
    },
    luxLevelMin: {
      type: Number,
    },
    luxLevelMax: {
      type: Number,
    },
    airChangesPerHour: {
      type: Number,
    },

    // Area Capacity / Operational Info
    areaSize: {
      type: Number,
    },
    areaSizeUnit: {
      type: String,
      enum: ["sq ft", "sq m", ""],
    },
    equipment: {
      type: [String],
      default: [],
    },
    maxEquipmentAllowed: {
      type: Number,
    },
    maxOperatorsAllowed: {
      type: Number,
    },
    materialFlowDirection: {
      type: String,
      enum: ["Inward", "Outward", "Both", ""],
    },
    personnelFlow: {
      type: String,
      enum: ["Unidirectional", "Bidirectional", ""],
    },

    // Qualification Information
    qualificationRequired: {
      type: Boolean,
      default: false,
    },
    qualificationStatus: {
      type: String,
      enum: ["Not Qualified", "Pending", "Qualified", ""],
    },
    qualificationDate: {
      type: Date,
    },
    requalificationFrequency: {
      type: Number, // in months
    },

    // Monitoring & Compliance
    environmentalMonitoringRequired: {
      type: Boolean,
      default: false,
    },
    environmentalReference: {
      type: String,
      trim: true,
    },
    environmentalReferenceVersion: {
      type: String,
      trim: true,
    },
    cleaningSopNumber: {
      type: String,
      trim: true,
    },
    sanitizationFrequency: {
      type: String,
      enum: ["Daily", "Weekly", "Monthly", ""],
    },
    pestControlRequired: {
      type: Boolean,
      default: false,
    },

    // Documentation
    layoutDocument: {
      type: String,
      trim: true,
    },
    riskAssessmentId: {
      type: String,
      trim: true,
    },
    validationProtocol: {
      type: String,
      trim: true,
    },
    remarks: {
      type: String,
      trim: true,
    },

    // Audit Information
    createdBy: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    updatedBy: {
      type: Schema.Types.ObjectId,
      ref: "User",
    },
    updateReason: {
      type: String,
    },

    // Soft Delete
    isDeleted: {
      type: Boolean,
      default: false,
      index: true,
    },
    deletedBy: {
      type: Schema.Types.ObjectId,
      ref: "User",
    },
    deletedAt: {
      type: Date,
    },
    deleteReason: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

export default mongoose.models.FacilityMaster ||
  mongoose.model<IFacility>("FacilityMaster", FacilityMasterSchema);
