import mongoose, { Schema, Document } from "mongoose";

export interface IEquipment extends Document {
    equipmentCode: number;
    equipmentName: string;
    equipmentType: string;
    category: string;
    modelNumber: string;
    serialNumber: string;
    assetTag: string;
    manufacturer: string;

    // Location Details
    site: string;
    building: string;
    floor: string;
    department: string;
    area: string;
    roomNumber: string;
    installationLocation: string;

    // Qualification / Validation
    qualificationRequired: boolean;
    qualificationStatus: string;
    iqDate: Date;
    oqDate: Date;
    pqDate: Date;

    // Calibration Details
    calibrationRequired: boolean;
    calibrationFrequency: number;
    calibrationStandard: string;
    lastCalibrationDate: Date;
    nextCalibrationDate: Date;
    calibrationStatus: string;

    // Maintenance Details
    maintenanceRequired: boolean;
    maintenanceType: string;
    maintenanceFrequency: number;
    lastMaintenanceDate: Date;
    nextMaintenanceDate: Date;
    maintenanceVendor: string;

    // Operational Information
    cleaningStatus: string;
    lastProductProcessed: string;
    currentStatus: string;

    // Critical Process Parameters (CPP)
    cppParameters: Array<{
        parameterName: string;
        minValue: number;
        maxValue: number;
    }>;

    // Documentation
    sopNumber: string;
    manualDocument: string;
    qualificationProtocol: string;
    calibrationCertificate: string;
    maintenanceRecord: string;

    // Audit
    createdBy: mongoose.Types.ObjectId;
    updatedBy?: mongoose.Types.ObjectId;
    updateReason?: string;

    // Soft Delete
    isDeleted: boolean;
    deletedBy?: mongoose.Types.ObjectId;
    deletedAt?: Date;
    deleteReason?: string;

    createdAt: Date;
    updatedAt: Date;
}

const EquipmentMasterSchema: Schema = new Schema(
    {
        // Basic Equipment Information
        equipmentCode: {
            type: Number,
            required: true,
            unique: true,
            index: true,
        },
        equipmentName: {
            type: String,
            required: true,
            index: true,
            trim: true,
        },
        equipmentType: {
            type: String,
            required: true,
        },
        category: {
            type: String,
            required: true,
        },
        modelNumber: {
            type: String,
            trim: true,
        },
        serialNumber: {
            type: String,
            trim: true,
        },
        assetTag: {
            type: String,
            trim: true,
        },

        manufacturer: {
            type: String,
            trim: true,
        },



        // Location Details
        site: {
            type: String,
            trim: true,
        },
        building: {
            type: String,
            trim: true,
        },
        floor: {
            type: String,
            trim: true,
        },
        department: {
            type: String,
            trim: true,
        },
        area: {
            type: String,
            trim: true,
        },
        roomNumber: {
            type: String,
            trim: true,
        },
        installationLocation: {
            type: String,
            trim: true,
        },

        // Qualification / Validation
        qualificationRequired: {
            type: Boolean,
            default: false,
        },
        qualificationStatus: {
            type: String,
        },
        iqDate: {
            type: Date,
        },
        oqDate: {
            type: Date,
        },
        pqDate: {
            type: Date,
        },

        // Calibration Details
        calibrationRequired: {
            type: Boolean,
            default: false,
        },
        calibrationFrequency: {
            type: Number, // in months
        },
        calibrationStandard: {
            type: String,
            trim: true,
        },
        lastCalibrationDate: {
            type: Date,
        },
        nextCalibrationDate: {
            type: Date,
        },
        calibrationStatus: {
            type: String,
        },

        // Maintenance Details
        maintenanceRequired: {
            type: Boolean,
            default: false,
        },
        maintenanceType: {
            type: String,
        },
        maintenanceFrequency: {
            type: Number, // in months
        },
        lastMaintenanceDate: {
            type: Date,
        },
        nextMaintenanceDate: {
            type: Date,
        },
        maintenanceVendor: {
            type: String,
            trim: true,
        },

        // Operational Information

        cleaningStatus: {
            type: String,
        },
        lastProductProcessed: {
            type: String,
        },
        currentStatus: {
            type: String,
            required: true,
            default: "Active",
            enum: ["Active", "Under Maintenance", "Breakdown", "Retired", "Decommissioned"],
        },


        // Critical Process Parameters (CPP)
        cppParameters: {
            type: Array,
            of: new Schema({
                parameterName: { type: String, trim: true },
                minValue: { type: Number },
                maxValue: { type: Number },
                unit: { type: String }
            }, { _id: false }),
            default: [],
        },

        // Documentation
        sopNumber: {
            type: String,
            trim: true,
        },
        manualDocument: {
            type: String,
            trim: true,
        },
        qualificationProtocol: {
            type: String,
            trim: true,
        },
        calibrationCertificate: {
            type: String,
            trim: true,
        },
        maintenanceRecord: {
            type: String,
            trim: true,
        },

        // Audit Information
        createdBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
            required: true,
        },
        updatedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
        },
        updateReason: {
            type: String,
        },

        // Soft Delete
        isDeleted: {
            type: Boolean,
            default: false,
            index: true,
        },
        deletedBy: {
            type: Schema.Types.ObjectId,
            ref: "User",
        },
        deletedAt: {
            type: Date,
        },
        deleteReason: {
            type: String,
        },
    },
    {
        timestamps: true,
    }
);

export default mongoose.models.EquipmentMaster ||
    mongoose.model<IEquipment>("EquipmentMaster", EquipmentMasterSchema);
