import mongoose from "mongoose";

// ─── Sub-schema for signature entries (monitoredBy, checkedBy, verifiedBy) ──
const SignatureEntrySchema = new mongoose.Schema(
  {
    name: { type: String },
    designation: { type: String },
    department: { type: String },
    signatureId: { type: mongoose.Schema.Types.ObjectId, ref: "Signature" },
    signatureHash: { type: String },
  },
  { _id: false }
);

// ─── Environmental Log Schema ─────────────────────────────────────────
const EnvironmentalLogSchema = new mongoose.Schema(
  {
    facilityCode: { type: String },
    dateTime: { type: Date, required: true },
    differentialPressure: { type: Number },
    temperature: { type: Number },
    humidity: { type: Number },
    particulates: { type: Number },
    luxLevel: { type: Number },
    status: {
      type: String,
      enum: ["Within Limit", "Warning", "Alarm"],
      default: "Within Limit",
    },
    monitoredBy: { type: SignatureEntrySchema },
    checkedBy: { type: SignatureEntrySchema },
    verifiedBy: { type: SignatureEntrySchema },
    rangeReference: { type: mongoose.Schema.Types.Mixed },
  },
  { timestamps: true }
);

export default mongoose.models.EnvironmentalLog ||
  mongoose.model("EnvironmentalLog", EnvironmentalLogSchema);
