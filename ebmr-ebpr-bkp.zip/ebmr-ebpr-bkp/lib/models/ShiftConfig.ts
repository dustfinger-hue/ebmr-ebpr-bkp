import mongoose from 'mongoose';

const ShiftConfigSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      default: 'Default Shifts',
    },
    numberOfShifts: {
      type: Number,
      required: true,
      min: 1,
      max: 4,
      default: 3,
    },
    hoursPerShift: {
      type: Number,
      required: true,
      min: 1,
      max: 24,
      default: 8,
    },
    shiftNames: {
      type: [String],
      default: ['Morning', 'Afternoon', 'Evening', 'Night'],
    },
    startTime: {
      type: String,
      default: '06:00',
    },
    lastModifiedBy: {
      type: String,
      default: 'Admin',
    },
  },
  { timestamps: true }
);

export default mongoose.models.ShiftConfig ||
  mongoose.model('ShiftConfig', ShiftConfigSchema);