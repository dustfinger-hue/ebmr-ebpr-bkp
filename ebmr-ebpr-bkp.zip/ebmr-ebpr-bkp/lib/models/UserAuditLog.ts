import mongoose, { Schema } from "mongoose";

const AuditLogSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    userRole: {
      type: String,
    },

    moduleName: {
      type: String,
      required: true,
    },

    recordId: {
      type: Schema.Types.ObjectId,
      required: true,
    },

    action: {
      type: String,
      enum: [
        "CREATE",
        "UPDATE",
        "DELETE",
        "APPROVE",
        "REJECT",
        "LOGIN",
        "LOGOUT"
      ],
      required: true,
    },

    oldData: {
      type: Schema.Types.Mixed,
    },

    newData: {
      type: Schema.Types.Mixed,
    },

    changedFields: {
      type: [String],
    },

    changeReason: {
      type: String,
    },

    ipAddress: {
      type: String,
    },

    userAgent: {
      type: String,
    }
  },
  { timestamps: true }
);

export default mongoose.models.AuditLog ||
  mongoose.model("AuditLog", AuditLogSchema);