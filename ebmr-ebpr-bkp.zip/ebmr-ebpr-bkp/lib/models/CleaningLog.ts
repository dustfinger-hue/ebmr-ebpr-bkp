import mongoose from "mongoose";

// ─── Sub-schema for signature entries (performedBy, checkedBy, verifiedBy) ──
const SignatureEntrySchema = new mongoose.Schema(
  {
    name: { type: String },
    designation: { type: String },
    department: { type: String },
    signatureId: { type: mongoose.Schema.Types.ObjectId, ref: "Signature" },
    signatureHash: { type: String },
  },
  { _id: false }
);
const userInfoSchema = new mongoose.Schema(
  {
    name: { type: String },
    designation: { type: String },
    department: { type: String },
    signatureId: { type: mongoose.Schema.Types.ObjectId, ref: "Signature" },
  },
  { _id: false }
);
// ─── Cleaning Log Schema ──────────────────────────────────────────────
const CleaningLogSchema = new mongoose.Schema(
  {
    facilityCode: { type: String },
    date: { type: Date, required: true },
    productName: { type: String },
    batchNo: { type: String },
    cleaningType: { type: String, required: true },
    cleaningMethod: { type: String, required: true },
    startDateTime: { type: Date },
    cleaningStartedBy: { type: userInfoSchema },
    endDateTime: { type: Date },
    cleaningStoppedBy: { type: userInfoSchema },
    status: {
      type: String,
      enum: ["Completed", "In-Progress"],
      default: "In-Progress",
    },
    checkedBy: { type: SignatureEntrySchema },
    verifiedBy: { type: SignatureEntrySchema },
  },
  { timestamps: true }
);

export default mongoose.models.CleaningLog ||
  mongoose.model("CleaningLog", CleaningLogSchema);