import mongoose, { Schema } from "mongoose";

const LotAllocationSchema = new Schema({
    lotNumber: { type: String, required: true },
    quantity: { type: Number, required: true, min: 0 },
}, { _id: false });

const MaterialAllocationSchema = new Schema({
    materialCode: { type: String, required: true },
    materialName: { type: String, required: true },
    materialCategory: { type: String, required: true },
    uom: { type: String, required: true },
    totalRequiredQuantity: { type: Number, required: true, min: 0 },
    lots: { type: [LotAllocationSchema], default: [] },
}, { _id: false });

const AllocatedBySubSchema = new Schema({
    userId: { type: Schema.Types.ObjectId, ref: "User", required: true },
    fullName: { type: String, required: true },
    designation: { type: String, required: true },
    department: { type: String, required: true },
    employeeId: { type: String, required: true },
}, { _id: false });

const MatetrialAllocationRecord = new Schema({
    processOrderId: { type: Schema.Types.ObjectId, ref: "ProcessOrder", required: true, index: true },
    processOrderCode: { type: String, required: true },
    productName: { type: String, required: true },
    batchNumber: { type: String, default: null },
    status: {
        type: String,
        required: true,
        enum: ["Pending", "Allocated"],
        default: "Pending"
    },
    materials: { type: [MaterialAllocationSchema], default: [] },
    lotAllocatedBy: { type: AllocatedBySubSchema, required: true },
    allocatedAt: { type: Date, default: Date.now },
}, { timestamps: true });

MatetrialAllocationRecord.index({ processOrderId: 1, status: 1 });

export default mongoose.models.MatetrialAllocationRecord || mongoose.model("MatetrialAllocationRecord", MatetrialAllocationRecord);
