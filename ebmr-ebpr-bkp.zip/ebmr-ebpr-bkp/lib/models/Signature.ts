import mongoose from "mongoose";

export interface ISignature {
    module: string;
    signatoryId: string;       // The actual signer (whose credentials were used)
    signatoryName: string;
    signatoryDesignation: string;
    signatoryDepartment: string;
    signatoryAuthorizationLevel: string;
    signatorySequence: number; // Optional - for multi-level signing
    loggedInUserId: string;     // The user who performed the action (logged in user)
    loggedInUserName: string;   // Name of the logged-in user
    loggedInUserDepartment: string;
    loggedInUserDesignation: string;
    signatureHash: string;
    signAction?: 'approved' | 'rejected' | 'reverted'; // Action performed by signatory
    associatedRecordId?: mongoose.Types.ObjectId; // Optional reference to the document being signed
    associatedRecordType?: string; // Type of the associated document (e.g., 'BatchManufacturingTemplate')
    timestamp: Date;
    expiresAt?: Date | undefined;          // Optional - expire hoga toh hoga warna nahi
    status: "pending" | "completed" | "expired" | "rejected";
    remarks?: string;
    ipAddress?: string;
    userAgent?: string;
}

const SignatureSchema = new mongoose.Schema<ISignature>(
    {

        // Signatory Details (Original signer)
        module: {
            type: String,
            required: true,
        },
        signatoryId: {
            type: String,
            required: true,
        },
        signatoryName: {
            type: String,
            required: true,
        },
        signatoryDesignation: {
            type: String,
            required: true,
        },
        signatoryDepartment: {
            type: String,
            required: true,
        },
        signatoryAuthorizationLevel: {
            type: String,
            required: true,
        },
        signatorySequence: {
            type: Number,
            required: true,
        },
        remarks: {
            type: String,
            required: true,
        },
        signatureHash: {
            type: String,
            required: true,
        },

        // Action performed by the signatory
        signAction: {
            type: String,
            enum: ['approved', 'rejected', 'reverted'],
            default: 'approved',
        },

        // Performed By User (Logged in user)
        loggedInUserId: {
            type: String,
            required: true,
        },
        loggedInUserName: {
            type: String,
            required: true,
        },
        loggedInUserDepartment: {
            type: String,
            required: true,
        },
        loggedInUserDesignation: {
            type: String,
            required: true,
        },
        timestamp: {
            type: Date,
            default: Date.now,
        },

        //Associated Document Reference (Optional - can be used to link to the document being signed)
        associatedRecordId: {
            type: mongoose.Schema.Types.ObjectId,
            refPath: 'associatedRecordType', // Dynamic reference to the associated document collection
        },
        associatedRecordType: {
            type: String, // e.g., 'BatchManufacturingTemplate', 'ChangeRequest', etc.
        },

        // TTL Field 
        expiresAt: {
            type: Date,
            default: () => new Date(Date.now() + 5 * 60 * 1000), // 5 minutes
            index: { expires: 0 } // Exact time par delete
        },
        status: {
            type: String,
            enum: ["pending", "signed", "expired", "rejected"],
            default: "pending", // CHANGE: "completed" se "pending" kar diya
        },

        // System Metadata
        ipAddress: {
            type: String,
        },
        userAgent: {
            type: String,
        },
    },
    { timestamps: true }
);

// Indexes for better query performance
SignatureSchema.index({ signatoryId: 1, module: 1 });
SignatureSchema.index({ module: 1, status: 1 });
SignatureSchema.index({ status: 1, expiresAt: 1 }); // For cleanup queries

export default mongoose.models.Signature ||
    mongoose.model<ISignature>("Signature", SignatureSchema);