import mongoose, { Schema, Document } from "mongoose";

export interface IMaterial extends Document {
    materialCode: string;
    materialName: string;
    category: string;
}

const MaterialMasterSchema: Schema = new Schema({
    category: { type: String, required: true },
    materialCode: { type: String, required: true, unique: true, index: true },

    materialName: { type: String, required: true },
    shortName: { type: String, required: true },
    description: { type: String, required: true },

    storageCondition: { type: Array, required: true },
    unitOfMeasurement: { type: String, required: true },

    humiditySensitive: { type: Boolean, required: true },
    heatSensitive: { type: Boolean, required: true },
    lightSensitive: { type: Boolean, required: true },
    flammable: { type: Boolean, required: true },
    corrosive: { type: Boolean, required: true },
    oxidizing: { type: Boolean, required: true },

    type: { type: String, required: true },

    status: { type: String, required: true },

    createdBy: { type: Schema.Types.ObjectId, ref: "User", required: true },
    createdAt: { type: Date, default: Date.now },

    updatedBy: { type: Schema.Types.ObjectId, ref: "User" },
    updateAt: { type: Date },
    updateReason: { type: String },

    isDeleted: { type: Boolean, default: false },
    deletedBy: { type: Schema.Types.ObjectId, ref: "User" },
    deletedAt: { type: Date },
    deleteReason: { type: String },
}, { timestamps: true }
);

export default mongoose.models.MaterialMaster ||
    mongoose.model<IMaterial>("MaterialMaster", MaterialMasterSchema);