
"use client";

import { Button, Form, Input, Modal, Space, Typography, message, Spin, Alert, Tag, Tooltip } from "antd";
import { useState } from "react";
import { CheckCircleOutlined, InfoCircleOutlined, SafetyCertificateOutlined } from "@ant-design/icons";

const { Text } = Typography;

interface RoleBasedSigningProps {
    module: string;
    levelOfAuthorization: string;
    sequence: number;
    onSignComplete?: (signatureData: any) => void; // ✅ Changed: ab hash aur id bhejega
    apiUrl?: string;
    disableProp?: boolean;
}

type SigningState = 'idle' | 'signing' | 'completed' | 'error';

export default function RoleBasedSigning({ module, levelOfAuthorization, sequence, onSignComplete, disableProp = true }: RoleBasedSigningProps) {
    const [modalOpen, setModalOpen] = useState(false);
    const [employeeId, setEmployeeId] = useState("");
    const [password, setPassword] = useState("");
    const [signingState, setSigningState] = useState<SigningState>('idle');
    const [errorMessage, setErrorMessage] = useState("");

    const resetForm = () => {
        setEmployeeId("");
        setPassword("");
        setSigningState('idle');
        setErrorMessage("");
    };

    const handleOpen = () => {
        resetForm();
        setModalOpen(true);
    };

    const handleClose = () => {
        if (signingState === 'signing') return;
        setModalOpen(false);
    };

    const handleSign = async () => {
        if (!employeeId.trim()) {
            message.error("Please enter Employee ID or Email");
            return;
        }
        if (!password.trim()) {
            message.error("Please enter password");
            return;
        }

        setSigningState('signing');
        setErrorMessage("");

        try {
            const res = await fetch("/api/user/role-based-signing/sign", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
                body: JSON.stringify({
                    module,
                    levelOfAuthorization,
                    sequence,
                    employeeId: employeeId.trim(),
                    password: password.trim(),
                }),
            });

            const data = await res.json();

            if (data.success && data.data) {

                // ✅ Success: Directly send hash and id to parent
                message.success(`Welcome ${data.data.name || "User"}! Signature created successfully!`);

                // ✅ Close modal
                setModalOpen(false);

                // ✅ Send data to parent component
                if (onSignComplete) {
                    onSignComplete(data.data);
                }

                // Reset state
                resetForm();

            } else {
                setErrorMessage(data.message || "Failed to sign");
                setSigningState('error');
            }
        } catch (error) {
            console.error("Signing error:", error);
            setErrorMessage("An error occurred while signing");
            setSigningState('error');
        }
    };

    return (
        <>
            <Button
                type="primary"
                icon={<SafetyCertificateOutlined />}
                onClick={handleOpen}
                size="middle"
                block
                disabled={disableProp}
            >
                Sign
            </Button>

            <Modal
                title={
                    <Space>
                        <SafetyCertificateOutlined style={{ color: "#722ed1" }} />
                        <Text strong>Role Based Signing</Text>
                    </Space>
                }
                open={modalOpen}
                onCancel={handleClose}
                footer={null}
                width={520}
                maskClosable={signingState !== 'signing'}
                destroyOnHidden
            >
                <Space direction="vertical" style={{ width: "100%" }} size="middle">
                    {/* Module Info */}
                    <div style={{
                        background: "rgba(114,46,209,0.06)",
                        borderRadius: 8,
                        padding: "14px 16px",
                        border: "1px solid rgba(114,46,209,0.15)",
                    }}>
                        <Space direction="vertical" size={4} style={{ width: "100%" }}>
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                                <Text type="secondary" style={{ fontSize: 12 }}>Module</Text>
                                <Space size={4}>
                                    <Tag color="gold" style={{ fontSize: 10, lineHeight: "16px", padding: "0 4px", margin: 0 }}>
                                        21 CFR Part 11
                                    </Tag>
                                    <Tooltip title={
                                        <div style={{ fontSize: 12, maxWidth: 300 }}>
                                            <strong>21 CFR Part 11 Compliance</strong><br /><br />
                                            This electronic signature is compliant with FDA 21 CFR Part 11 regulations.
                                            By signing, you confirm that:
                                            <ul style={{ margin: "4px 0", paddingLeft: 16 }}>
                                                <li>You are the authorized signatory</li>
                                                <li>You have reviewed the document</li>
                                                <li>Your identity has been verified</li>
                                                <li>This signature is legally equivalent to a handwritten signature</li>
                                            </ul>
                                        </div>
                                    }>
                                        <InfoCircleOutlined style={{ color: "#722ed1", cursor: "pointer", fontSize: 16 }} />
                                    </Tooltip>
                                </Space>
                            </div>
                            <Text strong style={{ fontSize: 15 }}>{module}</Text>
                            <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
                                <Tag color="purple">{levelOfAuthorization}</Tag>
                                <Tag color="blue">Seq #{sequence}</Tag>
                            </div>
                        </Space>
                    </div>

                    {/* IDLE STATE - Show Form */}
                    {signingState === 'idle' && (
                        <Form layout="vertical" style={{ marginTop: 4 }}>
                            <Form.Item label="Employee ID / Email" required>
                                <Input
                                    placeholder="Enter your employee ID or email"
                                    value={employeeId}
                                    onChange={(e) => setEmployeeId(e.target.value)}
                                    size="large"
                                />
                            </Form.Item>
                            <Form.Item label="Password" required>
                                <Input.Password
                                    placeholder="Enter your password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    size="large"
                                />
                            </Form.Item>
                            <Button
                                type="primary"
                                block
                                size="large"
                                onClick={handleSign}
                                icon={<SafetyCertificateOutlined />}
                                loading={signingState === 'idle' ? false : true}
                                style={{ marginTop: 8 }}
                            >
                                Sign
                            </Button>
                        </Form>
                    )}

                    {/* SIGNING STATE - Loading */}
                    {signingState === 'signing' && (
                        <div style={{ textAlign: "center", padding: "30px 0" }}>
                            <Spin size="large" />
                            <div style={{ marginTop: 16 }}>
                                <Text type="secondary">Verifying credentials and creating signature...</Text>
                            </div>
                        </div>
                    )}

                    {/* ERROR STATE */}
                    {signingState === 'error' && (
                        <>
                            <Alert
                                type="error"
                                message="Signing Failed"
                                description={errorMessage}
                                showIcon
                            />
                            <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
                                <Button type="primary" onClick={() => setSigningState('idle')}>
                                    Try Again
                                </Button>
                                <Button onClick={handleClose}>
                                    Cancel
                                </Button>
                            </div>
                        </>
                    )}
                </Space>
            </Modal>
        </>
    );
}