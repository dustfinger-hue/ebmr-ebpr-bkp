"use client";

import { Space, Tag, Avatar, Tooltip, Badge, Typography } from "antd";
const { Text } = Typography;
import {
    UserOutlined,
    TeamOutlined,
    CheckCircleOutlined,
} from "@ant-design/icons";
import { useSigningContext } from "./SigningContext";
import { seqColors } from "./types";

export default function SignatoriesDisplay() {
    const { hierarchyData, signedByUserIds, selectedPerson } = useSigningContext();
    const authorizedPersons = hierarchyData?.authorizedPersons || [];

    return (
        <div style={{ marginBottom: 24 }}>
            <Space size={8} style={{ marginBottom: 16 }}>
                <TeamOutlined style={{ color: "#1890ff", fontSize: 16 }} />
                <Text strong style={{ fontSize: 15 }}>
                    Authorized Signatories
                </Text>
                <Tag bordered={false} color="default" style={{ borderRadius: 12, fontSize: 11, lineHeight: "20px", marginLeft: 4 }}>
                    {authorizedPersons.length} available
                </Tag>
            </Space>

            <div
                style={{
                    display: "flex",
                    flexWrap: "wrap",
                    gap: 12,
                }}
            >
                {authorizedPersons.map((person) => {
                    const isSigned = signedByUserIds.includes(person.userId);
                    const isSelected = selectedPerson === person.userId;
                    const levelColor = seqColors[person.authorizationLevel] || "default";
                    const seqColor = seqColors[String(person.authorizationSequence ?? "")] || "default";

                    // Determine card style based on state
                    let borderColor = "rgba(255,255,255,0.08)";
                    let bgGradient = "rgba(255,255,255,0.04)";
                    let avatarBg = "rgba(255,255,255,0.15)";
                    let avatarColor = "rgba(255,255,255,0.5)";
                    let nameColor = "rgba(255,255,255,0.85)";
                    let subtextColor = "rgba(255,255,255,0.45)";
                    let boxShadow = "none";
                    let badgeIcon = null;

                    if (isSigned) {
                        // 🟢 GREEN - Already signed
                        borderColor = "rgba(82, 196, 26, 0.4)";
                        bgGradient = "linear-gradient(135deg, rgba(82,196,26,0.12) 0%, rgba(82,196,26,0.04) 100%)";
                        avatarBg = "#52c41a";
                        avatarColor = "#fff";
                        nameColor = "rgba(255,255,255,0.9)";
                        subtextColor = "rgba(82,196,26,0.8)";
                        badgeIcon = (
                            <Badge
                                count={<CheckCircleOutlined style={{ color: "#52c41a", fontSize: 14 }} />}
                                style={{ boxShadow: "none", backgroundColor: "transparent" }}
                            />
                        );
                    } else if (isSelected) {
                        // 🔵 BLUE - Currently selected
                        borderColor = "#1677ff";
                        bgGradient = "linear-gradient(135deg, rgba(22,119,255,0.12) 0%, rgba(22,119,255,0.06) 100%)";
                        avatarBg = "#1677ff";
                        avatarColor = "#fff";
                        nameColor = "#fff";
                        subtextColor = "rgba(255,255,255,0.65)";
                        boxShadow = "0 4px 14px rgba(22, 119, 255, 0.15)";
                        badgeIcon = (
                            <div
                                style={{
                                    position: "absolute",
                                    top: -1,
                                    right: -1,
                                    width: 20,
                                    height: 20,
                                    background: "#1677ff",
                                    borderRadius: "0 12px 0 12px",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                }}
                            >
                                <CheckCircleOutlined style={{ color: "#fff", fontSize: 11 }} />
                            </div>
                        );
                    }

                    return (
                        <Tooltip
                            key={person.userId}
                            title={
                                <div style={{ textAlign: "center" }}>
                                    <Text strong style={{ color: "#fff" }}>{person.name}</Text>
                                    <br />
                                    <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 11 }}>
                                        {person.designation} • {person.department}
                                    </Text>
                                    {isSigned && (
                                        <>
                                            <br />
                                            <Text style={{ color: "#52c41a", fontSize: 11 }}>✓ Already Signed</Text>
                                        </>
                                    )}
                                </div>
                            }
                            mouseEnterDelay={0.3}
                        >
                            <div
                                style={{
                                    display: "inline-flex",
                                    alignItems: "center",
                                    gap: 10,
                                    padding: "10px 16px",
                                    borderRadius: 12,
                                    border: `2px solid ${borderColor}`,
                                    background: bgGradient,
                                    transition: "all 0.25s ease",
                                    boxShadow,
                                    flex: "1 0 auto",
                                    minWidth: 200,
                                    maxWidth: "100%",
                                    position: "relative",
                                    userSelect: "none",
                                    cursor: "default",
                                    opacity: isSigned ? 0.85 : 1,
                                }}
                            >
                                {badgeIcon}

                                <Avatar
                                    size={38}
                                    icon={<UserOutlined />}
                                    style={{
                                        backgroundColor: avatarBg,
                                        color: avatarColor,
                                        flexShrink: 0,
                                        boxShadow: isSelected ? "0 2px 8px rgba(22, 119, 255, 0.3)" : "none",
                                    }}
                                />
                                <div style={{ flex: 1, minWidth: 0 }}>
                                    <div
                                        style={{
                                            display: "flex",
                                            alignItems: "center",
                                            gap: 6,
                                            marginBottom: 2,
                                        }}
                                    >
                                        <Text
                                            strong
                                            style={{
                                                fontSize: 13,
                                                color: nameColor,
                                                whiteSpace: "nowrap",
                                                overflow: "hidden",
                                                textOverflow: "ellipsis",
                                            }}
                                        >
                                            {person.name}
                                        </Text>
                                        {person.authorizationSequence && (
                                            <Tag
                                                color={seqColor}
                                                style={{
                                                    fontSize: 10,
                                                    lineHeight: "16px",
                                                    padding: "0 6px",
                                                    borderRadius: 4,
                                                    margin: 0,
                                                    fontWeight: 600,
                                                }}
                                            >
                                                #{person.authorizationSequence}
                                            </Tag>
                                        )}
                                    </div>
                                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                                        <Tag
                                            color={isSigned ? "green" : isSelected ? levelColor : "default"}
                                            style={{
                                                fontSize: 10,
                                                lineHeight: "16px",
                                                padding: "0 6px",
                                                borderRadius: 4,
                                                margin: 0,
                                                fontWeight: 600,
                                                opacity: isSigned || isSelected ? 1 : 0.7,
                                            }}
                                        >
                                            Lvl {person.authorizationLevel}
                                        </Tag>
                                        <Text
                                            style={{
                                                fontSize: 11,
                                                whiteSpace: "nowrap",
                                                overflow: "hidden",
                                                textOverflow: "ellipsis",
                                                color: subtextColor,
                                            }}
                                        >
                                            {isSigned ? "Signed ✓" : person.designation}
                                        </Text>
                                    </div>
                                </div>
                            </div>
                        </Tooltip>
                    );
                })}
            </div>
        </div>
    );
}