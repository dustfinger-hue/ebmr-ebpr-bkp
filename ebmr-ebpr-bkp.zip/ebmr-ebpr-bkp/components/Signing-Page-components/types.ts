"use client";

export type SignAction = 'approved' | 'rejected' | 'reverted';

export interface AuthorizedPerson {
    userId: string;
    name: string;
    designation: string;
    department: string;
    authorizationLevel: string;
    authorizationSequence?: number;
}

export interface VerifyResponse {
    success: boolean;
    message: string;
    data?: {
        module: string;
        signRequired: number;
        authorizedPersons: AuthorizedPerson[];
        signedByUserIds: string[];
        currentSequence: number;
    };
}

export interface SignResponse {
    success: boolean;
    message: string;
    data?: {
        signatureId: string;
        module: string;
        status: string;
        expiresAt: string;
        signatureHash: string;
        signingSequence: number;
        signAction: SignAction;
    };
}

export interface SignButtonProps {
    onSignComplete?: () => void;
    module: string;
    documentId?: string;
    schemaTitle?: string;
    data: any;
    label?: string;
    apiUrl: string;
}

export type PageMessageType = 'success' | 'error' | 'info' | 'warning';

export interface PageMessage {
    type: PageMessageType;
    message: string;
}

export type SigningState = 'form' | 'pending' | 'completed';

export const seqColors: Record<string, string> = {
    "1": "green",
    "2": "blue",
    "3": "purple",
    "4": "orange",
    "5": "red",
};

export const signActionColors: Record<SignAction, string> = {
    approved: 'green',
    rejected: 'red',
    reverted: 'orange',
};

export const signActionLabels: Record<SignAction, string> = {
    approved: '✅ Approve',
    rejected: '❌ Reject',
    reverted: '🔄 Revert',
};