"use client";

import { Button } from "antd";
import { SafetyCertificateOutlined } from "@ant-design/icons";
import { useSigningContext } from "./SigningContext";

export default function SignTriggerButton() {
    const { setSigningModalOpen } = useSigningContext();

    return (
        <Button
            type="primary"
            // size="large"
            icon={<SafetyCertificateOutlined />}
            onClick={() => setSigningModalOpen(true)}
        >
            Sign Document
        </Button>
    );
}