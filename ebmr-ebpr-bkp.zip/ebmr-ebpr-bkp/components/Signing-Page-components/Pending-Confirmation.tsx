"use client";

import { Alert, Button, Card, Row, Col, Space, Typography, Avatar, Tag, Progress } from "antd";
import {
    ExclamationCircleOutlined,
    SafetyCertificateOutlined,
    ClockCircleOutlined,
    CheckCircleOutlined,
    CloseCircleOutlined,
    CopyOutlined,
    UserOutlined,
} from "@ant-design/icons";
import { useSigningContext } from "./SigningContext";
import PageMessageAlert from "./PageMessageAlert";
import { useEffect, useState } from "react";

const { Text } = Typography;

export default function PendingConfirmation() {
    const {
        signAction,
        signatureHash,
        signatureId,
        module,
        selectedPersonDetails,
        expiresAt,
        confirming,
        handleConfirm,
        handleCancelPending,
        handleExpire,
        setPageMessage,
    } = useSigningContext();

    const [timeLeft, setTimeLeft] = useState<number>(300);
    const [hashCopied, setHashCopied] = useState(false);

    // ── Timer Logic ──
    useEffect(() => {
        if (!expiresAt) return;

        const interval = setInterval(() => {
            const now = new Date();
            const diff = expiresAt.getTime() - now.getTime();

            if (diff <= 0) {
                setTimeLeft(0);
                handleExpire();
                clearInterval(interval);
            } else {
                setTimeLeft(Math.floor(diff / 1000));
            }
        }, 1000);

        return () => clearInterval(interval);
    }, [expiresAt, handleExpire]);

    // ── Format timeLeft as MM:SS ──
    const formatTime = (seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    };

    // ── Calculate timer progress ──
    const timerProgress = (timeLeft / 300) * 100;
    const timerColor = timeLeft > 120 ? '#52c41a' : timeLeft > 60 ? '#faad14' : '#ff4d4f';

    const handleCopyHash = () => {
        navigator.clipboard.writeText(signatureHash).then(() => {
            setHashCopied(true);
            setPageMessage({ type: 'success', message: 'Hash copied to clipboard!' });
            setTimeout(() => {
                setHashCopied(false);
                setPageMessage(null);
            }, 2000);
        }).catch(() => {
            setPageMessage({ type: 'error', message: 'Failed to copy hash.' });
        });
    };

    return (
        <div style={{ padding: "24px 32px 28px" }}>
            <PageMessageAlert />
            {/* Warning Alert */}
            <Alert
                message="Signature Pending Confirmation"
                description={
                    <span>
                        This signature has been created but not yet finalized. Please confirm within <Text strong>{formatTime(timeLeft)}</Text> to complete the signing process, or it will expire automatically.
                    </span>
                }
                type="warning"
                showIcon
                icon={<ExclamationCircleOutlined />}
                style={{
                    borderRadius: 10,
                    border: "1px solid #ffe58f",
                    marginBottom: 24,
                }}
            />

            <Row gutter={24}>
                {/* Left Column: Signature Hash */}
                <Col span={15}>
                    <Card
                        title={
                            <Space>
                                <SafetyCertificateOutlined style={{ color: "#1890ff" }} />
                                <Text strong>Signature Hash</Text>
                            </Space>
                        }
                        size="small"
                        style={{
                            borderRadius: 10,
                            marginBottom: 16,
                        }}
                        styles={{ body: { padding: "16px 20px" } }}
                    >
                        <div
                            style={{
                                // background: "#f5f5f5",
                                borderRadius: 8,
                                padding: "12px 16px",
                                fontFamily: "monospace",
                                fontSize: 13,
                                wordBreak: "break-all",
                                border: "1px solid #2e2d2d",
                                position: "relative",
                                maxHeight: 100,
                                overflow: "auto",
                            }}
                        >
                            {signatureHash}
                        </div>
                        <Button
                            type="dashed"
                            size="small"
                            icon={<CopyOutlined />}
                            onClick={handleCopyHash}
                            style={{ marginTop: 8, borderRadius: 6 }}
                        >
                            {hashCopied ? 'Copied!' : 'Copy Hash'}
                        </Button>
                    </Card>

                    {/* Module Info Card */}
                    <Card
                        size="small"
                        style={{ borderRadius: 10 }}
                        styles={{ body: { padding: "12px 20px" } }}
                    >
                        <Space direction="vertical" size={4} style={{ width: '100%' }}>
                            <Row justify="space-between" style={{ marginBottom: 8 }}>
                                <Text type="secondary" style={{ fontSize: 12 }}>Module</Text>
                                <Text strong style={{ fontSize: 13 }}>{module.charAt(0).toUpperCase() + module.slice(1)}</Text>
                            </Row>
                            <Row justify="space-between" style={{ marginBottom: 8 }}>
                                <Text type="secondary" style={{ fontSize: 12 }}>Action</Text>
                                <Tag
                                    color={signAction === 'approved' ? 'green' : signAction === 'rejected' ? 'red' : 'orange'}
                                    style={{ fontSize: 11, fontWeight: 600, padding: '2px 8px' }}
                                >
                                    {signAction === 'approved' ? '✅ Approve' : signAction === 'rejected' ? '❌ Reject' : '🔄 Revert'}
                                </Tag>
                            </Row>
                            <Row justify="space-between" style={{ marginBottom: 8 }}>
                                <Text type="secondary" style={{ fontSize: 12 }}>Signature ID</Text>
                                <Text style={{ fontSize: 12, fontFamily: "monospace" }}>{signatureId}</Text>
                            </Row>
                            <Row justify="space-between" style={{ marginBottom: 0 }}>
                                <Text type="secondary" style={{ fontSize: 12 }}>Signatory</Text>
                                <Text strong style={{ fontSize: 13 }}>{selectedPersonDetails?.name || '—'}</Text>
                            </Row>
                        </Space>
                    </Card>
                </Col>

                {/* Right Column: Timer + Confirm */}
                <Col span={9}>
                    <Card
                        title={
                            <Space>
                                <ClockCircleOutlined style={{ color: timerColor }} />
                                <Text strong>Time Remaining</Text>
                            </Space>
                        }
                        size="small"
                        style={{
                            borderRadius: 10,
                            marginBottom: 16,
                            textAlign: "center",
                        }}
                        styles={{ body: { padding: "20px 24px" } }}
                    >
                        <div style={{ fontSize: 42, fontWeight: 700, fontFamily: "monospace", color: timerColor, letterSpacing: 2 }}>
                            {formatTime(timeLeft)}
                        </div>
                        <Progress
                            percent={timerProgress}
                            showInfo={false}
                            strokeColor={timerColor}
                            trailColor="#f0f0f0"
                            style={{ marginTop: 12, marginBottom: 4 }}
                        />
                        <Text type="secondary" style={{ fontSize: 12 }}>
                            {timeLeft > 120
                                ? 'Sufficient time remaining'
                                : timeLeft > 60
                                    ? 'Hurry up! Time is running out'
                                    : 'Expiring soon!'}
                        </Text>
                    </Card>

                    {/* Signatory Info */}
                    {selectedPersonDetails && (
                        <Card
                            size="small"
                            style={{
                                borderRadius: 10,
                                background: "linear-gradient(135deg, rgba(82,196,26,0.08), rgba(82,196,26,0.02))",
                                border: "1px solid rgba(82,196,26,0.2)",
                            }}
                            styles={{ body: { padding: "12px 16px" } }}
                        >
                            <Space>
                                <Avatar
                                    size={32}
                                    icon={<UserOutlined />}
                                    style={{ backgroundColor: "#52c41a" }}
                                />
                                <div>
                                    <Text style={{ fontSize: 12, color: "#52c41a", display: "block" }}>
                                        Signing as:
                                    </Text>
                                    <Text strong style={{ fontSize: 13 }}>
                                        {selectedPersonDetails.name}
                                    </Text>
                                    <Tag
                                        color="green"
                                        style={{ fontSize: 10, lineHeight: "16px", padding: "0 6px", marginLeft: 6 }}
                                    >
                                        Lvl {selectedPersonDetails.authorizationLevel}
                                    </Tag>
                                </div>
                            </Space>
                        </Card>
                    )}
                </Col>
            </Row>

            {/* Action Buttons */}
            <div
                style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    borderTop: "1px solid rgba(255,255,255,0.06)",
                    paddingTop: 20,
                    marginTop: 16,
                }}
            >
                <div>
                    <Text type="secondary" style={{ fontSize: 12 }}>
                        <ExclamationCircleOutlined style={{ marginRight: 6 }} />
                        Confirmation required within {formatTime(timeLeft)}
                    </Text>
                </div>
                <Space size={12}>
                    <Button
                        onClick={handleCancelPending}
                        disabled={confirming}
                        size="large"
                        icon={<CloseCircleOutlined />}
                        style={{
                            borderRadius: 8,
                            height: 42,
                            paddingInline: 24,
                            fontWeight: 500,
                        }}
                    >
                        Cancel
                    </Button>
                    <Button
                        type="primary"
                        icon={<CheckCircleOutlined />}
                        onClick={handleConfirm}
                        loading={confirming}
                        size="large"
                        style={{
                            borderRadius: 8,
                            height: 42,
                            paddingInline: 28,
                            fontWeight: 600,
                            boxShadow: "0 4px 12px rgba(82, 196, 26, 0.35)",
                            background: "linear-gradient(135deg, #52c41a, #389e0d)",
                            border: "none",
                        }}
                    >
                        {confirming ? "Confirming..." : "Confirm Signature"}
                    </Button>
                </Space>
            </div>
        </div>
    );
}