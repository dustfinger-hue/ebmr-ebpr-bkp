"use client";

import { Spin, Typography } from "antd";

const { Text } = Typography;

export default function LoadingState() {
    return (
        <div style={{ textAlign: "center", padding: "80px 0" }}>
            <Spin size="large" />
            <div style={{ marginTop: 20 }}>
                <Text type="secondary" style={{ fontSize: 15 }}>
                    Checking signing configuration...
                </Text>
            </div>
        </div>
    );
}