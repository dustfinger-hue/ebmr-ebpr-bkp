"use client";

import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { Form } from "antd";
import { VerifyResponse, SignResponse, SigningState, AuthorizedPerson, PageMessage, SignAction } from "./types";

interface SigningContextType {
    // Module/Document info (from Provider props)
    module: string;
    data: any;
    documentId?: string;
    schemaTitle?: string;

    // Modal state
    signingModalOpen: boolean;
    setSigningModalOpen: (open: boolean) => void;

    // Verification state
    verifying: boolean;
    hierarchyData: VerifyResponse["data"] | null;
    verifyError: string | null;

    // Document signing state
    signedByUserIds: string[];
    currentSequence: number;

    // Form state
    signAction: SignAction;
    setSignAction: (action: SignAction) => void;
    selectedPerson: string | undefined;
    setSelectedPerson: (id: string | undefined) => void;
    employeeId: string;
    setEmployeeId: (val: string) => void;
    password: string;
    setPassword: (val: string) => void;
    remarks: string;
    setRemarks: (val: string) => void;

    // Signing state
    signing: boolean;
    signingState: SigningState;
    setSigningState: (state: SigningState) => void;
    signatureHash: string;
    signatureId: string;
    expiresAt: Date | null;
    confirming: boolean;

    // Selected person details
    selectedPersonDetails: AuthorizedPerson | undefined;

    // Inline page message (replaces toast notifications)
    pageMessage: PageMessage | null;
    setPageMessage: (msg: PageMessage | null) => void;

    // Functions
    checkForSigningHierarchy: () => Promise<void>;
    handleSign: () => Promise<void>;
    handleConfirm: () => Promise<void>;
    handleCancelPending: () => void;
    handleExpire: () => void;
    resetForm: () => void;
    form: any;
}

const SigningContext = createContext<SigningContextType | null>(null);

export function useSigningContext() {
    const context = useContext(SigningContext);
    if (!context) {
        throw new Error("useSigningContext must be used within SigningProvider");
    }
    return context;
}

interface SigningProviderProps {
    children: ReactNode;
    module: string;
    data: any;
    documentId?: string;
    schemaTitle?: string;
    onSignComplete?: () => void;
    apiUrl: string;
}

export function SigningProvider({ children, module, data, documentId, schemaTitle, onSignComplete, apiUrl }: SigningProviderProps) {
    const [signingModalOpen, setSigningModalOpen] = useState(false);
    const [verifying, setVerifying] = useState(true);
    const [hierarchyData, setHierarchyData] = useState<VerifyResponse["data"] | null>(null);
    const [verifyError, setVerifyError] = useState<string | null>(null);
    const [signedByUserIds, setSignedByUserIds] = useState<string[]>([]);
    const [currentSequence, setCurrentSequence] = useState<number>(0);
    const [signAction, setSignAction] = useState<SignAction>('approved');
    const [selectedPerson, setSelectedPerson] = useState<string | undefined>(undefined);
    const [employeeId, setEmployeeId] = useState("");
    const [password, setPassword] = useState("");
    const [remarks, setRemarks] = useState("");
    const [signing, setSigning] = useState(false);
    const [signingState, setSigningState] = useState<SigningState>('form');
    const [signatureHash, setSignatureHash] = useState<string>('');
    const [signatureId, setSignatureId] = useState<string>('');
    const [expiresAt, setExpiresAt] = useState<Date | null>(null);
    const [confirming, setConfirming] = useState(false);
    const [signingData, setSigningData] = useState<SignResponse["data"] | null>(null);

    // Inline page message state (replaces toast notifications)
    const [pageMessage, setPageMessage] = useState<PageMessage | null>(null);

    const [form] = Form.useForm();

    // Reset form state when modal opens
    useEffect(() => {
        if (signingModalOpen) {
            resetForm();
            checkForSigningHierarchy();
        }
    }, [signingModalOpen]);

    const resetForm = () => {
        setVerifying(true);
        setHierarchyData(null);
        setVerifyError(null);
        setSignedByUserIds([]);
        setCurrentSequence(0);
        setSignAction('approved');
        setSelectedPerson(undefined);
        setEmployeeId("");
        setPassword("");
        setRemarks("");
        setSigning(false);
        setSigningState('form');
        setSignatureHash('');
        setSignatureId('');
        setExpiresAt(null);
        setConfirming(false);
        setPageMessage(null);
        form.resetFields();
    };

    const checkForSigningHierarchy = async () => {
        setVerifying(true);
        setVerifyError(null);
        try {
            let url = `/api/user/digital-signing/verify?module=${module}`;
            if (documentId && schemaTitle) {
                url += `&documentId=${documentId}&schemaTitle=${schemaTitle}`;
            }

            const response = await fetch(url, {
                method: "GET",
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
            });

            const resData: VerifyResponse = await response.json();

            if (resData.success && resData.data) {
                setHierarchyData(resData.data);
                setSignedByUserIds(resData.data.signedByUserIds || []);
                setCurrentSequence(resData.data.currentSequence || 0);

                // Auto-select based on current sequence
                const nextSequence = (resData.data.currentSequence || 0) + 1;
                const nextPerson = resData.data.authorizedPersons.find(
                    (p) => p.authorizationSequence === nextSequence
                );
                if (nextPerson) {
                    setSelectedPerson(nextPerson.userId);
                } else if (resData.data.authorizedPersons.length > 0) {
                    setSelectedPerson(resData.data.authorizedPersons[0].userId);
                }
            } else {
                setVerifyError(resData.message || "No signing hierarchy found for this module.");
            }
        } catch (error) {
            console.error("Error checking signing hierarchy:", error);
            setVerifyError("An error occurred while checking signing permissions.");
        } finally {
            setVerifying(false);
        }
    };

    const handleSign = async () => {
        setPageMessage(null);
        if (!selectedPerson) {
            setPageMessage({ type: 'error', message: "Please select a signatory." });
            return;
        }
        if (!employeeId.trim()) {
            setPageMessage({ type: 'error', message: "Please enter Employee ID." });
            return;
        }
        if (!password.trim()) {
            setPageMessage({ type: 'error', message: "Please enter password." });
            return;
        }

        setSigning(true);
        try {
            const response = await fetch("/api/user/digital-signing/sign", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
                body: JSON.stringify({
                    selectedPerson,
                    employeeId: employeeId.trim(),
                    password: password.trim(),
                    remarks: remarks.trim(),
                    module,
                    documentId: documentId || undefined,
                    schemaTitle: schemaTitle || undefined,
                    signAction,
                }),
            });

            const resData: SignResponse = await response.json();

            if (resData.success && resData.data) {
                setSignatureHash(resData.data.signatureHash);
                setSignatureId(resData.data.signatureId);
                setExpiresAt(new Date(resData.data.expiresAt));
                setSigningState('pending');
                setSigningData(resData.data);
                setPageMessage({ type: 'success', message: resData.message || "Signature pending confirmation. Please confirm within 5 minutes." });
            } else {
                setPageMessage({ type: 'error', message: resData.message || "Failed to sign document." });
            }
        } catch (error) {
            console.error("Error signing document:", error);
            setPageMessage({ type: 'error', message: "An error occurred while signing. Please try again." });
        } finally {
            setSigning(false);
        }
    };

    const handleConfirm = async () => {
        setConfirming(true);
        try {
            const payload = {
                signingData,
                fullTemplateData: data,
                module,
                documentId,
                schemaTitle
            }
            console.log
                ("Payload for confirmation:", payload);

            const response = await fetch(apiUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
                body: JSON.stringify(payload),
            });

            const resData = await response.json();

            if (resData.success) {
                setPageMessage({ type: 'success', message: resData.message || "Signature confirmed successfully." });
            } else {
                setPageMessage({ type: 'error', message: resData.message || "Failed to confirm signature." });
                return;
            }

            await new Promise(resolve => setTimeout(resolve, 500));

            setPageMessage(null);
            setSigningState('completed');

            setTimeout(() => {
                setSigningModalOpen(false);
                if (onSignComplete) {
                    onSignComplete();
                }
            }, 800);
        } catch (error) {
            console.error("Error confirming signature:", error);
            setPageMessage({ type: 'error', message: 'Failed to confirm signature.' });
        } finally {
            setConfirming(false);
        }
    };

    const handleCancelPending = () => {
        setSigningState('form');
        setPageMessage({ type: 'info', message: 'Signature request cancelled.' });
    };

    const handleExpire = () => {
        setSigningState('form');
        setPageMessage({ type: 'warning', message: 'Signature request has expired. Please try again.' });
    };

    const selectedPersonDetails = hierarchyData?.authorizedPersons.find(
        (p) => p.userId === selectedPerson
    );

    const value: SigningContextType = {
        module,
        data,
        documentId,
        schemaTitle,
        signingModalOpen,
        setSigningModalOpen,
        verifying,
        hierarchyData,
        verifyError,
        signedByUserIds,
        currentSequence,
        signAction,
        setSignAction,
        selectedPerson,
        setSelectedPerson,
        employeeId,
        setEmployeeId,
        password,
        setPassword,
        remarks,
        setRemarks,
        signing,
        signingState,
        setSigningState,
        signatureHash,
        signatureId,
        expiresAt,
        confirming,
        selectedPersonDetails,
        pageMessage,
        setPageMessage,
        checkForSigningHierarchy,
        handleSign,
        handleConfirm,
        handleCancelPending,
        handleExpire,
        resetForm,
        form,
    };

    return (
        <SigningContext.Provider value={value}>
            {children}
        </SigningContext.Provider>
    );
}