"use client";

import { Alert, Form, Input, Select, Button, Row, Col, Space, Typography, Radio } from "antd";
import {
    UserSwitchOutlined,
    IdcardOutlined,
    LockOutlined,
    CommentOutlined,
    SafetyCertificateOutlined,
    ClockCircleOutlined,
    VerifiedOutlined,
    CheckCircleOutlined,
    CloseCircleOutlined,
    RollbackOutlined,
} from "@ant-design/icons";
import { useSigningContext } from "./SigningContext";
import PageMessageAlert from "./PageMessageAlert";

const { Text } = Typography;

export default function SigningForm() {
    const {
        signAction,
        setSignAction,
        hierarchyData,
        selectedPerson,
        setSelectedPerson,
        employeeId,
        setEmployeeId,
        password,
        setPassword,
        remarks,
        setRemarks,
        signing,
        handleSign,
        setSigningModalOpen,
        form,
    } = useSigningContext();

    const authorizedPersons = hierarchyData?.authorizedPersons || [];

    const onSign = () => {
        handleSign();
    };

    return (
        <Form form={form} layout="vertical" size="middle">
            <PageMessageAlert />

            {/* Regulatory Compliance Notice */}
            <Alert
                title={
                    <Space>
                        <VerifiedOutlined style={{ color: '#1677ff' }} />
                        <Text strong style={{ fontSize: 12 }}>Regulatory Compliance</Text>
                    </Space>
                }
                description={
                    <Text style={{ fontSize: 11 }}>
                        By signing, you acknowledge this constitutes a legally binding electronic signature under applicable regulations including <strong>21 CFR Part 11, EU Annex 11 & GxP guidelines</strong>. This action will be recorded in the audit trail and is subject to regulatory review.
                    </Text>
                }
                type="info"
                showIcon={false}
                style={{
                    borderRadius: 8,
                    marginBottom: 20,
                    border: "1px solid #bae0ff",
                }}
            />

            {/* Action Selection */}
            <Form.Item
                label={
                    <Text style={{ fontSize: 13, fontWeight: 500 }}>
                        Action
                    </Text>
                }
                name="signAction"
                rules={[{ required: true, message: "Please select an action" }]}
                style={{ marginBottom: 20 }}
            >
                <Radio.Group
                    value={signAction}
                    onChange={(e) => setSignAction(e.target.value)}
                    optionType="button"
                    buttonStyle="solid"
                    size="large"
                    style={{ width: '100%', display: 'flex', gap: 8 }}
                >
                    <Radio.Button
                        value="approved"
                        style={{
                            flex: 1,
                            textAlign: 'center',
                            height: 42,
                            lineHeight: '42px',
                            borderRadius: 8,
                            border: signAction === 'approved' ? '2px solid #52c41a' : '1px solid #d9d9d9',
                            color: signAction === 'approved' ? '#52c41a' : undefined,
                            fontWeight: signAction === 'approved' ? 600 : 400,
                        }}
                    >
                        <CheckCircleOutlined style={{ marginRight: 4 }} /> Approve
                    </Radio.Button>
                    <Radio.Button
                        value="rejected"
                        style={{
                            flex: 1,
                            textAlign: 'center',
                            height: 42,
                            lineHeight: '42px',
                            borderRadius: 8,
                            border: signAction === 'rejected' ? '2px solid #ff4d4f' : '1px solid #d9d9d9',
                            color: signAction === 'rejected' ? '#ff4d4f' : undefined,
                            fontWeight: signAction === 'rejected' ? 600 : 400,
                        }}
                    >
                        <CloseCircleOutlined style={{ marginRight: 4 }} /> Reject
                    </Radio.Button>
                    <Radio.Button
                        value="reverted"
                        style={{
                            flex: 1,
                            textAlign: 'center',
                            height: 42,
                            lineHeight: '42px',
                            borderRadius: 8,
                            border: signAction === 'reverted' ? '2px solid #faad14' : '1px solid #d9d9d9',
                            color: signAction === 'reverted' ? '#faad14' : undefined,
                            fontWeight: signAction === 'reverted' ? 600 : 400,
                        }}
                    >
                        <RollbackOutlined style={{ marginRight: 4 }} /> Revert
                    </Radio.Button>
                </Radio.Group>
            </Form.Item>

            <Row gutter={24}>
                <Col span={13}>
                    <Form.Item
                        label={
                            <Text style={{ fontSize: 13, fontWeight: 500 }}>
                                <UserSwitchOutlined style={{ marginRight: 6 }} />
                                Sign as
                            </Text>
                        }
                        name="signatory"
                        rules={[{ required: true, message: "Please select a signatory" }]}
                    >
                        <Select
                            placeholder="Select authorized person"
                            value={selectedPerson}
                            onChange={(value) => setSelectedPerson(value)}
                            options={authorizedPersons.map((p) => ({
                                label: (
                                    <>
                                        <Text strong>{p.name}</Text>
                                        <Text type="secondary" style={{ marginLeft: 6, fontSize: 11 }}>
                                            ({p.designation})
                                        </Text>
                                    </>
                                ),
                                value: p.userId,
                            }))}
                            style={{ width: "100%" }}
                            size="large"
                            dropdownStyle={{ borderRadius: 8 }}
                        />
                    </Form.Item>

                    <Form.Item
                        label={
                            <Text style={{ fontSize: 13, fontWeight: 500 }}>
                                <IdcardOutlined style={{ marginRight: 6 }} />
                                Employee ID
                            </Text>
                        }
                        name="employeeId"
                        rules={[
                            { required: true, message: "Please enter Employee ID" },
                        ]}
                    >
                        <Input
                            prefix={<IdcardOutlined style={{ color: "#bfbfbf" }} />}
                            placeholder="Enter employee ID"
                            value={employeeId}
                            onChange={(e) => setEmployeeId(e.target.value)}
                            size="large"
                            style={{ borderRadius: 8 }}
                        />
                    </Form.Item>
                    <Form.Item
                        label={
                            <Text style={{ fontSize: 13, fontWeight: 500 }}>
                                <LockOutlined style={{ marginRight: 6 }} />
                                Password
                            </Text>
                        }
                        name="password"
                        rules={[{ required: true, message: "Please enter password" }]}
                    >
                        <Input.Password
                            prefix={<LockOutlined style={{ color: "#bfbfbf" }} />}
                            placeholder="Enter password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            size="large"
                            style={{ borderRadius: 8 }}
                        />
                    </Form.Item>
                </Col>

                <Col span={11}>
                    <Form.Item
                        label={
                            <Text style={{ fontSize: 13, fontWeight: 500 }}>
                                <CommentOutlined style={{ marginRight: 6 }} />
                                Remarks
                                {signAction !== 'approved' && <Text type="danger" style={{ fontWeight: 400 }}> *</Text>}
                            </Text>
                        }
                        name="remarks"
                        rules={[
                            { required: true, message: "Please enter remarks" },
                            { 
                                required: signAction !== 'approved', 
                                message: "Please provide reason for rejection or revert" 
                            },
                        ]}
                    >
                        <Input.TextArea
                            placeholder="Any additional remarks..."
                            rows={4}
                            value={remarks}
                            onChange={(e) => setRemarks(e.target.value)}
                            style={{ borderRadius: 8, resize: "none" }}
                        />
                    </Form.Item>
                </Col>
            </Row>

            {/* Action Buttons */}
            <div
                style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    borderTop: "1px solid rgba(255,255,255,0.06)",
                    paddingTop: 20,
                    marginTop: 4,
                }}
            >
                <div>
                    <Text type="secondary" style={{ fontSize: 12 }}>
                        <ClockCircleOutlined style={{ marginRight: 6 }} />
                        This action will be recorded in the audit trail.
                    </Text>
                </div>
                <Space size={12}>
                    <Button
                        onClick={() => setSigningModalOpen(false)}
                        disabled={signing}
                        size="large"
                        style={{
                            borderRadius: 8,
                            height: 42,
                            paddingInline: 24,
                            fontWeight: 500,
                        }}
                    >
                        Cancel
                    </Button>
                    <Button
                        type="primary"
                        icon={<SafetyCertificateOutlined />}
                        onClick={onSign}
                        loading={signing}
                        disabled={!selectedPerson || !employeeId || !password}
                        size="large"
                        style={{
                            borderRadius: 8,
                            height: 42,
                            paddingInline: 28,
                            fontWeight: 600,
                            boxShadow: signAction === 'approved' 
                                ? "0 4px 12px rgba(24, 144, 255, 0.35)"
                                : signAction === 'rejected'
                                    ? "0 4px 12px rgba(255, 77, 79, 0.35)"
                                    : "0 4px 12px rgba(250, 173, 20, 0.35)",
                            background:
                                !selectedPerson || !employeeId || !password
                                    ? undefined
                                    : signAction === 'approved'
                                        ? "linear-gradient(135deg, #1677ff, #0958d9)"
                                        : signAction === 'rejected'
                                            ? "linear-gradient(135deg, #ff4d4f, #cf1322)"
                                            : "linear-gradient(135deg, #faad14, #d48806)",
                            border: "none",
                        }}
                    >
                        {signing 
                            ? "Signing..." 
                            : `Sign to ${signAction === 'approved' ? 'Approve' : signAction === 'rejected' ? 'Reject' : 'Revert'}`
                        }
                    </Button>
                </Space>
            </div>
        </Form>
    );
}