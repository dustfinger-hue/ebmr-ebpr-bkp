"use client";

import { Alert } from "antd";
import { useSigningContext } from "./SigningContext";

export default function PageMessageAlert() {
    const { pageMessage, setPageMessage } = useSigningContext();

    if (!pageMessage) return null;

    return (
        <div style={{ marginBottom: 0 }}>
            <Alert
                title={pageMessage.message}
                type={pageMessage.type}
                showIcon
                closable
                onClose={() => setPageMessage(null)}
                style={{
                    borderRadius: 8,
                    marginBottom: 16,
                }}
            />
        </div>
    );
}
