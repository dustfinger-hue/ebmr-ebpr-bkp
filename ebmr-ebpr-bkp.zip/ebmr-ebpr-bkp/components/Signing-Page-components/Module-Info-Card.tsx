"use client";

import { Card, Row, Col, Space, Typography, Tag } from "antd";
import { SafetyCertificateOutlined } from "@ant-design/icons";
import { useSigningContext } from "./SigningContext";

const { Text } = Typography;

export default function ModuleInfoCard() {
    const { hierarchyData } = useSigningContext();
    const module = hierarchyData?.module || "";
    const signRequired = hierarchyData?.signRequired || 0;

    return (
        <Card
            style={{
                borderRadius: 10,
                marginBottom: 24,
            }}
            styles={{ body: { padding: "14px 20px" } }}
        >
            <Row align="middle" justify="space-between">
                <Col>
                    <Space size={12}>
                        <div
                            style={{
                                width: 36,
                                height: 36,
                                borderRadius: 8,
                                background: "linear-gradient(135deg, #e6f7ff, #bae7ff)",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                            }}
                        >
                            <SafetyCertificateOutlined style={{ color: "#1890ff", fontSize: 18 }} />
                        </div>
                        <div>
                            <Text type="secondary" style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: 0.5 }}>
                                Module
                            </Text>
                            <div>
                                <Text strong style={{ fontSize: 15 }}>{module}</Text>
                            </div>
                        </div>
                    </Space>
                </Col>
                <Col>
                    <Tag
                        color="blue"
                        style={{
                            borderRadius: 20,
                            paddingInline: 16,
                            paddingBlock: 3,
                            fontSize: 13,
                            fontWeight: 600,
                            marginRight: 0,
                        }}
                    >
                        {signRequired} Signature{signRequired > 1 ? "s" : ""} Required
                    </Tag>
                </Col>
            </Row>
        </Card>
    );
}