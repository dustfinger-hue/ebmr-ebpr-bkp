"use client";

import { Avatar, Typography } from "antd";
import { CheckCircleOutlined } from "@ant-design/icons";
import { useSigningContext } from "./SigningContext";

const { Title, Text } = Typography;

export default function CompletedState() {
    const { signatureHash } = useSigningContext();

    return (
        <div style={{ padding: "60px 32px", textAlign: "center" }}>
            <Avatar
                size={80}
                icon={<CheckCircleOutlined />}
                style={{
                    backgroundColor: "rgba(82, 196, 26, 0.1)",
                    color: "#52c41a",
                    marginBottom: 20,
                }}
            />
            <Title level={3} style={{ margin: 0, marginBottom: 8 }}>
                Signature Confirmed!
            </Title>
            <Text type="secondary" style={{ fontSize: 15, display: "block", marginBottom: 24 }}>
                Document has been signed and authorized successfully.
            </Text>
            {signatureHash && (
                <div style={{ maxWidth: 500, margin: "0 auto" }}>
                    <Text type="secondary" style={{ fontSize: 12 }}>Signature Hash</Text>
                    <div
                        style={{
                            // background: "#f5f5f5",
                            borderRadius: 8,
                            padding: "10px 16px",
                            fontFamily: "monospace",
                            fontSize: 12,
                            wordBreak: "break-all",
                            border: "1px solid #d9d9d9",
                            marginTop: 4,
                        }}
                    >
                        {signatureHash}
                    </div>
                </div>
            )}
        </div>
    );
}