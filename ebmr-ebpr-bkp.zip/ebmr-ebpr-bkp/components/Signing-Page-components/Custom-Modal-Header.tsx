"use client";

import { Space, Avatar, Badge, Typography, Tag, Tooltip } from "antd";
import {
    CheckCircleOutlined,
    ClockCircleOutlined,
    VerifiedOutlined,
    SafetyCertificateOutlined,
    InfoCircleOutlined,
} from "@ant-design/icons";
import { useSigningContext } from "./SigningContext";

const { Title, Text } = Typography;

export default function CustomModalHeader() {
    const { signingState, hierarchyData } = useSigningContext();
    const signRequired = hierarchyData?.signRequired;

    const getHeaderGradient = () => {
        switch (signingState) {
            case 'pending':
                return "linear-gradient(135deg, #1a1a2e 0%, #e8a317 50%, #0f3460 100%)";
            case 'completed':
                return "linear-gradient(135deg, #1a1a2e 0%, #389e0d 50%, #0f3460 100%)";
            default:
                return "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)";
        }
    };

    const getAvatarIcon = () => {
        switch (signingState) {
            case 'completed':
                return <CheckCircleOutlined />;
            case 'pending':
                return <ClockCircleOutlined />;
            default:
                return <SafetyCertificateOutlined />;
        }
    };

    const getBadgeIcon = () => {
        switch (signingState) {
            case 'completed':
                return <CheckCircleOutlined style={{ color: "#52c41a", fontSize: 14 }} />;
            case 'pending':
                return <ClockCircleOutlined style={{ color: "#faad14", fontSize: 14 }} />;
            default:
                return <VerifiedOutlined style={{ color: "#52c41a", fontSize: 14 }} />;
        }
    };

    const getAvatarColor = () => {
        switch (signingState) {
            case 'completed':
                return "#52c41a";
            case 'pending':
                return "#faad14";
            default:
                return "#1890ff";
        }
    };

    const getAvatarBorder = () => {
        switch (signingState) {
            case 'completed':
                return "2px solid rgba(82, 196, 26, 0.3)";
            case 'pending':
                return "2px solid rgba(250, 173, 20, 0.3)";
            default:
                return "2px solid rgba(24, 144, 255, 0.3)";
        }
    };

    const getTitle = () => {
        switch (signingState) {
            case 'pending':
                return 'Signature Pending Confirmation';
            case 'completed':
                return 'Signature Complete';
            default:
                return 'Digital Signature';
        }
    };

    const getSubtitle = () => {
        switch (signingState) {
            case 'pending':
                return 'Please confirm this signature to finalize the authorization';
            case 'completed':
                return 'Document has been signed and authorized successfully';
            default:
                return 'Verify and authorize this document electronically';
        }
    };

    return (
        <div
            style={{
                background: getHeaderGradient(),
                padding: "28px 32px 24px",
                position: "relative",
                overflow: "hidden",
            }}
        >
            <div
                style={{
                    position: "absolute",
                    top: -60,
                    right: -60,
                    width: 180,
                    height: 180,
                    borderRadius: "50%",
                    background: "rgba(24, 144, 255, 0.08)",
                }}
            />
            <div
                style={{
                    position: "absolute",
                    bottom: -40,
                    left: -20,
                    width: 120,
                    height: 120,
                    borderRadius: "50%",
                    background: "rgba(82, 196, 26, 0.06)",
                }}
            />

            <Space size={16} align="start" style={{ position: "relative", zIndex: 1 }}>
                <Badge
                    count={getBadgeIcon()}
                    offset={[-4, 28]}
                >
                    <Avatar
                        size={52}
                        icon={getAvatarIcon()}
                        style={{
                            backgroundColor: "rgba(24, 144, 255, 0.2)",
                            color: getAvatarColor(),
                            border: getAvatarBorder(),
                            flexShrink: 0,
                        }}
                    />
                </Badge>
                <div>
                    <Title
                        level={4}
                        style={{
                            color: "#fff",
                            margin: 0,
                            fontWeight: 700,
                            fontSize: 20,
                            letterSpacing: 0.3,
                        }}
                    >
                        {getTitle()}
                    </Title>
                    <Text style={{ color: "rgba(255,255,255,0.65)", fontSize: 13, marginTop: 4, display: "block" }}>
                        {getSubtitle()}
                    </Text>
                </div>
            </Space>

            {/* Regulatory Compliance Badge - always visible */}
            <div style={{ position: "absolute", top: 16, right: 32, zIndex: 1, display: "flex", gap: 8, alignItems: "center" }}>
                <Tooltip title="This signing process complies with 21 CFR Part 11, EU Annex 11 & GxP regulations">
                    <Tag
                        icon={<SafetyCertificateOutlined />}
                        color="green"
                        style={{
                            borderRadius: 4,
                            fontWeight: 600,
                            fontSize: 10,
                            lineHeight: "18px",
                            padding: "0 8px",
                            cursor: "pointer",
                            border: "1px solid rgba(82, 196, 26, 0.4)",
                        }}
                    >
                        21 CFR Part 11 Compliant
                    </Tag>
                </Tooltip>
                {signingState === 'form' && signRequired !== undefined && (
                    <Tag
                        icon={<InfoCircleOutlined />}
                        color="rgba(255,255,255,0.15)"
                        style={{
                            border: "1px solid rgba(255,255,255,0.15)",
                            color: "rgba(255,255,255,0.8)",
                            borderRadius: 4,
                            fontWeight: 500,
                        }}
                    >
                        Required: {signRequired || "—"}
                    </Tag>
                )}
            </div>
        </div>
    );
}