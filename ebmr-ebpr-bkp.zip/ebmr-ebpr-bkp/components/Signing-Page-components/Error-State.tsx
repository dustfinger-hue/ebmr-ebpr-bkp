"use client";

import { Alert, Button, Card, Space, Typography } from "antd";
import { CloseCircleOutlined, InfoCircleOutlined } from "@ant-design/icons";
import { useSigningContext } from "./SigningContext";

const { Text } = Typography;

export default function ErrorState() {
    const { verifyError, setSigningModalOpen } = useSigningContext();

    return (
        <div style={{ padding: "32px 32px 24px" }}>
            <Alert
                message="Signing Configuration Not Found"
                description={verifyError}
                type="warning"
                showIcon
                icon={<CloseCircleOutlined />}
                style={{
                    borderRadius: 10,
                    border: "1px solid #ffe58f",
                    marginBottom: 20,
                }}
            />
            <Card
                style={{
                    borderRadius: 10,
                    marginBottom: 20,
                }}
                styles={{ body: { padding: "16px 20px" } }}
            >
                <Space>
                    <InfoCircleOutlined style={{ color: "#faad14", fontSize: 18 }} />
                    <Text>
                        No signing hierarchy has been configured. Please contact your
                        administrator to set up the signing hierarchy.
                    </Text>
                </Space>
            </Card>
            <div style={{ textAlign: "right" }}>
                <Button
                    onClick={() => setSigningModalOpen(false)}
                    type="primary"
                    size="middle"
                    style={{ borderRadius: 8, height: 40, paddingInline: 28 }}
                >
                    Close
                </Button>
            </div>
        </div>
    );
}