"use client";

import { Modal } from "antd";

import SignTriggerButton from "./Signing-Page-components/Sign-Trigger-Button";
import CustomModalHeader from "./Signing-Page-components/Custom-Modal-Header";
import LoadingState from "./Signing-Page-components/Loading-State";
import ErrorState from "./Signing-Page-components/Error-State";
import ModuleInfoCard from "./Signing-Page-components/Module-Info-Card";
import SignatoriesDisplay from "./Signing-Page-components/Signatories-Display";
import SigningForm from "./Signing-Page-components/Signing-Form";
import PendingConfirmation from "./Signing-Page-components/Pending-Confirmation";
import CompletedState from "./Signing-Page-components/Completed-State";
import { SigningProvider, useSigningContext } from "./Signing-Page-components/SigningContext";
import { SignButtonProps } from "./Signing-Page-components/types";

function SigningModalContent() {
    const {
        signingModalOpen,
        setSigningModalOpen,
        verifying,
        verifyError,
        hierarchyData,
        signingState,
        signing,
    } = useSigningContext();

    return (
        <Modal
            open={signingModalOpen}
            onCancel={() => {
                // Prevent closing while signing is in progress or pending confirmation
                if (signing || signingState === 'pending') return;
                setSigningModalOpen(false);
            }}
            footer={null}
            width={960}
            destroyOnHidden
            maskClosable={!signing && signingState !== 'pending'}
            style={{ top: 40 }}
            className="digital-signing-modal"
            styles={{
                body: {
                    padding: 0,
                    borderRadius: 12,
                    overflow: "hidden",
                },
                header: {
                    display: "none",
                },
                mask: {
                    backdropFilter: "blur(4px)",
                },
            }}
        >
            {/* ── Custom Header ── */}
            <CustomModalHeader />

            {/* ── LOADING STATE ── */}
            {verifying && <LoadingState />}

            {/* ── NO HIERARCHY STATE ❌ ── */}
            {!verifying && verifyError && <ErrorState />}

            {/* ── HIERARCHY FOUND ✅ ── */}
            {!verifying && !verifyError && hierarchyData && signingState === 'form' && (
                <div style={{ padding: "24px 32px 28px" }}>
                    <ModuleInfoCard />
                    <SignatoriesDisplay />
                    <div style={{ borderTop: "1px solid rgba(255,255,255,0.06)", margin: "4px 0 20px" }} />
                    <SigningForm />
                </div>
            )}

            {/* ── PENDING CONFIRMATION STATE ── */}
            {signingState === 'pending' && <PendingConfirmation />}

            {/* ── COMPLETED STATE ── */}
            {signingState === 'completed' && <CompletedState />}
        </Modal>
    );
}

export default function SignButton(signProps: SignButtonProps) {
    return (
        <SigningProvider
            module={signProps.module}
            data={signProps.data}
            documentId={signProps.documentId}
            schemaTitle={signProps.schemaTitle}
            onSignComplete={signProps.onSignComplete}
            apiUrl={signProps.apiUrl}
        >
            <SignTriggerButton />
            <SigningModalContent />
        </SigningProvider>
    );
}