import mongoose from "mongoose";
import MaterialMaster from "../lib/models/MaterialMaster";

// MongoDB URI
const MONGODB_URI = process.env.MONGODB_URI || "mongodb+srv://abdulcodeat29:Alohomora1234@bmr-bpr.g7gbhd9.mongodb.net/ebmpr?retryWrites=true&w=majority&appName=bmr-bpr";

const materialData = [
  // Raw Materials (10)
  {
    materialName: "Microcrystalline Cellulose",
    shortName: "MCC",
    description: "Direct compression excipient used as binder and filler in tablet formulation",
    category: "Excipient",
    materialCode: "MAT-RAW-001",
    type: "Raw Material",
    storageCondition: ["Ambient (15-25°C)", "Protect From Moisture"],
    unitOfMeasurement: "kg",
    humiditySensitive: true,
    heatSensitive: false,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "Lactose Monohydrate",
    shortName: "LAC",
    description: "Common diluent and carrier in pharmaceutical formulations",
    category: "Excipient",
    materialCode: "MAT-RAW-002",
    type: "Raw Material",
    storageCondition: ["Ambient (15-25°C)", "Protect From Moisture", "Desiccated"],
    unitOfMeasurement: "kg",
    humiditySensitive: true,
    heatSensitive: false,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "Magnesium Stearate",
    shortName: "MGST",
    description: "Lubricant used in tablet and capsule manufacturing",
    category: "Excipient",
    materialCode: "MAT-RAW-003",
    type: "Raw Material",
    storageCondition: ["Ambient (15-25°C)", "Protect From Moisture"],
    unitOfMeasurement: "kg",
    humiditySensitive: true,
    heatSensitive: false,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "Crospovidone",
    shortName: "CPVP",
    description: "Superdisintegrant used in immediate release tablets",
    category: "Excipient",
    materialCode: "MAT-RAW-004",
    type: "Raw Material",
    storageCondition: ["Ambient (15-25°C)", "Protect From Moisture"],
    unitOfMeasurement: "kg",
    humiditySensitive: true,
    heatSensitive: false,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "Sodium Starch Glycolate",
    shortName: "SSG",
    description: "Superdisintegrant for tablet formulations",
    category: "Excipient",
    materialCode: "MAT-RAW-005",
    type: "Raw Material",
    storageCondition: ["Ambient (15-25°C)", "Protect From Moisture"],
    unitOfMeasurement: "kg",
    humiditySensitive: true,
    heatSensitive: false,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "Povidone (PVP K30)",
    shortName: "PVP",
    description: "Binder and film-forming agent in pharmaceutical formulations",
    category: "Excipient",
    materialCode: "MAT-RAW-006",
    type: "Raw Material",
    storageCondition: ["Ambient (15-25°C)", "Protect From Moisture"],
    unitOfMeasurement: "kg",
    humiditySensitive: true,
    heatSensitive: false,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "Titanium Dioxide",
    shortName: "TIO2",
    description: "Opacifier and whitening agent in tablet coatings",
    category: "Excipient",
    materialCode: "MAT-RAW-007",
    type: "Raw Material",
    storageCondition: ["Ambient (15-25°C)"],
    unitOfMeasurement: "kg",
    humiditySensitive: false,
    heatSensitive: false,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "Hydropropyl Methylcellulose (HPMC)",
    shortName: "HPMC",
    description: "Thickening agent, binder, and film former in pharmaceutical formulations",
    category: "Excipient",
    materialCode: "MAT-RAW-008",
    type: "Raw Material",
    storageCondition: ["Ambient (15-25°C)", "Protect From Moisture"],
    unitOfMeasurement: "kg",
    humiditySensitive: true,
    heatSensitive: false,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "Polyethylene Glycol 4000",
    shortName: "PEG4000",
    description: "Plasticizer and suppository base in pharmaceutical formulations",
    category: "Excipient",
    materialCode: "MAT-RAW-009",
    type: "Raw Material",
    storageCondition: ["Ambient (15-25°C)"],
    unitOfMeasurement: "kg",
    humiditySensitive: false,
    heatSensitive: false,
    lightSensitive: false,
    flammable: true,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "Colloidal Silicon Dioxide",
    shortName: "CSD",
    description: "Glidant to improve powder flow in tablet manufacturing",
    category: "Excipient",
    materialCode: "MAT-RAW-010",
    type: "Raw Material",
    storageCondition: ["Ambient (15-25°C)", "Protect From Moisture"],
    unitOfMeasurement: "kg",
    humiditySensitive: true,
    heatSensitive: false,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },

  // API (Active Pharmaceutical Ingredients) (5)
  {
    materialName: "Paracetamol API",
    shortName: "PCT-API",
    description: "Active pharmaceutical ingredient for analgesic and antipyretic preparations",
    category: "API",
    materialCode: "MAT-API-001",
    type: "Active Pharmaceutical Ingredient",
    storageCondition: ["Ambient (15-25°C)", "Protect From Moisture"],
    unitOfMeasurement: "kg",
    humiditySensitive: true,
    heatSensitive: false,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "Amoxicillin Trihydrate API",
    shortName: "AMX-API",
    description: "Beta-lactam antibiotic API for antibacterial formulations",
    category: "API",
    materialCode: "MAT-API-002",
    type: "Active Pharmaceutical Ingredient",
    storageCondition: ["Ambient (15-25°C)", "Protect From Moisture"],
    unitOfMeasurement: "kg",
    humiditySensitive: true,
    heatSensitive: true,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "Metformin HCl API",
    shortName: "MET-API",
    description: "Biguanide class antidiabetic API",
    category: "API",
    materialCode: "MAT-API-003",
    type: "Active Pharmaceutical Ingredient",
    storageCondition: ["Ambient (15-25°C)", "Protect From Moisture"],
    unitOfMeasurement: "kg",
    humiditySensitive: true,
    heatSensitive: false,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "Omeprazole API",
    shortName: "OMP-API",
    description: "Proton pump inhibitor API for acid-related disorders",
    category: "API",
    materialCode: "MAT-API-004",
    type: "Active Pharmaceutical Ingredient",
    storageCondition: ["Ambient (15-25°C)", "Protect From Light", "Nitrogen Flushed"],
    unitOfMeasurement: "kg",
    humiditySensitive: true,
    heatSensitive: false,
    lightSensitive: true,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "Ibuprofen API",
    shortName: "IBU-API",
    description: "NSAID API for pain and inflammation",
    category: "API",
    materialCode: "MAT-API-005",
    type: "Active Pharmaceutical Ingredient",
    storageCondition: ["Ambient (15-25°C)", "Protect From Moisture"],
    unitOfMeasurement: "kg",
    humiditySensitive: true,
    heatSensitive: false,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },

  // Packaging Materials (5)
  {
    materialName: "PVC Blister Film",
    shortName: "PVC-BF",
    description: "Polyvinyl chloride film for blister packaging",
    category: "Packaging Material",
    materialCode: "MAT-PKG-001",
    type: "Packaging Material",
    storageCondition: ["Ambient (15-25°C)", "Protect From Heat"],
    unitOfMeasurement: "kg",
    humiditySensitive: false,
    heatSensitive: true,
    lightSensitive: false,
    flammable: true,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "Aluminum Foil",
    shortName: "ALU-FL",
    description: "Cold form aluminum foil for blister packaging",
    category: "Packaging Material",
    materialCode: "MAT-PKG-002",
    type: "Packaging Material",
    storageCondition: ["Ambient (15-25°C)", "Protect From Moisture"],
    unitOfMeasurement: "kg",
    humiditySensitive: true,
    heatSensitive: false,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "HDPE Bottle",
    shortName: "HDPE-BT",
    description: "High density polyethylene bottle for solid dosage forms",
    category: "Packaging Material",
    materialCode: "MAT-PKG-003",
    type: "Packaging Material",
    storageCondition: ["Ambient (15-25°C)"],
    unitOfMeasurement: "pcs",
    humiditySensitive: false,
    heatSensitive: false,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "Child Resistant Cap",
    shortName: "CRC",
    description: "Child resistant closure for pharmaceutical containers",
    category: "Packaging Material",
    materialCode: "MAT-PKG-004",
    type: "Packaging Material",
    storageCondition: ["Ambient (15-25°C)"],
    unitOfMeasurement: "pcs",
    humiditySensitive: false,
    heatSensitive: false,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
  {
    materialName: "Induction Sealing Wadder",
    shortName: "ISW",
    description: "Induction sealing wadder for tamper evident packaging",
    category: "Packaging Material",
    materialCode: "MAT-PKG-005",
    type: "Packaging Material",
    storageCondition: ["Ambient (15-25°C)", "Protect From Moisture"],
    unitOfMeasurement: "pcs",
    humiditySensitive: true,
    heatSensitive: false,
    lightSensitive: false,
    flammable: false,
    corrosive: false,
    oxidizing: false,
    status: "Active",
    createdBy: new mongoose.Types.ObjectId("699ae310bc8198861bd826d8"),
  },
];

async function seedMaterialMaster() {
  try {
    console.log("Connecting to MongoDB...");
    await mongoose.connect(MONGODB_URI);
    console.log("Connected to MongoDB");

    const existingCount = await MaterialMaster.countDocuments();
    console.log(`Existing material count: ${existingCount}`);

    if (existingCount > 0) {
      console.log("Clearing existing material data...");
      await MaterialMaster.deleteMany({});
    }

    console.log("Inserting seed data...");

    const insertedMaterials = await MaterialMaster.insertMany(materialData);
    console.log(`Successfully inserted ${insertedMaterials.length} material records`);

    console.log("\n=== Seed Data Summary ===");
    console.log(`Total records: ${insertedMaterials.length}`);

    const activeCount = insertedMaterials.filter(m => m.status === "Active").length;
    const inactiveCount = insertedMaterials.filter(m => m.status === "Inactive").length;
    console.log(`Active: ${activeCount}`);
    console.log(`Inactive: ${inactiveCount}`);

    const excipientCount = insertedMaterials.filter(m => m.category === "Excipient").length;
    const apiCount = insertedMaterials.filter(m => m.category === "API").length;
    const packagingCount = insertedMaterials.filter(m => m.category === "Packaging Material").length;
    console.log(`Excipients: ${excipientCount}`);
    console.log(`APIs: ${apiCount}`);
    console.log(`Packaging: ${packagingCount}`);

    console.log("\n=== Material List ===");
    insertedMaterials.forEach((material, index) => {
      console.log(`${index + 1}. ${material.materialName} (${material.category}) - ${material.status}`);
    });

    console.log("\nSeed data insertion completed successfully!");
  } catch (error) {
    console.error("Error seeding data:", error);
  } finally {
    await mongoose.disconnect();
    console.log("Disconnected from MongoDB");
    process.exit(0);
  }
}

seedMaterialMaster();
